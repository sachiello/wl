<?php
// admin/performance.php
session_start();
require __DIR__ . '/../../config/config.php';

// Güvenlik
if (!isset($_SESSION['admin_id']) && !isset($_SESSION['agent_id'])) {
    header('Location: admin_login.php');
    exit;
}

$pageTitle = 'Performans Analizi';
$activeNav = 'performance';

// --- TARİH FİLTRESİ ---
$range = $_GET['range'] ?? '7d'; 
$startDate = date('Y-m-d');
$endDate   = date('Y-m-d');
$periodTitle = "Son 7 Gün";

if ($range === 'today') {
    $startDate = date('Y-m-d');
    $periodTitle = "Bugün";
} elseif ($range === 'yesterday') {
    $startDate = date('Y-m-d', strtotime('-1 day'));
    $endDate   = date('Y-m-d', strtotime('-1 day'));
    $periodTitle = "Dün";
} elseif ($range === '7d') {
    $startDate = date('Y-m-d', strtotime('-6 days'));
    $periodTitle = "Son 7 Gün";
} elseif ($range === '30d') {
    $startDate = date('Y-m-d', strtotime('-29 days'));
    $periodTitle = "Son 30 Gün";
} elseif ($range === 'this_month') {
    $startDate = date('Y-m-01');
    $periodTitle = "Bu Ay";
} elseif ($range === 'all') {
    $startDate = '2020-01-01';
    $periodTitle = "Tüm Zamanlar";
}

$startTs = "$startDate 00:00:00";
$endTs   = "$endDate 23:59:59";

// SQL Koşulları
$dateSqlSimple = " AND created_at BETWEEN '$startTs' AND '$endTs' ";
$dateSqlJoined = " AND d.created_at BETWEEN '$startTs' AND '$endTs' ";

// --- SORGULAR ---

// 1. Temel Toplamlar
$stmt = $pdo->query("SELECT COALESCE(SUM(amount_try),0) FROM deposit_orders WHERE status IN ('approved','confirmed') $dateSqlSimple");
$totalDeposit = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM deposit_orders WHERE status IN ('approved','confirmed') $dateSqlSimple");
$totalTxn = $stmt->fetchColumn();

// 2. Agent Performansı
$agentPerf = $pdo->query("
    SELECT da.id, da.name, COUNT(d.id) as total_cnt, SUM(d.amount_try) as total_vol, AVG(d.amount_try) as avg_amount
    FROM deposit_orders d
    JOIN deposit_agents da ON da.id = d.agent_id
    WHERE d.status IN ('approved','confirmed') $dateSqlJoined
    GROUP BY d.agent_id, da.id, da.name
    ORDER BY total_vol DESC
")->fetchAll(PDO::FETCH_ASSOC);

// 3. Site Performansı (YENİ)
$sitePerf = $pdo->query("
    SELECT s.id, s.name, s.logo_url, COUNT(d.id) as total_cnt, SUM(d.amount_try) as total_vol
    FROM deposit_orders d
    JOIN sites s ON s.id = d.site_id
    WHERE d.status IN ('approved','confirmed') $dateSqlJoined
    GROUP BY d.site_id, s.id, s.name, s.logo_url
    ORDER BY total_vol DESC
")->fetchAll(PDO::FETCH_ASSOC);

// 4. En İyi Müşteriler
$topUsers = $pdo->query("
    SELECT u.id, u.username, COUNT(d.id) as cnt, SUM(d.amount_try) as total 
    FROM deposit_orders d
    JOIN users u ON u.id = d.user_id
    WHERE d.status IN ('approved','confirmed') $dateSqlJoined
    GROUP BY d.user_id, u.id, u.username
    ORDER BY total DESC LIMIT 20
")->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/_admin_header.php';
?>

<style>
    /* Kart ve Grid */
    .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
    .anal-card { background: #fff; border-radius: 14px; padding: 24px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; }
    
    .kpi-value { font-size: 24px; font-weight: 800; color: #0f172a; margin-top: 5px; }
    .kpi-label { font-size: 12px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
    .text-green { color: #16a34a; } 

    /* Filtre */
    .filter-bar { display: flex; gap: 10px; background: #fff; padding: 10px; border-radius: 10px; border: 1px solid #e2e8f0; margin-bottom: 25px; overflow-x: auto; }
    .filter-btn { padding: 8px 16px; border-radius: 6px; text-decoration: none; color: #64748b; font-size: 13px; font-weight: 600; white-space: nowrap; }
    .filter-btn:hover { background: #f1f5f9; color: #2563eb; }
    .filter-btn.active { background: #2563eb; color: #fff; }

    /* Tablolar */
    .anal-table { width: 100%; border-collapse: collapse; }
    .anal-table th { text-align: left; font-size: 11px; text-transform: uppercase; color: #64748b; padding: 12px; border-bottom: 1px solid #e2e8f0; }
    .anal-table td { padding: 12px; border-bottom: 1px solid #f8fafc; font-size: 13px; color: #334155; cursor: pointer; transition: background 0.2s; }
    .anal-table tr:last-child td { border-bottom: none; }
    .anal-table tr:hover td { background: #f1f5f9; }

    /* Modal */
    .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 999; display: none; align-items: center; justify-content: center; backdrop-filter: blur(2px); }
    .modal-content { background: #fff; width: 90%; max-width: 700px; border-radius: 12px; max-height: 85vh; display: flex; flex-direction: column; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); }
    .modal-header { padding: 20px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
    .modal-body { padding: 20px; overflow-y: auto; }
    .modal-close { background: none; border: none; font-size: 24px; cursor: pointer; color: #64748b; }
    
    .detail-row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-size: 13px; }
    .detail-row:last-child { border-bottom: none; }
    .detail-badge { padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: 600; background: #dcfce7; color: #166534; }
</style>

<div class="page-content">

    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 20px;">
        <h1 style="margin:0; font-size: 24px; color: var(--text-main);">Performans Analizi</h1>
        <div style="font-size: 13px; color: var(--text-muted); background: #fff; padding: 6px 12px; border-radius: 20px; border: 1px solid var(--border-light);">
            <i class="ri-calendar-check-line"></i> <strong><?= $periodTitle ?></strong>
        </div>
    </div>

    <div class="filter-bar">
        <a href="?range=today" class="filter-btn <?= $range=='today'?'active':'' ?>">Bugün</a>
        <a href="?range=yesterday" class="filter-btn <?= $range=='yesterday'?'active':'' ?>">Dün</a>
        <a href="?range=7d" class="filter-btn <?= $range=='7d'?'active':'' ?>">Son 7 Gün</a>
        <a href="?range=30d" class="filter-btn <?= $range=='30d'?'active':'' ?>">Son 30 Gün</a>
        <a href="?range=this_month" class="filter-btn <?= $range=='this_month'?'active':'' ?>">Bu Ay</a>
        <a href="?range=all" class="filter-btn <?= $range=='all'?'active':'' ?>">Tüm Zamanlar</a>
    </div>

    <div class="kpi-grid">
        <div class="anal-card">
            <div class="kpi-label">Toplam Ciro</div>
            <div class="kpi-value text-green"><?= number_format($totalDeposit, 0, ',', '.') ?> ₺</div>
        </div>
        <div class="anal-card">
            <div class="kpi-label">Toplam İşlem</div>
            <div class="kpi-value"><?= number_format($totalTxn) ?> <small style="font-size:14px; color:#94a3b8;">Adet</small></div>
        </div>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 20px;">
        
        <div class="anal-card">
            <h3 style="margin-top:0; font-size:16px; color:#1e293b; border-bottom:1px solid #f1f5f9; padding-bottom:15px; margin-bottom:0;">
                <i class="ri-user-star-line" style="color:#9333ea;"></i> Aracı Performansı
            </h3>
            <table class="anal-table">
                <thead><tr><th>Aracı</th><th>İşlem</th><th>Hacim</th><th>Detay</th></tr></thead>
                <tbody>
                    <?php foreach($agentPerf as $a): ?>
                    <tr onclick="openDetail('agent', <?= $a['id'] ?>, '<?= htmlspecialchars($a['name']) ?>')">
                        <td style="font-weight:600;"><?= htmlspecialchars($a['name']) ?></td>
                        <td><?= $a['total_cnt'] ?></td>
                        <td style="font-weight:700; color:#2563eb;"><?= number_format($a['total_vol'], 0, ',', '.') ?> ₺</td>
                        <td style="text-align:right;"><i class="ri-arrow-right-s-line" style="color:#cbd5e1;"></i></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($agentPerf)): ?><tr><td colspan="4" style="text-align:center; padding:20px; color:#94a3b8;">Veri yok.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="anal-card">
            <h3 style="margin-top:0; font-size:16px; color:#1e293b; border-bottom:1px solid #f1f5f9; padding-bottom:15px; margin-bottom:0;">
                <i class="ri-global-line" style="color:#0ea5e9;"></i> Site Performansı
            </h3>
            <table class="anal-table">
                <thead><tr><th>Site</th><th>İşlem</th><th>Hacim</th><th>Detay</th></tr></thead>
                <tbody>
                    <?php foreach($sitePerf as $s): ?>
                    <tr onclick="openDetail('site', <?= $s['id'] ?>, '<?= htmlspecialchars($s['name']) ?>')">
                        <td style="font-weight:600; display:flex; align-items:center; gap:8px;">
                            <?php if($s['logo_url']): ?><img src="<?= $s['logo_url'] ?>" width="20" height="20" style="border-radius:4px; object-fit:contain;"><?php endif; ?>
                            <?= htmlspecialchars($s['name']) ?>
                        </td>
                        <td><?= $s['total_cnt'] ?></td>
                        <td style="font-weight:700; color:#0ea5e9;"><?= number_format($s['total_vol'], 0, ',', '.') ?> ₺</td>
                        <td style="text-align:right;"><i class="ri-arrow-right-s-line" style="color:#cbd5e1;"></i></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($sitePerf)): ?><tr><td colspan="4" style="text-align:center; padding:20px; color:#94a3b8;">Veri yok.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="anal-card" style="grid-column: 1 / -1;">
            <h3 style="margin-top:0; font-size:16px; color:#1e293b; border-bottom:1px solid #f1f5f9; padding-bottom:15px; margin-bottom:0;">
                <i class="ri-vip-crown-line" style="color:#f59e0b;"></i> En Çok Yatırım Yapanlar (Whales)
            </h3>
            <table class="anal-table">
                <thead><tr><th>Kullanıcı</th><th>İşlem Adedi</th><th>Toplam Tutar</th><th>Detay</th></tr></thead>
                <tbody>
                    <?php foreach($topUsers as $idx => $u): ?>
                    <tr onclick="openDetail('user', <?= $u['id'] ?>, '<?= htmlspecialchars($u['username']) ?>')">
                        <td style="font-weight:600; color:#1e293b;"><?= htmlspecialchars($u['username']) ?></td>
                        <td><?= $u['cnt'] ?></td>
                        <td style="font-weight:700; color:#16a34a;"><?= number_format($u['total'], 0, ',', '.') ?> ₺</td>
                        <td style="text-align:right;"><i class="ri-arrow-right-s-line" style="color:#cbd5e1;"></i></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($topUsers)): ?><tr><td colspan="4" style="text-align:center; padding:20px; color:#94a3b8;">Veri yok.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>

</div>

<div id="detailModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h3 style="margin:0;" id="modalTitle">Detaylar</h3>
            <button class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <div class="modal-body" id="modalBody">
            <div style="text-align:center; padding:30px; color:#94a3b8;">
                <i class="ri-loader-4-line spinning-icon" style="font-size:32px;"></i><br>Yükleniyor...
            </div>
        </div>
    </div>
</div>

<script>
function openDetail(type, id, name) {
    const modal = document.getElementById('detailModal');
    const title = document.getElementById('modalTitle');
    const body  = document.getElementById('modalBody');

    modal.style.display = 'flex';
    title.innerText = name + " - Detaylar";
    body.innerHTML = '<div style="text-align:center; padding:40px; color:#64748b;"><i class="ri-loader-4-line spinning-icon" style="font-size:32px;"></i><br><br>Veriler Yükleniyor...</div>';

    // TARİHLERİ GÜVENLİ HALE GETİRİYORUZ (URL ENCODE)
    const start = encodeURIComponent('<?= $startTs ?>');
    const end   = encodeURIComponent('<?= $endTs ?>');

    // AJAX İSTEĞİ
    fetch(`ajax_get_performance_detail.php?type=${type}&id=${id}&start=${start}&end=${end}`)
        .then(response => {
            if (!response.ok) {
                throw new Error("HTTP Hatası: " + response.status);
            }
            return response.text();
        })
        .then(html => {
            body.innerHTML = html;
        })
        .catch(error => {
            console.error('Detay hatası:', error);
            body.innerHTML = `<div style="text-align:center; padding:20px; color:#dc2626;">
                                <i class="ri-error-warning-line" style="font-size:32px;"></i><br>
                                <strong>Bir hata oluştu!</strong><br>
                                <small>${error.message}</small>
                              </div>`;
        });
}

function closeModal() {
    document.getElementById('detailModal').style.display = 'none';
}

window.onclick = function(event) {
    const modal = document.getElementById('detailModal');
    if (event.target == modal) {
        closeModal();
    }
}
</script>

<?php include __DIR__ . '/_admin_footer.php'; ?>