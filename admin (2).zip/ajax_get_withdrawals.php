<?php
// ajax_get_withdrawals.php
session_start();
require __DIR__ . '/../../config/config.php';

if (!isset($_SESSION['admin_id']) && !isset($_SESSION['agent_id'])) {
    http_response_code(403);
    exit;
}

$sql = "
    SELECT w.*, u.username, u.trc20_address 
    FROM withdraw_requests w
    JOIN users u ON u.id = w.user_id
    ORDER BY w.id DESC LIMIT 50
";
$rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

if (empty($rows)) {
    echo '<tr id="no-data-row"><td colspan="8" style="text-align:center; padding: 40px; color: var(--text-muted);">Veri yok.</td></tr>';
    exit;
}

foreach ($rows as $r):
    $status = $r['status'];
    $coin = $r['coin_type'];
    
    $stClass = 'pending'; $stLabel = 'Bekliyor'; $stIcon = 'ri-time-line';
    if($status=='approved') { $stClass='success'; $stLabel='Onaylandı'; $stIcon='ri-check-double-line'; }
    if($status=='rejected') { $stClass='danger'; $stLabel='Reddedildi'; $stIcon='ri-close-circle-line'; }
?>
<tr class="wd-row" data-id="<?= $r['id'] ?>" data-coin="<?= $coin ?>" data-status="<?= $status ?>">
    <td><span style="font-family: monospace; color: var(--text-muted);">#<?= $r['id'] ?></span></td>
    <td><strong><?= htmlspecialchars($r['username']) ?></strong></td>
    <td style="font-weight: 700;"><?= number_format($r['amount'], 4) ?></td>
    <td>
        <span class="badge-coin <?= $coin == 'USDT' ? 'badge-usdt' : 'badge-trx' ?>">
            <?= $coin ?>
        </span>
    </td>
    <td style="font-family: monospace; font-size: 12px; color: var(--text-muted);">
        <?= htmlspecialchars($r['trc20_address']) ?>
    </td>
    <td style="font-size: 12px; color: var(--text-muted);">
        <?= date('d.m.Y H:i', strtotime($r['created_at'])) ?>
    </td>
    <td>
        <span class="badge <?= $stClass ?>">
            <i class="<?= $stIcon ?>"></i> <?= $stLabel ?>
        </span>
    </td>
    <td style="text-align: right;">
        <?php if ($status === 'pending'): ?>
            <div class="action-group">
                <form method="post" action="withdrawals_update.php" style="display:inline;">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="id" value="<?= $r['id'] ?>">
                    <input type="hidden" name="action" value="approve">
                    <button type="submit" class="btn-icon btn-approve" title="Onayla" onclick="return confirm('Bu çekimi onaylıyor musunuz?')">
                        <i class="ri-check-line"></i>
                    </button>
                </form>
                <form method="post" action="withdrawals_update.php" style="display:inline;">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="id" value="<?= $r['id'] ?>">
                    <input type="hidden" name="action" value="reject">
                    <button type="submit" class="btn-icon btn-reject" title="Reddet" onclick="return confirm('Bu çekimi reddedip bakiyeyi iade etmek istiyor musunuz?')">
                        <i class="ri-close-line"></i>
                    </button>
                </form>
            </div>
        <?php else: ?>
            <i class="ri-checkbox-circle-fill" style="color: #cbd5e1; font-size: 20px;"></i>
        <?php endif; ?>
    </td>
</tr>
<?php endforeach; ?>
