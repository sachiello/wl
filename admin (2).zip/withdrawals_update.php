<?php
// withdrawals_update.php
session_start();
require __DIR__ . '/../../config/config.php';

// Güvenlik
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_validate_request()) {
    header('Location: withdrawals.php?error=csrf');
    exit;
}

$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$action = $_POST['action'] ?? '';

if ($id <= 0 || !in_array($action, ['approve', 'reject'], true)) {
    header('Location: withdrawals.php?error=invalid_params');
    exit;
}

// Talebi çek
$stmt = $pdo->prepare("SELECT * FROM withdraw_requests WHERE id = ? LIMIT 1");
$stmt->execute([$id]);
$req = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$req || $req['status'] !== 'pending') {
    header('Location: withdrawals.php?error=not_pending');
    exit;
}

try {
    $pdo->beginTransaction();

    if ($action === 'approve') {
        // Sadece statü güncelle
        $up = $pdo->prepare("UPDATE withdraw_requests SET status = 'approved' WHERE id = ?");
        $up->execute([$id]);
        
        // Loglama (İsteğe bağlı)
        // bw_log_action($pdo, 'withdrawal', 'admin', $_SESSION['admin_id'], 'approve', ['id'=>$id]);
        
        $pdo->commit();
        header('Location: withdrawals.php?msg=approved');
    } 
    elseif ($action === 'reject') {
        // 1. Statüyü güncelle
        $up = $pdo->prepare("UPDATE withdraw_requests SET status = 'rejected' WHERE id = ?");
        $up->execute([$id]);

        // 2. Bakiyeyi İADE ET (Refund)
        // Kullanıcının cüzdanını bul ve bakiyeyi arttır
        $walletUp = $pdo->prepare("
            UPDATE wallets 
            SET balance = balance + :amount 
            WHERE user_id = :uid AND coin_type = :coin
        ");
        $walletUp->execute([
            ':amount' => $req['amount'],
            ':uid'    => $req['user_id'],
            ':coin'   => $req['coin_type']
        ]);

        $pdo->commit();
        header('Location: withdrawals.php?msg=rejected_refunded');
    }

} catch (Exception $e) {
    $pdo->rollBack();
    die("Hata: " . $e->getMessage());
}
