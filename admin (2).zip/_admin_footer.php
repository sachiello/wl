<?php
// _admin_footer.php
?>
  </main> </div>    <audio id="adminAlertSound" src="https://cdn.freesound.org/previews/536/536108_11930272-lq.mp3" preload="auto"></audio>

<script>
let lastTotalCount = 0;
const alertSound = document.getElementById('adminAlertSound');

function updateLiveCounts() {
    // Dosya yolunun doğru olduğundan emin ol (admin klasörü içinden çağırılıyorsa)
    fetch('api/live_counts.php')
        .then(response => response.json())
        .then(data => {
            if(data.status !== 'success') return;

            const counts = data.counts;
            const currentTotal = parseInt(data.total);

            // 1. BADGE GÜNCELLEME
            updateBadge('deposits', counts.deposits);
            updateBadge('user_withdrawals', counts.user_withdrawals);
            updateBadge('site_withdrawals', counts.site_withdrawals);
            updateBadge('agent_requests', counts.agent_requests);
            updateBadge('agent_withdrawals', counts.agent_withdrawals);
            updateBadge('site_balance_requests', counts.site_balance_requests);
            updateBadge('site_deposit_requests', counts.site_deposit_requests); // Eğer varsa

            // 2. SESLİ BİLDİRİM (Yeni bir iş geldiyse)
            if (currentTotal > lastTotalCount && lastTotalCount !== 0) {
                try {
                    alertSound.play().catch(e => console.log("Ses oynatma izni yok."));
                    showToast("🔔 Yeni İşlem Bekliyor!");
                } catch(e) { console.log("Ses hatası."); }
            }
            
            // Toplamı güncelle
            lastTotalCount = currentTotal;
        })
        .catch(err => console.error("Live update error:", err));
}

// Yardımcı: Badge Elementini Bul ve Güncelle
function updateBadge(key, count) {
    // _admin_header.php içinde ID verdiğimiz span'ı buluyoruz (örn: id="badge_deposits")
    const badgeId = 'badge_' + key;
    let badgeEl = document.getElementById(badgeId);
    
    if (count > 0) {
        if (badgeEl) {
            badgeEl.innerText = '(' + count + ')';
            badgeEl.style.display = 'inline-block';
        }
    } else {
        if (badgeEl) badgeEl.style.display = 'none';
    }
}

// Yardımcı: Sağ Üst Bildirim Kutusu
function showToast(msg) {
    const div = document.createElement('div');
    div.style.cssText = "position:fixed; top:20px; right:20px; background:#ef4444; color:white; padding:15px; border-radius:8px; z-index:9999; font-weight:bold; box-shadow:0 5px 15px rgba(0,0,0,0.2); animation: slideIn 0.3s;";
    div.innerText = msg;
    document.body.appendChild(div);
    setTimeout(() => div.remove(), 4000);
}

// Animasyon CSS'i
const style = document.createElement('style');
style.innerHTML = `@keyframes slideIn { from { transform: translateX(100%); } to { transform: translateX(0); } }`;
document.head.appendChild(style);

// Başlat
document.addEventListener('DOMContentLoaded', () => {
    updateLiveCounts(); // Sayfa açılınca hemen çek
    setInterval(updateLiveCounts, 5000); // Sonra her 5 saniyede bir
});
</script>

</body>
</html>