<?php
// admin/user_sites.php
require __DIR__ . '/require_admin.php'; // $pdo, $currentAdmin

$pageTitle = 'Kullanıcı & Site Eşleşmeleri';
$activeNav = 'user_sites';

// --- Filtreler ---
$search = trim($_GET['q'] ?? '');
$siteFilter = $_GET['site_id'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 50;
$offset = ($page - 1) * $perPage;

// --- Yeni Ekleme İşlemi ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_link'])) {
    $userId = (int) $_POST['user_id'];
    $siteId = (int) $_POST['site_id'];
    $siteUsername = trim($_POST['site_username']);

    if ($userId > 0 && $siteId > 0 && $siteUsername !== '') {
        
        // Aynı kullanıcı + aynı site daha önce eklenmiş mi?
        $check = $pdo->prepare("SELECT id FROM user_sites WHERE user_id = ? AND site_id = ?");
        $check->execute([$userId, $siteId]);

        if (!$check->fetch()) {
            $stmt = $pdo->prepare("
                INSERT INTO user_sites (user_id, site_id, site_username, site_balance_try, linked_at)
                VALUES (:user_id, :site_id, :site_username, 0, NOW())
            ");
            $stmt->execute([
                ':user_id' => $userId,
                ':site_id' => $siteId,
                ':site_username' => $siteUsername
            ]);

            // Log ekle
            $meta = json_encode([
                'user_id' => $userId,
                'site_id' => $siteId,
                'site_username' => $siteUsername
            ], JSON_UNESCAPED_UNICODE);

            $log = $pdo->prepare("
                INSERT INTO activity_logs (actor_type, actor_id, scope, action, meta_json, created_at)
                VALUES ('admin', :admin_id, 'site_link', 'create', :meta_json, NOW())
            ");
            $log->execute([
                ':admin_id' => $currentAdmin['id'],
                ':meta_json' => $meta
            ]);

            header("Location: user_sites.php?ok=added");
            exit;
        } else {
            $error = "Bu kullanıcı bu siteye zaten bağlı.";
        }
    }
}

// --- Bakiye Güncelleme ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_balance'])) {
    $id = (int)$_POST['id'];
    $amount = (float)$_POST['site_balance_try'];

    $stmt = $pdo->prepare("UPDATE user_sites SET site_balance_try = :bal WHERE id = :id");
    $stmt->execute([
        ':bal' => $amount,
        ':id' => $id
    ]);

    header("Location: user_sites.php?ok=balance_updated");
    exit;
}

// --- Silme ---
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];

    // Önce meta almak için kayıt çek
    $info = $pdo->prepare("SELECT user_id, site_id FROM user_sites WHERE id = ?");
    $info->execute([$id]);
    $row = $info->fetch(PDO::FETCH_ASSOC);

    if ($row) {
        $pdo->prepare("DELETE FROM user_sites WHERE id = ?")->execute([$id]);

        // Log
        $meta = json_encode($row, JSON_UNESCAPED_UNICODE);
        $log = $pdo->prepare("
            INSERT INTO activity_logs (actor_type, actor_id, scope, action, meta_json, created_at)
            VALUES ('admin', :admin_id, 'site_link', 'delete', :meta_json, NOW())
        ");
        $log->execute([':admin_id' => $currentAdmin['id'], ':meta_json' => $meta]);
    }

    header("Location: user_sites.php?ok=deleted");
    exit;
}

// --- Sorgu Oluşturma ---
$where = [];
$params = [];

if ($search !== '') {
    $where[] = "(u.username LIKE :q OR us.site_username LIKE :q)";
    $params[':q'] = '%' . $search . '%';
}

if ($siteFilter !== '') {
    $where[] = "us.site_id = :site_id";
    $params[':site_id'] = $siteFilter;
}

$whereSql = $where ? "WHERE " . implode(" AND ", $where) : "";

// Toplam kayıt sayısı
$countSql = "SELECT COUNT(*) FROM user_sites us JOIN users u ON u.id = us.user_id JOIN sites s ON s.id = us.site_id $whereSql";
$countStmt = $pdo->prepare($countSql);
$countStmt->execute($params);
$totalRows = $countStmt->fetchColumn();
$totalPages = max(1, ceil($totalRows / $perPage));

// Liste Sorgusu
$sql = "
SELECT 
    us.id,
    u.username,
    u.id AS user_id,
    s.name AS site_name,
    s.id AS site_id,
    us.site_username,
    us.site_balance_try,
    us.linked_at
FROM user_sites us
JOIN users u ON u.id = us.user_id
JOIN sites s ON s.id = us.site_id
$whereSql
ORDER BY us.id DESC
LIMIT $perPage OFFSET $offset
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$links = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Tüm siteler dropdown için
$sites = $pdo->query("SELECT id, name FROM sites ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Header
include __DIR__ . '/_admin_header.php';
?>

<div class="admin-page">

    <div class="admin-page-header">
        <h1>Kullanıcı & Site Bağlantıları</h1>
        <p>Sistemdeki tüm kullanıcıların hangi sitelere bağlı olduğunu gösterir.</p>
    </div>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if (isset($_GET['ok'])): ?>
        <div class="alert alert-success">
            ✔ İşlem Başarılı: <?= htmlspecialchars($_GET['ok']) ?>
        </div>
    <?php endif; ?>

    <!-- Filtre -->
    <div class="admin-card" style="margin-bottom:20px;">
        <form method="get" class="admin-filter-form" style="display:flex; gap:15px; flex-wrap:wrap;">
            
            <input type="text" name="q" placeholder="Kullanıcı / Site Username"
                   value="<?= htmlspecialchars($search) ?>" class="admin-input">

            <select name="site_id" class="admin-select">
                <option value="">Tüm Siteler</option>
                <?php foreach ($sites as $s): ?>
                    <option value="<?= $s['id'] ?>" <?= $siteFilter == $s['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($s['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button class="btn btn-primary">Filtrele</button>
            <a href="user_sites.php" class="btn btn-secondary">Sıfırla</a>

            <button type="button" class="btn btn-success" onclick="document.getElementById('modal-add').style.display='flex';">
                + Yeni Bağlantı
            </button>

        </form>
    </div>

    <!-- Tablo -->
    <div class="admin-card">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Kullanıcı</th>
                    <th>Site</th>
                    <th>Site Username</th>
                    <th>Site Bakiye (TRY)</th>
                    <th>Bağlantı Tarihi</th>
                    <th>Aksiyon</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$links): ?>
                    <tr><td colspan="7" style="text-align:center; padding:30px;">Kayıt bulunamadı.</td></tr>
                <?php else: foreach ($links as $row): ?>
                    <tr>
                        <td>#<?= $row['id'] ?></td>
                        <td><?= htmlspecialchars($row['username']) ?> (#<?= $row['user_id'] ?>)</td>
                        <td><?= htmlspecialchars($row['site_name']) ?></td>
                        <td><?= htmlspecialchars($row['site_username']) ?></td>
                        <td>
                            <form method="post" style="display:flex; gap:5px;">
                                <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                <input type="number" step="0.01" name="site_balance_try" value="<?= $row['site_balance_try'] ?>" class="admin-input" style="width:100px;">
                                <button name="update_balance" class="btn btn-xs btn-warning">Güncelle</button>
                            </form>
                        </td>
                        <td><?= $row['linked_at'] ?></td>
                        <td>
                            <a href="user_sites.php?delete=<?= $row['id'] ?>"
                               class="btn btn-xs btn-danger"
                               onclick="return confirm('Bu bağlantıyı silmek istediğine emin misin?');">
                                Sil
                            </a>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Sayfalama -->
    <?php if ($totalPages > 1): ?>
        <div class="admin-pagination">
            <?php for ($i=1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?= $i ?>&q=<?= urlencode($search) ?>&site_id=<?= urlencode($siteFilter) ?>"
                   class="page-link <?= $page == $i ? 'is-active' : '' ?>">
                    <?= $i ?>
                </a>
            <?php endfor; ?>
        </div>
    <?php endif; ?>

</div>

<!-- Yeni Bağlantı Modal -->
<div class="admin-modal-backdrop" id="modal-add" style="display:none;">
    <div class="admin-modal" style="max-width:500px;">
        <button class="admin-modal-close" onclick="document.getElementById('modal-add').style.display='none';">&times;</button>

        <div class="admin-modal-header">
            <h2>Yeni Site Bağlantısı</h2>
        </div>

        <form method="post" class="admin-modal-body" style="display:flex; flex-direction:column; gap:15px;">
            <input type="hidden" name="add_link" value="1">

            <label>Kullanıcı</label>
            <input type="number" name="user_id" placeholder="User ID" class="admin-input" required>

            <label>Site</label>
            <select name="site_id" class="admin-select" required>
                <option value="">Seç...</option>
                <?php foreach ($sites as $s): ?>
                    <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?></option>
                <?php endforeach; ?>
            </select>

            <label>Site Username</label>
            <input type="text" name="site_username" placeholder="Kullanıcı adı (site içi)" class="admin-input" required>

            <button class="btn btn-primary">Bağlantıyı Kaydet</button>
        </form>
    </div>
</div>

<script>
// Kapama: backdrop click
document.getElementById('modal-add').addEventListener('click', function(e){
    if(e.target === this) this.style.display = 'none';
});
</script>

<?php include __DIR__ . '/_admin_footer.php'; ?>
