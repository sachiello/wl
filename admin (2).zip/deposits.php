<?php
// deposits.php - SORUNSUZ FİNAL SÜRÜM
session_start();
require __DIR__ . '/../../config/config.php';

// 1. GÜVENLİK VE YETKİ KONTROLÜ
$is_admin = isset($_SESSION['admin_id']);
$is_agent = isset($_SESSION['agent_id']);

if (!$is_admin && !$is_agent) {
    header('Location: admin_login.php');
    exit;
}

$permissions = [];
if ($is_admin) {
    $permissions = ['view_havale' => true, 'view_crypto' => true, 'view_cc' => true, 'can_approve' => true];
} else {
    $permissions = $_SESSION['agent_permissions'] ?? ['view_havale' => false, 'view_crypto' => false, 'view_cc' => false, 'can_approve' => false];
}

// 2. VERİ ÇEKME
$sql = "
    SELECT 
      d.*, 
      u.username,
      di.iban AS deposit_iban,
      da.name AS agent_name,
      cw.address AS crypto_wallet_address,
      cw.coin_symbol AS crypto_coin_symbol
    FROM deposit_orders d
    JOIN users u ON u.id = d.user_id
    LEFT JOIN deposit_ibans di ON di.id = d.iban_id
    LEFT JOIN deposit_agents da ON da.id = d.agent_id
    LEFT JOIN admin_crypto_wallets cw ON cw.id = d.crypto_wallet_id
    ORDER BY d.id DESC LIMIT 100
";
// Not: Performans için LIMIT 100 ekledim, çok fazla veri varsa sayfa kasmasın.

$all_rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

// 3. PHP FİLTRESİ (Yetkiye Göre)
$rows = array_filter($all_rows, function($row) use ($permissions) {
    $payment_method = $row['payment_method'] ?? 'havale';
    if ($payment_method === 'havale' && !$permissions['view_havale']) return false;
    if ($payment_method === 'crypto' && !$permissions['view_crypto']) return false;
    if ($payment_method === 'credit_card' && !$permissions['view_cc']) return false;
    return true;
});

$pageTitle = 'Yatırım Talepleri';
include __DIR__ . '/_admin_header.php';
?>

<style>
    .toolbar-container { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; gap: 15px; flex-wrap: wrap; }
    
    .modern-tabs { display: inline-flex; background: #fff; padding: 5px; border-radius: var(--radius-md); box-shadow: var(--shadow-soft); border: 1px solid var(--border-light); gap: 5px; }
    .tab-btn { padding: 8px 16px; border-radius: var(--radius-sm); color: var(--text-muted); font-size: 13px; font-weight: 600; display: flex; align-items: center; gap: 6px; cursor: pointer; border: none; background: transparent; transition: all 0.2s; }
    .tab-btn:hover { background: #f1f5f9; color: var(--primary); }
    .tab-btn.is-active { background: var(--primary); color: #fff; box-shadow: 0 4px 10px rgba(59, 130, 246, 0.3); }
    
    .toolbar-actions { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    .filter-select { padding: 10px 14px; border-radius: var(--radius-md); border: 1px solid var(--border-light); background: #fff; font-size: 13px; color: var(--text-main); outline: none; cursor: pointer; font-weight: 500; box-shadow: var(--shadow-soft); }
    
    .search-wrapper { position: relative; }
    .search-wrapper i { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--text-muted); font-size: 16px; }
    .search-input { padding: 10px 10px 10px 36px; border-radius: var(--radius-md); border: 1px solid var(--border-light); background: #fff; font-size: 13px; width: 180px; color: var(--text-main); outline: none; box-shadow: var(--shadow-soft); }
    
    .update-badge { font-size: 12px; color: var(--text-muted); display: flex; align-items: center; gap: 8px; background: #fff; padding: 8px 14px; border-radius: 20px; border: 1px solid var(--border-light); box-shadow: var(--shadow-soft); white-space: nowrap; }
    
    @keyframes spin { 100% { transform: rotate(360deg); } }
    .spinning-icon { animation: spin 1s linear infinite; color: var(--primary); display: inline-block; }
    .spinning-icon.paused { animation-play-state: paused; opacity: 0.7; }
    
    .badge-method { padding: 4px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; text-transform: uppercase; display: inline-flex; align-items: center; gap: 4px; }
    .badge-havale { background: #eff6ff; color: #1d4ed8; border: 1px solid #dbeafe; }
    .badge-crypto { background: #fefce8; color: #a16207; border: 1px solid #fef08a; }
    .badge-cc     { background: #faf5ff; color: #7e22ce; border: 1px solid #f3e8ff; }
    
    .action-group { display: flex; gap: 6px; justify-content: flex-end; }
    .btn-icon { width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; border-radius: 6px; text-decoration: none; border: 1px solid transparent; transition: all 0.2s;}
    .btn-approve { background: #f0fdf4; color: #16a34a; border-color: #bbf7d0; }
    .btn-approve:hover { background: #16a34a; color: #fff; transform: translateY(-2px); }
    .btn-reject { background: #fef2f2; color: #dc2626; border-color: #fecaca; }
    .btn-reject:hover { background: #dc2626; color: #fff; transform: translateY(-2px); }

    @keyframes softFlash { 0% { background-color: #dcfce7; } 100% { background-color: transparent; } }
    .new-item-flash { animation: softFlash 3s ease-out; }
    .deposit-row { transition: background-color 0.3s; }
</style>

<div class="page-content">
    
    <div class="toolbar-container">
        <div class="modern-tabs">
            <button onclick="filterTable('all')" class="tab-btn is-active" id="tab-all"><i class="ri-apps-line"></i> Tümü</button>
            <?php if ($permissions['view_havale']): ?>
                <button onclick="filterTable('havale')" class="tab-btn" id="tab-havale"><i class="ri-bank-card-line"></i> Havale</button>
            <?php endif; ?>
            <?php if ($permissions['view_crypto']): ?>
                <button onclick="filterTable('crypto')" class="tab-btn" id="tab-crypto"><i class="ri-bit-coin-line"></i> Kripto</button>
            <?php endif; ?>
            <?php if ($permissions['view_cc']): ?>
                <button onclick="filterTable('credit_card')" class="tab-btn" id="tab-cc"><i class="ri-bank-card-2-line"></i> Kredi Kartı</button>
            <?php endif; ?>
        </div>

        <div class="toolbar-actions">
            <select id="filterStatus" class="filter-select" onchange="masterFilter()">
                <option value="all">Tüm Durumlar</option>
                <option value="pending">⏳ Bekleyenler</option>
                <option value="approved">✅ Onaylananlar</option>
                <option value="rejected">❌ Reddedilenler</option>
            </select>

            <select id="filterDate" class="filter-select" onchange="masterFilter()">
                <option value="all">📅 Tüm Zamanlar</option>
                <option value="today">Bugün</option>
            </select>

            <div class="search-wrapper">
                <i class="ri-search-line"></i>
                <input type="text" id="searchInput" class="search-input" placeholder="Ara..." onkeyup="masterFilter()">
            </div>

            <div class="update-badge">
                <i class="ri-refresh-line spinning-icon paused" id="refreshIcon"></i>
                <span style="font-family: monospace; font-size: 13px;" id="lastUpdateTime">--:--:--</span>
            </div>
        </div>
    </div>

    <div class="table-container">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Kullanıcı</th>
                    <th>Tutar</th>
                    <th>Yöntem</th>
                    <th>Detay</th>
                    <th>Aracı</th>
                    <th>Tarih</th>
                    <th>Durum</th>
                    <th style="text-align: right;">İşlem</th>
                </tr>
            </thead>
            
            <tbody id="depositTableBody">
                <?php foreach ($rows as $r):
                    $method = $r['payment_method'] ?? 'havale';
                    
                    // --- DURUM MANTIĞI (AJAX ile BİREBİR AYNI OLMALI) ---
                    $dbStatus = strtolower(trim($r['status'])); // Veriyi temizle

                    $statusClass = 'pending';
                    $statusLabel = 'Bekliyor';
                    $statusIcon  = 'ri-time-line';

                    // Hem 'approved', hem 'confirmed', hem 'success' kabul et
                    if (in_array($dbStatus, ['approved', 'confirmed', 'success'])) { 
                        $statusClass = 'success'; 
                        $statusLabel = 'Onaylandı'; 
                        $statusIcon  = 'ri-check-double-line'; 
                    } 
                    elseif ($dbStatus == 'rejected') { 
                        $statusClass = 'danger'; 
                        $statusLabel = 'Reddedildi'; 
                        $statusIcon  = 'ri-close-circle-line'; 
                    }
                    
                    // JS Filtreleme için Tarih (Y-m-d)
                    $rawDate = date('Y-m-d', strtotime($r['created_at']));
                ?>
                <tr class="deposit-row" 
                    data-method="<?= $method ?>" 
                    data-id="<?= $r['id'] ?>"
                    data-status="<?= $dbStatus ?>" 
                    data-date="<?= $rawDate ?>">
                    
                    <td><span style="font-family: monospace; color: var(--text-muted);">#<?= $r['id'] ?></span></td>
                    <td><div style="font-weight: 600; color: var(--text-main);"><?= htmlspecialchars($r['username']) ?></div></td>
                    <td>
                        <div style="font-weight: 700; color: var(--text-main); font-size: 15px;">
                            <?= number_format($r['amount_try'], 2) ?> <span style="font-size: 11px; color: var(--text-muted);">TL</span>
                        </div>
                    </td>
                    <td>
                        <?php if ($method === 'havale'): ?>
                            <span class="badge-method badge-havale"><i class="ri-bank-line"></i> Havale</span>
                        <?php elseif ($method === 'crypto'): ?>
                            <span class="badge-method badge-crypto"><i class="ri-bit-coin-line"></i> Kripto</span>
                        <?php elseif ($method === 'credit_card'): ?>
                            <span class="badge-method badge-cc"><i class="ri-mastercard-line"></i> K.Kartı</span>
                        <?php endif; ?>
                    </td>
                    <td style="font-size: 13px; color: var(--text-muted);">
                        <?php if ($method === 'havale'): ?>
                            <i class="ri-arrow-right-s-line" style="vertical-align:middle"></i> <?= htmlspecialchars($r['deposit_iban'] ?? '-') ?>
                        <?php elseif ($method === 'crypto'): ?>
                             <strong style="color:var(--text-main)"><?= htmlspecialchars($r['crypto_coin_symbol'] ?? '') ?></strong>
                             <br><span style="font-size: 11px; font-family: monospace;"><?= substr($r['crypto_wallet_address'] ?? '', 0, 12) ?>...</span>
                        <?php else: ?> - <?php endif; ?>
                    </td>
                    <td>
                        <?php if($r['agent_name']): ?>
                            <span style="display: inline-flex; align-items: center; gap: 5px; background: #f3f4f6; padding: 4px 8px; border-radius: 6px; font-size: 12px;">
                                <i class="ri-user-star-line"></i> <?= htmlspecialchars($r['agent_name']) ?>
                            </span>
                        <?php else: ?> - <?php endif; ?>
                    </td>
                    <td style="font-size: 12px; color: var(--text-muted);"><?= date('d.m.Y H:i', strtotime($r['created_at'])) ?></td>
                    
                    <td>
                        <span class="badge <?= $statusClass ?>">
                            <i class="<?= $statusIcon ?>"></i> <?= $statusLabel ?>
                        </span>
                    </td>
                    
                    <td style="text-align: right;">
                        <?php if ($dbStatus === 'pending' && $permissions['can_approve']): ?>
                            <div class="action-group">
                                <form method="post" action="deposits_update.php" style="display:inline;">
                                    <?= csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?= $r['id'] ?>">
                                    <input type="hidden" name="action" value="confirm">
                                    <button type="submit" class="btn-icon btn-approve" title="Onayla">
                                        <i class="ri-check-line"></i>
                                    </button>
                                </form>
                                <form method="post" action="deposits_update.php" style="display:inline;">
                                    <?= csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?= $r['id'] ?>">
                                    <input type="hidden" name="action" value="reject">
                                    <button type="submit" class="btn-icon btn-reject" title="Reddet">
                                        <i class="ri-close-line"></i>
                                    </button>
                                </form>
                            </div>
                        <?php elseif($dbStatus === 'pending'): ?>
                            <span style="font-size: 11px; color: var(--text-muted); font-style: italic;">Yetki Yok</span>
                        <?php else: ?>
                            <i class="ri-checkbox-circle-fill" style="color: #cbd5e1; font-size: 20px;"></i>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                
                <tr id="no-data-row" style="display:none;">
                    <td colspan="9" style="text-align:center; padding: 40px; color: var(--text-muted);">
                        <i class="ri-filter-off-line" style="font-size: 48px; display: block; margin-bottom: 10px; opacity: 0.5;"></i>
                        Filtrelere uygun sonuç bulunamadı.
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<audio id="notificationSound" preload="auto">
    <source src="https://cdn.freesound.org/previews/337/337049_3232293-lq.mp3" type="audio/mp3">
</audio>

<script>
    let currentCategory = 'all';
    let lastMaxId = 0; 
    let firstLoad = true;

    // --- SES ÇALMA ---
    function playNotification() {
        const audio = document.getElementById('notificationSound');
        audio.play().catch(e => console.log("Ses hatası (Otomatik oynatma engellendi):", e));
    }

    // --- SEKME FİLTRESİ ---
    function filterTable(category) {
        currentCategory = category;
        const buttons = document.querySelectorAll('.tab-btn');
        buttons.forEach(btn => btn.classList.remove('is-active'));
        
        let activeBtnId = 'tab-all';
        if(category === 'havale') activeBtnId = 'tab-havale';
        if(category === 'crypto') activeBtnId = 'tab-crypto';
        if(category === 'credit_card') activeBtnId = 'tab-cc';
        
        const activeBtn = document.getElementById(activeBtnId);
        if(activeBtn) activeBtn.classList.add('is-active');

        masterFilter(); 
    }

    // --- ANA FİLTRE MANTIĞI ---
    function masterFilter() {
        const statusFilter = document.getElementById('filterStatus').value; 
        const dateFilter = document.getElementById('filterDate').value;     
        const searchTerm = document.getElementById('searchInput').value.toLowerCase().trim();
        const today = new Date().toISOString().split('T')[0];

        const rows = document.querySelectorAll('.deposit-row');
        let visibleCount = 0;

        rows.forEach(row => {
            const method = row.getAttribute('data-method'); 
            let status = row.getAttribute('data-status'); 
            const date   = row.getAttribute('data-date');   
            const rowText = row.innerText.toLowerCase();

            // Veritabanı durumu 'confirmed' ise 'approved' olarak muamele et (Filtre için)
            if (status === 'confirmed') status = 'approved';

            const categoryMatch = (currentCategory === 'all' || method === currentCategory);
            const statusMatch = (statusFilter === 'all' || status === statusFilter);
            
            let dateMatch = true;
            if (dateFilter === 'today') {
                dateMatch = (date === today);
            }

            const searchMatch = (searchTerm === '' || rowText.includes(searchTerm));

            if (categoryMatch && statusMatch && dateMatch && searchMatch) {
                row.style.display = ''; 
                visibleCount++;
            } else {
                row.style.display = 'none';
            }
        });

        const noData = document.getElementById('no-data-row');
        if(noData) noData.style.display = (visibleCount === 0) ? '' : 'none';
    }

    // --- AJAX GÜNCELLEME ---
    function fetchNewData() {
        const scrollPos = document.querySelector('.admin-content-scroll') ? document.querySelector('.admin-content-scroll').scrollTop : 0;
        const refreshIcon = document.getElementById('refreshIcon');
        if(refreshIcon) refreshIcon.classList.remove('paused');

        // CACHE BUSTING: ?t=zaman ekle
        fetch('ajax_get_deposits.php?t=' + new Date().getTime())
            .then(response => response.text())
            .then(html => {
                const tbody = document.getElementById('depositTableBody');
                document.getElementById('lastUpdateTime').innerText = new Date().toLocaleTimeString('tr-TR');

                if (tbody.innerHTML.trim() !== html.trim()) {
                   tbody.innerHTML = html;
                   
                   masterFilter();
                   
                   const rows = document.querySelectorAll('.deposit-row');
                   let currentMaxId = 0;
                   rows.forEach(row => {
                       const id = parseInt(row.getAttribute('data-id'));
                       if(id > currentMaxId) currentMaxId = id;
                       if (!firstLoad && id > lastMaxId) {
                           row.classList.add('new-item-flash');
                       }
                   });

                   if (currentMaxId > lastMaxId) {
                       if (!firstLoad) {
                           playNotification();
                           document.title = "🔔 YENİ İŞLEM!";
                           setTimeout(() => document.title = "Yatırım Talepleri", 4000);
                       }
                       lastMaxId = currentMaxId;
                   }
                   firstLoad = false;
                   
                   const scrollContainer = document.querySelector('.admin-content-scroll');
                   if(scrollContainer) scrollContainer.scrollTop = scrollPos;
                }
            })
            .catch(error => {
                console.error('Hata:', error);
                document.getElementById('lastUpdateTime').innerText = "Hata!";
                document.getElementById('lastUpdateTime').style.color = "red";
            })
            .finally(() => {
                if(refreshIcon) refreshIcon.classList.add('paused');
            });
    }

    document.addEventListener('DOMContentLoaded', () => {
        const rows = document.querySelectorAll('.deposit-row');
        rows.forEach(row => {
            const id = parseInt(row.getAttribute('data-id'));
            if(id > lastMaxId) lastMaxId = id;
        });
        firstLoad = false;
        
        document.getElementById('lastUpdateTime').innerText = new Date().toLocaleTimeString('tr-TR');
        setInterval(fetchNewData, 5000);
    });
</script>

<?php include __DIR__ . '/_admin_footer.php'; ?>
