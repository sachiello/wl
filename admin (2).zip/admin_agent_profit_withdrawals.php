<?php
// admin/admin_agent_profit_withdrawals.php - Agent Kâr Çekim Taleplerini Yönetme
require __DIR__ . '/require_admin.php';

$pageTitle = 'Agent Kâr Çekim Talepleri';
$activeNav = 'agent_withdrawals';

$adminError = null;
$adminSuccess = null;
$adminId = (int)($currentAdmin['id'] ?? 0);

// =================================================================
// POST İŞLEMLERİ (ONAY/RED)
// =================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF kontrolü
    if (!function_exists('csrf_validate')) {
        $adminError = "CSRF kontrol fonksiyonu bulunamadı.";
    } else {
        try {
            csrf_validate();
        } catch (Exception $e) {
            $err = $e->getMessage();
        }
    }
    
    if (!$err) {
        $requestId = (int)($_POST['request_id'] ?? 0);
        $action = $_POST['action'] ?? ''; // 'approve' (ödendi) veya 'reject'

        if ($requestId > 0 && ($action === 'approve' || $action === 'reject')) {
            try {
                $pdo->beginTransaction();

                // 1. Talebi Kilitle ve Çek (Agent bakiyelerini de FOR UPDATE ile çek)
                $stmt = $pdo->prepare("
                    SELECT r.*, a.agent_profit_balance
                    FROM agent_profit_withdraw_requests r
                    JOIN deposit_agents a ON a.id = r.agent_id
                    WHERE r.id = ? AND r.status = 'pending'
                    FOR UPDATE
                ");
                $stmt->execute([$requestId]);
                $request = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$request) {
                    throw new Exception("Talep bulunamadı veya zaten işlenmiş.");
                }

                $agentId = (int)$request['agent_id'];
                $amount = (float)$request['amount']; // Agent'ın istediği toplam tutar
                $netAmount = (float)$request['net_amount']; // Agent'a ödenecek net tutar
                $feeAmount = (float)$request['fee_amount']; // %1 Fee

                if ($action === 'approve') {
                    // KONTROL: Agent'ın mevcut kâr bakiyesi yeterli mi?
                    $currentProfit = (float)$request['agent_profit_balance'];
                    if ($currentProfit < $amount) {
                         throw new Exception("Agent'ın kâr bakiyesi yetersiz ({$currentProfit} TL). Ödeme yapılamaz.");
                    }

                    // 2a. ONAYLA: Agent'ın Kâr Bakiyesinden brüt tutarı (net + fee) düşür.
                    $pdo->prepare("
                        UPDATE deposit_agents
                        SET agent_profit_balance = agent_profit_balance - :amount,
                            total_profit_withdrawn = total_profit_withdrawn + :net_amount
                        WHERE id = :agent_id
                    ")->execute([
                        ':amount' => $amount,
                        ':net_amount' => $netAmount,
                        ':agent_id' => $agentId,
                    ]);

                    // 2b. agent_profit_withdraw_requests tablosundaki durumu 'paid' olarak güncelle
                    $pdo->prepare("
                        UPDATE agent_profit_withdraw_requests 
                        SET status = 'paid', admin_id = ?, processed_at = NOW() 
                        WHERE id = ?
                    ")->execute([$adminId, $requestId]);
                    
                    // 2c. Loglama (agent_profit_logs) - Çekim Logu
                    $pdo->prepare("
                        INSERT INTO agent_profit_logs
                            (agent_id, type, amount, fee_amount, description)
                        VALUES
                            (:agent_id, 'profit_withdraw', :amount, :fee, :description)
                    ")->execute([
                        ':agent_id' => $agentId,
                        ':amount' => -$netAmount, // Negatif tutar (çıkış)
                        ':fee' => $feeAmount,
                        ':description' => "TRC20 çekimi onaylandı (Talep #{$requestId})",
                    ]);
                    
                    $adminSuccess = "Kâr çekim talebi onaylandı ve Agent'ın kâr bakiyesinden {$amount} TL düşüldü. (Net Ödenen: {$netAmount} TL)";

                } elseif ($action === 'reject') {
                    // 2. REDDET: Sadece Talebin Durumunu Güncelle (Bakiye yerinde kalır)
                    $pdo->prepare("UPDATE agent_profit_withdraw_requests SET status = 'rejected', admin_id = ?, processed_at = NOW() WHERE id = ? AND status = 'pending'")
                        ->execute([$adminId, $requestId]);
                    
                    $adminSuccess = 'Kâr çekim talebi reddedildi. Agent bakiyesinden düşülmedi.';
                }

                $pdo->commit();

            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $adminError = "İşlem hatası: " . $e->getMessage();
            }
        } else {
            $err = "Geçersiz işlem veya talep ID'si.";
        }
    }
}

// =================================================================
// VERİ ÇEKME (Tüm talepler, bekleyenler en üstte)
// =================================================================
$sql = "
    SELECT r.*, a.name AS agent_name, a.agent_profit_balance AS agent_profit 
    FROM agent_profit_withdraw_requests r
    JOIN deposit_agents a ON a.id = r.agent_id
    ORDER BY r.status = 'pending' DESC, r.created_at DESC
";
$requests = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>

<?php include '_admin_header.php'; // Header'ı ve Sidebar'ı dahil et ?>

<style>
/* ============================================
   DARK MODE UYUMLU KÂR ÇEKİM SAYFASI STİLLERİ
   ============================================
*/
:root {
    --primary: #4f46e5;
    --success: #10b981;
    --danger: #dc2626;
    --warning: #f59e0b;
    --radius-sm: 6px;
    --radius-lg: 12px;
    
    --bg-card: #ffffff;
    --border-light: #e5e7eb;
    --text-main: #1f2937;
    --text-muted: #6b7280;
    --bg-table-head: #f8fafc;
    --bg-pending-row: #fffbeb;
    --color-success-bg: #dcfce7;
    --color-warning-bg: #fef3c7;
    --color-danger-bg: #fef2f2;
    --color-btn-reject: #fee2e2;
}

/* DARK MODE OVERRIDES */
body.dark-mode {
    --bg-card: #1f2937; 
    --border-light: #374151; 
    --text-main: #f9fafb; 
    --text-muted: #9ca3af; 
    --bg-table-head: #1f2937; 
    --bg-pending-row: #27272a; 
    --color-success-bg: #064e3b;
    --color-warning-bg: #78350f;
    --color-danger-bg: #991b1b;
    --color-btn-reject: #450a0a;
}

/* Ortak Stiller (Admin Agent Request sayfasından kopyalanmıştır) */
.page-content { padding: 32px; }
.card { 
    background: var(--bg-card); 
    border: 1px solid var(--border-light); 
    border-radius: var(--radius-lg); 
    padding: 24px; 
    box-shadow: 0 4px 10px rgba(0,0,0,0.05); 
    margin-bottom: 20px;
    transition: all 0.2s;
}
body.dark-mode .card { box-shadow: 0 4px 10px rgba(0,0,0,0.2); }
.card-header-styled { 
    border-bottom: 1px solid var(--border-light); 
    padding-bottom: 15px; 
    margin-bottom: 15px;
    display: flex; 
    justify-content: space-between; 
    align-items: center;
}
.card-header-styled h3 { color: var(--text-main); }
.admin-table { width: 100%; border-collapse: collapse; }
.admin-table th { 
    text-align: left; 
    padding: 12px 15px; 
    background-color: var(--bg-table-head); 
    color: var(--text-muted); 
    font-weight: 600; 
    text-transform: uppercase;
    font-size: 12px;
}
.admin-table td { 
    padding: 15px; 
    border-top: 1px solid var(--border-light); 
    vertical-align: middle; 
    font-size: 14px;
    color: var(--text-main); 
}
.admin-table tr:hover { background-color: rgba(79, 70, 229, 0.05); }
body.dark-mode .admin-table tr:hover { background-color: rgba(79, 70, 229, 0.1); }

/* --- Rozetler ve Butonlar --- */
.badge-status { padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
.status-pending { background-color: var(--color-warning-bg); color: var(--warning); }
.status-paid { background-color: var(--color-success-bg); color: var(--success); }
.status-rejected { background-color: var(--color-danger-bg); color: var(--danger); }

.btn-sm { padding: 6px 12px; font-size: 13px; border-radius: 6px; border: none; font-weight: 600; cursor: pointer; }
.btn-approve { background-color: var(--success); color: white; transition: background-color 0.2s; }
.btn-approve:hover { background-color: #047857; }
.btn-reject { background-color: var(--color-btn-reject); color: var(--danger); transition: background-color 0.2s; }
.btn-reject:hover { background-color: #fca5a5; }
body.dark-mode .btn-reject:hover { background-color: #7f1d1d; }

.pending-row { 
    background-color: var(--bg-pending-row); 
    animation: pulse-light 2s infinite; 
    border-left: 3px solid var(--warning);
}
@keyframes pulse-light { 0%, 100% { opacity: 1; } 50% { opacity: 0.95; } }
</style>

<div class="page-content">
    <header class="admin-header">
        
    </header>

    <?php if ($adminError): ?>
        <div class="alert-box alert-danger"><i class="ri-error-warning-fill"></i> <?= htmlspecialchars($adminError) ?></div>
    <?php endif; ?>

    <?php if ($adminSuccess): ?>
        <div class="alert-box alert-success"><i class="ri-checkbox-circle-fill"></i> <?= htmlspecialchars($adminSuccess) ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header-styled">
            <h3 style="font-weight: 600; font-size: 18px;">Kâr Çekim Talepleri</h3>
            <span class="badge-status status-pending"><?= count(array_filter($requests, fn($r) => $r['status'] === 'pending')) ?> BEKLEYEN</span>
        </div>

        <div class="table-container">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID / Agent</th>
                        <th>Adres / Bilgi</th>
                        <th>Toplam Tutar</th>
                        <th>Kesinti / Net</th>
                        <th>Agent Kâr (Mevcut)</th>
                        <th>Durum</th>
                        <th class="text-end">İşlem</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($requests)): ?>
                        <?php foreach ($requests as $req): 
                            $statusClass = $req['status'] === 'pending' ? 'status-pending' : ($req['status'] === 'paid' ? 'status-paid' : 'status-rejected');
                            $amount = (float)$req['amount'];
                            $netAmount = (float)$req['net_amount'];
                            $feeAmount = (float)$req['fee_amount'];
                        ?>
                            <tr class="<?= $req['status'] === 'pending' ? 'pending-row' : '' ?>">
                                <td>
                                    <div style="font-weight: 700; color: var(--text-main);">#<?= (int)$req['id'] ?></div>
                                    <div style="color: var(--primary); font-weight: 600; font-size: 13px;"><?= htmlspecialchars($req['agent_name']) ?></div>
                                </td>
                                <td>
                                    <div style="font-family: monospace; font-size: 13px; color: var(--text-main);"><?= htmlspecialchars($req['trc20_address']) ?></div>
                                    <div style="font-size: 11px; color: var(--text-muted);">Ağ: TRC20 / Coin: USDT</div>
                                </td>
                                <td>
                                    <div style="font-weight: 700; color: var(--text-main);"><?= number_format($amount, 2) ?> ₺</div>
                                    <div style="font-size: 11px; color: var(--text-muted);">Talep Tarihi: <?= date('d.m.Y H:i', strtotime($req['created_at'])) ?></div>
                                </td>
                                <td>
                                    <div style="font-weight: 700; color: var(--success);"><?= number_format($netAmount, 2) ?> ₺ NET</div>
                                    <div style="font-size: 11px; color: var(--danger);">Kesinti: <?= number_format($feeAmount, 2) ?> ₺ (%<?= number_format($req['fee_rate'], 2) ?>)</div>
                                </td>
                                <td>
                                    <div style="font-weight: 700; color: var(--success);">
                                        <?= number_format($req['agent_profit'] ?? 0, 2) ?> ₺
                                    </div>
                                    <div style="font-size: 11px; color: var(--text-muted);">Kâr Cüzdanı</div>
                                </td>
                                <td>
                                    <span class="badge-status <?= $statusClass ?>"><?= htmlspecialchars(strtoupper($req['status'])) ?></span>
                                </td>
                                <td class="text-end">
                                    <?php if ($req['status'] === 'pending'): ?>
                                        <form method="post" style="display:inline-block; margin-right: 5px;">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="request_id" value="<?= (int)$req['id'] ?>">
                                            <button type="submit" name="action" value="approve" class="btn-sm btn-approve"
                                                onclick="return confirm('Agent: <?= htmlspecialchars($req['agent_name']) ?>\nNet Ödenecek: <?= number_format($netAmount, 2) ?> ₺\n\nÖDEME YAPILDIKTAN SONRA ONAYLAYINIZ.');">
                                                Ödeme Yapıldı / Onayla <i class="ri-check-line"></i>
                                            </button>
                                        </form>
                                        <form method="post" class="d-inline-block">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="request_id" value="<?= (int)$req['id'] ?>">
                                            <button type="submit" name="action" value="reject" class="btn-sm btn-reject"
                                                    onclick="return confirm('Talebi reddetmek istediğinize emin misiniz? Bakiye Agent’a iade EDİLMEZ.');">
                                                Reddet
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span style="color: var(--text-muted); font-size: 12px;">İşlendi</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center" style="padding: 30px; color: var(--text-muted);">Henüz kâr çekim talebi yok.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '_admin_footer.php'; ?>