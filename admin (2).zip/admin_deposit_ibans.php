<?php
// admin/admin_deposit_ibans.php
require __DIR__ . '/require_admin.php'; // $pdo + $currentAdmin

$pageTitle    = 'IBAN Yönetimi';
$activeNav    = 'ibans';
$adminError   = null;
$adminSuccess = null;
$csrfFailed   = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !csrf_validate_request()) {
    $csrfFailed = true;
    $adminError = 'Oturum doğrulaması başarısız. Lütfen sayfayı yenileyip tekrar deneyin.';
}

// =====================
// 1) IBAN SİLME
// =====================
if (!$csrfFailed && isset($_POST['delete_iban'])) {
    $id = (int)$_POST['delete_iban'];
    $stmt = $pdo->prepare("DELETE FROM deposit_ibans WHERE id = ?");
    $stmt->execute([$id]);

    if (function_exists('bw_log_action')) {
        bw_log_action($pdo, 'iban', 'admin', (int)$currentAdmin['id'], 'delete', ['iban_id' => $id]);
    }

    header('Location: admin_deposit_ibans.php?ok=deleted');
    exit;
}

// =====================
// 2) IBAN KAYDET
// (Kota mantığı kaldırıldı, quota_limit/quota_used = 0 tutuluyor)
// =====================
if (!$csrfFailed && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_iban'])) {
    $id         = isset($_POST['id']) && $_POST['id'] !== '' ? (int)$_POST['id'] : null;
    $bankName   = trim($_POST['bank_name']    ?? '');
    $holderName = trim($_POST['holder_name'] ?? '');
    $iban       = trim($_POST['iban']         ?? '');
    $agentId    = isset($_POST['agent_id']) && $_POST['agent_id'] !== '' ? (int)$_POST['agent_id'] : null;
    $isActive   = isset($_POST['is_active']) ? 1 : 0;

    if ($bankName === '' || $iban === '') {
        $adminError = 'Banka adı ve IBAN zorunlu.';
    } else {
        if ($id) {
            // GÜNCELLE – quota_limit'e dokunmuyoruz (0 olarak kalabilir), limit kontrolü yok
            $stmt = $pdo->prepare("
                UPDATE deposit_ibans
                SET bank_name = ?, holder_name = ?, iban = ?, agent_id = ?, is_active = ?
                WHERE id = ?
            ");
            $stmt->execute([$bankName, $holderName, $iban, $agentId, $isActive, $id]);

            $adminSuccess = 'IBAN başarıyla güncellendi.';

            if (function_exists('bw_log_action')) {
                bw_log_action($pdo, 'iban', 'admin', (int)$currentAdmin['id'], 'update', ['iban_id' => $id]);
            }
        } else {
            // YENİ EKLE – quota_limit ve quota_used artık mantıksal olarak kullanılmıyor, 0 tutuluyor
            $ownerAdminId = (int)$currentAdmin['id'];
            $stmt = $pdo->prepare("
                INSERT INTO deposit_ibans (bank_name, holder_name, iban, agent_id, owner_admin_id, quota_limit, quota_used, is_active)
                VALUES (?, ?, ?, ?, ?, 0, 0, ?)
            ");
            $stmt->execute([$bankName, $holderName, $iban, $agentId, $ownerAdminId, $isActive]);

            $adminSuccess = 'Yeni IBAN havuza eklendi.';

            if (function_exists('bw_log_action')) {
                bw_log_action($pdo, 'iban', 'admin', (int)$currentAdmin['id'], 'create', [
                    'iban_id' => (int)$pdo->lastInsertId()
                ]);
            }
        }
    }
}

// =====================
// 3) VERİLERİ ÇEK
// =====================
$editIban = null;
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM deposit_ibans WHERE id = ? LIMIT 1");
    $stmt->execute([$id]);
    $editIban = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Aracılar
$agentsStmt = $pdo->query("SELECT id, name FROM deposit_agents WHERE is_active = 1 ORDER BY name ASC");
$agents = $agentsStmt->fetchAll(PDO::FETCH_ASSOC);

// IBAN Listesi
$listStmt = $pdo->query("
    SELECT di.*, da.name AS agent_name, a.username AS owner_name
    FROM deposit_ibans di
    LEFT JOIN deposit_agents da ON da.id = di.agent_id
    LEFT JOIN admins a ON a.id = di.owner_admin_id
    ORDER BY di.is_active DESC, di.id DESC
");
$ibans = $listStmt->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/_admin_header.php';
?>

<style>
    /* Form Kartı */
    .form-card {
        background: #fff; padding: 24px; border-radius: var(--radius-lg);
        box-shadow: var(--shadow-soft); margin-bottom: 30px; border: 1px solid var(--border-light);
    }
    .form-header {
        display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;
        padding-bottom: 15px; border-bottom: 1px solid var(--border-light);
    }
    .form-header h2 { margin: 0; font-size: 18px; color: var(--text-main); display: flex; align-items: center; gap: 8px; }

    .admin-form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
    .form-group { margin-bottom: 0; }
    .form-group label { display: block; font-size: 13px; font-weight: 600; color: var(--text-muted); margin-bottom: 6px; }
    .form-input { width: 100%; padding: 10px 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-light); background: #f8fafc; color: var(--text-main); font-size: 14px; transition: all 0.2s; }
    .form-input:focus { outline: none; border-color: var(--primary); background: #fff; box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1); }

    .full-width { grid-column: 1 / -1; }

    /* Butonlar */
    .btn-submit { background: var(--primary); color: #fff; border: none; padding: 12px 24px; border-radius: var(--radius-sm); font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; transition: all 0.2s; }
    .btn-submit:hover { background: #2563eb; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(37,99,235,0.2); }
    .btn-cancel { background: #f1f5f9; color: var(--text-muted); border: 1px solid var(--border-light); padding: 12px 20px; border-radius: var(--radius-sm); text-decoration: none; font-size: 14px; font-weight: 500; display: inline-flex; align-items: center; gap: 5px; }
    .btn-cancel:hover { background: #e2e8f0; color: var(--text-main); }

    /* Durum Badge'leri */
    .status-badge { padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; display: inline-flex; align-items: center; gap: 4px; }
    .status-active { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
    .status-passive { background: #f1f5f9; color: #64748b; border: 1px solid #e2e8f0; }

    /* Alert */
    .alert-box { padding: 15px; border-radius: var(--radius-sm); margin-bottom: 20px; display: flex; align-items: center; gap: 10px; font-size: 14px; }
    .alert-danger { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
    .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; }

    /* Aksiyon İkonları */
    .action-btn { width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; text-decoration: none; transition: all 0.2s; }
    .btn-edit { background: #eff6ff; color: var(--primary); }
    .btn-edit:hover { background: var(--primary); color: #fff; }
    .btn-del { background: #fef2f2; color: #dc2626; }
    .btn-del:hover { background: #dc2626; color: #fff; }
</style>

<div class="page-content">

    <?php if ($adminError): ?>
        <div class="alert-box alert-danger">
            <i class="ri-error-warning-fill" style="font-size: 18px;"></i>
            <?= htmlspecialchars($adminError) ?>
        </div>
    <?php endif; ?>

    <?php if ($adminSuccess || (isset($_GET['ok']) && $_GET['ok'] == 'deleted')): ?>
        <div class="alert-box alert-success">
            <i class="ri-checkbox-circle-fill" style="font-size: 18px;"></i>
            <?= htmlspecialchars($adminSuccess ?? 'İşlem başarıyla tamamlandı.') ?>
        </div>
    <?php endif; ?>

    <div class="form-card">
        <div class="form-header">
            <h2>
                <i class="ri-bank-card-2-line" style="color: var(--primary);"></i>
                <?= $editIban ? 'IBAN Düzenle' : 'Yeni IBAN Ekle' ?>
            </h2>
            <?php if ($editIban): ?>
                <a href="admin_deposit_ibans.php" class="btn-cancel"><i class="ri-close-line"></i> İptal</a>
            <?php endif; ?>
        </div>

        <form method="post">
            <?= csrf_field(); ?>
            <?php if ($editIban): ?>
                <input type="hidden" name="id" value="<?= (int)$editIban['id'] ?>">
            <?php endif; ?>

            <div class="admin-form-grid">
                <div class="form-group">
                    <label>Banka Adı</label>
                    <input type="text" name="bank_name" class="form-input" placeholder="Örn: Ziraat Bankası"
                           value="<?= htmlspecialchars($editIban['bank_name'] ?? '') ?>" required>
                </div>

                <div class="form-group">
                    <label>Hesap Sahibi (Ad Soyad)</label>
                    <input type="text" name="holder_name" class="form-input" placeholder="Örn: Ahmet Yılmaz"
                           value="<?= htmlspecialchars($editIban['holder_name'] ?? '') ?>" required>
                </div>

                <div class="form-group full-width">
                    <label>IBAN Numarası</label>
                    <input type="text" name="iban" class="form-input" placeholder="TR..." style="font-family: monospace; letter-spacing: 1px;"
                           value="<?= htmlspecialchars($editIban['iban'] ?? '') ?>" required>
                </div>

                <div class="form-group">
                    <label>Bağlı Aracı (Finans)</label>
                    <select name="agent_id" class="form-input">
                        <option value="">— Seçilmedi —</option>
                        <?php
                        $currentAgentId = $editIban['agent_id'] ?? null;
                        foreach ($agents as $agent):
                            $selected = ($currentAgentId == $agent['id']) ? 'selected' : '';
                        ?>
                            <option value="<?= (int)$agent['id'] ?>" <?= $selected ?>>
                                <?= htmlspecialchars($agent['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group full-width" style="margin-top: 5px;">
                    <label class="checkbox-label" style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-weight: 600; color: var(--text-main);">
                        <input type="checkbox" name="is_active" style="width: 18px; height: 18px;"
                            <?= isset($editIban['is_active']) ? ($editIban['is_active'] ? 'checked' : '') : 'checked' ?>>
                        <span>IBAN Aktif ve Kullanılabilir</span>
                    </label>
                </div>

                <div class="full-width" style="margin-top: 10px;">
                    <button type="submit" name="save_iban" class="btn-submit">
                        <i class="ri-save-line"></i>
                        <?= $editIban ? 'Değişiklikleri Kaydet' : 'IBAN Oluştur' ?>
                    </button>
                </div>
            </div>
        </form>
    </div>

    <div class="table-container">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Banka & Sahibi</th>
                    <th>IBAN</th>
                    <th>Aracı</th>
                    <th>Ekleyen</th>
                    <th>Statü</th>
                    <th style="text-align: right;">İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($ibans as $i): ?>
                <tr>
                    <td><span style="font-family: monospace; color: var(--text-muted);">#<?= (int)$i['id'] ?></span></td>

                    <td>
                        <div style="font-weight: 600; color: var(--text-main);"><?= htmlspecialchars($i['bank_name']) ?></div>
                        <div style="font-size: 12px; color: var(--text-muted);"><?= htmlspecialchars($i['holder_name']) ?></div>
                    </td>

                    <td>
                        <span style="font-family: monospace; background: #f1f5f9; padding: 4px 8px; border-radius: 4px; font-size: 12px; color: var(--text-main);">
                            <?= htmlspecialchars($i['iban']) ?>
                        </span>
                    </td>

                    <td>
                        <?php if ($i['agent_name']): ?>
                            <span style="display: inline-flex; align-items: center; gap: 5px; font-size: 12px;">
                                <i class="ri-user-star-line" style="color: var(--primary);"></i>
                                <?= htmlspecialchars($i['agent_name']) ?>
                            </span>
                        <?php else: ?>
                            <span style="color: var(--text-muted);">-</span>
                        <?php endif; ?>
                    </td>

                    <td style="font-size: 12px; color: var(--text-muted);">
                        <?= htmlspecialchars($i['owner_name'] ?? '-') ?>
                    </td>

                    <td>
                        <?php if ($i['is_active']): ?>
                            <span class="status-badge status-active">
                                <i class="ri-checkbox-circle-line"></i> Aktif
                            </span>
                        <?php else: ?>
                            <span class="status-badge status-passive">
                                <i class="ri-prohibited-line"></i> Pasif
                            </span>
                        <?php endif; ?>
                    </td>

                    <td style="text-align: right;">
                        <div style="display: inline-flex; gap: 5px;">
                            <a href="admin_deposit_ibans.php?edit=<?= (int)$i['id'] ?>" class="action-btn btn-edit" title="Düzenle">
                                <i class="ri-pencil-line"></i>
                            </a>
                            <form method="post" style="display: inline;" onsubmit="return confirm('Bu IBAN\'ı silmek istediğinize emin misiniz?');">
                                <?= csrf_field(); ?>
                                <input type="hidden" name="delete_iban" value="<?= (int)$i['id'] ?>">
                                <button type="submit" class="action-btn btn-del" title="Sil" style="border:none; background:none; cursor:pointer;">
                                    <i class="ri-delete-bin-line"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>

                <?php if (empty($ibans)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px; color: var(--text-muted);">
                            <i class="ri-bank-card-2-line" style="font-size: 48px; opacity: 0.5; margin-bottom: 10px; display: block;"></i>
                            Havuzda henüz IBAN bulunmuyor.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/_admin_footer.php'; ?>
