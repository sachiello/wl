<?php
// admin/index.php
session_start();
require __DIR__ . '/../../config/config.php';

// Güvenlik
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

$pageTitle  = 'Komuta Merkezi';
$activeNav  = 'dashboard';

// === BAREMLER (Operasyon Eşikleri) ===
$THRESH_AGENT_CASH_RISK   = 500000;  // Agent kasası risk eşiği
$THRESH_SITE_LOW_BALANCE  = 5000;    // Site düşük bakiye eşiği
$THRESH_PENDING_DEP       = 50;      // Bekleyen yatırım tıkanık eşiği
$THRESH_PENDING_WD        = 20;      // Bekleyen çekim tıkanık eşiği
$THRESH_IBAN_USAGE_RATIO  = 0.8;     // IBAN günlük limit kullanım oranı
$THRESH_AGENT_INACTIVE_HR = 24;      // Agent inaktivite eşiği (saat)

$today = date('Y-m-d');

// --- KOMİSYON ORANLARI (ÖRNEK) ---
// NOT: Şu an global varsayılan olarak kullanılıyor.
// İleride site bazlı/agent bazlı komisyonlara göre ayrı hesap yapabiliriz.
$DEPOSIT_COMM_RATE  = 0.04;  // %4 yatırım komisyonu (sitelerin yatırımlarından)
$WITHDRAW_COMM_RATE = 0.01;  // %1 site çekim payı

// --- USER YÖNETİM MERKEZİ METRİKLERİ ---
// Toplam Yatırım (User'lar)
$userTotalDeposit = $pdo->query("
    SELECT COALESCE(SUM(amount_try), 0) 
    FROM deposit_orders 
    WHERE status = 'confirmed'
")->fetchColumn();

// Toplam Çekim (User'lar)
$userTotalWithdraw = $pdo->query("
    SELECT COALESCE(SUM(amount), 0) 
    FROM withdraw_requests 
    WHERE status IN ('approved','paid','completed')
")->fetchColumn();

// Bugünün user istatistikleri
$todayStats = $pdo->query("
    SELECT
        COALESCE(SUM(CASE WHEN status = 'confirmed' THEN amount_try END), 0) AS today_deposit_try,
        COALESCE(COUNT(CASE WHEN status = 'confirmed' THEN 1 END), 0)       AS today_deposit_count
    FROM deposit_orders
    WHERE DATE(created_at) = CURDATE()
")->fetch(PDO::FETCH_ASSOC);

$todayWdStats = $pdo->query("
    SELECT
        COALESCE(SUM(CASE WHEN status IN ('approved','paid','completed') THEN amount END), 0) AS today_withdraw_try,
        COALESCE(COUNT(CASE WHEN status IN ('approved','paid','completed') THEN 1 END), 0)     AS today_withdraw_count
    FROM withdraw_requests
    WHERE DATE(created_at) = CURDATE()
")->fetch(PDO::FETCH_ASSOC);

// Bekleyen user işlemleri
$pendingDep = $pdo->query("
    SELECT COUNT(*) 
    FROM deposit_orders 
    WHERE status = 'pending'
")->fetchColumn();

$pendingWd = $pdo->query("
    SELECT COUNT(*) 
    FROM withdraw_requests 
    WHERE status = 'pending'
")->fetchColumn();

// Son bekleyen user işlemleri (kuyruk)
$recentPendingDeposits = $pdo->query("
    SELECT d.id, u.username, d.amount_try, d.created_at
    FROM deposit_orders d
    JOIN users u ON u.id = d.user_id
    WHERE d.status = 'pending'
    ORDER BY d.created_at DESC
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

$recentPendingWithdraws = $pdo->query("
    SELECT w.id, u.username, w.amount, w.created_at
    FROM withdraw_requests w
    JOIN users u ON u.id = w.user_id
    WHERE w.status = 'pending'
    ORDER BY w.created_at DESC
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

// --- AGENT YÖNETİM MERKEZİ METRİKLERİ ---
// Toplam Agent Yatırımı (Bize gelen onaylı agent bakiyeleri - TEMİNAT, BİZİM DEĞİL)
$agentTotalTopup = $pdo->query("
    SELECT COALESCE(SUM(amount_credited), 0)
    FROM agent_balance_requests
    WHERE status = 'approved'
")->fetchColumn();

// Agent sistem teminatı ve kasaları (limitler vs.)
$agentsSystemBalance = $pdo->query("
    SELECT COALESCE(SUM(system_balance), 0)
    FROM deposit_agents
")->fetchColumn();

// Agent kasalarında sahada dönen para
$agentsCash = $pdo->query("
    SELECT COALESCE(SUM(current_cash), 0) 
    FROM deposit_agents
")->fetchColumn();

// Bekleyen agent işlemleri
$pendingAgentReq = $pdo->query("
    SELECT COUNT(*) 
    FROM agent_balance_requests 
    WHERE status = 'pending'
")->fetchColumn();

$pendingAgentWithdraw = $pdo->query("
    SELECT COUNT(*) 
    FROM agent_withdraw_orders 
    WHERE status = 'pending'
")->fetchColumn();

// --- SITE YÖNETİM MERKEZİ METRİKLERİ ---
// Sitelerin toplam yatırımı (bize yükledikleri bakiye - GERÇEK PARA)
$siteTotalTopup = $pdo->query("
    SELECT COALESCE(SUM(amount), 0)
    FROM site_balance_requests
    WHERE status = 'approved'
")->fetchColumn();

// Sitelerin toplam mutabakatı (çektikleri bakiye)
$siteTotalSettlement = $pdo->query("
    SELECT COALESCE(SUM(amount), 0)
    FROM site_withdrawals
    WHERE status = 'completed'
")->fetchColumn();

// Sitelerin anlık bakiyeleri
$sitesBalance = $pdo->query("
    SELECT COALESCE(SUM(balance), 0) 
    FROM sites
")->fetchColumn();

// Sistemdeki yükümlülük: sahadaki agent kasaları + sitelerin bakiyesi
$systemExposure = $agentsCash + $sitesBalance;

// User net pozisyonu (bilgi amaçlı)
$userNetPosition = $userTotalDeposit - $userTotalWithdraw;

// --- BETWALLET CÜZDAN (İÇ KASA HESABI) ---
// Kasaya giren gerçek para (agent teminatları + site yatırımları)
$totalRealIn = $agentTotalTopup + $siteTotalTopup;

// Bizim kazancımız: sitelerden gelen yatırım komisyonu + site çekim payı
// (Şu an global varsayılan oranlarla yaklaşık hesap)
$betwalletDepositCommissionApprox  = $userTotalDeposit   * $DEPOSIT_COMM_RATE;   // user yatırımlarının %4'ü
$betwalletWithdrawFeeApprox       = $siteTotalSettlement * $WITHDRAW_COMM_RATE;  // site çekimlerinin %1'i
$betwalletTotalCommission         = $betwalletDepositCommissionApprox + $betwalletWithdrawFeeApprox;

// Minimum olması gereken kasa: sistem yükümlülüklerini (agent kasaları + site bakiyesi) karşılayacak nakit
$minRequiredCash = $systemExposure;

// "Senin paran": Agent teminatlarını HARİÇ tutan, sadece komisyonlardan oluşan öz sermaye
$theoreticalEquity = $betwalletTotalCommission;

// --- GENEL SAYILAR ---
$activeAgents = $pdo->query("
    SELECT COUNT(*) 
    FROM deposit_agents 
    WHERE is_active = 1
")->fetchColumn();

$activeSites = $pdo->query("
    SELECT COUNT(*) 
    FROM sites 
    WHERE is_active = 1
")->fetchColumn();

$registeredUsers = $pdo->query("
    SELECT COUNT(*) 
    FROM users
")->fetchColumn();

// --- SMART ALERTS (Kritik Sistem Uyarıları) ---
$alerts = [];

// Kural 1: Riskli Agent (Kasasında çok para biriken)
$riskyAgents = $pdo->query("
    SELECT name, current_cash 
    FROM deposit_agents 
    WHERE current_cash > {$THRESH_AGENT_CASH_RISK} 
      AND is_active = 1
")->fetchAll(PDO::FETCH_ASSOC);

foreach ($riskyAgents as $ra) {
    $alerts[] = [
        'type' => 'danger',
        'icon' => 'ri-alarm-warning-line',
        'msg'  => "RİSK: <b>{$ra['name']}</b>'ın kasasında <b>" . number_format($ra['current_cash'], 2) . " ₺</b> birikti. Tahsilat/çekim yönlendirmesi yap!"
    ];
}

// Kural 2: Site Bakiyesi Kritik
$lowBalanceSites = $pdo->query("
    SELECT name, balance 
    FROM sites 
    WHERE balance < {$THRESH_SITE_LOW_BALANCE} 
      AND is_active = 1
")->fetchAll(PDO::FETCH_ASSOC);

foreach ($lowBalanceSites as $lbs) {
    $alerts[] = [
        'type' => 'warning',
        'icon' => 'ri-battery-low-line',
        'msg'  => "DİKKAT: <b>{$lbs['name']}</b> sitesinin bakiyesi kritik seviyede (<b>" . number_format($lbs['balance'], 2) . " ₺</b>). Kullanıcı çekimleri durabilir."
    ];
}

// Kural 3: Sistem Tıkanıklığı
if ($pendingDep > $THRESH_PENDING_DEP || $pendingWd > $THRESH_PENDING_WD) {
    $alerts[] = [
        'type' => 'danger',
        'icon' => 'ri-speed-mini-line',
        'msg'  => "ACİL: Sistemde işlem yığılması var! (Bekleyen Yatırım: $pendingDep, Çekim: $pendingWd). Operasyonu güçlendir."
    ];
}

// Kural 4: Şüpheli Kullanıcı Aktivitesi (Son 1 saatte çok çekim)
$spamUsers = $pdo->query("
    SELECT u.username, COUNT(*) AS cnt 
    FROM withdraw_requests w 
    JOIN users u ON u.id = w.user_id 
    WHERE w.created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR) 
    GROUP BY w.user_id 
    HAVING cnt > 5
")->fetchAll(PDO::FETCH_ASSOC);

foreach ($spamUsers as $su) {
    $alerts[] = [
        'type' => 'info',
        'icon' => 'ri-spy-line',
        'msg'  => "GÜVENLİK: <b>{$su['username']}</b> son 1 saatte <b>{$su['cnt']}</b> adet çekim talebi oluşturdu. Detay kontrol et."
    ];
}

// Kural 5: IBAN Yakın Kota Uyarısı
$riskyIbans = $pdo->query("
    SELECT bank_name, holder_name, current_daily_txn, max_daily_txn 
    FROM deposit_ibans 
    WHERE max_daily_txn > 0 
      AND current_daily_txn > (max_daily_txn * {$THRESH_IBAN_USAGE_RATIO})
")->fetchAll(PDO::FETCH_ASSOC);

foreach ($riskyIbans as $ri) {
    $alerts[] = [
        'type' => 'warning',
        'icon' => 'ri-traffic-light-line',
        'msg'  => "IBAN RİSK: <b>{$ri['bank_name']} ({$ri['holder_name']})</b> limitine yaklaşıyor ({$ri['current_daily_txn']}/{$ri['max_daily_txn']}). Yeni IBAN/rota aç."
    ];
}

// Kural 6: Agent İnaktivite Uyarısı
$inactiveAgents = $pdo->query("
    SELECT name, last_login
    FROM deposit_agents
    WHERE is_active = 1 
      AND last_login IS NOT NULL
      AND last_login < DATE_SUB(NOW(), INTERVAL {$THRESH_AGENT_INACTIVE_HR} HOUR)
")->fetchAll(PDO::FETCH_ASSOC);

foreach ($inactiveAgents as $ia) {
    $lastLogin = date('d.m H:i', strtotime($ia['last_login']));
    $alerts[] = [
        'type' => 'info',
        'icon' => 'ri-sleep-line',
        'msg'  => "İNAKTİF: <b>{$ia['name']}</b> {$THRESH_AGENT_INACTIVE_HR}+ saattir panele girmedi (Son giriş: $lastLogin). Agent'ı uyandır."
    ];
}

include __DIR__ . '/_admin_header.php';
?>

<style>
    /* ===== KOMUTA MERKEZİ GENEL STİL (SIDEBAR'A DOKUNMAZ) ===== */


    .bw-admin-dashboard {
        padding: 1.5rem 1rem 2rem;
    }

    .bw-dashboard-title {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 1.25rem;
        flex-wrap: wrap;
    }

    .bw-dashboard-title h1 {
        font-size: 1.5rem;
        font-weight: 700;
        color: #f9fafb;
        margin: 0;
        display: flex;
        align-items: center;
        gap: .5rem;
    }

    .bw-dashboard-title h1 i {
        font-size: 1.6rem;
        color: #f97316;
    }

    .bw-dashboard-sub {
        font-size: .9rem;
        color: #9ca3af;
        margin-top: .25rem;
    }

    .bw-dashboard-badges {
        display: flex;
        gap: .5rem;
        flex-wrap: wrap;
        margin-top: .5rem;
    }

    .bw-chip {
        padding: .25rem .75rem;
        border-radius: 999px;
        font-size: .75rem;
        border: 1px solid rgba(156, 163, 175, 0.4);
        color: #e5e7eb;
        display: inline-flex;
        align-items: center;
        gap: .3rem;
        background: linear-gradient(135deg, rgba(31, 41, 55, .9), rgba(15, 23, 42, .9));
    }

    .bw-chip strong {
        color: #f97316;
        font-weight: 600;
    }

    /* === TABLAR: USER / AGENT / SITE / WALLET === */

    .bw-tab-nav {
        display: inline-flex;
        border-radius: 999px;
        background: rgba(15, 23, 42, 0.9);
        border: 1px solid rgba(55, 65, 81, 0.8);
        padding: .15rem;
        margin: 0 0 1rem 0;
        gap: .15rem;
        flex-wrap: wrap;
    }

    .bw-tab-btn {
        border: none;
        outline: none;
        background: transparent;
        color: #9ca3af;
        font-size: .8rem;
        font-weight: 500;
        padding: .45rem .9rem;
        border-radius: 999px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: .35rem;
        transition: background .15s ease, color .15s ease, box-shadow .15s ease;
        white-space: nowrap;
    }

    .bw-tab-btn i {
        font-size: 1rem;
    }

    .bw-tab-btn.is-active {
        background: linear-gradient(135deg, #ef4444, #b91c1c);
        color: #f9fafb;
        box-shadow: 0 0 18px rgba(220, 38, 38, .6);
    }

    .bw-tab-panel {
        display: none;
        margin-top: .5rem;
    }

    .bw-tab-panel.is-active {
        display: block;
    }

    /* === KPI KARTLARI === */

    .bw-kpi-card {
        background: radial-gradient(circle at top left, rgba(248, 250, 252, .07), transparent),
                    linear-gradient(135deg, rgba(15, 23, 42, 0.96), rgba(15, 23, 42, 0.98));
        border-radius: 1.1rem;
        border: 1px solid rgba(148, 163, 184, 0.25);
        box-shadow: 0 18px 45px rgba(0, 0, 0, 0.55);
        padding: 1rem 1.2rem;
        height: 100%;
        position: relative;
        overflow: hidden;
    }

    .bw-kpi-card::after {
        content: '';
        position: absolute;
        inset: 0;
        background: radial-gradient(circle at top right, rgba(220, 38, 38, .16), transparent 55%);
        opacity: .9;
        pointer-events: none;
    }

    .bw-kpi-inner {
        position: relative;
        z-index: 1;
        display: flex;
        justify-content: space-between;
        align-items: stretch;
        gap: .5rem;
    }

    .bw-kpi-meta {
        display: flex;
        flex-direction: column;
        gap: .35rem;
    }

    .bw-kpi-label {
        font-size: .75rem;
        text-transform: uppercase;
        letter-spacing: .08em;
        color: #9ca3af;
        font-weight: 600;
    }

    .bw-kpi-value {
        font-size: 1.3rem;
        font-weight: 700;
        color: #f9fafb;
        white-space: nowrap;
    }

    .bw-kpi-sub {
        font-size: .75rem;
        color: #9ca3af;
    }

    .bw-kpi-icon {
        width: 42px;
        height: 42px;
        border-radius: 999px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: radial-gradient(circle at 30% 0, rgba(248, 250, 252, .4), transparent),
                    linear-gradient(135deg, #ef4444, #b91c1c);
        color: #fef2f2;
        box-shadow: 0 0 25px rgba(220, 38, 38, .55);
        flex-shrink: 0;
    }

    .bw-kpi-icon i {
        font-size: 1.4rem;
    }

    .bw-kpi-pill {
        font-size: .7rem;
        padding: .15rem .55rem;
        border-radius: 999px;
        border: 1px solid rgba(156, 163, 175, 0.6);
        color: #e5e7eb;
        display: inline-flex;
        align-items: center;
        gap: .25rem;
    }

    .bw-kpi-pill span {
        color: #22c55e;
    }

    /* === KRİTİK SİSTEM UYARILARI – OKUNAK TASARIM === */

    .bw-alerts-card {
        border-radius: 1.1rem;
        border: 1px solid rgba(148, 163, 184, 0.35);
        background: linear-gradient(145deg, rgba(15, 23, 42, 0.98), rgba(15, 23, 42, 1));
        box-shadow: 0 20px 50px rgba(0, 0, 0, 0.65);
        overflow: hidden;
        margin-bottom: 1.25rem;
    }

    .bw-alerts-header {
        padding: .85rem 1.1rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: #111827;
        border-bottom: 1px solid rgba(55, 65, 81, 0.9);
        color: #f9fafb;
    }

    .bw-alerts-header h6 {
        margin: 0;
        font-weight: 700;
        font-size: .9rem;
        letter-spacing: .06em;
        text-transform: uppercase;
        display: flex;
        align-items: center;
        gap: .4rem;
    }

    .bw-alerts-header h6 i {
        color: #f97316;
    }

    .bw-alerts-header span.badge {
        background: rgba(248, 250, 252, .95) !important;
        color: #b91c1c !important;
        border-radius: 999px;
        font-size: .7rem;
        padding: .25rem .6rem;
        font-weight: 600;
    }

    .bw-alert-row {
        display: flex;
        gap: .75rem;
        padding: .7rem 1rem;
        font-size: .8rem;
        align-items: center;
        background: #020617;
        border-bottom: 1px solid rgba(31, 41, 55, .95);
        border-left: 3px solid rgba(75, 85, 99, .9);
    }

    .bw-alert-row:last-child {
        border-bottom: none;
    }

    .bw-alert-row.alert-danger {
        border-left-color: #ef4444;
    }

    .bw-alert-row.alert-warning {
        border-left-color: #fbbf24;
    }

    .bw-alert-row.alert-info {
        border-left-color: #38bdf8;
    }

    .bw-alert-icon {
        width: 32px;
        height: 32px;
        border-radius: 999px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        font-size: 1.15rem;
        background: rgba(31, 41, 55, .9);
        color: #e5e7eb;
    }

    .bw-alert-row.alert-danger .bw-alert-icon {
        color: #fecaca;
    }

    .bw-alert-row.alert-warning .bw-alert-icon {
        color: #fef3c7;
    }

    .bw-alert-row.alert-info .bw-alert-icon {
        color: #e0f2fe;
    }

    .bw-alert-text {
        color: #e5e7eb;
    }

    .bw-alert-text b {
        color: #fed7aa;
    }

    .bw-no-alerts {
        padding: .9rem 1.1rem;
        font-size: .8rem;
        color: #a7f3d0;
        background: rgba(22, 163, 74, .18);
        display: flex;
        align-items: center;
        gap: .5rem;
    }

    .bw-no-alerts i {
        font-size: 1.2rem;
    }

    /* === GENEL BLOKLAR === */

    .bw-section-card {
        border-radius: 1.1rem;
        border: 1px solid rgba(148, 163, 184, 0.35);
        background: linear-gradient(145deg, rgba(15, 23, 42, 0.96), rgba(15, 23, 42, 1));
        box-shadow: 0 18px 40px rgba(0, 0, 0, .6);
        padding: .95rem 1.1rem 1.1rem;
        height: 100%;
    }

    .bw-section-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: .7rem;
    }

    .bw-section-header h6 {
        margin: 0;
        font-size: .85rem;
        text-transform: uppercase;
        letter-spacing: .08em;
        color: #9ca3af;
    }

    .bw-section-header span {
        font-size: .75rem;
        color: #6b7280;
    }

    .bw-quick-link-grid .btn {
        border-radius: .9rem;
        border-width: 1px;
        border-color: rgba(148, 163, 184, 0.65);
        background: radial-gradient(circle at top left, rgba(148, 163, 184, .25), transparent),
                    linear-gradient(135deg, rgba(17, 24, 39, 1), rgba(15, 23, 42, 1));
        color: #e5e7eb;
        font-size: .8rem;
        box-shadow: 0 8px 20px rgba(0, 0, 0, .6);
        transition: transform .12s ease, box-shadow .12s ease, border-color .12s ease;
    }

    .bw-quick-link-grid .btn i {
        font-size: 1.3rem;
        margin-bottom: .2rem;
    }

    .bw-quick-link-grid .btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 14px 30px rgba(0, 0, 0, .7);
        border-color: #f97316;
    }

    .bw-mini-table {
        width: 100%;
        font-size: .78rem;
        border-collapse: collapse;
        margin-top: .4rem;
    }

    .bw-mini-table thead {
        color: #9ca3af;
        text-transform: uppercase;
        letter-spacing: .06em;
        font-size: .7rem;
    }

    .bw-mini-table th,
    .bw-mini-table td {
        padding: .3rem .2rem;
        border-bottom: 1px solid rgba(31, 41, 55, .85);
        white-space: nowrap;
    }

    .bw-mini-table tbody tr:last-child td {
        border-bottom: none;
    }

    .bw-badge-time {
        color: #6b7280;
        font-size: .72rem;
    }

    .bw-health-note {
        font-size: .78rem;
        color: #9ca3af;
        margin-bottom: .4rem;
    }

    .bw-health-pill {
        font-size: .72rem;
        border-radius: 999px;
        padding: .15rem .5rem;
        display: inline-flex;
        align-items: center;
        gap: .25rem;
        border: 1px solid rgba(148, 163, 184, 0.5);
        color: #e5e7eb;
        margin-right: .25rem;
        margin-bottom: .25rem;
    }

    .bw-health-pill i {
        font-size: .9rem;
    }

    @media (max-width: 767.98px) {
        .bw-admin-dashboard {
            padding: 1rem .75rem 1.5rem;
        }

        .bw-kpi-card {
            padding: .9rem 1rem;
        }

        .bw-kpi-value {
            font-size: 1.1rem;
        }

        .bw-dashboard-title {
            flex-direction: column;
            align-items: flex-start;
        }

        .bw-tab-nav {
            width: 100%;
        }

        .bw-tab-btn {
            flex: 1 1 auto;
            justify-content: center;
        }
    }
</style>

<div class="container-fluid bw-admin-dashboard">

    <!-- BAŞLIK + GENEL ÖZET -->
    <div class="bw-dashboard-title">
        <div>
            <h1>
                <i class="ri-radar-line"></i>
                Operasyon Komuta Merkezi
            </h1>
            <div class="bw-dashboard-sub">
                User, agent, site ve BetWallet kasa akışını dört ayrı yönetim sekmesinden takip ediyorsun.
            </div>
            <div class="bw-dashboard-badges">
                <div class="bw-chip">
                    <i class="ri-shield-check-line"></i>
                    Bugün: <strong><?= htmlspecialchars(date('d.m.Y')) ?></strong>
                </div>
                <div class="bw-chip">
                    <i class="ri-team-line"></i>
                    Aktif Agent: <strong><?= (int)$activeAgents ?></strong>
                </div>
                <div class="bw-chip">
                    <i class="ri-building-4-line"></i>
                    Aktif Site: <strong><?= (int)$activeSites ?></strong>
                </div>
                <div class="bw-chip">
                    <i class="ri-user-3-line"></i>
                    Üye: <strong><?= (int)$registeredUsers ?></strong>
                </div>
            </div>
        </div>
    </div>

    <!-- KRİTİK SİSTEM UYARILARI -->
    <div class="bw-alerts-card">
        <div class="bw-alerts-header">
            <h6>
                <i class="ri-warning-line"></i>
                Kritik Sistem Uyarıları
            </h6>
            <span class="badge">
                <?= !empty($alerts) ? count($alerts) . ' BİLDİRİM' : '0 KRİTİK' ?>
            </span>
        </div>
        <div>
            <?php if (!empty($alerts)): ?>
                <?php foreach ($alerts as $alert): ?>
                    <div class="bw-alert-row alert-<?= $alert['type'] ?>">
                        <div class="bw-alert-icon">
                            <i class="<?= $alert['icon'] ?>"></i>
                        </div>
                        <div class="bw-alert-text">
                            <?= $alert['msg'] ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="bw-no-alerts">
                    <i class="ri-shield-check-line"></i>
                    Sistem stabil. Agent kasaları, site bakiyeleri ve bekleyen işlemler güvenli aralıkta.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- SEKME NAV: USER / AGENT / SITE / WALLET -->
    <div class="bw-tab-nav" id="bwTabNav">
        <button class="bw-tab-btn is-active" data-tab="user">
            <i class="ri-user-settings-line"></i> User Yönetim Merkezi
        </button>
        <button class="bw-tab-btn" data-tab="agent">
            <i class="ri-user-star-line"></i> Agent Yönetim Merkezi
        </button>
        <button class="bw-tab-btn" data-tab="site">
            <i class="ri-building-2-line"></i> Site Yönetim Merkezi
        </button>
        <button class="bw-tab-btn" data-tab="wallet">
            <i class="ri-wallet-3-line"></i> BetWallet Cüzdan
        </button>
    </div>

    <!-- USER YÖNETİM MERKEZİ PANELİ -->
    <div class="bw-tab-panel is-active" data-tab-panel="user">

        <!-- USER KPI BAR -->
        <div class="row mb-4">
            <div class="col-xl-3 col-md-6 mb-3">
                <div class="bw-kpi-card">
                    <div class="bw-kpi-inner">
                        <div class="bw-kpi-meta">
                            <div class="bw-kpi-label">Toplam Yatırım (User)</div>
                            <div class="bw-kpi-value"><?= number_format($userTotalDeposit, 2) ?> ₺</div>
                            <div class="bw-kpi-sub">User tarafı onaylanmış yatırımlar</div>
                        </div>
                        <div class="text-right d-flex flex-column align-items-end justify-content-between">
                            <div class="bw-kpi-icon">
                                <i class="ri-arrow-down-circle-line"></i>
                            </div>
                            <span class="bw-kpi-pill">
                                <i class="ri-time-line"></i>
                                <span>Bugün: <?= number_format($todayStats['today_deposit_try'] ?? 0, 2) ?> ₺</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-3">
                <div class="bw-kpi-card">
                    <div class="bw-kpi-inner">
                        <div class="bw-kpi-meta">
                            <div class="bw-kpi-label">Toplam Çekim (User)</div>
                            <div class="bw-kpi-value"><?= number_format($userTotalWithdraw, 2) ?> ₺</div>
                            <div class="bw-kpi-sub">Kullanıcılara ödenen toplam</div>
                        </div>
                        <div class="text-right d-flex flex-column align-items-end justify-content-between">
                            <div class="bw-kpi-icon" style="background: linear-gradient(135deg,#0f766e,#22c55e); box-shadow: 0 0 25px rgba(16,185,129,.55);">
                                <i class="ri-hand-coin-line"></i>
                            </div>
                            <span class="bw-kpi-pill">
                                <i class="ri-time-line"></i>
                                <span>Bugün: <?= number_format($todayWdStats['today_withdraw_try'] ?? 0, 2) ?> ₺</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-3">
                <div class="bw-kpi-card">
                    <div class="bw-kpi-inner">
                        <div class="bw-kpi-meta">
                            <div class="bw-kpi-label">User Bekleyen İşlemler</div>
                            <div class="bw-kpi-value"><?= (int)$pendingDep ?> / <?= (int)$pendingWd ?></div>
                            <div class="bw-kpi-sub">Yatırım / Çekim kuyruğu</div>
                        </div>
                        <div class="text-right d-flex flex-column align-items-end justify-content-between">
                            <div class="bw-kpi-icon" style="background: linear-gradient(135deg,#6366f1,#4f46e5); box-shadow: 0 0 25px rgba(79,70,229,.6);">
                                <i class="ri-time-line"></i>
                            </div>
                            <span class="bw-kpi-pill">
                                <i class="ri-error-warning-line"></i>
                                <span>Dep. barem: <?= (int)$THRESH_PENDING_DEP ?></span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-3">
                <div class="bw-kpi-card">
                    <div class="bw-kpi-inner">
                        <div class="bw-kpi-meta">
                            <div class="bw-kpi-label">Sistem Yükümlülüğü</div>
                            <div class="bw-kpi-value"><?= number_format($systemExposure, 2) ?> ₺</div>
                            <div class="bw-kpi-sub">Agent kasaları + site bakiyeleri</div>
                        </div>
                        <div class="text-right d-flex flex-column align-items-end justify-content-between">
                            <div class="bw-kpi-icon" style="background: linear-gradient(135deg,#f97316,#ea580c); box-shadow: 0 0 25px rgba(249,115,22,.6);">
                                <i class="ri-global-line"></i>
                            </div>
                            <span class="bw-kpi-pill">
                                <i class="ri-building-4-line"></i>
                                <span>Toplam site bakiyesi: <?= number_format($sitesBalance, 0) ?> ₺</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- USER BEKLEYEN İŞLEMLER + HIZLI YÖNETİM -->
        <div class="row mb-3">
            <div class="col-lg-7 mb-3">
                <div class="bw-section-card">
                    <div class="bw-section-header">
                        <h6>Bekleyen User İşlemleri</h6>
                        <span>Yatırım / çekim kuyruğu</span>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3 mb-md-0">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <span class="text-muted" style="font-size:.76rem;">Bekleyen Yatırımlar</span>
                                <a href="deposits.php" style="font-size:.75rem; color:#f97316;">Tümünü gör</a>
                            </div>
                            <table class="bw-mini-table">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Kullanıcı</th>
                                    <th>Tutar</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if (!empty($recentPendingDeposits)): ?>
                                    <?php foreach ($recentPendingDeposits as $d): ?>
                                        <tr>
                                            <td>#<?= (int)$d['id'] ?></td>
                                            <td><?= htmlspecialchars($d['username']) ?></td>
                                            <td>
                                                <?= number_format($d['amount_try'], 2) ?> ₺
                                                <div class="bw-badge-time">
                                                    <?= date('d.m H:i', strtotime($d['created_at'])) ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="3">Bekleyen yatırım talebi yok.</td></tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <span class="text-muted" style="font-size:.76rem;">Bekleyen Çekimler</span>
                                <a href="withdrawals.php" style="font-size:.75rem; color:#38bdf8;">Tümünü gör</a>
                            </div>
                            <table class="bw-mini-table">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Kullanıcı</th>
                                    <th>Tutar</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if (!empty($recentPendingWithdraws)): ?>
                                    <?php foreach ($recentPendingWithdraws as $w): ?>
                                        <tr>
                                            <td>#<?= (int)$w['id'] ?></td>
                                            <td><?= htmlspecialchars($w['username']) ?></td>
                                            <td>
                                                <?= number_format($w['amount'], 2) ?> ₺
                                                <div class="bw-badge-time">
                                                    <?= date('d.m H:i', strtotime($w['created_at'])) ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="3">Bekleyen çekim talebi yok.</td></tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="mt-3" style="font-size:.78rem; color:#9ca3af;">
                        User tarafındaki tıkanmaları buradan anlık takip edebilirsin. Kuyruk anormal yükselirse agent dağıtımını artır.
                    </div>
                </div>
            </div>

            <div class="col-lg-5 mb-3">
                <div class="bw-section-card">
                    <div class="bw-section-header">
                        <h6>User Hızlı Yönetim</h6>
                        <span>Sık kullandığın sayfalar</span>
                    </div>
                    <p class="bw-health-note">
                        Kullanıcı çekimlerini, yatırımlarını ve kullanıcı yönetimini bu bloktan hızla açabilirsin.
                    </p>
                    <div class="row bw-quick-link-grid text-center">
                        <div class="col-4 mb-3">
                            <a href="deposits.php" class="btn btn-sm btn-block py-3">
                                <i class="ri-bank-card-line d-block"></i>
                                Yatırımlar
                            </a>
                        </div>
                        <div class="col-4 mb-3">
                            <a href="withdrawals.php" class="btn btn-sm btn-block py-3">
                                <i class="ri-hand-coin-line d-block"></i>
                                Çekimler
                            </a>
                        </div>
                        <div class="col-4 mb-3">
                            <a href="users.php" class="btn btn-sm btn-block py-3">
                                <i class="ri-user-search-line d-block"></i>
                                Üye Ara
                            </a>
                        </div>
                        <div class="col-4 mb-3">
                            <a href="admin_logs.php" class="btn btn-sm btn-block py-3">
                                <i class="ri-file-list-3-line d-block"></i>
                                Log Kayıtları
                            </a>
                        </div>
                        <div class="col-4 mb-3">
                            <a href="admin_settings.php" class="btn btn-sm btn-block py-3">
                                <i class="ri-settings-3-line d-block"></i>
                                Genel Ayarlar
                            </a>
                        </div>
                        <div class="col-4 mb-3">
                            <a href="admin_login.php" class="btn btn-sm btn-block py-3">
                                <i class="ri-shield-user-line d-block"></i>
                                Admin Girişleri
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- AGENT YÖNETİM MERKEZİ PANELİ -->
    <div class="bw-tab-panel" data-tab-panel="agent">

        <div class="row mb-4">
            <div class="col-xl-4 col-md-6 mb-3">
                <div class="bw-kpi-card">
                    <div class="bw-kpi-inner">
                        <div class="bw-kpi-meta">
                            <div class="bw-kpi-label">Toplam Yatırım (Agent → Biz)</div>
                            <div class="bw-kpi-value"><?= number_format($agentTotalTopup, 2) ?> ₺</div>
                            <div class="bw-kpi-sub">Agent teminatları (bizim paramız DEĞİL)</div>
                        </div>
                        <div class="text-right d-flex flex-column align-items-end justify-content-between">
                            <div class="bw-kpi-icon">
                                <i class="ri-user-star-line"></i>
                            </div>
                            <span class="bw-kpi-pill">
                                <i class="ri-information-line"></i>
                                <span>İpotekli güvence, kâr değil</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-4 col-md-6 mb-3">
                <div class="bw-kpi-card">
                    <div class="bw-kpi-inner">
                        <div class="bw-kpi-meta">
                            <div class="bw-kpi-label">Agent Sistem Teminatı</div>
                            <div class="bw-kpi-value"><?= number_format($agentsSystemBalance, 2) ?> ₺</div>
                            <div class="bw-kpi-sub">Agent'lara tanımlı toplam limit</div>
                        </div>
                        <div class="text-right d-flex flex-column align-items-end justify-content-between">
                            <div class="bw-kpi-icon" style="background: linear-gradient(135deg,#4f46e5,#0ea5e9); box-shadow:0 0 25px rgba(59,130,246,.6);">
                                <i class="ri-shield-keyhole-line"></i>
                            </div>
                            <span class="bw-kpi-pill">
                                <i class="ri-team-line"></i>
                                <span>Aktif agent: <?= (int)$activeAgents ?></span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-4 col-md-6 mb-3">
                <div class="bw-kpi-card">
                    <div class="bw-kpi-inner">
                        <div class="bw-kpi-meta">
                            <div class="bw-kpi-label">Agent Kasaları (Sahadaki Para)</div>
                            <div class="bw-kpi-value"><?= number_format($agentsCash, 2) ?> ₺</div>
                            <div class="bw-kpi-sub">Şu an IBAN'larda bekleyen</div>
                        </div>
                        <div class="text-right d-flex flex-column align-items-end justify-content-between">
                            <div class="bw-kpi-icon" style="background: linear-gradient(135deg,#f97316,#ea580c); box-shadow:0 0 25px rgba(249,115,22,.6);">
                                <i class="ri-wallet-3-line"></i>
                            </div>
                            <span class="bw-kpi-pill">
                                <i class="ri-error-warning-line"></i>
                                <span>Risk eşiği: <?= number_format($THRESH_AGENT_CASH_RISK, 0) ?> ₺</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- AGENT BEKLEYEN İŞLEMLER -->
        <div class="row mb-3">
            <div class="col-lg-7 mb-3">
                <div class="bw-section-card">
                    <div class="bw-section-header">
                        <h6>Agent Bekleyen İşlemler</h6>
                        <span>Bakiye talebi ve çekimler</span>
                    </div>

                    <div style="font-size:.8rem; color:#e5e7eb;">
                        <p class="mb-2">
                            Agent tarafında operasyonu şu an:
                        </p>
                        <ul style="padding-left:1.1rem; margin:0; list-style:disc;">
                            <li>
                                <strong><?= (int)$pendingAgentReq ?></strong> adet
                                <a href="admin_agent_requests.php" style="color:#f97316;">bekleyen agent bakiye talebi</a>
                            </li>
                            <li>
                                <strong><?= (int)$pendingAgentWithdraw ?></strong> adet
                                <a href="withdrawals.php" style="color:#38bdf8;">agent çekim görevi (agent_withdraw_orders)</a>
                            </li>
                            <li>
                                <strong><?= (int)$pendingDep ?></strong> user çekimi, dağıtım esnasında agent'lara yönlenir.
                            </li>
                        </ul>
                    </div>

                    <div class="mt-3 bw-health-note">
                        Agent 100.000 ₺ yatırdığında, komisyon oranına göre (ör. %3) sistem ona 103.000 ₺'lik yatırım alma hakkı tanır.
                        Kullanıcı yatırımları bu limite doğru akar, çekimler geldikçe kasa yeniden dolar.  
                        Ama bu 100.000 ₺ teminat senin paran değil; ipotekli, geri ödenebilir para.
                    </div>
                </div>
            </div>

            <div class="col-lg-5 mb-3">
                <div class="bw-section-card">
                    <div class="bw-section-header">
                        <h6>Agent Hızlı Yönetim</h6>
                        <span>Agent odaklı aksiyonlar</span>
                    </div>
                    <p class="bw-health-note">
                        Agent onboarding, IBAN yönetimi ve agent performansı için sık kullandığın ekranlar:
                    </p>
                    <div class="row bw-quick-link-grid text-center">
                        <div class="col-4 mb-3">
                            <a href="admin_deposit_agents.php" class="btn btn-sm btn-block py-3">
                                <i class="ri-user-add-line d-block"></i>
                                Agentlar
                            </a>
                        </div>
                        <div class="col-4 mb-3">
                            <a href="admin_agent_requests.php" class="btn btn-sm btn-block py-3">
                                <i class="ri-funds-line d-block"></i>
                                Bakiye Talepleri
                            </a>
                        </div>
                        <div class="col-4 mb-3">
                            <a href="admin_crypto_wallets.php" class="btn btn-sm btn-block py-3">
                                <i class="ri-bit-coin-line d-block"></i>
                                Kripto Cüzdan
                            </a>
                        </div>
                        <div class="col-4 mb-3">
                            <a href="admin_deposit_ibans.php" class="btn btn-sm btn-block py-3">
                                <i class="ri-bank-line d-block"></i>
                                IBAN Yönetimi
                            </a>
                        </div>
                        <div class="col-4 mb-3">
                            <a href="agent-login.php" class="btn btn-sm btn-block py-3">
                                <i class="ri-login-circle-line d-block"></i>
                                Agent Girişleri
                            </a>
                        </div>
                        <div class="col-4 mb-3">
                            <a href="site_reports.php" class="btn btn-sm btn-block py-3">
                                <i class="ri-bar-chart-2-line d-block"></i>
                                Performans Raporu
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- SITE YÖNETİM MERKEZİ PANELİ -->
    <div class="bw-tab-panel" data-tab-panel="site">

        <div class="row mb-4">
            <div class="col-xl-4 col-md-6 mb-3">
                <div class="bw-kpi-card">
                    <div class="bw-kpi-inner">
                        <div class="bw-kpi-meta">
                            <div class="bw-kpi-label">Toplam Yatırım (Site → Biz)</div>
                            <div class="bw-kpi-value"><?= number_format($siteTotalTopup, 2) ?> ₺</div>
                            <div class="bw-kpi-sub">Sitelerin BetWallet'a yüklediği gerçek para</div>
                        </div>
                        <div class="text-right d-flex flex-column align-items-end justify-content-between">
                            <div class="bw-kpi-icon">
                                <i class="ri-building-2-line"></i>
                            </div>
                            <span class="bw-kpi-pill">
                                <i class="ri-user-star-line"></i>
                                <span>Yatırım limiti = site çekim limiti</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-4 col-md-6 mb-3">
                <div class="bw-kpi-card">
                    <div class="bw-kpi-inner">
                        <div class="bw-kpi-meta">
                            <div class="bw-kpi-label">Toplam Mutabakat (Site Çekimi)</div>
                            <div class="bw-kpi-value"><?= number_format($siteTotalSettlement, 2) ?> ₺</div>
                            <div class="bw-kpi-sub">Sitelerin çekip kasasına aldığı tutar</div>
                        </div>
                        <div class="text-right d-flex flex-column align-items-end justify-content-between">
                            <div class="bw-kpi-icon" style="background: linear-gradient(135deg,#0f766e,#22c55e); box-shadow:0 0 25px rgba(16,185,129,.55);">
                                <i class="ri-hand-coin-line"></i>
                            </div>
                            <span class="bw-kpi-pill">
                                <i class="ri-time-line"></i>
                                <span>Bekleyen çekim: <?= (int)$pendingSiteWithdraw ?></span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-4 col-md-6 mb-3">
                <div class="bw-kpi-card">
                    <div class="bw-kpi-inner">
                        <div class="bw-kpi-meta">
                            <div class="bw-kpi-label">Sitelerin Anlık Bakiyesi</div>
                            <div class="bw-kpi-value"><?= number_format($sitesBalance, 2) ?> ₺</div>
                            <div class="bw-kpi-sub">Sitelerin kullanabileceği toplam bakiye</div>
                        </div>
                        <div class="text-right d-flex flex-column align-items-end justify-content-between">
                            <div class="bw-kpi-icon" style="background: linear-gradient(135deg,#6366f1,#4f46e5); box-shadow:0 0 25px rgba(79,70,229,.6);">
                                <i class="ri-global-line"></i>
                            </div>
                            <span class="bw-kpi-pill">
                                <i class="ri-error-warning-line"></i>
                                <span>Düşük bakiye eşiği: <?= number_format($THRESH_SITE_LOW_BALANCE, 0) ?> ₺</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- SITE BEKLEYEN İŞLEMLER -->
        <div class="row mb-3">
            <div class="col-lg-7 mb-3">
                <div class="bw-section-card">
                    <div class="bw-section-header">
                        <h6>Site Bekleyen İşlemler</h6>
                        <span>Bakiye yükleme ve çekim talepleri</span>
                    </div>

                    <div style="font-size:.8rem; color:#e5e7eb;">
                        <ul style="padding-left:1.1rem; margin:0; list-style:disc;">
                            <li>
                                <strong><?= (int)$pendingSiteReq ?></strong> adet
                                <a href="admin_site_requests.php" style="color:#f97316;">bekleyen site bakiye talebi</a>
                            </li>
                            <li>
                                <strong><?= (int)$pendingSiteWithdraw ?></strong> adet
                                <a href="site_withdrawals.php" style="color:#38bdf8;">bekleyen site çekimi</a>
                            </li>
                            <li>
                                <strong><?= (int)$pendingDep ?></strong> user yatırımı → sitelerin bakiyesine komisyona göre yansır.
                            </li>
                        </ul>
                    </div>

                    <div class="mt-3 bw-health-note">
                        Örnek akış:<br>
                        Agent 100.000 ₺ bize yatırır, komisyonu %3 ise sistem ona 103.000 ₺'lik yatırım alma hakkı tanır.
                        User 102.500 ₺ yatırım yaparsa mesela:
                        <ul style="padding-left:1.1rem; margin-top:.35rem; list-style:disc;">
                            <li>102.500 ₺'nin tamamı agent yatırım hakkından düşer,</li>
                            <li>%4 komisyon varsayımında user yatırımının %96'sı ilgili sitenin bakiyesine eklenir,</li>
                            <li>Kalan %4 + çekimlerdeki %1'lik pay BetWallet kârı olarak oluşur.</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-lg-5 mb-3">
                <div class="bw-section-card">
                    <div class="bw-section-header">
                        <h6>Site Hızlı Yönetim</h6>
                        <span>Site odaklı aksiyonlar</span>
                    </div>
                    <p class="bw-health-note">
                        Yeni site ekleme, site bakiyeleri ve mutabakat için gerekli ekranlar:
                    </p>
                    <div class="row bw-quick-link-grid text-center">
                        <div class="col-4 mb-3">
                            <a href="admin_sites.php" class="btn btn-sm btn-block py-3">
                                <i class="ri-store-2-line d-block"></i>
                                Siteler
                            </a>
                        </div>
                        <div class="col-4 mb-3">
                            <a href="admin_site_requests.php" class="btn btn-sm btn-block py-3">
                                <i class="ri-funds-box-line d-block"></i>
                                Bakiye Talepleri
                            </a>
                        </div>
                        <div class="col-4 mb-3">
                            <a href="site_withdrawals.php" class="btn btn-sm btn-block py-3">
                                <i class="ri-hand-coin-line d-block"></i>
                                Site Çekimleri
                            </a>
                        </div>
                        <div class="col-4 mb-3">
                            <a href="site_reports.php" class="btn btn-sm btn-block py-3">
                                <i class="ri-bar-chart-line d-block"></i>
                                Site Raporları
                            </a>
                        </div>
                        <div class="col-4 mb-3">
                            <a href="site_panel/index.php" class="btn btn-sm btn-block py-3">
                                <i class="ri-login-circle-line d-block"></i>
                                Site Panel Giriş
                            </a>
                        </div>
                        <div class="col-4 mb-3">
                            <a href="admin_settings.php#commission" class="btn btn-sm btn-block py-3">
                                <i class="ri-percent-line d-block"></i>
                                Komisyon Ayarları
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- BETWALLET CÜZDAN PANELİ -->
    <div class="bw-tab-panel" data-tab-panel="wallet">

        <div class="row mb-4">
            <!-- Toplam Kasa Girişi -->
            <div class="col-xl-4 col-md-6 mb-3">
                <div class="bw-kpi-card">
                    <div class="bw-kpi-inner">
                        <div class="bw-kpi-meta">
                            <div class="bw-kpi-label">Toplam Kasa Girişi</div>
                            <div class="bw-kpi-value"><?= number_format($totalRealIn, 2) ?> ₺</div>
                            <div class="bw-kpi-sub">Agent teminatları + site yatırımları (gerçek para)</div>
                        </div>
                        <div class="text-right d-flex flex-column align-items-end justify-content-between">
                            <div class="bw-kpi-icon">
                                <i class="ri-bank-card-2-line"></i>
                            </div>
                            <span class="bw-kpi-pill">
                                <i class="ri-information-line"></i>
                                <span>Kasa girişlerinin brüt toplamı</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Minimum Olması Gereken Kasa -->
            <div class="col-xl-4 col-md-6 mb-3">
                <div class="bw-kpi-card">
                    <div class="bw-kpi-inner">
                        <div class="bw-kpi-meta">
                            <div class="bw-kpi-label">Minimum Olması Gereken Kasa</div>
                            <div class="bw-kpi-value"><?= number_format($minRequiredCash, 2) ?> ₺</div>
                            <div class="bw-kpi-sub">Agent kasaları + site bakiyeleri kadar nakit</div>
                        </div>
                        <div class="text-right d-flex flex-column align-items-end justify-content-between">
                            <div class="bw-kpi-icon" style="background: linear-gradient(135deg,#f97316,#ea580c); box-shadow:0 0 25px rgba(249,115,22,.6);">
                                <i class="ri-global-line"></i>
                            </div>
                            <span class="bw-kpi-pill">
                                <i class="ri-alert-line"></i>
                                <span>Bu tutarın altı riskli</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- BetWallet Net Komisyon (Senin Paran) -->
            <div class="col-xl-4 col-md-6 mb-3">
                <div class="bw-kpi-card">
                    <div class="bw-kpi-inner">
                        <div class="bw-kpi-meta">
                            <div class="bw-kpi-label">BetWallet Net Komisyon (Senin Paran)</div>
                            <div class="bw-kpi-value"><?= number_format($theoreticalEquity, 2) ?> ₺</div>
                            <div class="bw-kpi-sub">Yatırım komisyonu + site çekim payı</div>
                        </div>
                        <div class="text-right d-flex flex-column align-items-end justify-content-between">
                            <div class="bw-kpi-icon" style="background: linear-gradient(135deg,#22c55e,#16a34a); box-shadow:0 0 25px rgba(34,197,94,.6);">
                                <i class="ri-pie-chart-2-line"></i>
                            </div>
                            <span class="bw-kpi-pill">
                                <i class="ri-line-chart-line"></i>
                                <span>Depo %<?= $DEPOSIT_COMM_RATE*100 ?> + Çekim %<?= $WITHDRAW_COMM_RATE*100 ?></span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- HESAP TABLOSU / AÇIKLAMA -->
        <div class="row mb-3">
            <div class="col-lg-7 mb-3">
                <div class="bw-section-card">
                    <div class="bw-section-header">
                        <h6>BetWallet İç Kasa Hesabı</h6>
                        <span>Teminat / yükümlülük / kâr ayrımı</span>
                    </div>

                    <div class="bw-health-note">
                        Bu tablo; agent teminatlarını, site yatırımlarını ve bunlardan doğan gerçek BetWallet kârını ayrı ayrı görmen için tasarlandı.
                    </div>

                    <table class="bw-mini-table">
                        <thead>
                        <tr>
                            <th>Kalem</th>
                            <th>Açıklama</th>
                            <th>Tutar (₺)</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td><strong>Agent Teminatları</strong></td>
                            <td>Onaylanmış agent yatırımları (bizim değil, ipotekli para)</td>
                            <td><?= number_format($agentTotalTopup, 2) ?></td>
                        </tr>
                        <tr>
                            <td><strong>Site Yüklemeleri</strong></td>
                            <td>Sitelerin BetWallet'a gönderdiği yatırımlar (gerçek para)</td>
                            <td><?= number_format($siteTotalTopup, 2) ?></td>
                        </tr>
                        <tr>
                            <td><strong>Toplam Kasa Girişi</strong></td>
                            <td>Agent teminat + site yatırımı (brüt giriş)</td>
                            <td><?= number_format($totalRealIn, 2) ?></td>
                        </tr>
                        <tr>
                            <td><strong>Sistem Yükümlülüğü</strong></td>
                            <td>Agent kasaları (current_cash) + site bakiyeleri (balance)</td>
                            <td><?= number_format($systemExposure, 2) ?></td>
                        </tr>
                        <tr>
                            <td><strong>Yatırım Komisyon Geliri (≈)</strong></td>
                            <td>User yatırımlarının yaklaşık %<?= $DEPOSIT_COMM_RATE*100 ?>'i</td>
                            <td><?= number_format($betwalletDepositCommissionApprox, 2) ?></td>
                        </tr>
                        <tr>
                            <td><strong>Çekim Komisyon Geliri (≈)</strong></td>
                            <td>Sitelerin çekimlerinin yaklaşık %<?= $WITHDRAW_COMM_RATE*100 ?>'i</td>
                            <td><?= number_format($betwalletWithdrawFeeApprox, 2) ?></td>
                        </tr>
                        <tr>
                            <td><strong>BetWallet Net Komisyon (Senin Paran)</strong></td>
                            <td>Yatırım + çekim komisyonları (agent teminatları hariç)</td>
                            <td><?= number_format($theoreticalEquity, 2) ?></td>
                        </tr>
                        </tbody>
                    </table>

                    <div class="mt-3 bw-health-note">
                        <strong>Özet:</strong> Agent teminatları (<?= number_format($agentTotalTopup, 2) ?> ₺) senin değil, güvence için kasada duran para.  
                        Senin gerçek kâr/öz sermayen; sitelerin user yatırımlarından ve site çekimlerinden kestiğin komisyonlardan oluşuyor.  
                        Bu tabloda o kısım <strong>"BetWallet Net Komisyon (Senin Paran)"</strong> satırında.
                    </div>
                </div>
            </div>

            <div class="col-lg-5 mb-3">
                <div class="bw-section-card">
                    <div class="bw-section-header">
                        <h6>Kendi Nakit Durumunu Okuma</h6>
                        <span>Operasyon rehberi</span>
                    </div>
                    <p class="bw-health-note">
                        Bu sekmeyi “BetWallet Cüzdanım” olarak düşün. Gözünle şu kontrolleri yapabilirsin:
                    </p>
                    <ul style="padding-left:1.1rem; margin:0; list-style:disc; font-size:.8rem; color:#e5e7eb;">
                        <li>
                            Bankadaki toplam nakit; agent teminatları + site yatırımları + geçmiş komisyon birikimiyle uyumlu mu?
                        </li>
                        <li>
                            <strong>Minimum Olması Gereken Kasa</strong> (<?= number_format($minRequiredCash, 2) ?> ₺)  
                            sistemin “kimseye borç kalmadan” çalışabilmesi için elinde bulunması gereken minimum nakit.
                        </li>
                        <li>
                            <strong>BetWallet Net Komisyon (Senin Paran)</strong> büyüdükçe, sistem senin için kârlı demektir.  
                            Burada agent teminatlarından gelen hiçbir tutar yok; sadece komisyonun var.
                        </li>
                        <li>
                            İleride istersen, banka hesaplarındaki gerçek bakiyeyi buraya da bağlayıp  
                            <strong>“teorik komisyon birikimi vs. gerçek kasa”</strong> şeklinde tam mutabakat ekranı kurabiliriz.
                        </li>
                    </ul>
                </div>
            </div>
        </div>

    </div>

</div>

<script>
    // Basit tab switcher (User / Agent / Site / Wallet)
    document.addEventListener('DOMContentLoaded', function () {
        const tabButtons = document.querySelectorAll('.bw-tab-btn');
        const tabPanels = document.querySelectorAll('.bw-tab-panel');

        tabButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const tab = btn.getAttribute('data-tab');

                tabButtons.forEach(b => b.classList.remove('is-active'));
                btn.classList.add('is-active');

                tabPanels.forEach(panel => {
                    if (panel.getAttribute('data-tab-panel') === tab) {
                        panel.classList.add('is-active');
                    } else {
                        panel.classList.remove('is-active');
                    }
                });
            });
        });
    });
</script>

<?php include __DIR__ . '/_admin_footer.php'; ?>
