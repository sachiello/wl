<?php
require __DIR__ . '/require_admin.php';
$pageTitle = 'Genel Ayarlar & Duyurular';

$success = null;
$error = null;

// KAYDETME İŞLEMİ
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_validate_request()) {
    if (isset($_POST['save_announcement'])) {
        $text = trim($_POST['announcement_text']);
        // Checkbox işaretli değilse post edilmez, bu yüzden isset kontrolü yaparız
        $active = isset($_POST['announcement_active']) ? '1' : '0';
        
        try {
            // Ayarları güncelle (Yoksa ekle - UNIQUE KEY sayesinde çalışır)
            $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('site_announcement', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
            $stmt->execute([$text, $text]);
            
            $stmt2 = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('site_announcement_active', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
            $stmt2->execute([$active, $active]);
            
            $success = "Duyuru ayarları başarıyla güncellendi.";
        } catch (Exception $e) {
            $error = "Hata: " . $e->getMessage();
        }
    }
}

// MEVCUT AYARLARI ÇEK
// Düzeltme: Sadece key ve value sütunlarını çekiyoruz
$settings = $pdo->query("SELECT setting_key, setting_value FROM settings")->fetchAll(PDO::FETCH_KEY_PAIR);

$annText = $settings['site_announcement'] ?? '';
$annActive = $settings['site_announcement_active'] ?? '0';

include __DIR__ . '/_admin_header.php';
?>

<div class="container-fluid mt-4">
    <h1 class="h3 mb-4 text-gray-800">Site Paneli Duyuru Ayarı</h1>
    
    <?php if($success): ?>
        <div class="alert alert-success" role="alert"><?= $success ?></div>
    <?php endif; ?>
    
    <?php if($error): ?>
        <div class="alert alert-danger" role="alert"><?= $error ?></div>
    <?php endif; ?>
    
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Duyuru Yönetimi</h6>
        </div>
        <div class="card-body">
            <form method="post">
                <?= csrf_field() ?>
                
                <div class="form-group">
                    <label for="announcement_text" style="font-weight: 600;">Duyuru Metni</label>
                    <textarea name="announcement_text" id="announcement_text" class="form-control" rows="3" placeholder="Site panellerinde görünecek duyuruyu buraya yazın..."><?= htmlspecialchars($annText) ?></textarea>
                    <small class="form-text text-muted">Bu metin tüm site (merchant) panellerinde en üstte görünecektir.</small>
                </div>
                
                <div class="form-group">
                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="announcement_active" name="announcement_active" value="1" <?= $annActive=='1' ? 'checked' : '' ?>>
                        <label class="custom-control-label" for="announcement_active" style="cursor: pointer;">Duyuru Barını Göster / Aktif Et</label>
                    </div>
                </div>
                
                <button type="submit" name="save_announcement" class="btn btn-primary">
                    <i class="ri-save-line"></i> Kaydet ve Yayınla
                </button>
            </form>
        </div>
    </div>
</div>

<?php include __DIR__ . '/_admin_footer.php'; ?>