<?php
// admin/site_reports.php
require __DIR__ . '/require_admin.php'; // $pdo, $currentAdmin

$pageTitle = 'Site Bazlı Raporlama';
$activeNav = 'site_reports';

// Tarih aralığı filtresi
$range = $_GET['range'] ?? '7d'; // today, yesterday, 7d, 30d, all
$siteFilter = isset($_GET['site_id']) ? (int)$_GET['site_id'] : 0;

$hasDateFilter = $range !== 'all';
$startDate = null;
$endDate = null;
$periodLabel = 'Tüm Zamanlar';

if ($hasDateFilter) {
    $today = new DateTimeImmutable('today');
    switch ($range) {
        case 'today':
            $start = $today;
            $end = $today;
            $periodLabel = 'Bugün';
            break;
        case 'yesterday':
            $start = $today->modify('-1 day');
            $end = $today->modify('-1 day');
            $periodLabel = 'Dün';
            break;
        case '30d':
            $start = $today->modify('-29 days');
            $end = $today;
            $periodLabel = 'Son 30 Gün';
            break;
        case '7d':
        default:
            $start = $today->modify('-6 days');
            $end = $today;
            $periodLabel = 'Son 7 Gün';
            break;
    }
    $startDate = $start->format('Y-m-d 00:00:00');
    $endDate   = $end->format('Y-m-d 23:59:59');
} else {
    $startDate = null;
    $endDate = null;
}

// Tüm siteleri dropdown için çek
$sitesStmt = $pdo->query("SELECT id, name FROM sites ORDER BY name ASC");
$allSites = $sitesStmt->fetchAll(PDO::FETCH_ASSOC);

// Ana rapor sorgusu
$sql = "
    SELECT 
        s.id,
        s.name,
        s.slug,
        s.logo_url,
        s.is_active,
        COALESCE(ds.total_deposit, 0)      AS total_deposit_try,
        COALESCE(ds.deposit_count, 0)      AS deposit_count,
        COALESCE(ds.unique_users, 0)       AS deposit_users,
        COALESCE(us.linked_users, 0)       AS linked_users,
        COALESCE(us.total_site_balance, 0) AS total_site_balance_try,
        COALESCE(sw.total_withdrawn, 0)    AS total_site_withdrawn
    FROM sites s
    LEFT JOIN (
        SELECT 
            site_id,
            SUM(amount_try)         AS total_deposit,
            COUNT(*)                AS deposit_count,
            COUNT(DISTINCT user_id) AS unique_users
        FROM deposit_orders
        WHERE status = 'confirmed'
          AND site_id IS NOT NULL
";

$params = [];
if ($hasDateFilter) {
    $sql .= " AND created_at BETWEEN :start_date AND :end_date";
    $params[':start_date'] = $startDate;
    $params[':end_date']   = $endDate;
}

$sql .= "
        GROUP BY site_id
    ) ds ON ds.site_id = s.id
    LEFT JOIN (
        SELECT 
            site_id,
            COUNT(*)              AS linked_users,
            SUM(site_balance_try) AS total_site_balance
        FROM user_sites
        GROUP BY site_id
    ) us ON us.site_id = s.id
    LEFT JOIN (
        SELECT 
            site_id,
            SUM(amount) AS total_withdrawn
        FROM site_withdrawals
        WHERE status = 'completed'
";

if ($hasDateFilter) {
    $sql .= " AND created_at BETWEEN :start_date2 AND :end_date2";
    $params[':start_date2'] = $startDate;
    $params[':end_date2']   = $endDate;
}

$sql .= "
        GROUP BY site_id
    ) sw ON sw.site_id = s.id
    WHERE 1=1
";

if ($siteFilter > 0) {
    $sql .= " AND s.id = :site_id";
    $params[':site_id'] = $siteFilter;
}

$sql .= "
    ORDER BY s.is_active DESC, s.name ASC
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Genel özetler
$totalDepositAll   = 0;
$totalWithdrawAll  = 0;
$totalLinkedUsers  = 0;
$totalCurrentBal   = 0;

foreach ($rows as $r) {
    $totalDepositAll  += (float)$r['total_deposit_try'];
    $totalWithdrawAll += (float)$r['total_site_withdrawn'];
    $totalLinkedUsers += (int)$r['linked_users'];
    $totalCurrentBal  += (float)$r['total_site_balance_try'];
}

include __DIR__ . '/_admin_header.php';
?>

<div class="admin-page">
    <div class="admin-page-header">
        <h1>Site Bazlı Raporlama</h1>
        <p>Seçili tarih aralığında her site için toplam yatırım, çekim, bağlı kullanıcı ve site içi bakiye özetleri.</p>
    </div>

    <div class="admin-stats-grid">
        <div class="admin-card">
            <div class="admin-card-title">Dönem</div>
            <div class="admin-card-value"><?= htmlspecialchars($periodLabel) ?></div>
        </div>
        <div class="admin-card">
            <div class="admin-card-title">Toplam Yatırım (Tüm Siteler)</div>
            <div class="admin-card-value"><?= number_format($totalDepositAll, 2) ?> TL</div>
        </div>
        <div class="admin-card">
            <div class="admin-card-title">Toplam Site Çekimi</div>
            <div class="admin-card-value"><?= number_format($totalWithdrawAll, 2) ?> TL</div>
        </div>
        <div class="admin-card">
            <div class="admin-card-title">Toplam Bağlı Kullanıcı</div>
            <div class="admin-card-value"><?= number_format($totalLinkedUsers) ?></div>
        </div>
        <div class="admin-card">
            <div class="admin-card-title">Toplam Site İçi Bakiye (TRY)</div>
            <div class="admin-card-value"><?= number_format($totalCurrentBal, 2) ?> TL</div>
        </div>
    </div>

    <div class="admin-card" style="margin-top:20px;">
        <form method="get" class="admin-filter-form" style="display:flex; gap:15px; flex-wrap:wrap; align-items:center;">
            <div class="filter-group">
                <label>Dönem</label>
                <select name="range" class="admin-select">
                    <option value="today"    <?= $range==='today'    ? 'selected' : '' ?>>Bugün</option>
                    <option value="yesterday"<?= $range==='yesterday'? 'selected' : '' ?>>Dün</option>
                    <option value="7d"       <?= $range==='7d'       ? 'selected' : '' ?>>Son 7 Gün</option>
                    <option value="30d"      <?= $range==='30d'      ? 'selected' : '' ?>>Son 30 Gün</option>
                    <option value="all"      <?= $range==='all'      ? 'selected' : '' ?>>Tüm Zamanlar</option>
                </select>
            </div>

            <div class="filter-group">
                <label>Site</label>
                <select name="site_id" class="admin-select">
                    <option value="0">Tüm Siteler</option>
                    <?php foreach ($allSites as $s): ?>
                        <option value="<?= (int)$s['id'] ?>" <?= $siteFilter === (int)$s['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($s['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="filter-group">
                <label>&nbsp;</label>
                <button class="btn btn-primary" type="submit">Filtrele</button>
            </div>

            <div class="filter-group">
                <label>&nbsp;</label>
                <a href="site_reports.php" class="btn btn-secondary">Sıfırla</a>
            </div>
        </form>
    </div>

    <div class="admin-card" style="margin-top:20px;">
        <div class="admin-card-header">
            <h2>Site Bazlı Özet Tablosu</h2>
        </div>
        <div class="admin-table-wrapper">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Site</th>
                        <th>Durum</th>
                        <th>Toplam Yatırım (TRY)</th>
                        <th>Yatırım Sayısı</th>
                        <th>Yatırım Yapan Kullanıcı</th>
                        <th>Bağlı Kullanıcı</th>
                        <th>Site İçi Bakiye (TRY)</th>
                        <th>Site Çekimi (TRY)</th>
                        <th>Net (Yatırım - Çekim)</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$rows): ?>
                    <tr>
                        <td colspan="9" style="text-align:center; padding:20px;">
                            Kayıt bulunamadı.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($rows as $row): 
                        $net = (float)$row['total_deposit_try'] - (float)$row['total_site_withdrawn'];
                    ?>
                    <tr>
                        <td>
                            <strong><?= htmlspecialchars($row['name']) ?></strong><br>
                            <span style="font-size:11px; color:#6b7280;"><?= htmlspecialchars($row['slug']) ?></span>
                        </td>
                        <td>
                            <?php if ((int)$row['is_active'] === 1): ?>
                                <span class="badge badge-success">Aktif</span>
                            <?php else: ?>
                                <span class="badge badge-secondary">Pasif</span>
                            <?php endif; ?>
                        </td>
                        <td><?= number_format($row['total_deposit_try'], 2) ?> TL</td>
                        <td><?= (int)$row['deposit_count'] ?></td>
                        <td><?= (int)$row['deposit_users'] ?></td>
                        <td><?= (int)$row['linked_users'] ?></td>
                        <td><?= number_format($row['total_site_balance_try'], 2) ?> TL</td>
                        <td><?= number_format($row['total_site_withdrawn'], 2) ?> TL</td>
                        <td>
                            <span style="font-weight:600; color: <?= $net >= 0 ? '#16a34a' : '#b91c1c' ?>;">
                                <?= number_format($net, 2) ?> TL
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
include __DIR__ . '/_admin_footer.php';
