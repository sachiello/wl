<?php
// ajax_get_deposits.php - TEMİZ VE SORUNSUZ SÜRÜM
session_start();
require __DIR__ . '/../../config/config.php';

// Güvenlik: Admin veya Agent girişi yoksa işlem yapma
if (!isset($_SESSION['admin_id']) && !isset($_SESSION['agent_id'])) {
    http_response_code(403);
    exit;
}

// Yetkileri Kontrol Et
$is_admin = isset($_SESSION['admin_id']);
$permissions = [];
if ($is_admin) {
    $permissions = ['view_havale' => true, 'view_crypto' => true, 'view_cc' => true, 'can_approve' => true];
} else {
    $permissions = $_SESSION['agent_permissions'] ?? ['view_havale' => false, 'view_crypto' => false, 'view_cc' => false, 'can_approve' => false];
}

// Veriyi Çek
$sql = "
    SELECT 
      d.*, 
      u.username,
      di.iban AS deposit_iban,
      da.name AS agent_name,
      cw.address AS crypto_wallet_address,
      cw.coin_symbol AS crypto_coin_symbol
    FROM deposit_orders d
    JOIN users u ON u.id = d.user_id
    LEFT JOIN deposit_ibans di ON di.id = d.iban_id
    LEFT JOIN deposit_agents da ON da.id = d.agent_id
    LEFT JOIN admin_crypto_wallets cw ON cw.id = d.crypto_wallet_id
    ORDER BY d.id DESC LIMIT 50
";

$all_rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

// Filtreleme
$rows = array_filter($all_rows, function($row) use ($permissions) {
    $payment_method = $row['payment_method'] ?? 'havale';
    if ($payment_method === 'havale' && !$permissions['view_havale']) return false;
    if ($payment_method === 'crypto' && !$permissions['view_crypto']) return false;
    if ($payment_method === 'credit_card' && !$permissions['view_cc']) return false;
    return true;
});

// HTML ÇIKTISI
if (empty($rows)) {
    echo '<tr id="no-data-row"><td colspan="9" style="text-align:center; padding: 40px; color: var(--text-muted);">
            <i class="ri-filter-off-line" style="font-size: 48px; display: block; margin-bottom: 10px; opacity: 0.5;"></i>
            Veri bulunamadı.
          </td></tr>';
    exit;
}

foreach ($rows as $r):
    $method = $r['payment_method'] ?? 'havale';
    
    // Veritabanı verisini temizle
    $dbStatus = strtolower(trim($r['status'])); 

    // --- DURUM BELİRLEME ---
    $statusClass = 'pending';
    $statusLabel = 'Bekliyor';
    $statusIcon  = 'ri-time-line';

    // Hem 'approved', hem 'confirmed' kabul et (Yeşil Işık)
    if (in_array($dbStatus, ['approved', 'confirmed', 'success', 'ok'])) { 
        $statusClass = 'success'; 
        $statusLabel = 'Onaylandı'; 
        $statusIcon  = 'ri-check-double-line'; 
    } 
    elseif ($dbStatus == 'rejected') { 
        $statusClass = 'danger'; 
        $statusLabel = 'Reddedildi'; 
        $statusIcon  = 'ri-close-circle-line'; 
    }
    
    $rawDate = date('Y-m-d', strtotime($r['created_at']));
?>
<tr class="deposit-row" 
    data-method="<?= $method ?>" 
    data-id="<?= $r['id'] ?>"
    data-status="<?= $dbStatus ?>" 
    data-date="<?= $rawDate ?>">
    
    <td><span style="font-family: monospace; color: var(--text-muted);">#<?= $r['id'] ?></span></td>
    <td><div style="font-weight: 600; color: var(--text-main);"><?= htmlspecialchars($r['username']) ?></div></td>
    <td>
        <div style="font-weight: 700; color: var(--text-main); font-size: 15px;">
            <?= number_format($r['amount_try'], 2) ?> <span style="font-size: 11px; color: var(--text-muted);">TL</span>
        </div>
    </td>
    <td>
        <?php if ($method === 'havale'): ?>
            <span class="badge-method badge-havale"><i class="ri-bank-line"></i> Havale</span>
        <?php elseif ($method === 'crypto'): ?>
            <span class="badge-method badge-crypto"><i class="ri-bit-coin-line"></i> Kripto</span>
        <?php elseif ($method === 'credit_card'): ?>
            <span class="badge-method badge-cc"><i class="ri-mastercard-line"></i> K.Kartı</span>
        <?php endif; ?>
    </td>
    <td style="font-size: 13px; color: var(--text-muted);">
        <?php if ($method === 'havale'): ?>
            <i class="ri-arrow-right-s-line" style="vertical-align:middle"></i> <?= htmlspecialchars($r['deposit_iban'] ?? '-') ?>
        <?php elseif ($method === 'crypto'): ?>
             <strong style="color:var(--text-main)"><?= htmlspecialchars($r['crypto_coin_symbol'] ?? '') ?></strong>
             <br><span style="font-size: 11px; font-family: monospace;"><?= substr($r['crypto_wallet_address'] ?? '', 0, 12) ?>...</span>
        <?php else: ?> - <?php endif; ?>
    </td>
    <td>
        <?php if($r['agent_name']): ?>
            <span style="display: inline-flex; align-items: center; gap: 5px; background: #f3f4f6; padding: 4px 8px; border-radius: 6px; font-size: 12px;">
                <i class="ri-user-star-line"></i> <?= htmlspecialchars($r['agent_name']) ?>
            </span>
        <?php else: ?> - <?php endif; ?>
    </td>
    <td style="font-size: 12px; color: var(--text-muted);"><?= date('d.m.Y H:i', strtotime($r['created_at'])) ?></td>
    
    <td>
        <span class="badge <?= $statusClass ?>">
            <i class="<?= $statusIcon ?>"></i> <?= $statusLabel ?>
        </span>
    </td>
    
    <td style="text-align: right;">
        <?php if ($dbStatus === 'pending' && $permissions['can_approve']): ?>
            <div class="action-group">
                <form method="post" action="deposits_update.php" style="display:inline;">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="id" value="<?= $r['id'] ?>">
                    <input type="hidden" name="action" value="confirm">
                    <button type="submit" class="btn-icon btn-approve" title="Onayla">
                        <i class="ri-check-line"></i>
                    </button>
                </form>
                <form method="post" action="deposits_update.php" style="display:inline;">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="id" value="<?= $r['id'] ?>">
                    <input type="hidden" name="action" value="reject">
                    <button type="submit" class="btn-icon btn-reject" title="Reddet">
                        <i class="ri-close-line"></i>
                    </button>
                </form>
            </div>
        <?php elseif($dbStatus === 'pending'): ?>
            <span style="font-size: 11px; color: var(--text-muted); font-style: italic;">Yetki Yok</span>
        <?php else: ?>
            <i class="ri-checkbox-circle-fill" style="color: #cbd5e1; font-size: 20px;"></i>
        <?php endif; ?>
    </td>
</tr>
<?php endforeach; ?>

<tr id="no-data-row" style="display:none;">
    <td colspan="9" style="text-align:center; padding: 40px; color: var(--text-muted);">
        <i class="ri-filter-off-line" style="font-size: 48px; display: block; margin-bottom: 10px; opacity: 0.5;"></i>
        Filtrelere uygun sonuç bulunamadı.
    </td>
</tr>
