<?php
// admin/withdrawals.php
session_start();
require __DIR__ . '/../../config/config.php';

if (!isset($_SESSION['admin_id']) && !isset($_SESSION['agent_id'])) {
    header('Location: admin_login.php'); exit;
}

$pageTitle = 'Kullanıcı Çekim Talepleri';
$activeNav = 'withdrawals';
$adminMessage = '';
$msgType = 'info';

// --- OTOMATİK DAĞITIM MANTIĞI (GÜNCELLENDİ) ---
// Kullanıcı verilerini de Agent görevine kopyalıyoruz.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['auto_dispatch'])) {
    try {
        $pdo->beginTransaction();
        $pendingOrders = $pdo->query("SELECT * FROM withdraw_requests WHERE status = 'pending'")->fetchAll(PDO::FETCH_ASSOC);
        $assignedCount = 0;

        foreach ($pendingOrders as $order) {
            $amount = (float)$order['amount'];
            
            // KRİTİK SEÇİM: Agent'ın 'current_cash'i (Nakit Kasası) bu ödemeyi yapmaya yetiyor mu?
            // Ayrıca Agent aktif olmalı.
            $stmt = $pdo->prepare("
                SELECT id, current_cash 
                FROM deposit_agents 
                WHERE is_active = 1 
                  AND current_cash >= ? 
                ORDER BY current_cash DESC -- En çok parası olandan başla (Yükü dağıt)
                LIMIT 1
            ");
            $stmt->execute([$amount]);
            $agent = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($agent) {
                // 1. İsteği 'processing' yap
                $pdo->prepare("UPDATE withdraw_requests SET status = 'processing' WHERE id = ?")->execute([$order['id']]);
                
                // 2. Agent'a İş Ata
                $ins = $pdo->prepare("
                    INSERT INTO agent_withdraw_orders 
                    (site_id, agent_id, user_id, amount, to_bank_name, to_iban, to_full_name, status, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', NOW())
                ");
                
                $ins->execute([
                    ($order['site_id'] ?? 0), 
                    $agent['id'], 
                    $order['user_id'], 
                    $amount,
                    $order['user_bank_name'],
                    $order['user_iban'],
                    $order['user_full_name']
                ]);
                
                $assignedCount++;
            }
        }
        $pdo->commit();
        $adminMessage = $assignedCount > 0 ? "$assignedCount işlem Agentlara dağıtıldı." : "Uygun Agent bulunamadı.";
        $msgType = $assignedCount > 0 ? 'success' : 'warning';

    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $adminMessage = "Hata: " . $e->getMessage();
        $msgType = 'danger';
    }
}
// --- LİSTELEME ---
// Kullanıcının banka/crypto bilgilerini de çekiyoruz.
$rows = $pdo->query("
    SELECT w.*, u.username, u.trc20_address 
    FROM withdraw_requests w 
    JOIN users u ON u.id = w.user_id 
    ORDER BY w.id DESC LIMIT 100
")->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/_admin_header.php';
?>

<div class="container-fluid p-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-4 gap-3">
        <div>
            <h1 class="h3 text-gray-800 m-0"><i class="ri-hand-coin-line me-2"></i><?= $pageTitle ?></h1>
            <p class="text-muted small m-0">Üyelerin (Users) para çekme talepleri.</p>
        </div>
        
        <form method="post">
            <button type="submit" name="auto_dispatch" class="btn btn-primary shadow-sm d-flex align-items-center px-4 py-2">
                <i class="ri-robot-2-line me-2 fs-5"></i>
                <div class="text-start">
                    <div class="fw-bold" style="font-size: 0.9rem;">Otomatik Dağıt</div>
                    <div style="font-size: 0.7rem; opacity: 0.8;">Uygun Agentlara Ata</div>
                </div>
            </button>
        </form>
    </div>

    <?php if ($adminMessage): ?>
        <div class="alert alert-<?= $msgType ?> alert-dismissible fade show shadow-sm" role="alert">
            <strong>Sistem:</strong> <?= htmlspecialchars($adminMessage) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow border-0">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light text-secondary">
                        <tr>
                            <th class="ps-4">ID</th>
                            <th>Kullanıcı</th>
                            <th>Tutar</th>
                            <th>Yöntem</th>
                            <th>Hedef Hesap (IBAN / Cüzdan)</th>
                            <th>Durum</th>
                            <th class="text-end pe-4">Zaman</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rows as $row): ?>
                        <tr class="wd-row border-bottom" data-id="<?= $row['id'] ?>">
                            <td class="ps-4 text-muted">#<?= $row['id'] ?></td>
                            <td class="fw-bold text-dark"><?= htmlspecialchars($row['username']) ?></td>
                            <td>
                                <span class="text-danger fw-bold fs-6">
                                    <?= number_format($row['amount'], 2) ?> <small class="text-muted">TL</small>
                                </span>
                            </td>
                            <td>
                                <?php if(isset($row['method']) && $row['method'] == 'bank'): ?>
                                    <span class="badge bg-white text-primary border border-primary"><i class="ri-bank-line me-1"></i>Banka</span>
                                <?php else: ?>
                                    <span class="badge bg-white text-success border border-success"><i class="ri-bit-coin-line me-1"></i>Kripto</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="d-flex flex-column" style="font-size: 0.85rem;">
                                    <?php if(isset($row['method']) && $row['method'] == 'bank'): ?>
                                        <span class="fw-bold text-dark"><?= htmlspecialchars($row['user_bank_name'] ?? '-') ?></span>
                                        <div class="d-flex align-items-center text-muted">
                                            <span class="me-1"><?= htmlspecialchars($row['user_iban'] ?? '-') ?></span>
                                            <i class="ri-file-copy-line cursor-pointer text-primary" onclick="navigator.clipboard.writeText('<?= htmlspecialchars($row['user_iban']) ?>')" title="Kopyala"></i>
                                        </div>
                                        <span class="small text-muted"><?= htmlspecialchars($row['user_full_name'] ?? '') ?></span>
                                    <?php else: ?>
                                        <div class="d-flex align-items-center text-muted">
                                            <span class="me-1 text-truncate" style="max-width: 150px;">
                                                <?= htmlspecialchars($row['address'] ?? $row['trc20_address']) ?>
                                            </span>
                                            <i class="ri-file-copy-line cursor-pointer text-primary" onclick="navigator.clipboard.writeText('<?= htmlspecialchars($row['address'] ?? $row['trc20_address']) ?>')" title="Kopyala"></i>
                                        </div>
                                        <span class="small text-muted">TRC20 Ağı</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <?php 
                                    $st = $row['status'];
                                    $badgeClass = 'bg-secondary';
                                    if($st=='confirmed' || $st=='approved') $badgeClass='bg-success';
                                    if($st=='pending') $badgeClass='bg-warning text-dark';
                                    if($st=='processing') $badgeClass='bg-info text-white';
                                    if($st=='rejected') $badgeClass='bg-danger';
                                ?>
                                <span class="badge <?= $badgeClass ?> rounded-pill"><?= strtoupper($st) ?></span>
                            </td>
                            <td class="text-end pe-4 text-muted small">
                                <?= date('d.m H:i', strtotime($row['created_at'])) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/_admin_footer.php'; ?>