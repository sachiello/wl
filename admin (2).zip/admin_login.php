<?php
session_start();
require __DIR__ . '/../../config/config.php';

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_validate_request()) {
        $error = "Oturum doğrulaması başarısız. Lütfen tekrar deneyin.";
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');

        $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ? LIMIT 1");
        $stmt->execute([$username]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$admin || !password_verify($password, $admin['password_hash'])) {
            $error = "Hatalı kullanıcı adı veya şifre.";
        } else {
            $_SESSION['admin_id'] = $admin['id'];
            header('Location: index.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Admin Giriş</title>
<link rel="stylesheet" href="/public/assets/admin.css">
</head>
<body>

<div class="admin-login-box">
  <h2>Admin Paneli</h2>

  <?php if ($error): ?>
    <div class="admin-alert"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="post">
      <?= csrf_field(); ?>
      <input type="text" name="username" placeholder="Kullanıcı adı" required>
      <input type="password" name="password" placeholder="Şifre" required>
      <button type="submit">Giriş Yap</button>
  </form>
</div>

</body>
</html>
<style>body {
    background: var(--bg-gradient);
    background-attachment: fixed;
    font-family: 'Plus Jakarta Sans', sans-serif;
    color: var(--text-main);
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    overflow: hidden;
}</style>