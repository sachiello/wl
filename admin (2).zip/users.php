<?php
// admin/users.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/require_admin.php'; // $pdo, $currentAdmin

$pageTitle = 'Kullanıcılar – Betwallet Admin';
$activeNav = 'users';

// -----------------------
// Filtre & Arama Parametreleri
// -----------------------
$search = trim($_GET['q'] ?? '');
$status = $_GET['status'] ?? 'all'; // all | active | banned
$page   = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;

$perPage = 50;
$offset  = ($page - 1) * $perPage;

// -----------------------
// Ban / Unban İşlemi
// -----------------------
if (isset($_GET['ban']) || isset($_GET['unban'])) {
    $targetId = (int)($_GET['ban'] ?? $_GET['unban']);
    if ($targetId > 0) {
        $newStatus = isset($_GET['ban']) ? 1 : 0;

        $stmt = $pdo->prepare("UPDATE users SET is_banned = :banned WHERE id = :id");
        $stmt->execute([
            ':banned' => $newStatus,
            ':id'     => $targetId
        ]);

        // Activity log'a yaz
        $action = $newStatus ? 'ban' : 'unban';
        $meta   = json_encode(['user_id' => $targetId]);

        $logStmt = $pdo->prepare("
            INSERT INTO activity_logs (actor_type, actor_id, scope, action, meta_json, created_at)
            VALUES ('admin', :admin_id, 'user', :action, :meta_json, NOW())
        ");
        $logStmt->execute([
            ':admin_id'  => $currentAdmin['id'] ?? null,
            ':action'    => $action,
            ':meta_json' => $meta,
        ]);

        // Mevcut filtreleri koruyarak geri dön
        $redirect = 'users.php?ok=' . ($newStatus ? 'banned' : 'unbanned');
        if ($search !== '') {
            $redirect .= '&q=' . urlencode($search);
        }
        if ($status !== 'all') {
            $redirect .= '&status=' . urlencode($status);
        }
        if ($page > 1) {
            $redirect .= '&page=' . $page;
        }

        header('Location: ' . $redirect);
        exit;
    }
}

// -----------------------
// Genel İstatistikler
// -----------------------

// Toplam kullanıcı sayısı
$totalUsers = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();

// Banlı kullanıcı sayısı
$bannedUsers = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE is_banned = 1")->fetchColumn();

// Toplam cüzdan bakiyeleri (TRX / USDT)
$walletTotals = [
    'TRX'  => 0,
    'USDT' => 0,
];

$walletStmt = $pdo->query("
    SELECT coin_type, SUM(balance) AS total_balance
    FROM wallets
    GROUP BY coin_type
");
foreach ($walletStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $coin = $row['coin_type'];
    $walletTotals[$coin] = (float)$row['total_balance'];
}

// -----------------------
// Liste için filtreler
// -----------------------
$where  = [];
$params = [];

if ($search !== '') {
    // Arama filtrelemesi: username veya TRC20 adresi
    $where[]      = '(u.username LIKE :q OR u.trc20_address LIKE :q)';
    $params[':q'] = '%' . $search . '%';
}

if ($status === 'active') {
    $where[] = 'u.is_banned = 0';
} elseif ($status === 'banned') {
    $where[] = 'u.is_banned = 1';
}

$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

// -----------------------
// Toplam kayıt sayısı
// -----------------------
$countSql   = "SELECT COUNT(*) FROM users u {$whereSql}";
$countStmt  = $pdo->prepare($countSql);
$countStmt->execute($params);
$totalRecords = (int)$countStmt->fetchColumn();
$totalPages   = max(1, (int)ceil($totalRecords / $perPage));

// -----------------------
// Kullanıcı Liste Sorgusu
// -----------------------
$listSql = "
    SELECT 
        u.id,
        u.username,
        u.trc20_address,
        u.created_at,
        u.is_banned,
        COALESCE(w_trx.balance, 0)  AS trx_balance,
        COALESCE(w_usdt.balance, 0) AS usdt_balance,
        COALESCE(d.total_deposit, 0)    AS total_deposit_try,
        COALESCE(wd.total_withdraw, 0)  AS total_withdraw_try,
        COALESCE(sites.linked_sites, 0) AS linked_sites
    FROM users u
    LEFT JOIN wallets w_trx 
        ON w_trx.user_id = u.id AND w_trx.coin_type = 'TRX'
    LEFT JOIN wallets w_usdt
        ON w_usdt.user_id = u.id AND w_usdt.coin_type = 'USDT'
    LEFT JOIN (
        -- Onaylanmış toplam yatırım tutarı (TRY)
        SELECT user_id, SUM(amount_try) AS total_deposit
        FROM deposit_orders
        WHERE status = 'confirmed'
        GROUP BY user_id
    ) d ON d.user_id = u.id
    LEFT JOIN (
        -- Onaylanmış toplam çekim tutarı (Coin)
        SELECT user_id, SUM(amount) AS total_withdraw
        FROM withdraw_requests
        WHERE status = 'approved'
        GROUP BY user_id
    ) wd ON wd.user_id = u.id
    LEFT JOIN (
        -- Bağlı site sayısı
        SELECT user_id, COUNT(*) AS linked_sites
        FROM user_sites
        GROUP BY user_id
    ) sites ON sites.user_id = u.id
    {$whereSql}
    ORDER BY u.id DESC
    LIMIT {$perPage} OFFSET {$offset}
";

$listStmt = $pdo->prepare($listSql);
$listStmt->execute($params);
$users = $listStmt->fetchAll(PDO::FETCH_ASSOC);

// Flash mesaj
$ok = $_GET['ok'] ?? null;

// Header
include __DIR__ . '/_admin_header.php';
?>

<div class="admin-page">
    <div class="admin-page-header">
        <h1>Kullanıcılar</h1>
        <p>Finans sistemine kayıtlı tüm BetWallet kullanıcıları.</p>
    </div>

    <?php if ($ok === 'banned'): ?>
        <div class="alert alert-warning">Kullanıcı başarıyla banlandı.</div>
    <?php elseif ($ok === 'unbanned'): ?>
        <div class="alert alert-success">Kullanıcının banı kaldırıldı.</div>
    <?php endif; ?>

    <div class="admin-stats-grid">
        <div class="admin-card">
            <div class="admin-card-title">Toplam Kullanıcı</div>
            <div class="admin-card-value"><?= number_format($totalUsers) ?></div>
        </div>
        <div class="admin-card">
            <div class="admin-card-title">Aktif Kullanıcı</div>
            <div class="admin-card-value"><?= number_format($totalUsers - $bannedUsers) ?></div>
        </div>
        <div class="admin-card">
            <div class="admin-card-title">Banlı Kullanıcı</div>
            <div class="admin-card-value"><?= number_format($bannedUsers) ?></div>
        </div>
        <div class="admin-card">
            <div class="admin-card-title">Toplam Cüzdan (TRX)</div>
            <div class="admin-card-value"><?= number_format($walletTotals['TRX'], 4) ?> TRX</div>
        </div>
        <div class="admin-card">
            <div class="admin-card-title">Toplam Cüzdan (USDT)</div>
            <div class="admin-card-value"><?= number_format($walletTotals['USDT'], 4) ?> USDT</div>
        </div>
    </div>

    <div class="admin-filters">
        <form method="get" class="admin-filter-form">
            <div class="filter-group">
                <label>Arama</label>
                <input type="text" name="q"
                       value="<?= htmlspecialchars($search) ?>"
                       placeholder="Username veya TRC20 adresi">
            </div>

            <div class="filter-group">
                <label>Durum</label>
                <select name="status">
                    <option value="all" <?= $status === 'all' ? 'selected' : '' ?>>Tümü</option>
                    <option value="active" <?= $status === 'active' ? 'selected' : '' ?>>Sadece Aktif</option>
                    <option value="banned" <?= $status === 'banned' ? 'selected' : '' ?>>Sadece Banlı</option>
                </select>
            </div>

            <div class="filter-group">
                <label>&nbsp;</label>
                <button type="submit" class="btn btn-primary">Filtrele</button>
            </div>
        </form>

        <div class="admin-filter-summary">
            Toplam <?= number_format($totalRecords) ?> kayıt bulundu.
        </div>
    </div>

    <div class="admin-card">
        <div class="admin-card-header">
            <h2>Kullanıcı Listesi</h2>
        </div>

        <div class="admin-table-wrapper">
            <table class="admin-table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>TRC20 Adresi</th>
                    <th>TRX Bakiye</th>
                    <th>USDT Bakiye</th>
                    <th>Toplam Yatırım (TRY)</th>
                    <th>Toplam Çekim (COIN)</th>
                    <th>Bağlı Site</th>
                    <th>Durum</th>
                    <th>Oluşturulma</th>
                    <th>Aksiyon</th>
                </tr>
                </thead>
                <tbody>
                <?php if (!$users): ?>
                    <tr>
                        <td colspan="11" style="text-align:center; padding:20px;">
                            Kayıt bulunamadı.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($users as $u): ?>
                        <tr class="<?= $u['is_banned'] ? 'is-banned' : '' ?>">
                            <td>#<?= (int)$u['id'] ?></td>
                            <td><?= htmlspecialchars($u['username']) ?></td>
                            <td style="font-size: 12px;"><?= htmlspecialchars($u['trc20_address']) ?></td>
                            <td><?= number_format((float)$u['trx_balance'], 4) ?></td>
                            <td><?= number_format((float)$u['usdt_balance'], 4) ?></td>
                            <td><?= number_format((float)$u['total_deposit_try'], 2) ?> TL</td>
                            <td><?= number_format((float)$u['total_withdraw_try'], 2) ?></td>
                            <td><?= (int)$u['linked_sites'] ?></td>
                            <td>
                                <?php if ($u['is_banned']): ?>
                                    <span class="badge badge-danger">Banlı</span>
                                <?php else: ?>
                                    <span class="badge badge-success">Aktif</span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($u['created_at']) ?></td>
                            <td>
                              <a href="user_detail.php?id=<?= (int)$u['id'] ?>&popup=1"
   class="btn btn-xs btn-info js-user-detail"
   data-user-id="<?= (int)$u['id'] ?>">
    Detay
</a>


                                <?php if ($u['is_banned']): ?>
                                    <a href="users.php?unban=<?= (int)$u['id'] ?>&page=<?= $page ?>&q=<?= urlencode($search) ?>&status=<?= urlencode($status) ?>"
                                       class="btn btn-xs btn-success"
                                       onclick="return confirm('Banı kaldırmak istediğine emin misin?');">
                                        Banı Kaldır
                                    </a>
                                <?php else: ?>
                                    <a href="users.php?ban=<?= (int)$u['id'] ?>&page=<?= $page ?>&q=<?= urlencode($search) ?>&status=<?= urlencode($status) ?>"
                                       class="btn btn-xs btn-danger"
                                       onclick="return confirm('Bu kullanıcıyı banlamak istediğine emin misin?');">
                                        Banla
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($totalPages > 1): ?>
            <div class="admin-pagination">
                <?php
                $base_url   = 'users.php?q=' . urlencode($search) . '&status=' . urlencode($status);
                $start_page = max(1, $page - 2);
                $end_page   = min($totalPages, $page + 2);

                if ($page > 1) {
                    $url = $base_url . '&page=' . ($page - 1);
                    echo '<a href="' . $url . '" class="page-link">&laquo; Önceki</a>';
                }

                for ($p = $start_page; $p <= $end_page; $p++):
                    $url = $base_url . '&page=' . $p;
                    ?>
                    <a href="<?= $url ?>"
                       class="page-link <?= $p === $page ? 'is-active' : '' ?>">
                        <?= $p ?>
                    </a>
                <?php endfor;

                if ($page < $totalPages) {
                    $url = $base_url . '&page=' . ($page + 1);
                    echo '<a href="' . $url . '" class="page-link">Sonraki &raquo;</a>';
                }
                ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<!-- Kullanıcı Detay Modalı -->
<div class="admin-modal-backdrop" id="user-detail-modal" style="display:none;">
    <div class="admin-modal">
        <button type="button" class="admin-modal-close" id="user-detail-close">
            &times;
        </button>
        <div class="admin-modal-header">
            <h2 id="user-detail-title">Kullanıcı Detayı</h2>
        </div>
        <div class="admin-modal-body" id="user-detail-content">
            <!-- AJAX ile yüklenecek -->
            <div style="padding:20px; text-align:center; font-size:13px; color:#6b7280;">
                Yükleniyor...
            </div>
        </div>
    </div>
</div>

<script>
// Kullanıcı detay popup
document.addEventListener('DOMContentLoaded', function () {
    const modal      = document.getElementById('user-detail-modal');
    const modalBody  = document.getElementById('user-detail-content');
    const closeBtn   = document.getElementById('user-detail-close');

    // Detay butonuna tıklama
    document.body.addEventListener('click', function (e) {
        const btn = e.target.closest('.js-user-detail');
        if (!btn) return;

        e.preventDefault();
        const url = btn.getAttribute('href');

        // Önce loading göster
        modalBody.innerHTML = '<div style="padding:20px; text-align:center; font-size:13px; color:#6b7280;">Yükleniyor...</div>';
        modal.style.display = 'flex';

        fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(res => res.text())
            .then(html => {
                modalBody.innerHTML = html;
            })
            .catch(err => {
                modalBody.innerHTML = '<div style="padding:20px; text-align:center; color:#b91c1c;">Bir hata oluştu: ' + err + '</div>';
            });
    });

    // Kapat butonu
    closeBtn.addEventListener('click', function () {
        modal.style.display = 'none';
        modalBody.innerHTML = '';
    });

    // Backdrop tıklayınca kapansın
    modal.addEventListener('click', function (e) {
        if (e.target === modal) {
            modal.style.display = 'none';
            modalBody.innerHTML = '';
        }
    });
});
</script>
<?php
include __DIR__ . '/_admin_footer.php';

