<?php
// admin/agent_cash_logs.php - Agent Manuel Kasa Giriş Logları
require __DIR__ . '/require_admin.php';

$pageTitle = 'Agent Manuel Kasa Logları';
$activeNav = 'agent_cash_logs'; // Yeni aktif menü adı

// =================================================================
// VERİ ÇEKME (Manuel Kasa Girişleri)
// =================================================================
// activity_logs tablosundan sadece 'agent' tarafından yapılan 'cash_in_manual' hareketlerini çekiyoruz.
$sql = "
    SELECT 
        l.*, 
        a.name AS agent_name 
    FROM activity_logs l
    JOIN deposit_agents a ON a.id = l.actor_id
    WHERE l.actor_type = 'agent' AND l.action = 'cash_in_manual'
    ORDER BY l.created_at DESC
    LIMIT 300
";
$logs = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>

<?php include '_admin_header.php'; // Header'ı ve Sidebar'ı dahil et ?>

<style>
/* ============================================
   DARK MODE UYUMLU LOG SAYFASI STİLLERİ
   ============================================
*/
:root {
    --primary: #4f46e5;
    --success: #10b981;
    --danger: #dc2626;
    --warning: #f59e0b;
    --radius-lg: 12px;
    --text-main: #1f2937;
    --text-muted: #6b7280;
    --bg-card: #ffffff;
    --bg-table-head: #f8fafc;
    --bg-log-detail: #f1f5f9;
    --border-light: #e5e7eb;
}

/* DARK MODE OVERRIDES */
body.dark-mode {
    --text-main: #f9fafb; /* Açık ana metin */
    --text-muted: #9ca3af; /* Açık gri metin */
    --bg-card: #1f2937; /* Koyu kart */
    --bg-table-head: #374151; /* Koyu tablo başlığı */
    --bg-log-detail: #4b5563; /* Koyu detay kutusu */
    --border-light: #374151; /* Koyu kenarlık */
}

/* Ortak Stiller (Dark/Light her ikisine de uygulanır) */
.page-content { padding: 32px; }
.card { 
    background: var(--bg-card); 
    border: 1px solid var(--border-light); 
    border-radius: var(--radius-lg); 
    padding: 24px; 
    box-shadow: 0 4px 10px rgba(0,0,0,0.05); 
    margin-bottom: 20px;
    transition: all 0.2s;
}
body.dark-mode .card { box-shadow: 0 4px 10px rgba(0,0,0,0.2); }

.card-header-styled { 
    border-bottom: 1px solid var(--border-light); 
    padding-bottom: 15px; 
    margin-bottom: 15px;
    display: flex; 
    justify-content: space-between; 
    align-items: center;
}
.card-header-styled h3 { color: var(--text-main); }
.admin-table { width: 100%; border-collapse: collapse; }
.admin-table th { 
    text-align: left; 
    padding: 12px 15px; 
    background-color: var(--bg-table-head); 
    color: var(--text-muted); 
    font-weight: 600; 
    text-transform: uppercase;
    font-size: 12px;
}
.admin-table td { 
    padding: 15px; 
    border-top: 1px solid var(--border-light); 
    vertical-align: middle; 
    font-size: 14px;
    color: var(--text-main); 
}
.admin-table tr:hover { background-color: rgba(79, 70, 229, 0.05); }
body.dark-mode .admin-table tr:hover { background-color: rgba(79, 70, 229, 0.1); }

.log-detail-box {
    background-color: var(--bg-log-detail);
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 13px;
    margin-top: 5px;
    font-weight: 500;
}
.log-detail-box strong { color: var(--text-main); }

/* Inline Renk Düzeltmeleri */
.admin-table td div[style*="var(--primary)"] {
    color: var(--primary) !important;
}
.admin-table td div[style*="var(--success)"] {
    color: var(--success) !important;
}
.admin-table td div[style*="var(--danger)"] {
    color: var(--danger) !important;
}
</style>

<div class="page-content">
    <header class="admin-header">
        <h2 class="page-title"><?= htmlspecialchars($pageTitle) ?></h2>
    </header>

    <div class="card">
        <div class="card-header-styled" style="border-bottom: 1px solid var(--border-light); padding-bottom: 15px; margin-bottom: 15px;">
            <h3 style="font-weight: 600; font-size: 18px;">Son 300 Kasa Giriş Hareketi</h3>
        </div>

        <div class="table-container">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Tarih</th>
                        <th>Agent</th>
                        <th>İşlem Türü</th>
                        <th>Tutar</th>
                        <th>Detaylar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($logs)): ?>
                        <?php foreach ($logs as $log): 
                            $meta = json_decode($log['meta_json'], true);
                            $amount = (float)($meta['amount'] ?? 0);
                            $oldCash = (float)($meta['old_cash'] ?? 0);
                            $newCash = (float)($meta['new_cash'] ?? 0);
                        ?>
                            <tr>
                                <td><?= date('d.m.Y H:i', strtotime($log['created_at'])) ?></td>
                                <td>
                                    <div style="font-weight: 700; color: var(--primary);"><?= htmlspecialchars($log['agent_name']) ?></div>
                                    <div style="font-size: 11px; color: var(--text-muted);">ID: <?= (int)$log['actor_id'] ?></div>
                                </td>
                                <td>
                                    <span style="background: #eef2ff; color: var(--primary); padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: 600;">
                                        KASA GİRİŞİ (MANUEL)
                                    </span>
                                </td>
                                <td>
                                    <div style="font-weight: 700; color: var(--success); font-size: 16px;">+<?= number_format($amount, 2) ?> ₺</div>
                                </td>
                                <td>
                                    <div class="log-detail-box">
                                        Eski Kasa: <strong><?= number_format($oldCash, 2) ?> ₺</strong> 
                                        &rarr; Yeni Kasa: <strong><?= number_format($newCash, 2) ?> ₺</strong>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center" style="padding: 30px; color: var(--text-muted);">Henüz manuel kasa giriş kaydı bulunmamaktadır.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '_admin_footer.php'; ?>