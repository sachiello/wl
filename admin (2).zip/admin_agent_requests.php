<?php
// admin/admin_agent_requests.php - TAM VE DÜZELTİLMİŞ SÜRÜM
require __DIR__ . '/require_admin.php';

$pageTitle  = 'Agent Bakiye Talepleri';
$activeNav  = 'agent_requests';

$adminError = null;
$adminSuccess = null;
$csrfFailed = false;
$adminId = (int)($currentAdmin['id'] ?? 0);

// =================================================================
// POST İŞLEMLERİ (ONAY/RED)
// =================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF kontrolü
    if (!function_exists('csrf_validate')) {
        // Fonksiyon yoksa hata mesajı
        $adminError = "CSRF kontrol fonksiyonu bulunamadı.";
    } else {
        try {
            csrf_validate();
        } catch (Exception $e) {
            $err = $e->getMessage();
        }
    }
    
    if (!$err) {
        $requestId = (int)($_POST['req_id'] ?? 0);
        $action = $_POST['action'] ?? ''; // 'approve' veya 'reject'

        if ($requestId > 0 && ($action === 'approve' || $action === 'reject')) {
            try {
                $pdo->beginTransaction();

                // 1. Talebi Kilitle ve Çek (Agent bakiyelerini de FOR UPDATE ile çekmek daha güvenlidir)
                $stmt = $pdo->prepare("
                    SELECT r.*, a.system_balance, a.current_cash, a.agent_profit_balance
                    FROM agent_balance_requests r
                    JOIN deposit_agents a ON a.id = r.agent_id
                    WHERE r.id = ? AND r.status = 'pending'
                    FOR UPDATE
                ");
                $stmt->execute([$requestId]);
                $request = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$request) {
                    throw new Exception("Talep bulunamadı veya zaten işlenmiş.");
                }

                $agentId = (int)$request['agent_id'];
                $amount = (float)$request['amount']; // Agent'ın gönderdiği ana para
                $bonusRate = (float)$request['bonus_rate'];
                
                $teminatInc = $amount;
                $initialProfit = round($amount * ($bonusRate / 100), 2);
                $amountCredited = $teminatInc + $initialProfit; // Toplam yüklenen (Teminat + Kâr)

                if ($action === 'approve') {
                    // 2a. ONAYLA: Agent'ın Teminat Bakiyesini ve Kâr Cüzdanını Güncelle
                    $updateAgent = $pdo->prepare("
                        UPDATE deposit_agents
                        SET system_balance = system_balance + :teminat_inc,
                            agent_profit_balance = agent_profit_balance + :profit_inc,
                            total_profit_earned = total_profit_earned + :profit_inc
                        WHERE id = :agent_id
                    ");
                    $updateAgent->execute([
                        ':teminat_inc' => $teminatInc,
                        ':profit_inc' => $initialProfit,
                        ':agent_id' => $agentId,
                    ]);

                    // 2b. agent_balance_requests tablosunu güncelle
                    $pdo->prepare("
                        UPDATE agent_balance_requests 
                        SET status = 'approved', amount_credited = ?, admin_id = ?, processed_at = NOW() 
                        WHERE id = ?
                    ")->execute([$amountCredited, $adminId, $requestId]);
                    
                    // 2c. Loglama (agent_balance_logs ve agent_profit_logs)
                    // Agent Balance Log'u (Teminat hareketi)
                    $afterBalance = (float)$request['system_balance'] + $teminatInc;
                    $beforeBalance = (float)$request['system_balance'];

                    $insertBalanceLog = $pdo->prepare("
                        INSERT INTO agent_balance_logs
                            (agent_id, amount, balance_before, balance_after, source_type, source_id, description)
                        VALUES
                            (:agent_id, :amount, :before, :after, 'manual_load', :source_id, :description)
                    ");
                    $insertBalanceLog->execute([
                        ':agent_id' => $agentId,
                        ':amount' => $teminatInc,
                        ':before' => $beforeBalance,
                        ':after' => $afterBalance,
                        ':source_id' => $requestId,
                        ':description' => 'Admin onaylı teminat yükleme',
                    ]);

                    // Kâr hareketini agent_profit_logs tablosuna yaz
                    if ($initialProfit > 0) {
                        $insertProfitLog = $pdo->prepare("
                            INSERT INTO agent_profit_logs
                                (agent_id, type, amount, fee_amount, description)
                            VALUES
                                (:agent_id, 'bonus_on_topup', :amount, 0, :description)
                        ");
                        $insertProfitLog->execute([
                            ':agent_id' => $agentId,
                            ':amount' => $initialProfit,
                            ':description' => "İlk teminat yüklemesinden gelen kâr (Talep #{$requestId})",
                        ]);
                    }

                    $adminSuccess = sprintf(
                        "Talep onaylandı. Agent teminatına %s TL, kâr cüzdanına %s TL eklendi.",
                        number_format($teminatInc, 2),
                        number_format($initialProfit, 2)
                    );

                } elseif ($action === 'reject') {
                    // 2. REDDET: Talebin Durumunu Güncelle
                    $pdo->prepare("UPDATE agent_balance_requests SET status = 'rejected', admin_id = ?, processed_at = NOW() WHERE id = ? AND status = 'pending'")
                        ->execute([$adminId, $requestId]);
                    
                    $adminSuccess = 'Talep reddedildi.';
                }

                $pdo->commit();

            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $adminError = "İşlem hatası: " . $e->getMessage();
            }
        } else {
            // Eğer CSRF hatası yoksa ve işlem geçersizse hata ver
            if (!$adminError) {
                 $adminError = "Geçersiz işlem veya talep ID'si.";
            }
        }
    }
}

// =================================================================
// VERİ ÇEKME (Tüm talepler, bekleyenler en üstte)
// =================================================================
$sql = "
    SELECT r.*, a.name AS agent_name, a.system_balance AS agent_collateral, a.current_cash AS agent_cash 
    FROM agent_balance_requests r
    JOIN deposit_agents a ON a.id = r.agent_id
    ORDER BY r.status = 'pending' DESC, r.created_at DESC
";
$requests = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>

<?php include '_admin_header.php'; // Header'ı ve Sidebar'ı dahil et ?>

<style>
/* ============================================
   DARK MODE UYUMLU AGENT TALEP SAYFASI STİLLERİ
   ============================================
*/
:root {
    --primary: #4f46e5;
    --success: #10b981;
    --danger: #dc2626;
    --warning: #f59e0b;
    --radius-sm: 6px;
    --radius-lg: 12px;
}

/* Light Mode Varsayılanları (Mevcut hali) */
:root {
    --bg-body: #f3f4f6;
    --bg-card: #ffffff;
    --border-light: #e5e7eb;
    --text-main: #1f2937;
    --text-muted: #6b7280;
    --bg-table-head: #f8fafc;
    --bg-pending-row: #fffbeb;
    --bg-alert-danger: #fef2f2;
    --bg-alert-success: #f0fdf4;
    --color-success-bg: #dcfce7;
    --color-warning-bg: #fef3c7;
    --color-danger-bg: #fef2f2;
    --color-btn-reject: #fee2e2;
}

/* DARK MODE OVERRIDES */
body.dark-mode {
    --bg-body: #111827;
    --bg-card: #1f2937; 
    --border-light: #374151; 
    --text-main: #f9fafb; 
    --text-muted: #9ca3af; 
    --bg-table-head: #1f2937; 
    --bg-pending-row: #27272a; 
    --bg-alert-danger: #450a0a; 
    --bg-alert-success: #064e3b; 
    --color-success-bg: #065f46;
    --color-warning-bg: #78350f;
    --color-danger-bg: #991b1b;
    --color-btn-reject: #450a0a;
}
body.dark-mode .alert-danger { border-color: #7f1d1d; color: #fca5a5; }
body.dark-mode .alert-success { border-color: #0d9488; color: #5eead4; }

/* Ortak Stiller */
.page-content { padding: 32px; }
.card { 
    background: var(--bg-card); 
    border: 1px solid var(--border-light); 
    border-radius: var(--radius-lg); 
    padding: 24px; 
    box-shadow: 0 4px 10px rgba(0,0,0,0.05); 
    margin-bottom: 20px;
    transition: all 0.2s;
}
body.dark-mode .card { box-shadow: 0 4px 10px rgba(0,0,0,0.2); }

.card-header-styled { 
    border-bottom: 1px solid var(--border-light); 
    padding-bottom: 15px; 
    margin-bottom: 15px;
    display: flex; 
    justify-content: space-between; 
    align-items: center;
}
.card-header-styled h3 { color: var(--text-main); }
.table-container { overflow-x: auto; }
.admin-table { width: 100%; border-collapse: collapse; }
.admin-table th { 
    text-align: left; 
    padding: 12px 15px; 
    background-color: var(--bg-table-head); 
    color: var(--text-muted); 
    font-weight: 600; 
    text-transform: uppercase;
    font-size: 12px;
}
.admin-table td { 
    padding: 15px; 
    border-top: 1px solid var(--border-light); 
    vertical-align: middle; 
    font-size: 14px;
    color: var(--text-main); 
}
.admin-table tr:hover { background-color: rgba(79, 70, 229, 0.05); }
body.dark-mode .admin-table tr:hover { background-color: rgba(79, 70, 229, 0.1); }

/* --- Bildirimler --- */
.alert-box { 
    padding: 15px; 
    border-radius: var(--radius-sm); 
    margin-bottom: 20px; 
    display: flex; 
    align-items: center; 
    gap: 10px; 
    font-size: 14px; 
    font-weight: 600;
}
.alert-danger { background: var(--bg-alert-danger); color: var(--danger); border: 1px solid #fecaca; }
.alert-success { background: var(--bg-alert-success); color: var(--success); border: 1px solid #bbf7d0; }

/* --- Rozetler ve Butonlar --- */
.badge-status { 
    padding: 4px 10px; 
    border-radius: 20px; 
    font-size: 11px; 
    font-weight: 700; 
    text-transform: uppercase; 
}
.status-pending { background-color: var(--color-warning-bg); color: var(--warning); }
.status-approved { background-color: var(--color-success-bg); color: var(--success); }
.status-rejected { background-color: var(--color-danger-bg); color: var(--danger); }

.btn-sm { padding: 6px 12px; font-size: 13px; border-radius: 6px; border: none; font-weight: 600; cursor: pointer; }
.btn-approve { background-color: var(--success); color: white; transition: background-color 0.2s; }
.btn-approve:hover { background-color: #047857; }
.btn-reject { background-color: var(--color-btn-reject); color: var(--danger); transition: background-color 0.2s; }
.btn-reject:hover { background-color: #fca5a5; }
body.dark-mode .btn-reject:hover { background-color: #7f1d1d; }

/* Animasyon */
.pending-row { 
    background-color: var(--bg-pending-row); 
    animation: pulse-light 2s infinite; 
    border-left: 3px solid var(--warning);
}
@keyframes pulse-light { 0%, 100% { opacity: 1; } 50% { opacity: 0.95; } }

/* Inline Renk Düzeltmeleri */
.admin-table td .font-weight-bold, .admin-table td .text-main {
    color: var(--text-main) !important;
}
.admin-table td .text-muted {
    color: var(--text-muted) !important;
}
/* Agent Adı Rengi */
.admin-table td div[style*="var(--primary)"] {
    color: var(--primary) !important;
}
.admin-table td div[style*="var(--success)"] {
    color: var(--success) !important;
}
.admin-table td div[style*="var(--danger)"] {
    color: var(--danger) !important;
}
</style>

<div class="page-content">

    <?php if ($adminError): ?>
        <div class="alert-box alert-danger"><i class="ri-error-warning-fill"></i> <?= htmlspecialchars($adminError) ?></div>
    <?php endif; ?>

    <?php if ($adminSuccess): ?>
        <div class="alert-box alert-success"><i class="ri-checkbox-circle-fill"></i> <?= htmlspecialchars($adminSuccess) ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header-styled">
            <h3 style="font-weight: 600; font-size: 18px;">Agent Bakiye Talepleri</h3>
            <span class="badge-status status-pending"><?= count(array_filter($requests, fn($r) => $r['status'] === 'pending')) ?> BEKLEYEN</span>
        </div>

        <div class="table-container">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID / Agent</th>
                        <th>Gönderilen Tutar</th>
                        <th>Kredi (+Teminat +Kâr)</th>
                        <th>Agent Bakiyesi (Mevcut)</th>
                        <th>Durum</th>
                        <th>Tarih</th>
                        <th class="text-end">İşlem</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($requests)): ?>
                        <?php foreach ($requests as $req): 
                            $statusClass = $req['status'] === 'pending' ? 'status-pending' : ($req['status'] === 'approved' ? 'status-approved' : 'status-rejected');
                            $amount = (float)$req['amount'];
                            $bonusRate = (float)$req['bonus_rate'];
                            $initialProfit = round($amount * ($bonusRate / 100), 2);
                            $teminatInc = $amount;
                        ?>
                            <tr class="<?= $req['status'] === 'pending' ? 'pending-row' : '' ?>">
                                <td>
                                    <div class="font-weight-bold" style="color: var(--text-main);">#<?= (int)$req['id'] ?></div>
                                    <div style="color: var(--primary); font-weight: 600; font-size: 13px;"><?= htmlspecialchars($req['agent_name']) ?></div>
                                </td>
                                <td>
                                    <div style="font-weight: 700; color: var(--text-main);"><?= number_format($amount, 2) ?> ₺</div>
                                    <div style="font-size: 11px; color: var(--text-muted);">Bonus: <?= $bonusRate ?>%</div>
                                </td>
                                <td>
                                    <div style="font-weight: 700; color: var(--success);">
                                        Toplam: <?= number_format($teminatInc + $initialProfit, 2) ?> ₺
                                    </div>
                                    <div style="font-size: 11px; color: var(--text-muted);">Teminat: <?= number_format($teminatInc, 2) ?> ₺ / Kâr: <?= number_format($initialProfit, 2) ?> ₺</div>
                                </td>
                                <td>
                                    <div style="font-weight: 700; color: var(--text-main);">
                                        T: <?= number_format($req['agent_collateral'], 2) ?> ₺<br>
                                        K: <?= number_format($req['agent_cash'], 2) ?> ₺
                                    </div>
                                </td>
                                <td>
                                    <span class="badge-status <?= $statusClass ?>"><?= htmlspecialchars(strtoupper($req['status'])) ?></span>
                                </td>
                                <td style="color: var(--text-muted);"><?= date('d.m.Y H:i', strtotime($req['created_at'])) ?></td>
                                <td class="text-end">
                                    <?php if ($req['status'] === 'pending'): ?>
                                        <form method="post" style="display:inline-block; margin-right: 5px;">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="req_id" value="<?= (int)$req['id'] ?>">
                                            <button type="submit" name="action" value="approve" class="btn-sm btn-approve"
                                                onclick="return confirm('Agent: <?= htmlspecialchars($req['agent_name']) ?>\nToplam Yüklenecek: <?= number_format($teminatInc + $initialProfit, 2) ?> ₺\n\nONAYLAMAK İSTEDİĞİNİZE EMİN MİSİNİZ?');">
                                                Onayla <i class="ri-check-line"></i>
                                            </button>
                                        </form>
                                        <form method="post" class="d-inline-block">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="req_id" value="<?= (int)$req['id'] ?>">
                                            <button type="submit" name="action" value="reject" class="btn-sm btn-reject"
                                                    onclick="return confirm('Talebi reddetmek istediğinize emin misiniz?');">
                                                Reddet
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span style="color: var(--text-muted); font-size: 12px;">İşlendi</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center" style="padding: 30px; color: var(--text-muted);">Bekleyen bakiye/teminat talebi yok.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '_admin_footer.php'; ?>