<?php
// _admin_header.php
// BURAYA SORGULARI EKLEMEK İÇİN GEREKLİ require_admin.php'nin yüklendiği varsayılır.

// Varsayılan değerler
$pageTitle = $pageTitle ?? 'Admin Panel';
$activeNav = $activeNav ?? '';

// ================= PHP MANTIĞI =================
if (isset($pdo)) {
    $counts = [];

    try {
        // 1. Kullanıcı yatırımları (pending)
        $counts['deposits'] = (int)$pdo->query("
            SELECT COUNT(*) FROM deposit_orders WHERE status = 'pending'
        ")->fetchColumn();

        // 2. Kullanıcı çekimleri (pending)
        $counts['user_withdrawals'] = (int)$pdo->query("
            SELECT COUNT(*) FROM withdraw_requests WHERE status = 'pending'
        ")->fetchColumn();

        // 3. Site çekimleri (Mutabakat) (pending)
        $counts['site_withdrawals'] = (int)$pdo->query("
            SELECT COUNT(*) FROM site_withdrawals WHERE status = 'pending'
        ")->fetchColumn();

        // 4. Agent bakiye talepleri (pending)
        $counts['agent_requests'] = (int)$pdo->query("
            SELECT COUNT(*) FROM agent_balance_requests WHERE status = 'pending'
        ")->fetchColumn();

        // 5. Agent çekim talepleri (pending)
        $counts['agent_withdrawals'] = (int)$pdo->query("
            SELECT COUNT(*) FROM agent_withdraw_orders WHERE status = 'pending'
        ")->fetchColumn();

        // 6. Site Yükleme/Bakiye Talepleri (YENİ)
        $counts['site_balance_requests'] = (int)$pdo->query("
            SELECT COUNT(*) FROM site_balance_requests WHERE status = 'pending'
        ")->fetchColumn();

        // 7. Site Deposit Requests
        $counts['site_deposit_requests'] = (int)$pdo->query("
            SELECT COUNT(*) FROM site_deposit_requests WHERE status = 'pending'
        ")->fetchColumn();

    } catch (Throwable $e) {
        $counts = [];
    }

    // Link bazlı badge helper
    $badge = function (string $key) use (&$counts) {
        $val = $counts[$key] ?? 0;
        $display = ($val > 0) ? 'inline-block' : 'none';
        return '<span class="nav-badge" id="badge_' . $key . '" style="display:' . $display . ';">(' . (int)$val . ')</span>';
    };

    // Sekme (section) bazlı toplam badge helper
    $sectionBadge = function (string $sectionKey) use (&$counts) {
        $map = [
            'finance_users'  => ['deposits', 'user_withdrawals'],
            'finance_agents' => ['agent_requests', 'agent_withdrawals'],
            'finance_sites'  => ['site_balance_requests', 'site_withdrawals', 'site_deposit_requests'],
        ];

        if (!isset($map[$sectionKey])) {
            return '';
        }

        $sum = 0;
        foreach ($map[$sectionKey] as $k) {
            $sum += (int)($counts[$k] ?? 0);
        }

        if ($sum <= 0) {
            return '';
        }

        return '<span class="nav-badge nav-badge-section">(' . $sum . ')</span>';
    };
} else {
    $badge = fn($key) => '';
    $sectionBadge = fn($key) => '';
}

// Agent sidebar'ından alınan stil helper'ı
if (!function_exists('getAdminMenuStyle')) {
    function getAdminMenuStyle($pageName, $currentPage) {
        $isActive = ($currentPage == $pageName);
        $bg = $isActive ? '#eef2ff' : 'transparent';
        $color = $isActive ? '#4f46e5' : '#4b5563';
        $fontWeight = $isActive ? '600' : '500';
        return "display: flex; align-items: center; gap: 10px; padding: 12px 20px; color: $color; font-weight: $fontWeight; background: $bg; text-decoration: none; margin-bottom: 2px; border-radius: 0 20px 20px 0; margin-right: 10px;";
    }
}
// ===============================================
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?></title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">

    <link rel="stylesheet" href="../../public/assets/admin.css">

    <style>
        /* Agent Panelinden Adapte Edilen Stiller */
        .admin-layout {
            min-height: 100vh;
            display: flex;
            background: #f3f4f6; /* Genel arka plan */
        }
        .admin-sidebar {
            width: 260px;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            box-sizing: border-box;
            background: #ffffff; /* Beyaz sidebar arka planı */
            box-shadow: 2px 0 5px rgba(0,0,0,0.05);
            padding-top: 15px;
            padding-bottom: 15px;
            position: sticky;
            top: 0;
        }
        .admin-logo {
            padding: 10px 20px;
            margin-bottom: 20px;
            font-size: 20px;
            font-weight: 800;
            color: #4f46e5;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .admin-nav {
            flex: 1 1 auto;
            overflow-y: auto;
            padding-right: 4px;
        }

        /* Navigasyon Linkleri - Agent Stili */
        .admin-nav-link { 
            position: relative; 
            display: flex; 
            align-items: center; 
            gap: 10px; 
            padding: 12px 20px; 
            color: #4b5563; 
            font-weight: 500; 
            background: transparent; 
            text-decoration: none; 
            margin-bottom: 2px; 
            border-radius: 0 20px 20px 0; 
            margin-right: 10px;
            transition: all 0.2s;
        }
        .admin-nav-link i { font-size: 18px; }
        .admin-nav-link:hover { 
            background: #f3f4f6;
            color: #1f2937;
        }
        .admin-nav-link.is-active {
            background: #eef2ff; /* Açık mavi aktif renk */
            color: #4f46e5; /* İndigo */
            font-weight: 600;
        }
        .admin-nav-link.is-active i { color: #4f46e5; }
        .admin-nav-link span { margin-left: 0; } /* span'ın sol marjini kaldırıldı */
        
        /* Rozetler */
        .nav-badge {
            background: #ef4444; /* Kırmızı */
            color: white;
            font-size: 10px;
            font-weight: 700;
            padding: 2px 6px;
            border-radius: 999px;
            margin-left: auto; /* Sağa yasla */
            line-height: 1;
            display: inline-block;
            box-shadow: 0 0 6px rgba(239, 68, 68, 0.5);
            animation: pulse-badge 1.6s infinite ease-in-out;
        }
        .nav-badge-section {
            font-size: 10px;
            padding: 1px 6px;
            margin-left: 5px; /* Başlığa yakın tut */
        }
        @keyframes pulse-badge {
            0%   { box-shadow: 0 0 4px rgba(239, 68, 68, 0.5); }
            50%  { box-shadow: 0 0 10px rgba(239, 68, 68, 1); }
            100% { box-shadow: 0 0 4px rgba(239, 68, 68, 0.5); }
        }

        /* Açılır/kapanır nav section'lar */
        .nav-section { margin-bottom: 8px; }
        .nav-category-toggle {
            width: 100%;
            border: none;
            background: transparent;
            color: #1f2937; /* Koyu metin rengi */
            text-align: left;
            padding: 9px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            cursor: pointer;
            border-radius: 10px;
            margin: 4px 0;
            font-weight: 600;
        }
        .nav-category-toggle:hover {
            background: #f3f4f6;
        }
        .nav-category-title {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            font-weight: 700;
            text-transform: none; /* Uppercase'i kaldırdık */
            letter-spacing: 0;
            color: #4f46e5; /* Agent sidebar'ından alınan renk */
        }
        .nav-category-title i { font-size: 16px; color: #4f46e5; }

        .nav-category-arrow {
            transition: transform 0.2s ease;
            font-size: 16px;
            opacity: 0.8;
            color: #4b5563;
        }

        .nav-section.collapsed .nav-category-arrow {
            transform: rotate(-90deg);
        }

        .nav-section-body {
            overflow: hidden;
            transition: max-height 0.2s ease;
            padding-left: 0; /* İçeriği sıfırladık */
        }

        .nav-section.collapsed .nav-section-body {
            max-height: 0;
        }
        .nav-section:not(.collapsed) .nav-section-body {
            max-height: 500px;
        }
        
        /* Logout Linki */
        .admin-logout-link {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 20px;
            color: #ef4444;
            font-weight: 500;
            text-decoration: none;
        }

        /* Header Stili */
        .admin-header {
            background: #ffffff;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #e5e7eb;
            position: sticky;
            top: 0;
            z-index: 50;
        }
        .admin-header h2 { font-size: 20px; margin: 0; color: #1f2937; }
        .header-actions { display: flex; align-items: center; gap: 15px; }
        .user-pill {
            display: flex;
            align-items: center;
            gap: 8px;
            background: #f3f4f6;
            padding: 8px 12px;
            border-radius: 999px;
            font-size: 14px;
            font-weight: 500;
            color: #1f2937;
        }
        .user-avatar {
            width: 30px;
            height: 30px;
            background: #4f46e5;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
        }
    </style>
</head>
<body>

<div class="admin-layout">

    <aside class="admin-sidebar">
        <div class="admin-logo">
            <i class="ri-wallet-3-fill"></i>
            <span>BETWALLET ADMIN</span>
        </div>

        <nav class="admin-nav">
            <div class="nav-section" data-section="dashboard">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title">
                        <i class="ri-dashboard-line"></i>
                        <span>Genel Bakış</span>
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <a href="index.php" class="admin-nav-link <?= $activeNav === 'dashboard' ? 'is-active' : '' ?>">
                        <i class="ri-home-5-line"></i>
                        <span>Panel</span>
                    </a>
                </div>
            </div>

            <div class="nav-section" data-section="users">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title">
                        <i class="ri-user-3-line"></i>
                        <span>Kullanıcı Yönetimi</span>
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <a href="users.php" class="admin-nav-link <?= $activeNav === 'users' ? 'is-active' : '' ?>">
                        <i class="ri-user-3-line"></i>
                        <span>Kullanıcılar</span>
                    </a>
                    <a href="user_sites.php" class="admin-nav-link <?= $activeNav === 'user_sites' ? 'is-active' : '' ?>">
                        <i class="ri-user-shared-line"></i>
                        <span>Kullanıcı &amp; Site Eşleşmeleri</span>
                    </a>
                    <a href="site_reports.php" class="admin-nav-link <?= $activeNav === 'site_reports' ? 'is-active' : '' ?>">
                        <i class="ri-bar-chart-2-line"></i>
                        <span>Site Raporları</span>
                    </a>
                </div>
            </div>

            <div class="nav-section" data-section="finance_users">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title">
                        <i class="ri-hand-coin-line"></i>
                        <span>Finansal İşlemler – Kullanıcı</span>
                        <?= $sectionBadge('finance_users') ?>
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <a href="deposits.php" class="admin-nav-link <?= $activeNav === 'deposits' ? 'is-active' : '' ?>">
                        <i class="ri-arrow-down-circle-line"></i>
                        <span>Yatırımlar</span>
                        <?= $badge('deposits') ?>
                    </a>
                    <a href="withdrawals.php" class="admin-nav-link <?= $activeNav === 'withdrawals' ? 'is-active' : '' ?>">
                        <i class="ri-hand-coin-line"></i>
                        <span>Kullanıcı Çekimleri</span>
                        <?= $badge('user_withdrawals') ?>
                    </a>
                </div>
            </div>
            
            <div class="nav-section" data-section="finance_agents">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title">
                        <i class="ri-user-star-line"></i>
                        <span>Finansal İşlemler – Agent</span>
                        <?= $sectionBadge('finance_agents') ?>
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <a href="admin_agent_requests.php" class="admin-nav-link <?= $activeNav === 'agent_requests' ? 'is-active' : '' ?>">
                        <i class="ri-inbox-line"></i>
                        <span>Bakiye Talepleri</span>
                        <?= $badge('agent_requests') ?>
                    </a>
                    <a href="admin_agent_profit_withdrawals.php" class="admin-nav-link <?= $activeNav === 'agent_withdrawals' ? 'is-active' : '' ?>">
                        <i class="ri-wallet-2-line"></i>
                        <span>Çekim Talepleri</span>
                        <?= $badge('agent_withdrawals') ?>
                    </a>
                </div>
            </div>

            <div class="nav-section" data-section="finance_sites">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title">
                        <i class="ri-global-line"></i>
                        <span>Finansal İşlemler – Site</span>
                        <?= $sectionBadge('finance_sites') ?>
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <a href="admin_site_requests.php" class="admin-nav-link <?= $activeNav === 'site_requests' ? 'is-active' : '' ?>">
                        <i class="ri-add-circle-line"></i>
                        <span>Bakiye Yükleme Onayı</span>
                        <?= $badge('site_balance_requests') ?>
                    </a>

                    <a href="site_withdrawals.php" class="admin-nav-link <?= $activeNav === 'site_withdrawals' ? 'is-active' : '' ?>">
                        <i class="ri-exchange-dollar-line"></i>
                        <span>Mutabakat (Çekim) Talepleri</span>
                        <?= $badge('site_withdrawals') ?>
                    </a>
                    
                    <a href="site_deposit_requests.php" class="admin-nav-link <?= $activeNav === 'site_deposit_requests' ? 'is-active' : '' ?>">
                        <i class="ri-download-cloud-2-line"></i>
                        <span>API Yükleme Talepleri</span>
                        <?= $badge('site_deposit_requests') ?>
                    </a>
                </div>
            </div>

            <div class="nav-section" data-section="management">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title">
                        <i class="ri-briefcase-4-line"></i>
                        <span>Yönetim</span>
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <a href="admin_sites.php" class="admin-nav-link <?= $activeNav === 'sites' ? 'is-active' : '' ?>">
                        <i class="ri-global-line"></i>
                        <span>Siteler</span>
                    </a>
                    <a href="admin_deposit_ibans.php" class="admin-nav-link <?= $activeNav === 'ibans' ? 'is-active' : '' ?>">
                        <i class="ri-bank-card-line"></i>
                        <span>IBAN Yönetimi</span>
                    </a>
                    <a href="admin_deposit_agents.php" class="admin-nav-link <?= $activeNav === 'agents' ? 'is-active' : '' ?>">
                        <i class="ri-user-star-line"></i>
                        <span>Aracılar</span>
                    </a>
                    <a href="performance.php" class="admin-nav-link <?= $activeNav === 'performance' ? 'is-active' : '' ?>">
                        <i class="ri-pie-chart-2-line"></i>
                        <span>Performans Analizi</span>
                    </a>
                    <a href="admin_crypto_wallets.php" class="admin-nav-link <?= $activeNav === 'crypto_wallets' ? 'is-active' : '' ?>">
                        <i class="ri-qr-code-line"></i>
                        <span>Kripto Cüzdanları</span>
                    </a>
                    <a href="admin_settings.php" class="admin-nav-link <?= $activeNav === 'settings' ? 'is-active' : '' ?>">
                        <i class="ri-settings-3-line"></i>
                        <span>Ayarlar &amp; Duyuru</span>
                    </a>
                    <a href="admins.php" class="admin-nav-link <?= $activeNav === 'admins' ? 'is-active' : '' ?>">
                        <i class="ri-shield-user-line"></i>
                        <span>Admin Kullanıcıları</span>
                    </a>
                </div>
            </div>

            <div class="nav-section" data-section="logs">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title">
                        <i class="ri-history-line"></i>
                        <span>Loglar</span>
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <a href="admin_logs.php" class="admin-nav-link <?= $activeNav === 'logs' ? 'is-active' : '' ?>">
                        <i class="ri-history-line"></i>
                        <span>İşlem Geçmişi</span>
                    </a>
                    <a href="agent_balance_logs.php" class="admin-nav-link <?= $activeNav === 'agent_balance_logs' ? 'is-active' : '' ?>">
                        <i class="ri-list-ordered-2"></i>
                        <span>Agent Bakiye Logları</span>
                    </a>
                    <a href="agent_personnel_logs.php" class="admin-nav-link <?= $activeNav === 'agent_personnel_logs' ? 'is-active' : '' ?>">
                        <i class="ri-user-settings-line"></i>
                        <span>Personel Logları</span>
                    </a>
                </div>
            </div>
        </nav>

        <div style="margin-top: auto;">
            <a href="admin_logout.php" class="admin-logout-link">
                <i class="ri-logout-box-r-line"></i>
                <span>Oturumu Kapat</span>
            </a>
        </div>
    </aside>

    <main class="admin-main">
        <div class="admin-content-scroll">
            
            <header class="admin-header">
                <div class="page-title">
                    <h2><?= htmlspecialchars($pageTitle) ?></h2>
                </div>
                
                <div class="header-actions">
                    <button class="btn-glass" style="padding: 10px; border-radius: 50%; border:none; background: #f3f4f6; color: #4b5563;">
                        <i class="ri-notification-3-line" style="margin:0;"></i>
                    </button>

                    <div class="user-pill">
                        <div class="user-avatar">
                            <i class="ri-user-3-fill"></i>
                        </div>
                        <span>Admin</span>
                        <i class="ri-arrow-down-s-line" style="color: var(--text-muted);"></i>
                    </div>
                </div>
            </header>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const sections = document.querySelectorAll('.nav-section');

    sections.forEach(section => {
        const toggle = section.querySelector('.nav-category-toggle');
        const body = section.querySelector('.nav-section-body');

        if (!toggle || !body) return;

        // Varsayılan: tüm menüler kapalı başlasın
        section.classList.add('collapsed');
        
        // Aktif olan linkin olduğu menüyü otomatik aç
        const isActive = section.querySelector('.admin-nav-link.is-active');
        if (isActive) {
            section.classList.remove('collapsed');
        }


        toggle.addEventListener('click', () => {
            section.classList.toggle('collapsed');
        });
    });
});
</script>