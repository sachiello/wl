<?php
// _admin_header.php
// BURAYA SORGULARI EKLEMEK İÇİN GEREKLİ require_admin.php'nin yüklendiği varsayılır.

// Varsayılan değerler
$pageTitle = $pageTitle ?? 'Admin Panel';
$activeNav = $activeNav ?? '';

// Agent panelinden alınmış kullanıcı bilgileri için placeholder
$displayName = isset($me['name']) ? $me['name'] : 'Admin User';
$displayRole = 'Sistem Yöneticisi';

// ================= PHP MANTIĞI =================
if (isset($pdo)) {
    $counts = [];

    try {
        // 1. Kullanıcı yatırımları (pending)
        $counts['deposits'] = (int)$pdo->query("
            SELECT COUNT(*) FROM deposit_orders WHERE status = 'pending'
        ")->fetchColumn();

        // 2. Kullanıcı çekimleri (pending)
        $counts['user_withdrawals'] = (int)$pdo->query("
            SELECT COUNT(*) FROM withdraw_requests WHERE status = 'pending'
        ")->fetchColumn();

        // 3. Site çekimleri (Mutabakat) (pending)
        $counts['site_withdrawals'] = (int)$pdo->query("
            SELECT COUNT(*) FROM site_withdrawals WHERE status = 'pending'
        ")->fetchColumn();

        // 4. Agent bakiye talepleri (pending)
        $counts['agent_requests'] = (int)$pdo->query("
            SELECT COUNT(*) FROM agent_balance_requests WHERE status = 'pending'
        ")->fetchColumn();

        // 5. Agent çekim talepleri (pending)
        $counts['agent_withdrawals'] = (int)$pdo->query("
            SELECT COUNT(*) FROM agent_withdraw_orders WHERE status = 'pending'
        ")->fetchColumn();

        // 6. Site Yükleme/Bakiye Talepleri (YENİ)
        // (site_balance_requests tablosu)
        $counts['site_balance_requests'] = (int)$pdo->query("
            SELECT COUNT(*) FROM site_balance_requests WHERE status = 'pending'
        ")->fetchColumn();

        // 7. Site Deposit Requests (Eğer API üzerinden geliyorsa - Eski yapıdan kalma olabilir)
        $counts['site_deposit_requests'] = (int)$pdo->query("
            SELECT COUNT(*) FROM site_deposit_requests WHERE status = 'pending'
        ")->fetchColumn();

    } catch (Throwable $e) {
        $counts = [];
    }

    // Link bazlı badge helper
    $badge = function (string $key) use (&$counts) {
        $val = $counts[$key] ?? 0;
        // Değer 0 olsa bile span'ı gizli olarak basıyoruz ki JS onu bulup güncelleyebilsin.
        $display = ($val > 0) ? 'inline-block' : 'none';
        return '<span class="nav-badge" id="badge_' . $key . '" style="display:' . $display . ';">(' . (int)$val . ')</span>';
    };

    // Sekme (section) bazlı toplam badge helper
    $sectionBadge = function (string $sectionKey) use (&$counts) {
        // Hangi section hangi counter'ları topluyor:
        $map = [
            'finance_users'  => ['deposits', 'user_withdrawals'],
            'finance_agents' => ['agent_requests', 'agent_withdrawals'],
            'finance_sites'  => ['site_balance_requests', 'site_withdrawals', 'site_deposit_requests'],
        ];

        if (!isset($map[$sectionKey])) {
            return '';
        }

        $sum = 0;
        foreach ($map[$sectionKey] as $k) {
            $sum += (int)($counts[$k] ?? 0);
        }

        if ($sum <= 0) {
            return '';
        }

        return '<span class="nav-badge nav-badge-section">(' . $sum . ')</span>';
    };
} else {
    $badge = fn($key) => '';
    $sectionBadge = fn($key) => '';
}
// ===============================================
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?></title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">

    <link rel="stylesheet" href="../../public/assets/admin.css">

    <style>
        /*
        * Layout, font ve ana renk stilleri admin.css'e taşındı.
        * Burada sadece badge animasyonu ve nav section stili bırakılıyor.
        */

        .nav-badge {
            background: #ef4444;
            color: white;
            font-size: 10px;
            font-weight: 700;
            padding: 2px 6px;
            border-radius: 999px;
            margin-left: 5px;
            line-height: 1;
            display: inline-block;
            box-shadow: 0 0 6px rgba(239, 68, 68, 0.8);
            animation: pulse-badge 1.6s infinite ease-in-out;
        }

        .nav-badge-section {
            font-size: 10px;
            padding: 1px 6px;
        }

        @keyframes pulse-badge {
            0%   { box-shadow: 0 0 4px rgba(239, 68, 68, 0.5); }
            50%  { box-shadow: 0 0 10px rgba(239, 68, 68, 1); }
            100% { box-shadow: 0 0 4px rgba(239, 68, 68, 0.5); }
        }

        /* Açılır/kapanır nav section'lar */
        .nav-section {
            margin-bottom: 8px;
        }

        .nav-category-toggle {
            width: 100%;
            border: none;
            background: transparent; /* Stil admin.css'e taşındı */
            color: inherit;
            font: inherit;
            text-align: left;
            padding: 9px 14px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            cursor: pointer;
            opacity: 0.95;
            border-radius: 10px;
            margin: 4px 6px;
        }

        .nav-category-toggle:hover {
            opacity: 1;
            background: var(--bg-hover); /* Değişken kullanıldı */
        }

        .nav-category-title {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px; /* Font boyutu Agent ile uyumlu hale getirildi */
            font-weight: 600;
            text-transform: none;
            letter-spacing: normal;
        }

        .nav-category-title i {
            font-size: 20px;
        }

        .nav-category-arrow {
            transition: transform 0.2s ease;
            font-size: 16px;
            opacity: 0.8;
            margin-left: auto;
        }

        .nav-section.collapsed .nav-category-arrow {
            transform: rotate(-90deg);
        }

        .nav-section-body {
            overflow: hidden;
            transition: max-height 0.2s ease;
            padding-left: 0; /* Padding kaldırıldı, linkler yönetmeli */
        }
        .nav-section-body a {
            padding-left: 10px;
        }

        .nav-section.collapsed .nav-section-body {
            max-height: 0;
        }

        .nav-section:not(.collapsed) .nav-section-body {
            max-height: 500px;
        }
    </style>
</head>
<body>

<button class="mobile-menu-btn" onclick="toggleSidebar()">
    <i class="ri-menu-2-line"></i>
</button>

<div class="sidebar-overlay" onclick="toggleSidebar()"></div>

<div class="admin-layout">

    <aside class="admin-sidebar" id="appSidebar">
        <div class="admin-logo">
            <i class="ri-wallet-3-fill"></i>
            <span>BETWALLET</span>
            <i class="ri-close-line" style="font-size:24px; cursor:pointer; margin-left:auto; display:none;" id="closeMenuIcon" onclick="toggleSidebar()"></i>
        </div>

        <nav class="admin-nav">
            <div class="nav-section" data-section="dashboard">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title">
                        <i class="ri-dashboard-line"></i>
                        <span>Genel Bakış</span>
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <a href="index.php" class="admin-nav-link <?= $activeNav === 'dashboard' ? 'is-active' : '' ?>">
                        <i class="ri-home-5-line"></i>
                        <span>Panel</span>
                    </a>
                </div>
            </div>

            <div class="nav-section" data-section="users">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title">
                        <i class="ri-user-3-line"></i>
                        <span>Kullanıcı Yönetimi</span>
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <a href="users.php" class="admin-nav-link <?= $activeNav === 'users' ? 'is-active' : '' ?>">
                        <i class="ri-user-3-line"></i>
                        <span>Kullanıcılar</span>
                    </a>
                    <a href="user_sites.php" class="admin-nav-link <?= $activeNav === 'user_sites' ? 'is-active' : '' ?>">
                        <i class="ri-user-shared-line"></i>
                        <span>Kullanıcı &amp; Site Eşleşmeleri</span>
                    </a>
                    <a href="site_reports.php" class="admin-nav-link <?= $activeNav === 'site_reports' ? 'is-active' : '' ?>">
                        <i class="ri-bar-chart-2-line"></i>
                        <span>Site Raporları</span>
                    </a>
                </div>
            </div>

            <div class="nav-section" data-section="finance_users">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title">
                        <i class="ri-hand-coin-line"></i>
                        <span>Finansal İşlemler – Kullanıcı</span>
                        <?= $sectionBadge('finance_users') ?>
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <a href="deposits.php" class="admin-nav-link <?= $activeNav === 'deposits' ? 'is-active' : '' ?>">
                        <i class="ri-arrow-down-circle-line"></i>
                        <span>Yatırımlar</span>
                        <?= $badge('deposits') ?>
                    </a>
                    <a href="withdrawals.php" class="admin-nav-link <?= $activeNav === 'withdrawals' ? 'is-active' : '' ?>">
                        <i class="ri-hand-coin-line"></i>
                        <span>Kullanıcı Çekimleri</span>
                        <?= $badge('user_withdrawals') ?>
                    </a>
                </div>
            </div>
            
            <div class="nav-section" data-section="finance_agents">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title">
                        <i class="ri-user-star-line"></i>
                        <span>Finansal İşlemler – Agent</span>
                        <?= $sectionBadge('finance_agents') ?>
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <a href="admin_agent_requests.php" class="admin-nav-link <?= $activeNav === 'agent_requests' ? 'is-active' : '' ?>">
                        <i class="ri-inbox-line"></i>
                        <span>Bakiye Talepleri</span>
                        <?= $badge('agent_requests') ?>
                    </a>
                    <a href="admin_agent_profit_withdrawals.php" class="admin-nav-link <?= $activeNav === 'agent_withdrawals' ? 'is-active' : '' ?>">
                        <i class="ri-wallet-2-line"></i>
                        <span>Çekim Talepleri</span>
                        <?= $badge('agent_withdrawals') ?>
                    </a>
                </div>
            </div>

            <div class="nav-section" data-section="finance_sites">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title">
                        <i class="ri-global-line"></i>
                        <span>Finansal İşlemler – Site</span>
                        <?= $sectionBadge('finance_sites') ?>
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <a href="admin_site_requests.php" class="admin-nav-link <?= $activeNav === 'site_requests' ? 'is-active' : '' ?>">
                        <i class="ri-add-circle-line"></i>
                        <span>Bakiye Yükleme Onayı</span>
                        <?= $badge('site_balance_requests') ?>
                    </a>

                    <a href="site_withdrawals.php" class="admin-nav-link <?= $activeNav === 'site_withdrawals' ? 'is-active' : '' ?>">
                        <i class="ri-exchange-dollar-line"></i>
                        <span>Mutabakat (Çekim) Talepleri</span>
                        <?= $badge('site_withdrawals') ?>
                    </a>
                    
                    <a href="site_deposit_requests.php" class="admin-nav-link <?= $activeNav === 'site_deposit_requests' ? 'is-active' : '' ?>">
                        <i class="ri-download-cloud-2-line"></i>
                        <span>API Yükleme Talepleri</span>
                        <?= $badge('site_deposit_requests') ?>
                    </a>
                </div>
            </div>

            <div class="nav-section" data-section="management">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title">
                        <i class="ri-briefcase-4-line"></i>
                        <span>Yönetim</span>
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <a href="admin_sites.php" class="admin-nav-link <?= $activeNav === 'sites' ? 'is-active' : '' ?>">
                        <i class="ri-global-line"></i>
                        <span>Siteler</span>
                    </a>
                    <a href="admin_deposit_ibans.php" class="admin-nav-link <?= $activeNav === 'ibans' ? 'is-active' : '' ?>">
                        <i class="ri-bank-card-line"></i>
                        <span>IBAN Yönetimi</span>
                    </a>
                    <a href="admin_deposit_agents.php" class="admin-nav-link <?= $activeNav === 'agents' ? 'is-active' : '' ?>">
                        <i class="ri-user-star-line"></i>
                        <span>Aracılar</span>
                    </a>
                    <a href="performance.php" class="admin-nav-link <?= $activeNav === 'performance' ? 'is-active' : '' ?>">
                        <i class="ri-pie-chart-2-line"></i>
                        <span>Performans Analizi</span>
                    </a>
                    <a href="admin_crypto_wallets.php" class="admin-nav-link <?= $activeNav === 'crypto_wallets' ? 'is-active' : '' ?>">
                        <i class="ri-qr-code-line"></i>
                        <span>Kripto Cüzdanları</span>
                    </a>
                    <a href="admin_settings.php" class="admin-nav-link <?= $activeNav === 'settings' ? 'is-active' : '' ?>">
                        <i class="ri-settings-3-line"></i>
                        <span>Ayarlar &amp; Duyuru</span>
                    </a>
                    <a href="admins.php" class="admin-nav-link <?= $activeNav === 'admins' ? 'is-active' : '' ?>">
                        <i class="ri-shield-user-line"></i>
                        <span>Admin Kullanıcıları</span>
                    </a>
                </div>
            </div>

            <div class="nav-section" data-section="logs">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title">
                        <i class="ri-history-line"></i>
                        <span>Loglar</span>
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <a href="admin_logs.php" class="admin-nav-link <?= $activeNav === 'logs' ? 'is-active' : '' ?>">
                        <i class="ri-history-line"></i>
                        <span>İşlem Geçmişi</span>
                    </a>
                    <a href="agent_cash_logs.php" class="admin-nav-link <?= $activeNav === 'agent_balance_logs' ? 'is-active' : '' ?>">
                        <i class="ri-list-ordered-2"></i>
                        <span>Agent Kasa Logları</span>
                    </a>
                    <a href="agent_personnel_logs.php" class="admin-nav-link <?= $activeNav === 'agent_personnel_logs' ? 'is-active' : '' ?>">
                        <i class="ri-user-settings-line"></i>
                        <span>Personel Logları</span>
                    </a>
                </div>
            </div>
        </nav>

        <div class="sidebar-footer">
            <div class="user-info">
                <div class="user-avatar">
                    <?= strtoupper(substr($displayName, 0, 1)) ?>
                </div>
                <div class="user-details">
                    <div><?= htmlspecialchars($displayName) ?></div>
                    <div><?= htmlspecialchars($displayRole) ?></div>
                </div>
            </div>
            <a href="admin_logout.php" class="logout-link">
                <i class="ri-logout-box-r-line"></i> Güvenli Çıkış
            </a>
        </div>
        </aside>

    <main class="admin-main">
        <div class="admin-content-scroll">
            
            <header class="admin-header">
                <div class="page-title">
                    <h2><?= htmlspecialchars($pageTitle) ?></h2>
                </div>
                
                <div class="header-actions">
                    <div class="dark-mode-toggle" onclick="toggleDarkMode()">
                        <i class="ri-moon-line"></i>
                    </div>

                    <button class="btn-glass" style="padding: 10px; border-radius: 50%;">
                        <i class="ri-notification-3-line" style="margin:0;"></i>
                    </button>

                    <div class="user-pill">
                        <div class="user-avatar">
                            <i class="ri-user-3-fill"></i>
                        </div>
                        <span><?= htmlspecialchars($displayName) ?></span>
                        <i class="ri-arrow-down-s-line" style="color: var(--text-muted);"></i>
                    </div>
                </div>
            </header>

<script>
// AGENT PANELİNDEN ALINAN MOBİL VE DARK MODE SCRIPT'leri
function toggleSidebar() {
    const sidebar = document.getElementById('appSidebar');
    const overlay = document.querySelector('.sidebar-overlay');
    const closeIcon = document.getElementById('closeMenuIcon');
    
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
    
    // Mobil görünümde kapatma ikonunu göster/gizle
    if (window.innerWidth <= 768) {
        if (sidebar.classList.contains('active')) {
            closeIcon.style.display = 'block';
        } else {
            closeIcon.style.display = 'none';
        }
    }
}

// DARK MODE LOGIC (Agent panelinden alındı)
if (localStorage.getItem('theme') === 'dark') {
    document.body.classList.add('dark-mode');
}
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
}

// Menü section açma/kapatma (Mevcut mantık korundu)
document.addEventListener('DOMContentLoaded', function () {
    const sections = document.querySelectorAll('.nav-section');

    sections.forEach(section => {
        const toggle = section.querySelector('.nav-category-toggle');
        
        // DÜZELTME: Sayfa yüklendiğinde tüm menüleri varsayılan olarak kapatır.
        section.classList.add('collapsed'); 

        toggle.addEventListener('click', () => {
            section.classList.toggle('collapsed');
        });
    });
});
</script>