<?php
session_start();
require __DIR__ . '/../../config/config.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ? LIMIT 1");
$stmt->execute([$_SESSION['admin_id']]);
$currentAdmin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$currentAdmin) {
    session_destroy();
    header('Location: admin_login.php');
    exit;
}
