<?php
// config.php
// Kullanılan coin listesi
$ACTIVE_COINS = ['USDT']; // TRX'i çıkardık, istersek BTC, ETH ekleriz

// Simple .env loader
$dotenvPath = __DIR__ . '/../.env';
if (file_exists($dotenvPath)) {
    $lines = file($dotenvPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            list($key, $value) = explode('=', $line, 2);
            $_ENV[trim($key)] = trim($value);
            $_SERVER[trim($key)] = trim($value);
        }
    }
}

$DB_HOST = $_ENV['DB_HOST'] ?? 'localhost';
$DB_NAME = $_ENV['DB_NAME'] ?? 'u592601370_bwtest';
$DB_USER = $_ENV['DB_USER'] ?? 'u592601370_bwtestuser';
$DB_PASS = $_ENV['DB_PASS'] ?? 'bwtest123A';

try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die('DB error: ' . $e->getMessage());
}

/**
 * CSRF helpers
 */
function csrf_token(): string {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
}

function csrf_validate_request(): bool {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    $token = $_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    return $token !== '' && isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function csrf_reject_if_invalid(bool $respondJson = false): void {
    if (csrf_validate_request()) {
        return;
    }

    http_response_code(400);
    if ($respondJson) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'error' => 'Geçersiz veya zaman aşımına uğramış oturum doğrulaması. Lütfen sayfayı yenileyin.']);
    } else {
        echo 'CSRF doğrulaması başarısız.';
    }
    exit;
}

/**
 * Basit TRC20 adresi simülasyonu (demo için).
 * Gerçekte chain üstünden üretmen gerekir.
 */
function generateTrc20Address(): string {
    return 'T' . bin2hex(random_bytes(15)); // 31 char civarı
}

/**
 * Merchant imzası üretme (HMAC-SHA256)
 */
function make_signature(string $secret, array $params): string {
    ksort($params);
    $base = http_build_query($params);
    return hash_hmac('sha256', $base, $secret);
}

/**
 * Basit tablo kolon kontrolü (schema bağımlılığını azaltmak için).
 */
function bw_table_has_column(PDO $pdo, string $table, string $column): bool {
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $table) || !preg_match('/^[a-zA-Z0-9_]+$/', $column)) {
        return false;
    }

    $stmt = $pdo->prepare("SHOW COLUMNS FROM `{$table}` LIKE ?");
    $stmt->execute([$column]);
    return (bool)$stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * Kota kontrollü aktif IBAN seçimi.
 * - IBAN aktif olmalı, limit dolmamış olmalı.
 * - Bağlı aracı aktif olmalı ve aracının kotası dolmamış olmalı.
 * Geriye IBAN + aracı bilgilerini döner.
 */
function bw_get_available_iban(PDO $pdo): ?array {
    $sql = "
        SELECT 
          di.*,
          da.id AS agent_id,
          da.balance AS agent_balance, /* Yeni eklendi */
          /* ... diğer sütunlar ... */
        FROM deposit_ibans di
        LEFT JOIN deposit_agents da ON da.id = di.agent_id
        WHERE di.is_active = 1
          AND (di.quota_limit = 0 OR di.quota_used < di.quota_limit)
          AND (
              da.id IS NULL
           OR (
                da.is_active = 1 
                AND da.balance > 0 /* KRİTİK KONTROL: Bakiye sıfırdan büyük olmalı */
                AND (da.quota_limit = 0 OR da.quota_used < da.quota_limit)
              )
          )
        ORDER BY RAND()
        LIMIT 1
    ";

    $stmt = $pdo->query($sql);
    $row  = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}

/**
 * Spesifik IBAN'ı kota/aktivite kontrolüyle getir.
 * Yatırım talebi yaratılırken forma gizli gelen IBAN'ın hâlâ kullanılabilir
 * olup olmadığını doğrulamak için kullanılır.
 */
function bw_get_iban_if_available(PDO $pdo, int $ibanId): ?array {
    if ($ibanId <= 0) {
        return null;
    }

    $sql = "
        SELECT
          di.*,
          da.name        AS agent_name,
          da.quota_limit AS agent_quota_limit,
          da.quota_used  AS agent_quota_used,
          da.is_active   AS agent_active
        FROM deposit_ibans di
        LEFT JOIN deposit_agents da ON da.id = di.agent_id
        WHERE di.id = :id
          AND di.is_active = 1
          AND (di.quota_limit = 0 OR di.quota_used < di.quota_limit)
          AND (
                da.id IS NULL
             OR (da.is_active = 1 AND (da.quota_limit = 0 OR da.quota_used < da.quota_limit))
          )
        LIMIT 1
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([':id' => $ibanId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}

/**
 * Kota artışı ve limit dolduysa otomatik pasif etme.
 */
function bw_increment_quota(PDO $pdo, ?int $ibanId, ?int $agentId, float $amountTry): void {
    if ($amountTry <= 0) {
        return;
    }

    if ($ibanId) {
        $stmt = $pdo->prepare("UPDATE deposit_ibans SET quota_used = quota_used + :amt WHERE id = :id");
        $stmt->execute([':amt' => $amountTry, ':id' => $ibanId]);

        $check = $pdo->prepare("SELECT quota_limit, quota_used FROM deposit_ibans WHERE id = ? LIMIT 1");
        $check->execute([$ibanId]);
        $row = $check->fetch(PDO::FETCH_ASSOC);
        if ($row && (float)$row['quota_limit'] > 0 && (float)$row['quota_used'] >= (float)$row['quota_limit']) {
            $pdo->prepare("UPDATE deposit_ibans SET is_active = 0 WHERE id = ?")->execute([$ibanId]);
        }
    }

    if ($agentId) {
        $stmt = $pdo->prepare("UPDATE deposit_agents SET quota_used = quota_used + :amt WHERE id = :id");
        $stmt->execute([':amt' => $amountTry, ':id' => $agentId]);

        $check = $pdo->prepare("SELECT quota_limit, quota_used FROM deposit_agents WHERE id = ? LIMIT 1");
        $check->execute([$agentId]);
        $row = $check->fetch(PDO::FETCH_ASSOC);
        if ($row && (float)$row['quota_limit'] > 0 && (float)$row['quota_used'] >= (float)$row['quota_limit']) {
            $pdo->prepare("UPDATE deposit_agents SET is_active = 0 WHERE id = ?")->execute([$agentId]);
        }
    }
}

/**
 * Tablo var mı kontrolü.
 */
function bw_table_exists(PDO $pdo, string $table): bool {
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $table)) {
        return false;
    }
    $stmt = $pdo->prepare("SHOW TABLES LIKE ?");
    $stmt->execute([$table]);
    return (bool)$stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * Basit audit log helper.
 * Beklenen tablo: activity_logs(id, actor_type, actor_id, scope, action, meta_json, created_at)
 */
function bw_log_action(PDO $pdo, string $scope, string $actorType, ?int $actorId, string $action, array $meta = []): void {
    if (!bw_table_exists($pdo, 'activity_logs')) {
        return;
    }
    $stmt = $pdo->prepare("
        INSERT INTO activity_logs (actor_type, actor_id, scope, action, meta_json, created_at)
        VALUES (:actor_type, :actor_id, :scope, :action, :meta_json, NOW())
    ");
    $stmt->execute([
        ':actor_type' => $actorType,
        ':actor_id'   => $actorId,
        ':scope'      => $scope,
        ':action'     => $action,
        ':meta_json'  => json_encode($meta, JSON_UNESCAPED_UNICODE),
    ]);
}

/**
 * Aktif ve istenen coin türüne uygun bir kripto cüzdanı seçer.
 */
function bw_get_available_crypto_wallet(PDO $pdo, string $coinSymbol): ?array {
    $stmt = $pdo->prepare("
        SELECT id, address, network, coin_symbol
        FROM admin_crypto_wallets
        WHERE is_active = 1 AND coin_symbol = ?
        ORDER BY RAND()
        LIMIT 1
    ");
    $stmt->execute([$coinSymbol]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}

/**
 * ID ile spesifik bir kripto cüzdanını getirir.
 */
function bw_get_crypto_wallet_by_id(PDO $pdo, int $walletId): ?array {
    if ($walletId <= 0) {
        return null;
    }
    $stmt = $pdo->prepare("SELECT * FROM admin_crypto_wallets WHERE id = ?");
    $stmt->execute([$walletId]);
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}
