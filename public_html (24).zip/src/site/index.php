<?php
// site_panel/index.php
require 'init.php';

// Oturum Kontrolü
if (!isset($_SESSION['site_id'])) {
    header('Location: login.php');
    exit;
}

$siteId = (int)$_SESSION['site_id'];

// 1. Site Verileri
$stmt = $pdo->prepare("SELECT * FROM sites WHERE id = ?");
$stmt->execute([$siteId]);
$siteInfo = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$siteInfo) { die("Site verisi bulunamadı."); }

// 2. İstatistikler
$todayVol = $pdo->query("SELECT SUM(amount_try) FROM merchant_orders WHERE site_id = $siteId AND status = 'success' AND DATE(created_at) = CURDATE()")->fetchColumn() ?? 0;
$totalVol = $pdo->query("SELECT SUM(amount_try) FROM merchant_orders WHERE site_id = $siteId AND status = 'success'")->fetchColumn() ?? 0;
$pendingWithdraw = $pdo->query("SELECT SUM(amount) FROM site_withdrawals WHERE site_id = $siteId AND status = 'pending'")->fetchColumn() ?? 0;
$recentTx = $pdo->query("SELECT * FROM merchant_orders WHERE site_id = $siteId ORDER BY id DESC LIMIT 7")->fetchAll(PDO::FETCH_ASSOC);

// 3. Ayarlar & Bildirimler
$announcement = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'site_announcement'")->fetchColumn();
$annActive    = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'site_announcement_active'")->fetchColumn();
$is2faActive  = (bool)$siteInfo['two_factor_enabled'];

// 4. Sistem Uyarısı
$systemAlert = null;
if ($siteInfo['net_balance'] < 1000) {
    $systemAlert = "Bakiyeniz kritik seviyenin altında (1.000 TL). Lütfen yükleme yapınız.";
}

$pageTitle = 'Genel Bakış';
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($siteInfo['name']) ?> - Yönetim Paneli</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        :root { --primary: #c2273f; --bg-body: #f1f5f9; --bg-card: #ffffff; --text-main: #0f172a; --text-muted: #64748b; --border-color: #e2e8f0; --success: #10b981; --warning: #f59e0b; --info: #3b82f6; --danger: #ef4444; }
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; display: flex; }
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        .sidebar { width: 260px; background: var(--bg-card); border-right: 1px solid var(--border-color); padding: 20px; display: none; }
        @media(min-width: 1024px) { .sidebar { display: block; } }
        .main-content { flex: 1; padding: 30px; overflow-y: auto; }
        
        .header-area { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
        .welcome-text h1 { margin: 0; font-size: 24px; font-weight: 800; }
        .welcome-text p { margin: 5px 0 0; color: var(--text-muted); font-size: 14px; }
        .action-btn { background: var(--bg-card); border: 1px solid var(--border-color); color: var(--text-main); padding: 10px 16px; border-radius: 8px; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 600; transition: all 0.2s; text-decoration: none; }
        .action-btn:hover { background: #f8fafc; border-color: var(--primary); color: var(--primary); }
        
        .announcement-bar { background: rgba(59, 130, 246, 0.1); border: 1px solid rgba(59, 130, 246, 0.3); color: var(--info); padding: 12px 16px; border-radius: 10px; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; font-size: 14px; font-weight: 500; }
        .system-alert { background: #fef2f2; border: 1px solid #fee2e2; color: #b91c1c; padding: 12px 16px; border-radius: 10px; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; font-size: 14px; font-weight: 600; }
        
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: var(--bg-card); padding: 24px; border-radius: 16px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05); border: 1px solid var(--border-color); position: relative; overflow: hidden; transition: transform 0.2s; }
        .stat-card:hover { transform: translateY(-3px); }
        .stat-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 15px; }
        .stat-icon { width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 20px; }
        .stat-title { font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }
        .stat-value { font-size: 28px; font-weight: 800; color: var(--text-main); letter-spacing: -0.5px; }
        .stat-desc { font-size: 12px; color: var(--text-muted); margin-top: 5px; }
        
        .card-primary .stat-icon { background: rgba(59, 130, 246, 0.1); color: var(--info); }
        .card-success .stat-icon { background: rgba(16, 185, 129, 0.1); color: var(--success); }
        .card-warning .stat-icon { background: rgba(245, 158, 11, 0.1); color: var(--warning); }
        .card-brand .stat-icon { background: rgba(194, 39, 63, 0.1); color: var(--primary); }
        
        .dashboard-split { display: grid; grid-template-columns: 2fr 1fr; gap: 20px; }
        @media(max-width: 900px) { .dashboard-split { grid-template-columns: 1fr; } }
        .content-card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); padding: 20px; height: fit-content; margin-bottom: 20px; }
        .card-title { font-size: 16px; font-weight: 700; margin: 0 0 20px 0; display: flex; align-items: center; gap: 8px; }
        
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; font-size: 14px; }
        th { text-align: left; padding: 12px; color: var(--text-muted); font-weight: 600; border-bottom: 1px solid var(--border-color); font-size: 12px; text-transform: uppercase; }
        td { padding: 12px; border-bottom: 1px solid var(--border-color); color: var(--text-main); vertical-align: middle; }
        tr:last-child td { border-bottom: none; }
        .badge { padding: 4px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
        .badge-success { background: rgba(16, 185, 129, 0.15); color: var(--success); }
        .user-ref { font-family: monospace; background: rgba(0,0,0,0.05); padding: 2px 6px; border-radius: 4px; }
    </style>
</head>
<body>

<div class="app-wrapper">
    
    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        
        <div class="header-area">
            <div class="welcome-text">
                <h1>Hoş Geldin, <?= htmlspecialchars($siteInfo['name']) ?></h1>
                <p>İstatistiklerini ve finansal durumunu buradan yönetebilirsin.</p>
            </div>
        </div>

        <?php if($systemAlert): ?>
        <div class="system-alert">
            <i class="ri-alarm-warning-fill"></i>
            <span><?= $systemAlert ?></span>
        </div>
        <?php endif; ?>

        <?php if($annActive == '1' && !empty($announcement)): ?>
        <div class="announcement-bar">
            <i class="ri-megaphone-fill"></i>
            <span><?= htmlspecialchars($announcement) ?></span>
        </div>
        <?php endif; ?>

        <div class="stats-grid">
            
            <div class="stat-card card-primary" style="border-left: 4px solid var(--info);">
                <div class="stat-header">
                    <div>
                        <div class="stat-title">ÇEKİLEBİLİR BAKİYE</div>
                        <div class="stat-value">
                            <?= number_format($siteInfo['net_balance'], 2) ?> ₺
                        </div>
                    </div>
                    <div class="stat-icon"><i class="ri-wallet-3-fill"></i></div>
                </div>
                <div class="stat-desc">Mutabakat için uygun net tutar.</div>
            </div>

            <div class="stat-card card-success">
                <div class="stat-header">
                    <div>
                        <div class="stat-title">GÜNLÜK YATIRIM</div>
                        <div class="stat-value">
                            <?= number_format($todayVol, 2) ?> ₺
                        </div>
                    </div>
                    <div class="stat-icon"><i class="ri-calendar-check-fill"></i></div>
                </div>
                <div class="stat-desc">Bugün gerçekleşen yatırımlar.</div>
            </div>

            <div class="stat-card card-brand">
                <div class="stat-header">
                    <div>
                        <div class="stat-title">TOPLAM YATIRIM</div>
                        <div class="stat-value">
                            <?= number_format($totalVol, 2) ?> ₺
                        </div>
                    </div>
                    <div class="stat-icon"><i class="ri-bar-chart-grouped-fill"></i></div>
                </div>
                <div class="stat-desc">Sistem genelindeki toplam hacim.</div>
            </div>

            <div class="stat-card card-warning">
                <div class="stat-header">
                    <div>
                        <div class="stat-title">BEKLEYEN MUTABAKAT</div>
                        <div class="stat-value">
                            <?= number_format($pendingWithdraw, 2) ?> ₺
                        </div>
                    </div>
                    <div class="stat-icon"><i class="ri-time-fill"></i></div>
                </div>
                <div class="stat-desc">İşlem sırasındaki çekim talepleri.</div>
            </div>

        </div>

        <div class="dashboard-split">
            
            <div class="content-card">
                <h3 class="card-title"><i class="ri-exchange-dollar-line"></i> Son Yatırımlar (Canlı Akış)</h3>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Sipariş ID</th>
                                <th>Kullanıcı</th>
                                <th>Tutar</th>
                                <th>Net</th>
                                <th>Tarih</th>
                                <th>Durum</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($recentTx) > 0): ?>
                                <?php foreach($recentTx as $tx): ?>
                                <tr>
                                    <td><span class="user-ref">#<?= substr($tx['order_id'], -8) ?></span></td>
                                    <td>User-<?= $tx['user_id'] ?></td>
                                    <td style="font-weight:700;"><?= number_format($tx['amount_try'], 2) ?> ₺</td>
                                    <td style="color:var(--success);"><?= number_format($tx['net_amount'], 2) ?> ₺</td>
                                    <td style="font-size:12px; color:var(--text-muted);"><?= date('H:i', strtotime($tx['created_at'])) ?></td>
                                    <td><span class="badge badge-success">ONAY</span></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="6" style="text-align:center; padding:20px; color:var(--text-muted);">Henüz işlem yok.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div style="text-align:center; margin-top:15px;">
                    <a href="deposits.php" style="font-size:13px; font-weight:600; color:var(--primary); text-decoration:none;">Tümünü Gör <i class="ri-arrow-right-line"></i></a>
                </div>
            </div>

            <div style="display:flex; flex-direction:column; gap:20px;">
                
                <div class="content-card" style="<?= $is2faActive ? 'border-left: 4px solid var(--success);' : 'border-left: 4px solid var(--danger);' ?>">
                    <h3 class="card-title"><i class="ri-shield-keyhole-line"></i> Güvenlik Durumu</h3>
                    <?php if($is2faActive): ?>
                        <div style="color:var(--success); font-weight:600; display:flex; align-items:center; gap:8px; margin-bottom:10px;">
                            <i class="ri-checkbox-circle-fill"></i> 2FA Aktif
                        </div>
                        <p style="font-size:13px; color:var(--text-muted);">Hesabınız güvende.</p>
                    <?php else: ?>
                        <div style="color:var(--danger); font-weight:600; display:flex; align-items:center; gap:8px; margin-bottom:10px;">
                            <i class="ri-error-warning-fill"></i> 2FA Pasif
                        </div>
                        <p style="font-size:13px; color:var(--text-muted); margin-bottom:10px;">Güvenliğiniz için 2FA açın.</p>
                        <a href="settings.php" class="action-btn" style="justify-content:center; background:var(--danger); color:#fff; border:none;">Hemen Aktifleştir</a>
                    <?php endif; ?>
                </div>

                <div class="content-card">
                    <h3 class="card-title"><i class="ri-server-line"></i> API Bağlantısı</h3>
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px;">
                        <div style="width:10px; height:10px; background:var(--success); border-radius:50%; box-shadow:0 0 0 3px rgba(16, 185, 129, 0.2);"></div>
                        <span style="font-size:13px; font-weight:600;">Sistem Aktif</span>
                    </div>
                    <p style="font-size:12px; color:var(--text-muted); margin-bottom:15px;">
                        Callback URL: <br>
                        <code style="background:rgba(0,0,0,0.1); padding:2px 4px; border-radius:4px; word-break:break-all;"><?= $siteInfo['callback_url'] ?: 'Ayarlanmamış' ?></code>
                    </p>
                    <div style="font-size:12px; color:var(--primary); background:#fff1f2; padding:10px; border-radius:6px;">
                        <i class="ri-robot-line"></i> <b>Otomasyon API</b> ve özel entegrasyonlar için bizimle iletişime geçin.
                    </div>
                </div>

                <div class="content-card">
                    <h3 class="card-title"><i class="ri-guide-fill"></i> Finans Özeti</h3>
                    <div style="font-size:13px; color:var(--text-muted); line-height:1.6;">
                        <p style="margin-bottom:10px;"><strong>Komisyon:</strong> %<?= $siteInfo['commission_rate'] ?></p>
                        <p>Bakiyenizi çekmek için mutabakat talebi oluşturabilirsiniz.</p>
                        <a href="withdrawals.php" class="action-btn" style="justify-content:center; background:var(--primary); color:#fff; border:none; margin-top:10px; text-decoration:none;">
                            Mutabakat Talep Et
                        </a>
                    </div>
                </div>

            </div>
        </div>

    </div>
</div>

</body>
</html>