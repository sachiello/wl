<?php 
$cur = basename($_SERVER['PHP_SELF']); 
$siteName = $site['name'] ?? $_SESSION['site_name'] ?? 'Merchant Panel';
if (!isset($netBalance)) $netBalance = 0.00;
$showSidebarBalance = true;
if (isset($_SESSION['is_personnel']) && $_SESSION['is_personnel']) {
    // hasPerm fonksiyonunun init.php'de tanımlı olduğunu varsayıyoruz
    if (!function_exists('hasPerm') || !hasPerm('view_sidebar_balance')) {
        $showSidebarBalance = false;
    }
}
?>

<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;800&display=swap" rel="stylesheet">

<style>


    /* --- LOGO ALANI (YENİLENDİ) --- */
    .sidebar-header {
        padding: 25px 20px 10px 20px;
    }
    
    .brand-wrapper {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 25px;
        text-decoration: none;
    }

    .brand-icon {
        width: 42px;
        height: 42px;
        background: linear-gradient(135deg, var(--primary) 0%, #9f1239 100%);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 22px;
        box-shadow: 0 4px 15px rgba(194, 39, 63, 0.3);
    }

    .brand-text {
        display: flex;
        flex-direction: column;
    }

    .brand-title {
        font-family: 'Orbitron', sans-serif; /* Fütüristik Font */
        font-size: 18px;
        font-weight: 800;
        color: var(--text-main);
        letter-spacing: 1px;
        line-height: 1;
    }

    .brand-subtitle {
        font-size: 11px;
        color: var(--text-muted);
        margin-top: 4px;
        font-weight: 600;
        letter-spacing: 0.5px;
        text-transform: uppercase;
    }

    /* --- SİNEMATİK BAKİYE KARTI (YENİLENDİ) --- */
    .sidebar-balance-card {
        background: linear-gradient(145deg, #1e1e24, #0f0f13); /* Koyu Sinematik Taban */
        border-radius: 16px;
        padding: 20px;
        position: relative;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        border: 1px solid rgba(255,255,255,0.05);
        margin-bottom: 10px;
    }

    /* Kırmızı Glow Efekti */
    .sidebar-balance-card::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -50%;
        width: 100%;
        height: 100%;
        background: radial-gradient(circle, rgba(220,38,38,0.4) 0%, transparent 70%);
        filter: blur(40px);
        opacity: 0.6;
        pointer-events: none;
    }

    .sb-label {
        font-size: 10px;
        font-weight: 700;
        color: rgba(255,255,255,0.6);
        letter-spacing: 1px;
        text-transform: uppercase;
        position: relative;
        z-index: 2;
    }

    .sb-amount {
        font-family: 'Orbitron', sans-serif;
        font-size: 22px;
        font-weight: 700;
        color: #fff;
        margin-top: 5px;
        position: relative;
        z-index: 2;
        text-shadow: 0 2px 10px rgba(0,0,0,0.5);
    }
    .sb-amount small { font-size: 14px; color: rgba(255,255,255,0.8); font-family: 'Inter', sans-serif; }

    .sb-icon {
        position: absolute;
        right: 15px;
        bottom: 15px;
        font-size: 24px;
        color: rgba(255,255,255,0.1);
        z-index: 1;
    }

    /* --- MENÜ --- */
    .sidebar-menu {
        flex: 1;
        padding: 10px 16px;
        overflow-y: auto;
    }

    .menu-label {
        font-size: 11px;
        font-weight: 700;
        color: var(--text-muted);
        margin: 20px 0 8px 12px;
        opacity: 0.7;
        letter-spacing: 0.5px;
    }
    
    .sidebar-link {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 11px 14px;
        color: var(--text-muted);
        text-decoration: none;
        font-size: 13px;
        font-weight: 500;
        border-radius: 10px;
        transition: all 0.2s ease;
        margin-bottom: 2px;
    }
    
    .sidebar-link i { font-size: 18px; opacity: 0.8; transition: all 0.2s; }
    
    .sidebar-link:hover {
        background: rgba(0,0,0,0.03);
        color: var(--text-main);
        transform: translateX(2px);
    }
    
    .sidebar-link.active {
        background: rgba(194, 39, 63, 0.08);
        color: var(--primary);
        font-weight: 700;
    }
    .sidebar-link.active i { color: var(--primary); opacity: 1; }

    /* --- FOOTER & DARK MODE --- */
    .sidebar-footer {
        padding: 16px;
        border-top: 1px solid var(--border-color);
    }

    .dm-toggle {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 14px;
        border-radius: 10px;
        cursor: pointer;
        background: var(--bg-body);
        transition: 0.2s;
        color: var(--text-main);
        font-size: 13px;
        font-weight: 600;
    }
    .dm-toggle:hover { background: rgba(0,0,0,0.05); }

    .logout-link {
        margin-top: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 10px;
        border-radius: 10px;
        color: #ef4444;
        font-weight: 600;
        font-size: 13px;
        text-decoration: none;
        transition: 0.2s;
        background: rgba(239, 68, 68, 0.05);
    }
    .logout-link:hover { background: rgba(239, 68, 68, 0.1); }

    /* Dark Mode Adjustments */
    body.dark-mode .sidebar { background: #111827; border-color: #1f2937; }
    body.dark-mode .brand-title { color: #fff; }
    body.dark-mode .sidebar-link:hover { background: rgba(255,255,255,0.05); color: #fff; }
    body.dark-mode .sidebar-footer { border-color: #1f2937; }
    body.dark-mode .dm-toggle { background: #1f2937; color: #e5e7eb; }
    body.dark-mode .dm-toggle:hover { background: #374151; }
</style>

<aside class="sidebar">
    
    <div class="sidebar-header">
        <a href="index.php" class="brand-wrapper">
            <div class="brand-icon">
                <i class="ri-wallet-3-fsll"></i>
            </div>
            <div class="brand-text">
                <div class="brand-title">BETWALLET</div>
                <div class="brand-subtitle"><?= htmlspecialchars($siteName) ?></div>
            </div>
        </a>
        
        <div class="sidebar-balance-card">
            <div class="sb-label">GÜNCEL BAKİYE</div>
            <div class="sb-amount">
                <?php if($showSidebarBalance): ?>
                    <?= number_format($netBalance, 2) ?> <small>₺</small>
                <?php else: ?>
                    <span class="blur-text">*******</span> <small>₺</small>
                <?php endif; ?>
            </div>
            <i class="ri-safe-2-line icon"></i>
        </div>
    </div>

    <nav class="sidebar-menu">
        <div class="menu-label">FİNANSAL İŞLEMLER</div>
        
        <a href="index.php" class="sidebar-link <?= $cur=='index.php'?'active':'' ?>">
            <i class="ri-dashboard-3-line"></i>
            <span>Genel Bakış</span>
        </a>
        
        <?php if(hasPerm('view_deposits')): ?>
        <a href="deposits.php" class="sidebar-link <?= $cur=='deposits.php'?'active':'' ?>">
            <i class="ri-arrow-left-down-line"></i>
            <span>Yatırımlar (Gelen)</span>
        </a>
        <?php endif; ?>

        <?php if(hasPerm('view_users')): ?>
        <a href="user_withdrawals.php" class="sidebar-link <?= $cur=='user_withdrawals.php'?'active':'' ?>">
            <i class="ri-arrow-right-up-line"></i>
            <span>Oyuncu Çekimleri</span>
        </a>
        <?php endif; ?>

        <?php if(hasPerm('create_withdraw')): ?>
        <a href="withdrawals.php" class="sidebar-link <?= $cur=='withdrawals.php'?'active':'' ?>">
            <i class="ri-safe-2-line"></i>
            <span>Mutabakat (Kasa Çek)</span>
        </a>
        <?php endif; ?>

        <?php if(hasPerm('balance')): ?>
        <a href="balance.php" class="sidebar-link <?= $cur=='balance.php'?'active':'' ?>">
            <i class="ri-add-box-line"></i>
            <span>Bakiye Yükle</span>
        </a>
        <?php endif; ?>
        
        <div class="menu-label">YÖNETİM & API</div>

        <?php if(hasPerm('manage_personnel')): ?>
        <a href="personnel.php" class="sidebar-link <?= $cur=='personnel.php'?'active':'' ?>">
            <i class="ri-group-line"></i>
            <span>Personel Yönetimi</span>
        </a>
        <?php endif; ?>

        <?php if(hasPerm('manage_settings')): ?>
        <a href="developer.php" class="sidebar-link <?= $cur=='developer.php'?'active':'' ?>">
            <i class="ri-terminal-box-line"></i>
            <span>Geliştirici / API</span>
        </a>
        <a href="settings.php" class="sidebar-link <?= $cur=='settings.php'?'active':'' ?>">
            <i class="ri-shield-user-line"></i>
            <span>Ayarlar & Güvenlik</span>
        </a>
        <?php endif; ?>
    </nav>

    <div class="sidebar-footer">
        <div class="dm-toggle" id="sidebarDarkModeToggle">
            <span style="display:flex; align-items:center; gap:8px;">
                <i class="ri-moon-clear-line"></i> Görünüm
            </span>
            <i class="ri-toggle-line" style="font-size:20px; opacity:0.5;" id="dmToggleIcon"></i>
        </div>

        <a href="login.php?logout=1" class="logout-link">
            <i class="ri-logout-circle-r-line"></i>
            <span>Güvenli Çıkış</span>
        </a>
    </div>

</aside>

<script>
    // Sidebar Dark Mode Logic
    const dmBtn = document.getElementById('sidebarDarkModeToggle');
    const dmIcon = document.getElementById('dmToggleIcon');
    
    // Sayfa yüklendiğinde ikon durumu
    if (document.body.classList.contains('dark-mode')) {
        dmIcon.className = 'ri-toggle-fill';
        dmIcon.style.color = 'var(--primary)';
        dmIcon.style.opacity = '1';
    }

    dmBtn.addEventListener('click', function() {
        if (typeof toggleDarkMode === "function") { 
            toggleDarkMode(); 
        } else {
            const body = document.body;
            body.classList.toggle('dark-mode');
            const isDark = body.classList.contains('dark-mode');
            localStorage.setItem('theme', isDark ? 'dark' : 'light');
        }
        
        // İkon güncelleme
        if (document.body.classList.contains('dark-mode')) {
            dmIcon.className = 'ri-toggle-fill';
            dmIcon.style.color = 'var(--primary)';
            dmIcon.style.opacity = '1';
        } else {
            dmIcon.className = 'ri-toggle-line';
            dmIcon.style.color = '';
            dmIcon.style.opacity = '0.5';
        }
    });
</script>