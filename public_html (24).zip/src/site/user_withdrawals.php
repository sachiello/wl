<?php
require 'init.php';

// Güvenlik: Oturum Kontrolü
if (!isset($_SESSION['site_id'])) {
    header('Location: login.php');
    exit;
}

// Güncel Site Bakiyesini Çek (Anlık Kontrol İçin)
$stmt = $pdo->prepare("SELECT * FROM sites WHERE id = ?");
$stmt->execute([$_SESSION['site_id']]);
$site = $stmt->fetch(PDO::FETCH_ASSOC);
$currentSiteBalance = (float)$site['net_balance'];

// Sayfalama Ayarları
$page   = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit  = 20;
$offset = ($page - 1) * $limit;

// Filtreler
$start  = $_GET['start'] ?? '';
$end    = $_GET['end'] ?? '';
$search = trim($_GET['search'] ?? '');

// Sorgu Hazırlığı: Yeni tabloya (merchant_player_withdraws) bağlanıyoruz
$whereSQL = "WHERE w.site_id = ?";
$params   = [$site['id']];

if ($start && $end) {
    $whereSQL .= " AND DATE(w.created_at) BETWEEN ? AND ?";
    $params[] = $start;
    $params[] = $end;
}

if ($search) {
    // Site kullanıcı adı (site_user_ref) veya Tutar araması
    $whereSQL .= " AND (w.site_user_ref LIKE ? OR w.amount LIKE ? OR w.order_id LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

// Toplam Kayıt
$countSql = "SELECT COUNT(*) FROM merchant_player_withdraws w $whereSQL";
$stmtCount = $pdo->prepare($countSql);
$stmtCount->execute($params);
$totalRecords = $stmtCount->fetchColumn();
$totalPages   = ceil($totalRecords / $limit);

// Verileri Çek
// user_id ile users tablosunu birleştirip BetWallet kullanıcı adını da alabiliriz (opsiyonel)
$sql = "
    SELECT w.*, u.username as bw_username
    FROM merchant_player_withdraws w
    LEFT JOIN users u ON w.user_id = u.id
    $whereSQL
    ORDER BY w.created_at DESC 
    LIMIT $limit OFFSET $offset
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Oyuncu Çekimleri - <?= htmlspecialchars($site['name']) ?></title>
    
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

    <style>
        /* GLOBAL CSS (Diğer sayfalarla uyumlu) */
        :root { --primary: #c2273f; --bg-body: #f1f5f9; --bg-card: #ffffff; --text-main: #0f172a; --text-muted: #64748b; --border-color: #e2e8f0; --success: #10b981; --info: #0ea5e9; --danger: #ef4444; --warning: #f59e0b; }
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; display: flex; }
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        
        .sidebar { width: 260px; background: var(--bg-card); border-right: 1px solid var(--border-color); padding: 20px; flex-shrink: 0; display: none; }
        @media(min-width: 1024px) { .sidebar { display: block; } }

        .main-content { flex: 1; padding: 30px; overflow-y: auto; width: 100%; }
        
        .card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); padding: 20px; margin-bottom: 20px; }
        .form-control { width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 8px; }
        
        .btn { padding: 10px 20px; border-radius: 8px; border: none; font-weight: 600; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; font-size: 14px; }
        .btn-primary { background: var(--primary); color: #fff; }
        .btn-secondary { background: #e2e8f0; color: var(--text-main); }
        .btn-sm { padding: 6px 12px; font-size: 12px; }

        table { width: 100%; border-collapse: collapse; font-size: 14px; min-width: 600px; }
        th { text-align: left; padding: 12px; color: var(--text-muted); font-size: 11px; text-transform: uppercase; border-bottom: 1px solid var(--border-color); }
        td { padding: 12px; border-bottom: 1px solid var(--border-color); vertical-align: middle; }
        
        .badge { padding: 4px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
        .bg-green { background: rgba(16, 185, 129, 0.1); color: var(--success); }
        .bg-yellow { background: rgba(245, 158, 11, 0.1); color: var(--warning); }
        .bg-red { background: rgba(239, 68, 68, 0.1); color: var(--danger); }
        .bg-gray { background: #f1f5f9; color: var(--text-muted); }

        /* Bakiye Yetersiz Uyarısı İçin Özel Stil */
        .insufficient-balance {
            background: #fef2f2;
            color: #dc2626;
            border: 1px solid #fee2e2;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .sufficient-balance {
            color: var(--success);
            font-size: 11px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .ref-code { font-family: monospace; background: rgba(0,0,0,0.04); padding: 3px 6px; border-radius: 4px; font-size: 12px; color: var(--text-main); }
    </style>
</head>
<body>

<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    
    <div class="main-content">
        <div class="topbar" style="margin-bottom: 30px;">
            <h1 style="margin:0; font-size:24px; font-weight:800;">Oyuncu Çekim Talepleri</h1>
            <p style="margin:5px 0 0; color:var(--text-muted);">Sitenizden BetWallet cüzdanına yapılan transfer istekleri.</p>
        </div>

        <div class="card" style="border-left: 4px solid var(--info); display:flex; justify-content:space-between; align-items:center;">
            <div>
                <div style="font-size:12px; font-weight:700; color:var(--text-muted);">ANLIK ÇEKİLEBİLİR SİTE BAKİYESİ</div>
                <div style="font-size:24px; font-weight:800; color:var(--text-main);">
                    <?= number_format($currentSiteBalance, 2) ?> ₺
                </div>
            </div>
            <div style="font-size:12px; color:var(--text-muted); max-width: 400px; text-align:right;">
                <i class="ri-information-line"></i> Kullanıcı çekimleri bu bakiyeden düşer. Yetersiz bakiye durumunda işlemler beklemeye alınır.
            </div>
        </div>

        <div class="card">
            <form method="get" style="display:flex; gap:12px; flex-wrap:wrap; align-items:flex-end;">
                <div style="flex:1; min-width:200px;">
                    <label style="font-size:12px; font-weight:700; color:var(--text-muted); display:block; margin-bottom:5px;">Tarih Aralığı</label>
                    <input type="text" id="dateRange" class="form-control" placeholder="Tarih seçin...">
                    <input type="hidden" name="start" id="startDate" value="<?= htmlspecialchars($start) ?>">
                    <input type="hidden" name="end" id="endDate" value="<?= htmlspecialchars($end) ?>">
                </div>
                <div style="flex:1; min-width:200px;">
                    <label style="font-size:12px; font-weight:700; color:var(--text-muted); display:block; margin-bottom:5px;">Arama</label>
                    <input type="text" name="search" class="form-control" placeholder="Ref No, Site Kullanıcısı veya Tutar..." value="<?= htmlspecialchars($search) ?>">
                </div>
                <div>
                    <button class="btn btn-primary"><i class="ri-filter-3-line"></i> Filtrele</button>
                    <?php if($start || $search): ?>
                        <a href="player_withdrawals.php" class="btn btn-secondary">Temizle</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <div class="card" style="padding:0; overflow:hidden;">
            <div style="overflow-x:auto;">
                <table>
                    <thead>
                        <tr>
                            <th style="padding-left:20px;">İşlem Kodu</th>
                            <th>Site Kullanıcısı</th>
                            <th>Çekim Tutarı</th>
                            <th>Cüzdan Karşılığı</th>
                            <th>Site Bakiye Durumu</th>
                            <th>Tarih</th>
                            <th style="text-align:right; padding-right:20px;">İşlem Durumu</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($rows as $r): ?>
                        <?php 
                            // Bakiye Yeterlilik Kontrolü
                            $amount = (float)$r['amount'];
                            $isInsufficient = ($r['status'] == 'pending' && $amount > $currentSiteBalance);
                        ?>
                        <tr>
                            <td style="padding-left:20px;">
                                <span class="ref-code">#<?= htmlspecialchars($r['order_id']) ?></span>
                            </td>
                            <td style="font-weight:600; color:var(--text-main);">
                                <?= htmlspecialchars($r['site_user_ref'] ?? 'Bilinmeyen') ?>
                                <?php if(isset($r['bw_username'])): ?>
                                    <div style="font-size:11px; color:var(--text-muted);">
                                        BetWallet: <?= htmlspecialchars($r['bw_username']) ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td style="font-weight:700; color:var(--danger);">
                                -<?= number_format($amount, 2) ?> ₺
                            </td>
                            <td style="color:var(--text-muted); font-family:monospace;">
                                <?= number_format($r['coin_amount'], 6) ?> USDT
                            </td>
                            <td>
                                <?php if($r['status'] == 'pending'): ?>
                                    <?php if($isInsufficient): ?>
                                        <div class="insufficient-balance">
                                            <i class="ri-alert-line"></i> YETERSİZ
                                        </div>
                                    <?php else: ?>
                                        <div class="sufficient-balance">
                                            <i class="ri-check-double-line"></i> UYGUN
                                        </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span style="font-size:11px; color:var(--text-muted);">İşlendi</span>
                                <?php endif; ?>
                            </td>
                            <td style="font-size:13px; color:var(--text-muted);">
                                <?= date('d.m.Y H:i', strtotime($r['created_at'])) ?>
                            </td>
                            <td style="text-align:right; padding-right:20px;">
                                <?php 
                                $st = $r['status'];
                                if($st=='approved') echo '<span class="badge bg-green">ONAYLANDI</span>';
                                elseif($st=='pending') echo '<span class="badge bg-yellow">ONAY BEKLİYOR</span>';
                                else echo '<span class="badge bg-red">REDDEDİLDİ</span>';
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>

                        <?php if(!$rows): ?>
                            <tr>
                                <td colspan="7" style="text-align:center; padding:30px; color:var(--text-muted);">
                                    Herhangi bir talep bulunamadı.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($totalPages > 1): ?>
            <div style="padding:20px; border-top:1px solid var(--border-color); display:flex; justify-content:center; gap:5px;">
                <?php for($i=1; $i<=$totalPages; $i++): ?>
                    <a href="?page=<?= $i ?>&start=<?= $start ?>&end=<?= $end ?>&search=<?= $search ?>" 
                       class="btn btn-sm <?= $page==$i ? 'btn-primary' : 'btn-secondary' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>
            </div>
            <?php endif; ?>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://npmcdn.com/flatpickr/dist/l10n/tr.js"></script>
<script>
    flatpickr("#dateRange", {
        mode: "range",
        dateFormat: "Y-m-d",
        locale: "tr",
        defaultDate: ["<?= $start ?>", "<?= $end ?>"],
        onClose: function(selectedDates, dateStr, instance) {
            if (selectedDates.length === 2) {
                document.getElementById('startDate').value = instance.formatDate(selectedDates[0], "Y-m-d");
                document.getElementById('endDate').value = instance.formatDate(selectedDates[1], "Y-m-d");
            }
        }
    });
</script>

</body>
</html>