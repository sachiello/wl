<?php
// site/login.php
session_start();
require __DIR__ . '/../../config/config.php';

// 1. ÇIKIŞ İŞLEMİ
if (isset($_GET['logout'])) {
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
    }
    session_destroy();
    header('Location: login.php');
    exit;
}

// 2. OTURUM KONTROLÜ
if (isset($_SESSION['site_id'])) {
    header('Location: index.php');
    exit;
}

$error = '';
if (isset($_SESSION['error_message'])) {
    $error = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}

// 3. GİRİŞ İŞLEMİ
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username'] ?? '');
    $pass = trim($_POST['password'] ?? '');

    if ($user && $pass) {
        // A) Site Sahibi mi?
        $stmt = $pdo->prepare("SELECT * FROM sites WHERE site_username = ? LIMIT 1");
        $stmt->execute([$user]);
        $siteOwner = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($siteOwner) {
            $isMatch = password_verify($pass, $siteOwner['site_password']);
            if (!$isMatch && $siteOwner['site_password'] === $pass) $isMatch = true; // Düz metin desteği

            if ($isMatch) {
                if (!$siteOwner['is_active']) {
                    $_SESSION['error_message'] = "Hesabınız pasif durumda.";
                    header('Location: login.php'); exit;
                } else {
                    // IP Kısıtlama Kontrolü
                    if (!empty($siteOwner['allowed_ips'])) {
                        $allowed = array_map('trim', explode(',', $siteOwner['allowed_ips']));
                        if (!in_array($_SERVER['REMOTE_ADDR'], $allowed)) {
                            $_SESSION['error_message'] = "Bu IP adresinden erişim izniniz yok.";
                            header('Location: login.php'); exit;
                        }
                    }

                    $_SESSION['site_id'] = $siteOwner['id'];
                    $_SESSION['site_name'] = $siteOwner['name'];
                    $_SESSION['is_personnel'] = false;
                    header('Location: index.php'); exit;
                }
            } else {
                $_SESSION['error_message'] = "Kullanıcı adı veya şifre hatalı.";
                header('Location: login.php'); exit;
            }
        } 
        else {
            // B) Personel mi?
            $stmtP = $pdo->prepare("SELECT * FROM site_personnel WHERE username = ? LIMIT 1");
            $stmtP->execute([$user]);
            $personnel = $stmtP->fetch(PDO::FETCH_ASSOC);

            if ($personnel && password_verify($pass, $personnel['password_hash'])) {
                if (!$personnel['is_active']) {
                    $_SESSION['error_message'] = "Personel hesabı pasif durumda.";
                    header('Location: login.php'); exit;
                } else {
                    $_SESSION['site_id'] = $personnel['site_id'];
                    $_SESSION['personnel_id'] = $personnel['id'];
                    $_SESSION['is_personnel'] = true;
                    $_SESSION['personnel_name'] = $personnel['username'];
                    header('Location: index.php'); exit;
                }
            } else {
                $_SESSION['error_message'] = "Kullanıcı adı veya şifre hatalı.";
                header('Location: login.php'); exit;
            }
        }
    } else {
        $_SESSION['error_message'] = "Lütfen tüm alanları doldurun.";
        header('Location: login.php'); exit;
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>BetWallet Merchant Giriş</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Orbitron:wght@600;800&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary: #c2273f;
            --primary-hover: #9f1239;
            --bg-body: #f8fafc;
            --text-main: #0f172a;
            --text-muted: #64748b;
            --border-color: #e2e8f0;
        }

        body {
            background: var(--bg-body);
            font-family: 'Inter', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            color: var(--text-main);
        }

        .login-card {
            background: #fff;
            padding: 40px;
            border-radius: 16px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.08);
            border: 1px solid var(--border-color);
        }

        .logo-area {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .brand-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 26px;
            font-weight: 800;
            color: var(--primary);
            letter-spacing: -1px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .brand-subtitle {
            font-size: 13px;
            color: var(--text-muted);
            margin-top: 5px;
            font-weight: 500;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: var(--text-main);
            margin-bottom: 8px;
        }

        .input-wrapper {
            position: relative;
        }
        
        .input-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            font-size: 18px;
        }

        .form-input {
            width: 100%;
            padding: 14px 14px 14px 44px; /* İkon için soldan boşluk */
            border: 1px solid var(--border-color);
            border-radius: 10px;
            font-size: 14px;
            outline: none;
            box-sizing: border-box;
            transition: all 0.2s;
            background: #fcfcfc;
        }

        .form-input:focus {
            border-color: var(--primary);
            background: #fff;
            box-shadow: 0 0 0 3px rgba(194, 39, 63, 0.1);
        }

        .btn-login {
            width: 100%;
            padding: 14px;
            background: var(--primary);
            color: #fff;
            border: none;
            border-radius: 10px;
            font-weight: 700;
            font-size: 15px;
            cursor: pointer;
            transition: background 0.2s;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
        }

        .btn-login:hover {
            background: var(--primary-hover);
        }

        .error-box {
            background: #fee2e2;
            color: #991b1b;
            padding: 12px;
            border-radius: 8px;
            font-size: 13px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
            border: 1px solid #fecaca;
        }

        .footer-text {
            text-align: center;
            margin-top: 25px;
            font-size: 12px;
            color: var(--text-muted);
        }
    </style>
</head>
<body>

    <div class="login-card">
        
        <div class="logo-area">
            <div class="brand-title">
                <i class="ri-wallet-3-fill"></i> BETWALLET
            </div>
            <div class="brand-subtitle">Merchant Yönetim Paneli</div>
        </div>

        <?php if($error): ?>
            <div class="error-box">
                <i class="ri-error-warning-fill"></i>
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="post">
            <div class="form-group">
                <label class="form-label">Kullanıcı Adı</label>
                <div class="input-wrapper">
                    <i class="ri-user-3-line input-icon"></i>
                    <input type="text" name="username" class="form-input" placeholder="Hesap adınız" required autofocus>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Şifre</label>
                <div class="input-wrapper">
                    <i class="ri-lock-2-line input-icon"></i>
                    <input type="password" name="password" class="form-input" placeholder="••••••••" required>
                </div>
            </div>

            <button type="submit" class="btn-login">
                Giriş Yap <i class="ri-arrow-right-line"></i>
            </button>
        </form>

        <div class="footer-text">
            &copy; <?= date('Y') ?> BetWallet Teknoloji<br>
            Güvenli Ödeme Sistemleri
        </div>

    </div>

</body>
</html>