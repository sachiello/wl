<?php
require 'init.php';

// Yetki Kontrolü
if (isset($_SESSION['is_personnel']) && $_SESSION['is_personnel'] && !function_exists('hasPerm')) {
    die("<div class='app-wrapper'><div class='main-content'><div class='card bg-red' style='color:#fff; padding:20px;'>Yetkisiz Erişim.</div></div></div>");
}
if (isset($_SESSION['is_personnel']) && $_SESSION['is_personnel'] && function_exists('hasPerm') && !hasPerm('manage_settings')) {
    die("<div class='app-wrapper'><div class='main-content'><div class='card bg-red' style='color:#fff; padding:20px;'>Bu sayfayı görüntüleme yetkiniz yok.</div></div></div>");
}

$msg = ""; 
$err = "";

if (isset($_SESSION['message'])) {
    $msg = $_SESSION['message'];
    unset($_SESSION['message']);
}
if (isset($_SESSION['error_message'])) {
    $err = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}

$ga = class_exists('GoogleAuthenticator') ? new GoogleAuthenticator() : null;

// Secret Yönetimi (aktif değilse temp secret üret)
if ($ga && empty($site['two_factor_secret'])) {
    if (!isset($_SESSION['temp_secret'])) {
        $_SESSION['temp_secret'] = $ga->createSecret();
    }
    $secret = $_SESSION['temp_secret'];
} else {
    $secret = $site['two_factor_secret'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // CSRF Kontrolü
    $tokenCheck = isset($_POST['csrf_token'], $_SESSION['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token'];
    if (!$tokenCheck) {
        $_SESSION['error_message'] = "Güvenlik hatası. Lütfen sayfayı yenileyin.";
        header("Location: settings.php");
        exit;
    }

    // 1. IP KAYDET
    if (isset($_POST['save_ip'])) {
        $ips = trim($_POST['allowed_ips'] ?? '');
        $pdo->prepare("UPDATE sites SET allowed_ips = ? WHERE id = ?")
            ->execute([$ips, $site['id']]);
        $_SESSION['message'] = "IP erişim ayarları başarıyla güncellendi.";
        header("Location: settings.php");
        exit;
    }

    // 2. 2FA AKTİFLEŞTİR
    if (isset($_POST['enable_2fa'])) {
        if (!$ga || !$secret) {
            $_SESSION['error_message'] = "2FA yapılandırması eksik. Lütfen sistem yöneticinize başvurun.";
            header("Location: settings.php");
            exit;
        }

        $code = trim($_POST['code'] ?? '');
        if ($ga->verifyCode($secret, $code, 2)) {
            $pdo->prepare("UPDATE sites SET two_factor_enabled = 1, two_factor_secret = ? WHERE id = ?")
                ->execute([$secret, $site['id']]);
            $_SESSION['message'] = "Google Authenticator (2FA) başarıyla aktifleştirildi!";
            unset($_SESSION['temp_secret']);
            header("Location: settings.php");
            exit;
        } else {
            $_SESSION['error_message'] = "Hatalı doğrulama kodu. Lütfen tekrar deneyin.";
            header("Location: settings.php");
            exit;
        }
    }

    // 3. 2FA KAPAT (Artık KOD İLE KAPATILIYOR)
    if (isset($_POST['disable_2fa'])) {
        if (!$ga || empty($site['two_factor_secret'])) {
            $_SESSION['error_message'] = "2FA pasif görünse de yapılandırma eksik. Lütfen tekrar deneyin.";
            header("Location: settings.php");
            exit;
        }

        $code = trim($_POST['code'] ?? '');
        if ($code === '') {
            $_SESSION['error_message'] = "2FA'yı devre dışı bırakmak için doğrulama kodu girmeniz gerekir.";
            header("Location: settings.php");
            exit;
        }

        $secretCurrent = $site['two_factor_secret'];

        if (!$ga->verifyCode($secretCurrent, $code, 2)) {
            $_SESSION['error_message'] = "Hatalı 2FA kodu. Güvenlik nedeniyle 2FA devre dışı bırakılmadı.";
            header("Location: settings.php");
            exit;
        }

        // Kod doğru → 2FA'yı kapat
        $pdo->prepare("UPDATE sites SET two_factor_enabled = 0, two_factor_secret = NULL WHERE id = ?")
            ->execute([$site['id']]);
        $_SESSION['message'] = "2FA başarıyla devre dışı bırakıldı.";
        header("Location: settings.php");
        exit;
    }
}

$qrUrl = ($ga && $secret && !$site['two_factor_enabled'])
    ? $ga->getQRCodeGoogleUrl('BetWallet_Site_' . preg_replace('/\s+/', '_', $site['name']), $secret)
    : '';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ayarlar & Güvenlik - <?= htmlspecialchars($site['name']) ?></title>
    
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        /* GLOBAL CSS */
        :root {
            --primary: #c2273f;
            --bg-body: #f1f5f9;
            --bg-card: #ffffff;
            --text-main: #0f172a;
            --text-muted: #64748b;
            --border-color: #e2e8f0;
            --success: #10b981;
            --info: #0ea5e9;
            --danger: #ef4444;
            --warning: #f59e0b;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-body);
            color: var(--text-main);
            margin: 0;
            display: flex;
        }
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        
        .sidebar {
            width: 260px;
            background: var(--bg-card);
            border-right: 1px solid var(--border-color);
            padding: 20px;
            flex-shrink: 0;
            display: none;
        }
        @media(min-width: 1024px) {
            .sidebar { display: block; }
        }

        .main-content { flex: 1; padding: 30px; overflow-y: auto; width: 100%; }
        
        /* KART */
        .card {
            background: var(--bg-card);
            border-radius: 16px;
            border: 1px solid var(--border-color);
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
            height: 100%;
        }
        
        /* FORM */
        .form-group { margin-bottom: 20px; }
        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: var(--text-muted);
            margin-bottom: 8px;
        }
        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            outline: none;
            font-size: 14px;
            box-sizing: border-box;
            transition: border-color 0.2s;
            font-family: 'Inter', sans-serif;
        }
        .form-control:focus { border-color: var(--primary); }
        textarea.form-control { min-height: 100px; resize: vertical; }

        /* BUTONLAR */
        .btn {
            padding: 12px 24px;
            border-radius: 8px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            font-size: 14px;
            text-decoration: none;
            transition: opacity 0.2s;
            width: 100%;
        }
        .btn:hover { opacity: 0.9; }
        .btn-primary { background: var(--primary); color: #fff; }
        .btn-danger {
            background: #fee2e2;
            color: var(--danger);
            border: 1px solid #fecaca;
        }
        .btn-danger:hover {
            background: var(--danger);
            color: #fff;
        }

        /* ALERT */
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            font-weight: 500;
        }
        .alert-success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }
        .alert-danger {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        /* QR KOD ALANI */
        .qr-container {
            background: #fff;
            padding: 15px;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            display: inline-block;
            margin-bottom: 15px;
        }
        .secret-code {
            background: #f1f5f9;
            padding: 8px 12px;
            border-radius: 6px;
            font-family: monospace;
            font-size: 14px;
            color: var(--text-main);
            margin-top: 10px;
            display: inline-block;
            border: 1px dashed var(--border-color);
        }
    </style>
</head>
<body>

<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    
    <div class="main-content">
        <div class="topbar" style="margin-bottom: 30px;">
            <h1 style="margin:0; font-size:24px; font-weight:800; color:var(--text-main);">Ayarlar & Güvenlik</h1>
            <p style="margin:5px 0 0; color:var(--text-muted);">Hesap güvenliğinizi ve erişim kısıtlamalarınızı yönetin.</p>
        </div>
        
        <?php if($msg): ?>
            <div class="alert alert-success">
                <i class="ri-checkbox-circle-fill"></i> <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>

        <?php if($err): ?>
            <div class="alert alert-danger">
                <i class="ri-error-warning-fill"></i> <?= htmlspecialchars($err) ?>
            </div>
        <?php endif; ?>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 30px; align-items: start;">
            
            <!-- IP AYARLARI -->
            <div>
                <div class="card">
                    <div style="margin-bottom:20px;">
                        <h3 style="margin:0; font-size:18px; display:flex; align-items:center; gap:10px;">
                            <i class="ri-shield-keyhole-line" style="color:var(--info);"></i> IP Erişim Kısıtlaması
                        </h3>
                        <p style="font-size:13px; color:var(--text-muted); margin-top:5px;">
                            Panelinize sadece belirlediğiniz IP adreslerinden erişilmesine izin verin. Boş bırakırsanız her yerden erişilebilir.
                        </p>
                    </div>

                    <form method="post">
                        <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
                        <input type="hidden" name="save_ip" value="1">
                        
                        <div class="form-group">
                            <label>İzinli IP Adresleri (Virgülle ayırın)</label>
                            <textarea name="allowed_ips" class="form-control" rows="4" placeholder="Örn: 192.168.1.1, 85.44.12.10"><?= htmlspecialchars($site['allowed_ips'] ?? '') ?></textarea>
                        </div>
                        
                        <div style="font-size:12px; color:var(--info); margin-bottom:20px; background:#eff6ff; padding:10px; border-radius:6px; border:1px solid #dbeafe;">
                            <i class="ri-map-pin-line"></i> Şu anki IP Adresiniz: <b><?= htmlspecialchars($_SERVER['REMOTE_ADDR'] ?? '-') ?></b>
                        </div>
                        
                        <button class="btn btn-primary">
                            <i class="ri-save-line"></i> Ayarları Kaydet
                        </button>
                    </form>
                </div>
            </div>

            <!-- 2FA AYARLARI -->
            <div>
                <div class="card">
                    <div style="margin-bottom:20px;">
                        <h3 style="margin:0; font-size:18px; display:flex; align-items:center; gap:10px;">
                            <i class="ri-smartphone-line" style="color:var(--success);"></i> Google Authenticator (2FA)
                        </h3>
                        <p style="font-size:13px; color:var(--text-muted); margin-top:5px;">
                            Finansal işlemler (Para Çekme vb.) yapabilmek için 2FA zorunludur.
                        </p>
                    </div>

                    <?php if($site['two_factor_enabled']): ?>
                        <div style="text-align:center; padding:30px 20px 20px;">
                            <div style="width:80px; height:80px; background:#dcfce7; color:var(--success); border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 20px auto;">
                                <i class="ri-shield-check-fill" style="font-size:40px;"></i>
                            </div>
                            <h4 style="color:var(--text-main); margin:0 0 10px 0;">Hesabınız Korunuyor</h4>
                            <p style="font-size:14px; color:var(--text-muted); margin-bottom:20px;">
                                İki adımlı doğrulama şu anda aktif. Devre dışı bırakmak için mevcut Authenticator kodunuzu girmeniz gerekir.
                            </p>
                            
                            <form method="post" style="max-width:280px; margin:0 auto;">
                                <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
                                <div class="form-group" style="margin-bottom:15px;">
                                    <label>2FA Kodu (Devre Dışı Bırakma İçin)</label>
                                    <input type="text"
                                           name="code"
                                           class="form-control"
                                           placeholder="6 Haneli Kod"
                                           style="text-align:center; font-size:18px; letter-spacing:4px; font-weight:700;"
                                           maxlength="6"
                                           required
                                           autocomplete="off">
                                </div>
                                <button name="disable_2fa" class="btn btn-danger"
                                        onclick="return confirm('2FA güvenlik katmanını kaldırmak istediğinize emin misiniz? Doğru kodu girdiğinizde 2FA devre dışı bırakılacaktır.');">
                                    <i class="ri-lock-unlock-line"></i> 2FA&#39;yı Devre Dışı Bırak
                                </button>
                            </form>
                        </div>

                    <?php else: ?>
                        <div style="text-align:center;">
                            <div class="qr-container">
                                <?php if($qrUrl): ?>
                                    <img src="<?= $qrUrl ?>" alt="QR Code" width="160">
                                <?php else: ?>
                                    <p style="color:var(--danger);">QR Kod oluşturulamadı. (GoogleAuth sınıfı eksik)</p>
                                <?php endif; ?>
                            </div>
                            
                            <div style="margin-bottom:20px;">
                                <span class="secret-code">Kod: <?= htmlspecialchars($secret) ?></span>
                            </div>

                            <form method="post" style="max-width:280px; margin:0 auto;">
                                <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
                                <div class="form-group" style="margin-bottom:15px;">
                                    <input type="text"
                                           name="code"
                                           class="form-control"
                                           placeholder="Uygulamadaki 6 Haneli Kod"
                                           style="text-align:center; font-size:18px; letter-spacing:4px; font-weight:700;"
                                           maxlength="6"
                                           required
                                           autocomplete="off">
                                </div>
                                <button name="enable_2fa" class="btn btn-primary">
                                    <i class="ri-lock-2-fill"></i> Aktifleştir
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>

                </div>
            </div>

        </div>
    </div>
</div>

</body>
</html>
