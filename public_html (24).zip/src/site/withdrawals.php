<?php
require 'init.php';

// Yetki Kontrolü: Sadece Patron veya 'create_withdraw' yetkisi olan personel
if (isset($_SESSION['is_personnel']) && $_SESSION['is_personnel']) {
    if (!function_exists('hasPerm') || !hasPerm('create_withdraw')) {
        die("<div class='app-wrapper'><div class='main-content'><div class='card bg-red' style='color:#fff; padding:20px;'>Bu sayfayı görüntüleme yetkiniz yok (Mutabakat Yetkisi Gerekli).</div></div></div>");
    }
}

// Güvenlik: Oturum Kontrolü
if (!isset($_SESSION['site_id'])) {
    header('Location: login.php');
    exit;
}

// Site Bilgilerini Tazele (Güncel Bakiye İçin)
$stmt = $pdo->prepare("SELECT * FROM sites WHERE id = ?");
$stmt->execute([$_SESSION['site_id']]);
$site = $stmt->fetch(PDO::FETCH_ASSOC);
$netBalance = (float)$site['net_balance'];

// 2FA Zorunluluğu – SAYFADA GÜVENLİK KİLİDİ OLARAK GÖSTER
$need2FA = empty($site['two_factor_enabled']); // 1 değilse kilit devreye girsin

$msg = ""; 
$err = "";

if (isset($_SESSION['message'])) {
    $msg = $_SESSION['message'];
    unset($_SESSION['message']);
}
if (isset($_SESSION['error_message'])) {
    $err = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}
$ga = class_exists('GoogleAuthenticator') ? new GoogleAuthenticator() : null;

// ----------------------------------------------------
// İŞLEM 1: YENİ TALEP OLUŞTURMA (POST)
// ----------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 2FA KURULU DEĞİLKEN POST İŞLEMİNE İZİN VERME
    if ($need2FA) {
        $_SESSION['error_message'] = "2FA kurulumu tamamlanmadan mutabakat talebi oluşturamazsınız.";
        header("Location: withdrawals.php");
        exit;
    }

    // CSRF Kontrolü (init.php'de csrf_token() / csrf_field() olduğunu varsayıyoruz)
    $amount = (float)($_POST['amount'] ?? 0);
    $wallet = trim($_POST['wallet'] ?? '');
    $code   = trim($_POST['2fa_code'] ?? '');

    // Validasyonlar
    if ($amount <= 0) {
        $_SESSION['error_message'] = "Geçersiz tutar girdiniz.";
    } elseif ($amount > $netBalance) {
        $_SESSION['error_message'] = "Yetersiz bakiye! Çekilebilir miktarınız: " . number_format($netBalance, 2) . " ₺";
    } elseif (empty($wallet)) {
        $_SESSION['error_message'] = "Cüzdan adresi boş bırakılamaz.";
    } elseif ($ga && !$ga->verifyCode($site['two_factor_secret'], $code, 2)) {
        // 2 tolerans aralığı (zaman kayması için)
        $_SESSION['error_message'] = "Hatalı veya süresi dolmuş 2FA Kodu!";
    } else {
        try {
            $pdo->beginTransaction();
            
            // 1. Bakiyeden Düş
            $upd = $pdo->prepare("UPDATE sites SET net_balance = net_balance - ? WHERE id = ?");
            if (!$upd->execute([$amount, $site['id']])) {
                throw new Exception("Bakiye güncellenemedi.");
            }

            // 2. Talebi Kaydet
            // Not: Komisyon admin tarafında kesilip gönderilecek, buraya brüt tutarı giriyoruz.
            $ins = $pdo->prepare("INSERT INTO site_withdrawals (site_id, amount, wallet_address, status, created_at) VALUES (?, ?, ?, 'pending', NOW())");
            $ins->execute([$site['id'], $amount, $wallet]);

            $pdo->commit();
            
            $_SESSION['message'] = "Mutabakat talebi başarıyla alındı. Yönetici onayından sonra cüzdanınıza transfer edilecektir.";

        } catch (Exception $e) {
            $pdo->rollBack();
            $_SESSION['error_message'] = "Sistem Hatası: " . $e->getMessage();
        }
    }
    header("Location: withdrawals.php");
    exit;
}

// ----------------------------------------------------
// İŞLEM 2: GEÇMİŞ LİSTELEME (GET)
// ----------------------------------------------------
$page   = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit  = 20;
$offset = ($page - 1) * $limit;

$start  = $_GET['start'] ?? '';
$end    = $_GET['end'] ?? '';
$search = trim($_GET['search'] ?? '');

// Sorgu İnşası
$whereSQL = "WHERE site_id = ?";
$params   = [$site['id']];

if ($start && $end) {
    $whereSQL .= " AND DATE(created_at) BETWEEN ? AND ?";
    $params[] = $start;
    $params[] = $end;
}

if ($search) {
    $whereSQL .= " AND (wallet_address LIKE ? OR amount LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

// Sayfalama
$stmtCount = $pdo->prepare("SELECT COUNT(*) FROM site_withdrawals $whereSQL");
$stmtCount->execute($params);
$totalRecords = $stmtCount->fetchColumn();
$totalPages   = ceil($totalRecords / $limit);

// Veri Çekme
$sql = "SELECT * FROM site_withdrawals $whereSQL ORDER BY created_at DESC LIMIT $limit OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$history = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mutabakat - <?= htmlspecialchars($site['name']) ?></title>
    
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

    <style>
        /* GLOBAL STYLES (Diğer sayfalarla uyumlu) */
        :root {
            --primary: #c2273f;
            --bg-body: #f1f5f9;
            --bg-card: #ffffff;
            --text-main: #0f172a;
            --text-muted: #64748b;
            --border-color: #e2e8f0;
            --success: #10b981;
            --info: #0ea5e9;
            --danger: #ef4444;
            --warning: #f59e0b;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-body);
            color: var(--text-main);
            margin: 0;
            display: flex;
        }
        
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        
        /* SIDEBAR (Diğer sayfalarla aynı) */
        .sidebar {
            width: 260px;
            background: var(--bg-card);
            border-right: 1px solid var(--border-color);
            padding: 20px;
            flex-shrink: 0;
            display: none;
        }
        @media(min-width: 1024px) { .sidebar { display: block; } }

        .main-content { flex: 1; padding: 30px; overflow-y: auto; width: 100%; position: relative; }

        /* KARTLAR VE FORMLAR */
        .card {
            background: var(--bg-card);
            border-radius: 16px;
            border: 1px solid var(--border-color);
            padding: 25px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }
        
        .form-group { margin-bottom: 15px; }
        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: var(--text-muted);
            margin-bottom: 6px;
        }
        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            outline: none;
            font-size: 14px;
            box-sizing: border-box;
            transition: border-color 0.2s;
        }
        .form-control:focus { border-color: var(--primary); }

        .btn {
            padding: 12px 24px;
            border-radius: 8px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            font-size: 14px;
            transition: opacity 0.2s;
        }
        .btn:hover { opacity: 0.9; }
        .btn-primary { background: var(--primary); color: #fff; }
        .btn-secondary { background: #e2e8f0; color: var(--text-main); }
        .btn-sm { padding: 6px 12px; font-size: 12px; }

        /* ALERT KUTULARI */
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert-success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }
        .alert-danger {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        /* TABLO */
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; font-size: 14px; min-width: 600px; }
        th {
            text-align: left;
            padding: 12px 16px;
            color: var(--text-muted);
            font-weight: 600;
            border-bottom: 1px solid var(--border-color);
            font-size: 11px;
            text-transform: uppercase;
        }
        td {
            padding: 12px 16px;
            border-bottom: 1px solid var(--border-color);
            vertical-align: middle;
        }
        
        .badge {
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
        }
        .bg-green { background: rgba(16, 185, 129, 0.15); color: var(--success); }
        .bg-yellow { background: rgba(245, 158, 11, 0.15); color: var(--warning); }
        .bg-red { background: rgba(239, 68, 68, 0.15); color: var(--danger); }

        /* ===============================
           2FA GÜVENLİK KİLİDİ (OVERLAY)
           =============================== */
        .blur-locked {
            filter: blur(6px);
            opacity: 0.4;
            pointer-events: none;
            user-select: none;
        }
        .lock-overlay {
            position: fixed;
            inset: 0;
            z-index: 999;
            background: rgba(15, 23, 42, 0.65);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .lock-box {
            background: #ffffff;
            max-width: 420px;
            width: 100%;
            border-radius: 20px;
            padding: 30px 26px 26px;
            text-align: center;
            box-shadow: 0 24px 80px rgba(0,0,0,0.35);
            border: 1px solid rgba(248, 250, 252, 0.9);
        }
        .lock-icon-wrap {
            width: 72px;
            height: 72px;
            border-radius: 50%;
            margin: 0 auto 16px auto;
            background: radial-gradient(circle at 30% 0%, #f97373, #b91c1c);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fef2f2;
            box-shadow: 0 18px 40px rgba(220, 38, 38, 0.45);
        }
        .lock-icon-wrap i {
            font-size: 36px;
        }
        .lock-title {
            font-size: 20px;
            font-weight: 800;
            color: #111827;
            margin-bottom: 8px;
        }
        .lock-text {
            font-size: 14px;
            color: #4b5563;
            margin-bottom: 18px;
        }
        .lock-text strong {
            color: #1f2937;
        }
        .lock-pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            padding: 6px 12px;
            border-radius: 999px;
            background: #fef2f2;
            color: #b91c1c;
            border: 1px solid #fecaca;
            margin-bottom: 18px;
            font-weight: 600;
        }
        .lock-btn {
            margin-top: 5px;
            width: 100%;
            padding: 11px 16px;
            border-radius: 999px;
            border: none;
            font-weight: 700;
            font-size: 14px;
            cursor: pointer;
            background: #c2273f;
            color: #f9fafb;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            box-shadow: 0 14px 30px rgba(190, 18, 60, 0.45);
        }
        .lock-btn:hover {
            opacity: 0.96;
        }
        .lock-helper {
            margin-top: 10px;
            font-size: 12px;
            color: #6b7280;
        }
    </style>
</head>
<body>

<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    
    <div class="main-content">

        <?php if ($need2FA): ?>
        <!-- 2FA GÜVENLİK KİLİDİ OVERLAY -->
        <div class="lock-overlay">
            <div class="lock-box">
                <div class="lock-icon-wrap">
                    <i class="ri-shield-keyhole-line"></i>
                </div>
                <div class="lock-pill">
                    <i class="ri-error-warning-line"></i>
                    2FA GÜVENLİK KİLİDİ AKTİF
                </div>
                <div class="lock-title">Mutabakat İçin 2FA Zorunlu</div>
                <p class="lock-text">
                    Bu sayfadan <strong>para çekim / mutabakat</strong> talebi oluşturabilmek için
                    önce <strong>Google Authenticator (2FA)</strong> kurulumunu tamamlamanız gerekir.
                </p>
                <button class="lock-btn" onclick="window.location.href='settings.php';">
                    <i class="ri-smartphone-line"></i>
                    2FA Kurulumuna Git
                </button>
                <div class="lock-helper">
                    Ayarlar &gt; Güvenlik sayfasından QR kodu tarayıp 6 haneli kod ile 2FA’yı aktif edin.
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div id="pageContent" class="<?= $need2FA ? 'blur-locked' : '' ?>">

            <div class="topbar" style="margin-bottom:30px;">
                <h1 style="margin:0; font-size:24px; font-weight:800; color:var(--text-main);">Mutabakat Merkezi</h1>
                <p style="margin:5px 0 0; color:var(--text-muted);">Çekilebilir bakiyenizi kripto cüzdanınıza aktarın.</p>
            </div>
            
            <?php if($msg): ?>
                <div class="alert alert-success"><i class="ri-checkbox-circle-fill"></i> <?= htmlspecialchars($msg) ?></div>
            <?php endif; ?>
            <?php if($err): ?>
                <div class="alert alert-danger"><i class="ri-error-warning-fill"></i> <?= htmlspecialchars($err) ?></div>
            <?php endif; ?>

            <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 20px; align-items: start;">
                
                <div class="card" style="border-top: 4px solid var(--info);">
                    <div style="margin-bottom:25px; text-align:center;">
                        <div style="font-size:12px; font-weight:700; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px;">ÇEKİLEBİLİR NET BAKİYE</div>
                        <div style="font-size:32px; font-weight:800; color:var(--info); margin-top:5px;">
                            <?= number_format($netBalance, 2) ?> <small style="font-size:16px;">₺</small>
                        </div>
                    </div>

                    <form method="post">
                        <?php if(function_exists('csrf_field')) echo csrf_field(); ?>

                        <div class="form-group">
                            <label>Çekilecek Tutar (TL)</label>
                            <input type="number" name="amount" id="wdAmount" class="form-control" step="0.01" min="100" max="<?= $netBalance ?>" placeholder="0.00" required oninput="calcFee()">
                            <div style="font-size:11px; color:var(--text-muted); margin-top:4px;">Minimum çekim limiti: 100.00 ₺</div>
                        </div>

                        <div style="background:#f8fafc; padding:15px; border-radius:8px; border:1px dashed var(--border-color); margin-bottom:20px;">
                            <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:8px;">
                                <span style="color:var(--text-muted);">İşlem Ücreti (%1):</span>
                                <span style="font-weight:600; color:var(--danger);" id="feeDisplay">0.00 ₺</span>
                            </div>
                            <div style="display:flex; justify-content:space-between; font-size:15px; font-weight:700; border-top:1px solid var(--border-color); padding-top:8px;">
                                <span style="color:var(--text-main);">Hesaba Geçecek:</span>
                                <span style="color:var(--success);" id="netDisplay">0.00 ₺</span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>USDT (TRC20) Cüzdan Adresi</label>
                            <input type="text" name="wallet" class="form-control" placeholder="T..." required>
                        </div>

                        <div class="form-group">
                            <label>Google 2FA Kodu</label>
                            <div style="position:relative;">
                                <i class="ri-shield-keyhole-line" style="position:absolute; left:12px; top:12px; color:var(--text-muted);"></i>
                                <input type="text" name="2fa_code" class="form-control" placeholder="000 000" maxlength="6" style="padding-left:35px; letter-spacing:4px; font-weight:700;" required>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary" style="width:100%;">
                            <i class="ri-bank-card-line"></i> Talep Oluştur
                        </button>
                    </form>
                </div>

                <div class="card" style="margin-bottom:0;">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                        <h3 style="margin:0; font-size:18px;">Geçmiş Talepler</h3>
                        
                        <form method="get" style="display:flex; gap:8px;">
                            <input type="text" id="dateRange" class="form-control" placeholder="Tarih" style="width:120px; padding:6px;">
                            <input type="hidden" name="start" id="startDate" value="<?= htmlspecialchars($start) ?>">
                            <input type="hidden" name="end" id="endDate" value="<?= htmlspecialchars($end) ?>">
                            <button class="btn btn-secondary btn-sm"><i class="ri-search-line"></i></button>
                        </form>
                    </div>

                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Tarih</th>
                                    <th>Brüt Tutar</th>
                                    <th>Cüzdan</th>
                                    <th style="text-align:right;">Durum</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($history as $h): ?>
                                <tr>
                                    <td style="color:var(--text-muted); font-size:13px;">
                                        <?= date('d.m.Y H:i', strtotime($h['created_at'])) ?>
                                    </td>
                                    <td style="font-weight:700;">
                                        <?= number_format($h['amount'], 2) ?> ₺
                                    </td>
                                    <td style="font-family:monospace; font-size:12px; color:var(--text-muted);">
                                        <?= htmlspecialchars(substr($h['wallet_address'], 0, 8) . '...' . substr($h['wallet_address'], -6)) ?>
                                    </td>
                                    <td style="text-align:right;">
                                        <?php 
                                        if($h['status'] == 'completed') {
                                            echo '<span class="badge bg-green">ÖDENDİ</span>';
                                        } elseif($h['status'] == 'pending') {
                                            echo '<span class="badge bg-yellow">BEKLİYOR</span>';
                                        } else {
                                            echo '<span class="badge bg-red">REDDEDİLDİ</span>';
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>

                                <?php if(empty($history)): ?>
                                    <tr>
                                        <td colspan="4" style="text-align:center; padding:30px; color:var(--text-muted);">
                                            Henüz bir işlem kaydı bulunmuyor.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if($totalPages > 1): ?>
                    <div style="margin-top:20px; display:flex; justify-content:center; gap:5px;">
                        <?php for($i=1; $i<=$totalPages; $i++): ?>
                            <a href="?page=<?= $i ?>&start=<?= urlencode($start) ?>&end=<?= urlencode($end) ?>" 
                               class="btn btn-sm <?= $page == $i ? 'btn-primary' : 'btn-secondary' ?>">
                                <?= $i ?>
                            </a>
                        <?php endfor; ?>
                    </div>
                    <?php endif; ?>

                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://npmcdn.com/flatpickr/dist/l10n/tr.js"></script>
<script>
    // Canlı Komisyon Hesaplama
    function calcFee() {
        let amount = parseFloat(document.getElementById('wdAmount').value);
        
        if (isNaN(amount) || amount <= 0) {
            document.getElementById('feeDisplay').innerText = "0.00 ₺";
            document.getElementById('netDisplay').innerText = "0.00 ₺";
            return;
        }

        let fee = amount * 0.01; // %1 Komisyon
        let net = amount - fee;

        document.getElementById('feeDisplay').innerText = fee.toLocaleString('tr-TR', {minimumFractionDigits: 2, maximumFractionDigits: 2}) + ' ₺';
        document.getElementById('netDisplay').innerText = net.toLocaleString('tr-TR', {minimumFractionDigits: 2, maximumFractionDigits: 2}) + ' ₺';
    }

    // Tarih Seçici
    flatpickr("#dateRange", {
        mode: "range",
        dateFormat: "Y-m-d",
        locale: "tr",
        defaultDate: ["<?= $start ?>", "<?= $end ?>"],
        onClose: function(selectedDates, dateStr, instance) {
            if (selectedDates.length === 2) {
                document.getElementById('startDate').value = instance.formatDate(selectedDates[0], "Y-m-d");
                document.getElementById('endDate').value = instance.formatDate(selectedDates[1], "Y-m-d");
            }
        }
    });
</script>

</body>
</html>
