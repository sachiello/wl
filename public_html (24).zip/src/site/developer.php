<?php
require 'init.php';

// Yetki Kontrolü
if (isset($_SESSION['is_personnel']) && $_SESSION['is_personnel'] && !function_exists('hasPerm')) {
    die("<div class='app-wrapper'><div class='main-content'><div class='card bg-red' style='color:#fff; padding:20px;'>Yetkisiz Erişim.</div></div></div>");
}
if (isset($_SESSION['is_personnel']) && $_SESSION['is_personnel'] && function_exists('hasPerm') && !hasPerm('manage_settings')) {
    die("<div class='app-wrapper'><div class='main-content'><div class='card bg-red' style='color:#fff; padding:20px;'>Bu sayfayı görüntüleme yetkiniz yok.</div></div></div>");
}

$msg = ""; 
$err = "";

if (isset($_SESSION['message'])) {
    $msg = $_SESSION['message'];
    unset($_SESSION['message']);
}
if (isset($_SESSION['error_message'])) {
    $err = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}

// Secret Key Yenileme
if (isset($_POST['regen_keys'])) {
    $tokenCheck = isset($_POST['csrf_token']) && isset($_SESSION['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token'];
    if (!$tokenCheck && function_exists('csrf_token')) {
        $_SESSION['error_message'] = "Güvenlik hatası. Lütfen sayfayı yenileyin.";
        header("Location: developer.php"); exit;
    } else {
        try {
            $newSecret = bin2hex(random_bytes(32));
            $pdo->prepare("UPDATE sites SET api_secret = ? WHERE id = ?")->execute([$newSecret, $site['id']]);
            $site['api_secret'] = $newSecret;
            $_SESSION['message'] = "Secret Key başarıyla yenilendi.";
        } catch (PDOException $e) {
            $_SESSION['error_message'] = "Veritabanı hatası.";
        }
        header("Location: developer.php"); exit;
    }
}

if (empty($site['api_key'])) {
    $stmt = $pdo->prepare("SELECT api_key, api_secret FROM sites WHERE id = ?");
    $stmt->execute([$_SESSION['site_id']]);
    $res = $stmt->fetch(PDO::FETCH_ASSOC);
    $site['api_key'] = $res['api_key'];
    $site['api_secret'] = $res['api_secret'];
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Geliştirici Merkezi - <?= htmlspecialchars($site['name']) ?></title>
    
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        /* GLOBAL CSS */
        :root { --primary: #c2273f; --bg-body: #f1f5f9; --bg-card: #ffffff; --text-main: #0f172a; --text-muted: #64748b; --border-color: #e2e8f0; --success: #10b981; --info: #0ea5e9; --danger: #ef4444; --warning: #f59e0b; --code-bg: #1e293b; }
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; display: flex; }
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        .sidebar { width: 260px; background: var(--bg-card); border-right: 1px solid var(--border-color); padding: 20px; flex-shrink: 0; display: none; }
        @media(min-width: 1024px) { .sidebar { display: block; } }
        .main-content { flex: 1; padding: 30px; overflow-y: auto; width: 100%; }
        
        /* API KEYS SECTION */
        .card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); padding: 25px; margin-bottom: 25px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        
        .api-group { margin-bottom: 20px; }
        .api-label { display: block; font-size: 13px; font-weight: 700; color: var(--text-muted); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px; }
        .api-input-wrapper { position: relative; display: flex; align-items: center; }
        .api-input { width: 100%; padding: 14px 110px 14px 16px; background: #f8fafc; border: 1px solid var(--border-color); border-radius: 8px; font-family: 'Monaco', 'Consolas', monospace; font-size: 14px; color: var(--text-main); outline: none; transition: border-color 0.2s; }
        .api-input:focus { border-color: var(--primary); background: #fff; }
        
        .api-actions { position: absolute; right: 8px; display: flex; gap: 5px; }
        .action-btn { width: 32px; height: 32px; border: 1px solid var(--border-color); background: #fff; border-radius: 6px; display: flex; align-items: center; justify-content: center; cursor: pointer; color: var(--text-muted); transition: all 0.2s; }
        .action-btn:hover { border-color: var(--primary); color: var(--primary); }

        /* ACCORDION STYLES */
        .accordion-item { border: 1px solid var(--border-color); border-radius: 12px; overflow: hidden; margin-bottom: 15px; background: #fff; }
        .accordion-header { padding: 15px 20px; background: #fff; cursor: pointer; display: flex; justify-content: space-between; align-items: center; transition: background 0.2s; }
        .accordion-header:hover { background: #f8fafc; }
        .accordion-title { font-weight: 600; color: var(--text-main); display: flex; align-items: center; gap: 10px; }
        .accordion-icon { width: 32px; height: 32px; border-radius: 8px; background: #eff6ff; color: var(--primary); display: flex; align-items: center; justify-content: center; font-size: 18px; }
        .accordion-content { max-height: 0; overflow: hidden; transition: max-height 0.3s ease-out; background: #fcfcfc; }
        .accordion-body { padding: 20px; border-top: 1px solid var(--border-color); font-size: 14px; line-height: 1.6; color: var(--text-muted); }
        
        .accordion-item.active .accordion-header { background: #f8fafc; }
        .accordion-item.active .accordion-arrow { transform: rotate(180deg); }

        /* CODE BLOCKS */
        .code-container { position: relative; margin: 15px 0; border-radius: 8px; overflow: hidden; }
        .code-header { background: #0f172a; color: #94a3b8; padding: 8px 15px; font-size: 12px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #334155; }
        .code-lang { font-weight: 700; color: #fff; }
        .code-copy { background: transparent; border: 1px solid #334155; color: #cbd5e1; border-radius: 4px; padding: 2px 8px; font-size: 11px; cursor: pointer; transition: all 0.2s; }
        .code-copy:hover { background: #334155; color: #fff; }
        pre { background: var(--code-bg); color: #e2e8f0; padding: 15px; margin: 0; overflow-x: auto; font-family: 'Consolas', 'Monaco', monospace; font-size: 13px; }
        
        .step-badge { display: inline-block; background: var(--primary); color: #fff; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 700; margin-right: 5px; }
        
        .btn { padding: 10px 20px; border-radius: 8px; border: none; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; font-size: 14px; text-decoration: none; transition: opacity 0.2s; }
        .btn:hover { opacity: 0.9; }
        .btn-primary { background: var(--primary); color: #fff; }
        .btn-secondary { background: #e2e8f0; color: var(--text-main); }
        .btn-danger { background: #fef2f2; color: var(--danger); border: 1px solid #fecaca; }
        .btn-danger:hover { background: var(--danger); color: #fff; }

        .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; font-size: 14px; font-weight: 500; }
        .alert-success { background: rgba(16, 185, 129, 0.1); color: var(--success); border: 1px solid rgba(16, 185, 129, 0.2); }
        .alert-danger { background: rgba(239, 68, 68, 0.1); color: var(--danger); border: 1px solid rgba(239, 68, 68, 0.2); }

        /* ÜST BÖLÜM KOD KUTUSU */
        .code-block { background: #1e293b; color: #e2e8f0; padding: 20px; border-radius: 12px; font-family: 'Monaco', 'Consolas', monospace; font-size: 13px; line-height: 1.6; overflow-x: auto; position: relative; }
        .code-block-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 1px solid #334155; }
        .endpoint-url { color: #38bdf8; font-weight: 600; }
        .method-badge { background: #0f172a; color: #f59e0b; padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: 700; margin-right: 10px; }
        
        .info-box { background: #eff6ff; border-left: 4px solid #3b82f6; padding: 15px; border-radius: 6px; margin-bottom: 20px; font-size: 14px; color: #1e40af; }
    </style>
</head>
<body>

<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    
    <div class="main-content">
        <div class="topbar" style="margin-bottom: 30px;">
            <h1 style="margin:0; font-size:24px; font-weight:800; color:var(--text-main);">Geliştirici Merkezi</h1>
            <p style="margin:5px 0 0; color:var(--text-muted);">API anahtarlarınız ve entegrasyon dokümantasyonu.</p>
        </div>
        
        <?php if($msg): ?><div class="alert alert-success"><i class="ri-checkbox-circle-fill"></i> <?= $msg ?></div><?php endif; ?>
        <?php if($err): ?><div class="alert alert-danger"><i class="ri-error-warning-fill"></i> <?= $err ?></div><?php endif; ?>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
            
            <div>
                <div class="card">
                    <div style="margin-bottom:20px;">
                        <h3 style="margin:0; font-size:18px;">API Anahtarları</h3>
                        <p style="font-size:13px; color:var(--text-muted); margin-top:5px;">Bu anahtarlar sitenize özeldir. Secret Key'i asla sunucu tarafı dışında (frontend) kullanmayın.</p>
                    </div>

                    <div class="api-group">
                        <label class="api-label">Merchant ID (API Key)</label>
                        <div class="api-input-wrapper">
                            <input type="text" class="api-input" value="<?= htmlspecialchars($site['api_key']) ?>" readonly id="apiKey">
                            <div class="api-actions">
                                <button class="action-btn" onclick="copyToClipboard('apiKey')" title="Kopyala"><i class="ri-file-copy-line"></i></button>
                            </div>
                        </div>
                    </div>

                    <div class="api-group">
                        <label class="api-label">Secret Key</label>
                        <div class="api-input-wrapper">
                            <input type="password" class="api-input" value="<?= htmlspecialchars($site['api_secret']) ?>" readonly id="apiSecret">
                            <div class="api-actions">
                                <button class="action-btn" onclick="toggleSecret()" title="Göster/Gizle"><i class="ri-eye-line" id="eyeIcon"></i></button>
                                <button class="action-btn" onclick="copyToClipboard('apiSecret')" title="Kopyala"><i class="ri-file-copy-line"></i></button>
                            </div>
                        </div>
                    </div>

                    <div style="border-top: 1px solid var(--border-color); padding-top: 20px; margin-top: 20px;">
                        <div class="info-box" style="background:#fff1f2; border-color:#e11d48; color:#9f1239;">
                            <i class="ri-alert-fill"></i> <b>Dikkat:</b> Secret Key'i yenilediğinizde, eski anahtarı kullanan tüm entegrasyonlarınız duracaktır.
                        </div>
                        <form method="post" onsubmit="return confirm('Secret Key değişecek. Mevcut sistemleriniz etkilenebilir. Devam etmek istiyor musunuz?');">
                            <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
                            <button name="regen_keys" class="btn btn-danger" style="width:100%;">
                                <i class="ri-refresh-line"></i> Secret Key'i Yenile
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <div>
                <div class="card">
                    <h3 style="margin:0 0 15px 0; font-size:18px;">Hızlı Entegrasyon</h3>
                    
                    <div class="info-box">
                        <i class="ri-information-line"></i> Kullanıcılarınızın sitenizden BetWallet hesaplarına para çekebilmesi için aşağıdaki örneği kullanın.
                    </div>

                    <div class="code-block">
                        <div class="code-block-header">
                            <div>
                                <span class="method-badge">POST</span> 
                                <span class="endpoint-url">/api/request_withdraw.php</span>
                            </div>
                            <button class="action-btn" style="background:transparent; color:#94a3b8; border:none;" onclick="copyCode()" title="Kodu Kopyala"><i class="ri-file-copy-line"></i></button>
                        </div>
<pre id="phpCode" style="margin:0; color:#cbd5e1;">&lt;?php
// Örnek Kullanım
$apiUrl = 'https://betwallet.com/api/request_withdraw.php';
$apiKey = '<?= htmlspecialchars($site['api_key']) ?>';
$secret = '<?= htmlspecialchars($site['api_secret']) ?>';

$data = [
    'api_key'      => $apiKey,
    'site_user_id' => 'User123',
    'bw_username'  => 'user1234',
    'amount'       => 100.00,
    'order_id'     => 'TRX-'.time(),
    'ts'           => time()
];

// İmza Oluşturma
$payload = $data['api_key'] . $data['order_id'] . 
           $data['amount'] . $data['bw_username'] . $data['ts'];
           
$data['sig'] = hash_hmac('sha256', $payload, $secret);

// İsteği Gönder (cURL)...
?&gt;</pre>
                    </div>
                    
                    <div style="margin-top:20px; text-align:center;">
                        <a href="#" class="btn btn-secondary" style="width:100%;">
                            <i class="ri-book-open-line"></i> Tam Dokümantasyonu İndir (PDF)
                        </a>
                    </div>
                </div>
            </div>

        </div>

        <h3 style="margin: 30px 0 15px 0; font-size:18px; border-top: 1px solid var(--border-color); padding-top: 20px;">📘 Entegrasyon Kılavuzu (v1.0)</h3>

        <div class="accordion-item">
            <div class="accordion-header" onclick="toggleAccordion(this)">
                <div class="accordion-title">
                    <div class="accordion-icon" style="background:#dbeafe; color:#1e40af;"><i class="ri-global-line"></i></div>
                    1. Webhook (Callback) Kurulumu <span style="font-size:11px; background:#fee2e2; color:#991b1b; padding:2px 6px; border-radius:4px;">ZORUNLU</span>
                </div>
                <i class="ri-arrow-down-s-line accordion-arrow"></i>
            </div>
            <div class="accordion-content">
                <div class="accordion-body">
                    <p>Kullanıcı para yatırma veya çekme işlemi yaptığında, sonucun sitenize yansıması için bir dinleyici (endpoint) hazırlamalısınız. BetWallet, işlem sonucunu bu adrese <b>POST</b> eder.</p>
                    <div class="code-container">
                        <div class="code-header"><span class="code-lang">PHP (Örnek Callback)</span> <button class="code-copy" onclick="copyCode(this)">Kopyala</button></div>
<pre>
&lt;?php
// Dosya: /api/betwallet-callback.php
$apiSecret = "<?= htmlspecialchars($site['api_secret']) ?>"; 

$json = file_get_contents('php://input');
$data = json_decode($json, true);

if (!$data || !isset($data['hash'])) { http_response_code(400); exit; }

$checkStr = $data['order_id'] . '|' . $data['amount'] . '|' . $data['status'] . '|' . $data['ts'];
$calcHash = hash_hmac('sha256', $checkStr, $apiSecret);

if (!hash_equals($calcHash, $data['hash'])) { http_response_code(403); exit; }

if ($data['status'] === 'success') {
    // İşlem başarılı, veritabanınızı güncelleyin
    echo "OK"; 
}
?&gt;
</pre>
                    </div>
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <div class="accordion-header" onclick="toggleAccordion(this)">
                <div class="accordion-title">
                    <div class="accordion-icon" style="background:#dcfce7; color:#166534;"><i class="ri-download-2-line"></i></div>
                    2. Para Yatırma (Redirect Yöntemi)
                </div>
                <i class="ri-arrow-down-s-line accordion-arrow"></i>
            </div>
            <div class="accordion-content">
                <div class="accordion-body">
                    <p>Kullanıcıyı ödeme yapması için BetWallet ödeme kapısına yönlendirin.</p>
                    <div class="code-container">
                        <div class="code-header"><span class="code-lang">PHP (Yönlendirme Linki)</span> <button class="code-copy" onclick="copyCode(this)">Kopyala</button></div>
<pre>
&lt;?php
$gatewayUrl   = "https://betwallet.com/merchant/index.php";
$merchantId   = <?= $site['id'] ?>; 
$secret       = "<?= htmlspecialchars($site['api_secret']) ?>";
$userRef      = "kullanici_123"; 
$ts           = time();

$payload = $merchantId . '|' . $userRef . '|' . $ts;
$sig     = hash_hmac('sha256', $payload, $secret);

$query = http_build_query(['site' => $merchantId, 'user_ref' => $userRef, 'ts' => $ts, 'sig' => $sig]);
header("Location: $gatewayUrl?$query");
exit;
?&gt;
</pre>
                    </div>
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <div class="accordion-header" onclick="toggleAccordion(this)">
                <div class="accordion-title">
                    <div class="accordion-icon" style="background:#f3e8ff; color:#6b21a8;"><i class="ri-link-m"></i></div>
                    3. Hesap Bağlama (Opsiyonel)
                </div>
                <i class="ri-arrow-down-s-line accordion-arrow"></i>
            </div>
            <div class="accordion-content">
                <div class="accordion-body">
                    <p>Kullanıcıların BetWallet arayüzünden sitenizi eklemesi için sitenizde aşağıdaki yapıda bir API hazırlamalısınız.</p>
                    <div style="margin-bottom:10px; font-size:13px;"><span class="step-badge">İSTEK</span> BetWallet sunucusu size sorar (POST):</div>
                    <div class="code-container" style="margin-bottom:20px;"><pre>{ "api_key": "...", "username": "...", "password": "..." }</pre></div>
                    <div style="margin-bottom:10px; font-size:13px;"><span class="step-badge">CEVAP</span> Sizin dönmeniz gereken JSON:</div>
                    <div class="code-container"><pre>{ "status": true, "user_id": "12345", "current_balance": 50.00 }</pre></div>
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <div class="accordion-header" onclick="toggleAccordion(this)">
                <div class="accordion-title">
                    <div class="accordion-icon" style="background:#fee2e2; color:#991b1b;"><i class="ri-shield-check-line"></i></div>
                    Güvenlik Kontrol Listesi
                </div>
                <i class="ri-arrow-down-s-line accordion-arrow"></i>
            </div>
            <div class="accordion-content">
                <div class="accordion-body">
                    <ul style="margin:0; padding-left:20px; color:var(--text-main);">
                        <li style="margin-bottom:8px;"><b>HTTPS:</b> Tüm endpointleriniz SSL sertifikası ile korunmalıdır.</li>
                        <li style="margin-bottom:8px;"><b>Hash Kontrolü:</b> Callback dosyasında mutlaka imza doğrulaması yapın.</li>
                        <li><b>Loglama:</b> Gelen ve giden istekleri loglayın.</li>
                    </ul>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
    function copyToClipboard(elementId) {
        const copyText = document.getElementById(elementId);
        const originalType = copyText.type;
        if(originalType === 'password') copyText.type = 'text';
        copyText.select();
        copyText.setSelectionRange(0, 99999); 
        navigator.clipboard.writeText(copyText.value).then(() => alert("Kopyalandı!"));
        if(originalType === 'password') copyText.type = 'password';
    }

    function toggleSecret() {
        const input = document.getElementById('apiSecret');
        const icon = document.getElementById('eyeIcon');
        if (input.type === "password") {
            input.type = "text";
            icon.classList.replace('ri-eye-line', 'ri-eye-off-line');
        } else {
            input.type = "password";
            icon.classList.replace('ri-eye-off-line', 'ri-eye-line');
        }
    }

    function copyCode() {
        const code = document.getElementById('phpCode').innerText;
        navigator.clipboard.writeText(code).then(() => alert("Örnek kod kopyalandı!"));
    }

    function toggleAccordion(header) {
        const item = header.parentElement;
        const content = header.nextElementSibling;
        
        document.querySelectorAll('.accordion-item').forEach(acc => {
            if(acc !== item) {
                acc.classList.remove('active');
                acc.querySelector('.accordion-content').style.maxHeight = null;
            }
        });

        item.classList.toggle('active');
        if (item.classList.contains('active')) {
            content.style.maxHeight = content.scrollHeight + "px";
        } else {
            content.style.maxHeight = null;
        }
    }
</script>

</body>
</html>