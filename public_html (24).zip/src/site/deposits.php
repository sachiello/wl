<?php
require 'init.php';

// Güvenlik: Oturum kontrolü
if (!isset($_SESSION['site_id'])) {
    header('Location: login.php');
    exit;
}
$siteId = (int)$_SESSION['site_id'];

// ------------------------------
// Filtreler
// ------------------------------
$start  = $_GET['start']  ?? '';
$end    = $_GET['end']    ?? '';
$search = $_GET['search'] ?? '';

// DÜZELTME: deposit_orders yerine merchant_orders kullanıldı.
// Siteye gelen paralar bu tabloda.
$sql = "SELECT m.*, u.username 
        FROM merchant_orders m 
        LEFT JOIN users u ON m.user_id = u.id 
        WHERE m.site_id = ? AND m.status = 'success'";

$params = [$siteId];

if ($start && $end) {
    // merchant_orders tablosunda tarih sütunu 'created_at'
    $sql .= " AND DATE(m.created_at) BETWEEN ? AND ?";
    $params[] = $start;
    $params[] = $end;
}

if ($search) {
    // ID, Sipariş Kodu veya Kullanıcı Adı araması
    $sql .= " AND (m.id LIKE ? OR m.order_id LIKE ? OR u.username LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$sql .= " ORDER BY m.created_at DESC LIMIT 200";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $deposits = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Veritabanı hatası: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yatırım Raporları</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    
<style>
    /* ----------------------------------------------------
       GLOBAL DEĞİŞKENLER & RESET
       ---------------------------------------------------- */
    :root {
        --primary: #c2273f;
        --bg-body: #f1f5f9;
        --bg-card: #ffffff;
        --text-main: #0f172a;
        --text-muted: #64748b;
        --border-color: #e2e8f0;
        --success: #10b981;
    }
    
    body {
        font-family: 'Inter', sans-serif;
        background: var(--bg-body);
        color: var(--text-main);
        margin: 0;
        display: flex; /* Sidebar ve içerik yan yana */
    }

    /* ----------------------------------------------------
       LAYOUT (SIDEBAR & MAIN CONTENT) - Index.php ile Eşitlendi
       ---------------------------------------------------- */
    .app-wrapper {
        display: flex;
        width: 100%;
        min-height: 100vh;
    }

    /* Sidebar Ayarları - Index.php ile birebir aynı ölçüler */
    .sidebar {
        width: 260px; /* Index.php'deki genişlik */
        background: var(--bg-card);
        border-right: 1px solid var(--border-color);
        padding: 20px;
        flex-shrink: 0; /* Küçülmesini engelle */
        display: none; /* Mobilde gizli */
    }
    
    @media(min-width: 1024px) { 
        .sidebar { display: block; } 
    }

    .main-content {
        flex: 1;
        padding: 30px;
        overflow-y: auto; /* İçerik taşarsa scroll çıksın */
        width: 100%; /* Kalan alanı kapla */
    }

    /* ----------------------------------------------------
       KART VE FORM ELEMENTLERİ
       ---------------------------------------------------- */
    .card {
        background: var(--bg-card);
        border-radius: 16px;
        border: 1px solid var(--border-color);
        padding: 20px;
        box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
    }

    .form-control {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid var(--border-color);
        border-radius: 8px;
        outline: none;
        box-sizing: border-box;
        font-size: 14px;
        transition: border-color 0.2s;
    }
    .form-control:focus { border-color: var(--primary); }

    .btn {
        padding: 10px 20px;
        border-radius: 8px;
        border: none;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        font-size: 14px;
        transition: opacity 0.2s;
    }
    .btn:hover { opacity: 0.9; }
    .btn-primary { background: var(--primary); color: #fff; }
    .btn-secondary { background: #e2e8f0; color: var(--text-main); }

    /* ----------------------------------------------------
       TABLO STİLLERİ
       ---------------------------------------------------- */
    .table-responsive { overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; font-size: 14px; min-width: 600px; }
    th { text-align: left; padding: 12px 16px; color: var(--text-muted); font-weight: 600; border-bottom: 1px solid var(--border-color); font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; }
    td { padding: 12px 16px; border-bottom: 1px solid var(--border-color); vertical-align: middle; }
    tr:last-child td { border-bottom: none; }
    
    .badge { padding: 4px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
    .bg-green { background: rgba(16, 185, 129, 0.15); color: #10b981; }
    .ref-code { font-family: monospace; background: rgba(0,0,0,0.04); padding: 3px 6px; border-radius: 4px; font-size: 12px; color: var(--text-main); }
</style>
</head>
<body>

<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        <div class="topbar" style="margin-bottom: 30px;">
            <h1 style="margin:0; font-size:24px; font-weight:800;">Yatırım Raporu</h1>
            <p style="margin:5px 0 0; color:var(--text-muted);">Sitenize aktarılan kullanıcı bakiyelerinin listesi.</p>
        </div>

        <div class="card" style="margin-bottom: 20px;">
            <form method="get" style="display:flex; gap:12px; flex-wrap:wrap; align-items:flex-end;">
                
                <div class="form-group" style="flex:1; min-width:200px;">
                    <label style="font-size:12px; font-weight:700; display:block; margin-bottom:5px;">Tarih Aralığı</label>
                    <input type="text" id="dateRange" class="form-control" placeholder="Tarih seçin...">
                    <input type="hidden" name="start" id="startDate" value="<?= htmlspecialchars($start) ?>">
                    <input type="hidden" name="end" id="endDate" value="<?= htmlspecialchars($end) ?>">
                </div>

                <div class="form-group" style="flex:1; min-width:200px;">
                    <label style="font-size:12px; font-weight:700; display:block; margin-bottom:5px;">Arama</label>
                    <input type="text" name="search" class="form-control" placeholder="Ref No, ID veya Kullanıcı..." value="<?= htmlspecialchars($search) ?>">
                </div>

                <div class="form-group">
                    <button class="btn btn-primary" type="submit"><i class="ri-filter-3-line"></i> Filtrele</button>
                    <?php if ($start || $end || $search): ?>
                        <a href="deposits.php" class="btn btn-secondary">Temizle</a>
                    <?php endif; ?>
                </div>

            </form>
        </div>

        <div class="card" style="padding:0; overflow:hidden;">
            <div style="overflow-x:auto;">
                <table>
                    <thead>
                        <tr>
                            <th style="padding-left:20px;">Ref No</th>
                            <th>Kullanıcı</th>
                            <th>Brüt Tutar</th>
                            <th>Net (Size Geçen)</th>
                            <th>Tarih</th>
                            <th style="text-align:right; padding-right:20px;">Durum</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($deposits) > 0): ?>
                            <?php foreach ($deposits as $d): ?>
                                <tr>
                                    <td style="padding-left:20px;">
                                        <span class="ref-code">#<?= htmlspecialchars($d['order_id']) ?></span>
                                    </td>
                                    <td style="font-weight:600; color:var(--text-main);">
                                        <?= htmlspecialchars($d['username'] ?? 'Silinmiş Üye') ?>
                                        <div style="font-size:11px; color:var(--text-muted);">ID: <?= $d['user_id'] ?></div>
                                    </td>
                                    <td style="font-weight:500; color:var(--text-muted);">
                                        <?= number_format($d['amount_try'], 2) ?> ₺
                                    </td>
                                    <td style="font-weight:700; color:#10b981;">
                                        +<?= number_format($d['net_amount'], 2) ?> ₺
                                    </td>
                                    <td style="color:var(--text-muted); font-size:13px;">
                                        <?= date('d.m.Y H:i', strtotime($d['created_at'])) ?>
                                    </td>
                                    <td style="text-align:right; padding-right:20px;">
                                        <span class="badge bg-green">BAŞARILI</span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" style="text-align:center; padding:30px; color:var(--text-muted);">
                                    <i class="ri-inbox-archive-line" style="font-size:24px; display:block; margin-bottom:10px;"></i>
                                    Kriterlere uygun kayıt bulunamadı.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://npmcdn.com/flatpickr/dist/l10n/tr.js"></script>
<script>
    flatpickr("#dateRange", {
        mode: "range",
        dateFormat: "Y-m-d",
        locale: "tr",
        defaultDate: ["<?= $start ?>", "<?= $end ?>"],
        onClose: function(selectedDates, dateStr, instance) {
            if (selectedDates.length === 2) {
                document.getElementById('startDate').value = instance.formatDate(selectedDates[0], "Y-m-d");
                document.getElementById('endDate').value = instance.formatDate(selectedDates[1], "Y-m-d");
            }
        }
    });
</script>
</body>
</html>