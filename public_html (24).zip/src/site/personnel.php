<?php
require 'init.php';

// Yetki Kontrolü
if (isset($_SESSION['is_personnel']) && $_SESSION['is_personnel'] && !function_exists('hasPerm')) {
    die("<div class='app-wrapper'><div class='main-content'><div class='card bg-red' style='color:#fff; padding:20px;'>Yetkisiz Erişim.</div></div></div>");
}
if (isset($_SESSION['is_personnel']) && $_SESSION['is_personnel'] && function_exists('hasPerm') && !hasPerm('manage_personnel')) {
    die("<div class='app-wrapper'><div class='main-content'><div class='card bg-red' style='color:#fff; padding:20px;'>Bu sayfayı görüntüleme yetkiniz yok.</div></div></div>");
}

$msg = ""; 
$err = "";

if (isset($_SESSION['message'])) {
    $msg = $_SESSION['message'];
    unset($_SESSION['message']);
}
if (isset($_SESSION['error_message'])) {
    $err = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}

// --------------------------------------------------
// İŞLEM: POST İSTEKLERİ
// --------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $tokenCheck = isset($_POST['csrf_token']) && isset($_SESSION['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token'];
    if (!$tokenCheck && function_exists('csrf_token')) {
        $_SESSION['error_message'] = "Güvenlik hatası. Lütfen sayfayı yenileyin.";
        header("Location: personnel.php"); exit;
    }
    
    // 1. EKLEME
    elseif (isset($_POST['add_user'])) {
        $user = trim($_POST['username']);
        $pass = trim($_POST['password']);
        $perms = isset($_POST['perms']) ? $_POST['perms'] : [];
        
        if (strlen($user) < 3 || strlen($pass) < 4) {
            $_SESSION['error_message'] = "Kullanıcı adı en az 3, şifre en az 4 karakter olmalıdır.";
            header("Location: personnel.php"); exit;
        } else {
            $check = $pdo->prepare("SELECT id FROM site_personnel WHERE username = ? AND site_id = ?");
            $check->execute([$user, $site['id']]);
            if ($check->fetch()) {
                $_SESSION['error_message'] = "Bu kullanıcı adı zaten kullanılıyor.";
                header("Location: personnel.php"); exit;
            } else {
                $hash = password_hash($pass, PASSWORD_BCRYPT);
                $permJson = json_encode($perms);
                
                $ins = $pdo->prepare("INSERT INTO site_personnel (site_id, username, password_hash, permissions, is_active, created_at) VALUES (?, ?, ?, ?, 1, NOW())");
                $ins->execute([$site['id'], $user, $hash, $permJson]);
                $_SESSION['message'] = "Personel başarıyla eklendi.";
                header("Location: personnel.php"); exit;
            }
        }
    }
    
    // 2. DÜZENLEME
    elseif (isset($_POST['edit_user'])) {
        $editId = (int)$_POST['edit_id'];
        $perms = isset($_POST['perms']) ? $_POST['perms'] : [];
        $permJson = json_encode($perms);
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $newPass = trim($_POST['password']);

        if (!empty($newPass)) {
            $hash = password_hash($newPass, PASSWORD_BCRYPT);
            $pdo->prepare("UPDATE site_personnel SET password_hash = ?, permissions = ?, is_active = ? WHERE id = ? AND site_id = ?")->execute([$hash, $permJson, $isActive, $editId, $site['id']]);
        } else {
            $pdo->prepare("UPDATE site_personnel SET permissions = ?, is_active = ? WHERE id = ? AND site_id = ?")->execute([$permJson, $isActive, $editId, $site['id']]);
        }
        $_SESSION['message'] = "Personel bilgileri güncellendi.";
        header("Location: personnel.php"); exit;
    }

    // 3. SİLME
    elseif (isset($_POST['delete_id'])) {
        $id = (int)$_POST['delete_id'];
        $pdo->prepare("DELETE FROM site_personnel WHERE id = ? AND site_id = ?")->execute([$id, $site['id']]);
        $_SESSION['message'] = "Personel kaydı silindi.";
        header("Location: personnel.php"); exit;
    }
}

// Personel Listesini Çek
$users = $pdo->prepare("SELECT * FROM site_personnel WHERE site_id = ? ORDER BY created_at DESC");
$users->execute([$site['id']]);
$list = $users->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Yönetimi - <?= htmlspecialchars($site['name']) ?></title>
    
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        /* GLOBAL CSS */
        :root { --primary: #c2273f; --bg-body: #f1f5f9; --bg-card: #ffffff; --text-main: #0f172a; --text-muted: #64748b; --border-color: #e2e8f0; --success: #10b981; --info: #0ea5e9; --danger: #ef4444; --warning: #f59e0b; }
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; display: flex; }
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        
        .sidebar { width: 260px; background: var(--bg-card); border-right: 1px solid var(--border-color); padding: 20px; flex-shrink: 0; display: none; }
        @media(min-width: 1024px) { .sidebar { display: block; } }

        .main-content { flex: 1; padding: 30px; overflow-y: auto; width: 100%; }
        
        /* KART & FORM */
        .card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); padding: 20px; margin-bottom: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        
        .form-control { width: 100%; padding: 10px 12px; border: 1px solid var(--border-color); border-radius: 8px; outline: none; box-sizing: border-box; font-size: 14px; transition: border-color 0.2s; }
        .form-control:focus { border-color: var(--primary); }

        .btn { padding: 10px 20px; border-radius: 8px; border: none; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; font-size: 14px; text-decoration: none; transition: opacity 0.2s; }
        .btn:hover { opacity: 0.9; }
        .btn-primary { background: var(--primary); color: #fff; }
        .btn-secondary { background: #e2e8f0; color: var(--text-main); }
        .btn-danger { background: #fef2f2; color: var(--danger); border: 1px solid #fecaca; }
        .btn-danger:hover { background: var(--danger); color: #fff; }
        .btn-sm { padding: 6px 12px; font-size: 12px; }

        /* ALERT */
        .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; font-size: 14px; font-weight: 500; }
        .alert-success { background: rgba(16, 185, 129, 0.1); color: var(--success); border: 1px solid rgba(16, 185, 129, 0.2); }
        .alert-danger { background: rgba(239, 68, 68, 0.1); color: var(--danger); border: 1px solid rgba(239, 68, 68, 0.2); }

        /* TABLO */
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; font-size: 14px; min-width: 600px; }
        th { text-align: left; padding: 12px 16px; color: var(--text-muted); font-weight: 600; border-bottom: 1px solid var(--border-color); font-size: 11px; text-transform: uppercase; }
        td { padding: 12px 16px; border-bottom: 1px solid var(--border-color); vertical-align: middle; }
        tr:last-child td { border-bottom: none; }

        .badge { padding: 4px 8px; border-radius: 6px; font-size: 11px; font-weight: 600; display: inline-block; margin-right: 4px; margin-bottom: 4px; }
        .bg-green { background: #dcfce7; color: #166534; }
        .bg-yellow { background: #fef9c3; color: #854d0e; }
        .bg-blue { background: #dbeafe; color: #1e40af; }
        .bg-purple { background: #f3e8ff; color: #6b21a8; }
        .bg-gray { background: #f3f4f6; color: #374151; }
        .bg-red { background: #fee2e2; color: #991b1b; }
        .bg-indigo { background: #e0e7ff; color: #3730a3; }

        /* MODAL */
        .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; display: none; backdrop-filter: blur(3px); }
        .modal-content { background: #fff; border-radius: 16px; width: 100%; max-width: 500px; padding: 25px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); animation: slideUp 0.3s ease-out; }
        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .modal-header h3 { margin: 0; font-size: 18px; color: var(--text-main); }
        .close-btn { font-size: 24px; color: var(--text-muted); cursor: pointer; transition: color 0.2s; }
        .close-btn:hover { color: var(--danger); }
        
        .checkbox-group { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px; }
        .checkbox-group label { display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--text-main); cursor: pointer; padding: 8px; border: 1px solid var(--border-color); border-radius: 6px; transition: background 0.2s; }
        .checkbox-group label:hover { background: #f8fafc; }
        .checkbox-group input[type="checkbox"] { width: 16px; height: 16px; accent-color: var(--primary); }

        @keyframes slideUp { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    </style>
</head>
<body>

<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    
    <div class="main-content">
        <div class="topbar" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:30px;">
            <div>
                <h1 style="margin:0; font-size:24px; font-weight:800; color:var(--text-main);">Personel Yönetimi</h1>
                <p style="margin:5px 0 0; color:var(--text-muted);">Alt kullanıcılar oluşturun ve yetkilerini yönetin.</p>
            </div>
            <button class="btn btn-primary" onclick="openModal('addModal')">
                <i class="ri-user-add-line"></i> Yeni Personel
            </button>
        </div>
        
        <?php if($msg): ?><div class="alert alert-success"><i class="ri-checkbox-circle-fill"></i> <?= $msg ?></div><?php endif; ?>
        <?php if($err): ?><div class="alert alert-danger"><i class="ri-error-warning-fill"></i> <?= $err ?></div><?php endif; ?>

        <div class="card" style="padding:0; overflow:hidden;">
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th style="padding-left:20px;">Kullanıcı</th>
                            <th>Yetkiler</th>
                            <th>Durum</th>
                            <th style="text-align:right; padding-right:20px;">İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($list as $u): 
                            $pPerms = json_decode($u['permissions'], true) ?? []; 
                        ?>
                        <tr>
                            <td style="padding-left:20px; font-weight:600;">
                                <i class="ri-user-line" style="vertical-align:middle; color:var(--text-muted); margin-right:5px;"></i>
                                <?= htmlspecialchars($u['username']) ?>
                            </td>
                            <td>
                                <?php if(in_array('view_deposits', $pPerms)) echo '<span class="badge bg-green">Yatırım</span>'; ?>
                                <?php if(in_array('create_withdraw', $pPerms)) echo '<span class="badge bg-yellow">Mutabakat</span>'; ?>
                                <?php if(in_array('request_balance', $pPerms)) echo '<span class="badge bg-blue">Bakiye</span>'; ?>
                                <?php if(in_array('view_users', $pPerms)) echo '<span class="badge bg-purple">Oyuncular</span>'; ?>
                                <?php if(in_array('view_sidebar_balance', $pPerms)) echo '<span class="badge bg-indigo">Bakiye (Side)</span>'; ?>
                                <?php if(in_array('manage_settings', $pPerms)) echo '<span class="badge bg-gray">Ayarlar</span>'; ?>
                                <?php if(in_array('manage_personnel', $pPerms)) echo '<span class="badge bg-gray">Yönetim</span>'; ?>
                                <?php if(empty($pPerms)) echo '<span style="color:var(--text-muted); font-size:12px;">Yetki Yok</span>'; ?>
                            </td>
                            <td>
                                <?= $u['is_active'] ? '<span class="badge bg-green">AKTİF</span>' : '<span class="badge bg-red">PASİF</span>' ?>
                            </td>
                            <td style="text-align:right; padding-right:20px;">
                                <button class="btn btn-sm btn-secondary" onclick='openEditModal(<?= json_encode($u) ?>)'>
                                    <i class="ri-edit-line"></i>
                                </button>
                                <form method="post" style="display:inline;" onsubmit="return confirm('Bu personeli silmek istediğinize emin misiniz?');">
                                    <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
                                    <input type="hidden" name="delete_id" value="<?= $u['id'] ?>">
                                    <button class="btn btn-sm btn-danger">
                                        <i class="ri-delete-bin-line"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        
                        <?php if(empty($list)): ?>
                            <tr><td colspan="4" style="text-align:center; padding:30px; color:var(--text-muted);">Henüz personel bulunmuyor.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div id="addModal" class="modal-overlay" style="display:none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="ri-user-add-line" style="color:var(--primary);"></i> Personel Ekle</h3>
            <i class="ri-close-line close-btn" onclick="closeModal('addModal')"></i>
        </div>
        <form method="post">
            <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
            <input type="hidden" name="add_user" value="1">
            
            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:15px;">
                <div>
                    <label style="font-size:12px; font-weight:600; display:block; margin-bottom:5px;">Kullanıcı Adı</label>
                    <input type="text" name="username" class="form-control" required>
                </div>
                <div>
                    <label style="font-size:12px; font-weight:600; display:block; margin-bottom:5px;">Şifre</label>
                    <input type="text" name="password" class="form-control" required>
                </div>
            </div>
            
            <div style="margin-bottom:20px;">
                <label style="font-size:12px; font-weight:600; display:block; margin-bottom:5px;">Erişim Yetkileri</label>
                <div class="checkbox-group">
                    <label><input type="checkbox" name="perms[]" value="view_deposits" checked> Yatırımları Görüntüle</label>
                    <label><input type="checkbox" name="perms[]" value="view_users" checked> Oyuncu Çekimlerini Gör</label>
                    <label><input type="checkbox" name="perms[]" value="view_sidebar_balance" checked> Sidebar Bakiyesini Gör</label>
                    <label><input type="checkbox" name="perms[]" value="create_withdraw"> Mutabakat (Para Çek)</label>
                    <label><input type="checkbox" name="perms[]" value="request_balance"> Bakiye Yükle</label>
                    <label><input type="checkbox" name="perms[]" value="manage_settings"> Ayarlar ve API</label>
                    <label><input type="checkbox" name="perms[]" value="manage_personnel"> Personel Yönetimi</label>
                </div>
            </div>
            
            <button class="btn btn-primary" style="width:100%;">Kaydet</button>
        </form>
    </div>
</div>

<div id="editModal" class="modal-overlay" style="display:none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="ri-edit-line" style="color:var(--primary);"></i> Düzenle: <span id="editName"></span></h3>
            <i class="ri-close-line close-btn" onclick="closeModal('editModal')"></i>
        </div>
        <form method="post">
            <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
            <input type="hidden" name="edit_user" value="1">
            <input type="hidden" name="edit_id" id="editId">
            
            <div style="margin-bottom:15px;">
                <label style="font-size:12px; font-weight:600; display:block; margin-bottom:5px;">Yeni Şifre (Değiştirmeyecekseniz boş bırakın)</label>
                <input type="text" name="password" class="form-control" placeholder="******">
            </div>
            
            <div style="margin-bottom:15px;">
                <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
                    <input type="checkbox" name="is_active" id="editActive" value="1" style="width:16px; height:16px;"> 
                    <span style="font-weight:600;">Hesap Aktif</span>
                </label>
            </div>

            <div style="margin-bottom:20px;">
                <label style="font-size:12px; font-weight:600; display:block; margin-bottom:5px;">Erişim Yetkileri</label>
                <div class="checkbox-group">
                    <label><input type="checkbox" name="perms[]" value="view_deposits" id="p_dep"> Yatırımları Görüntüle</label>
                    <label><input type="checkbox" name="perms[]" value="view_users" id="p_usr"> Oyuncu Çekimlerini Gör</label>
                    <label><input type="checkbox" name="perms[]" value="view_sidebar_balance" id="p_side_bal"> Sidebar Bakiyesini Gör</label>
                    <label><input type="checkbox" name="perms[]" value="create_withdraw" id="p_wd"> Mutabakat (Para Çek)</label>
                    <label><input type="checkbox" name="perms[]" value="request_balance" id="p_bal"> Bakiye Yükle</label>
                    <label><input type="checkbox" name="perms[]" value="manage_settings" id="p_set"> Ayarlar ve API</label>
                    <label><input type="checkbox" name="perms[]" value="manage_personnel" id="p_per"> Personel Yönetimi</label>
                </div>
            </div>
            
            <button class="btn btn-primary" style="width:100%;">Güncelle</button>
        </form>
    </div>
</div>

<script>
    function openModal(id) { document.getElementById(id).style.display = 'flex'; }
    function closeModal(id) { document.getElementById(id).style.display = 'none'; }
    
    // Modal Dışına Tıklayınca Kapatma
    window.onclick = function(event) {
        if (event.target.classList.contains('modal-overlay')) {
            event.target.style.display = "none";
        }
    }

    function openEditModal(data) {
        document.getElementById('editId').value = data.id;
        document.getElementById('editName').innerText = data.username;
        document.getElementById('editActive').checked = (data.is_active == 1);
        
        let perms = [];
        try { perms = JSON.parse(data.permissions); } catch(e) {}
        if(!Array.isArray(perms)) perms = [];

        document.getElementById('p_dep').checked = perms.includes('view_deposits');
        document.getElementById('p_usr').checked = perms.includes('view_users');
        document.getElementById('p_side_bal').checked = perms.includes('view_sidebar_balance'); // YENİ
        document.getElementById('p_wd').checked = perms.includes('create_withdraw');
        document.getElementById('p_bal').checked = perms.includes('request_balance');
        document.getElementById('p_set').checked = perms.includes('manage_settings');
        document.getElementById('p_per').checked = perms.includes('manage_personnel');
        
        openModal('editModal');
    }
</script>

</body>
</html>