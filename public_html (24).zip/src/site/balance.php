<?php
require 'init.php';

// Yetki Kontrolü
if (isset($_SESSION['is_personnel']) && $_SESSION['is_personnel'] && !function_exists('hasPerm')) {
    // hasPerm fonksiyonu yoksa basit kontrol (Varsa kendi fonksiyonunu kullan)
    die("<div class='app-wrapper'><div class='main-content'><div class='card bg-red' style='color:#fff'>Yetkisiz Erişim.</div></div></div>");
}

$msg = ""; 
$err = "";

if (isset($_SESSION['message'])) {
    $msg = $_SESSION['message'];
    unset($_SESSION['message']);
}
if (isset($_SESSION['error_message'])) {
    $err = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}

// BAKİYE TALEBİ İŞLEME
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF Kontrolü (Varsa kullan, yoksa basit geç)
    $tokenCheck = isset($_POST['csrf_token']) && isset($_SESSION['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token'];
    
    if (!$tokenCheck && function_exists('csrf_token')) {
        $_SESSION['error_message'] = "Güvenlik hatası (CSRF). Lütfen sayfayı yenileyip tekrar deneyin.";
    } elseif (isset($_POST['amount'])) {
        $amount = (float)$_POST['amount'];
        if ($amount < 100) {
            $_SESSION['error_message'] = "Minimum yükleme tutarı 100 TL'dir.";
        } else {
            try {
                $stmt = $pdo->prepare("INSERT INTO site_balance_requests (site_id, amount, status, created_at) VALUES (?, ?, 'pending', NOW())");
                $stmt->execute([$site['id'], $amount]);
                $_SESSION['message'] = "Bakiye yükleme bildiriminiz başarıyla alındı. Yönetici onayından sonra bakiyenize eklenecektir.";
            } catch (PDOException $e) {
                $_SESSION['error_message'] = "Veritabanı hatası: " . $e->getMessage();
            }
        }
    }
    header("Location: balance.php");
    exit;
}

// Admin Cüzdan Adresini Çek
$walletData = $pdo->query("SELECT address, network, coin_symbol FROM admin_crypto_wallets WHERE coin_symbol = 'USDT' AND network = 'TRC20' AND is_active = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);
$walletAddr = $walletData['address'] ?? 'Henüz Tanımlanmamış';
$network    = $walletData['network'] ?? 'TRC20';

// Geçmiş Talepleri Çek
$history = $pdo->prepare("SELECT * FROM site_balance_requests WHERE site_id = ? ORDER BY created_at DESC LIMIT 10");
$history->execute([$site['id']]);
$rows = $history->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bakiye Yükle - <?= htmlspecialchars($site['name']) ?></title>
    
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        /* GLOBAL CSS */
        :root { --primary: #c2273f; --bg-body: #f1f5f9; --bg-card: #ffffff; --text-main: #0f172a; --text-muted: #64748b; --border-color: #e2e8f0; --success: #10b981; --info: #0ea5e9; --danger: #ef4444; --warning: #f59e0b; }
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; display: flex; }
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        
        .sidebar { width: 260px; background: var(--bg-card); border-right: 1px solid var(--border-color); padding: 20px; flex-shrink: 0; display: none; }
        @media(min-width: 1024px) { .sidebar { display: block; } }

        .main-content { flex: 1; padding: 30px; overflow-y: auto; width: 100%; }
        
        /* Kartlar */
        .card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); padding: 25px; margin-bottom: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        
        /* Form Elemanları */
        .form-control { width: 100%; padding: 12px; border: 1px solid var(--border-color); border-radius: 8px; outline: none; font-size: 14px; box-sizing: border-box; transition: border-color 0.2s; }
        .form-control:focus { border-color: var(--primary); }
        .btn { padding: 12px 24px; border-radius: 8px; border: none; font-weight: 600; cursor: pointer; width: 100%; font-size: 14px; transition: opacity 0.2s; display: inline-flex; justify-content: center; align-items: center; gap: 8px; }
        .btn:hover { opacity: 0.9; }
        .btn-primary { background: var(--primary); color: #fff; }
        
        /* Alert */
        .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; font-size: 14px; font-weight: 500; }
        .alert-success { background: rgba(16, 185, 129, 0.1); color: var(--success); border: 1px solid rgba(16, 185, 129, 0.2); }
        .alert-danger { background: rgba(239, 68, 68, 0.1); color: var(--danger); border: 1px solid rgba(239, 68, 68, 0.2); }

        /* Tablo */
        table { width: 100%; border-collapse: collapse; font-size: 14px; }
        th { text-align: left; padding: 12px; color: var(--text-muted); border-bottom: 1px solid var(--border-color); font-size: 11px; text-transform: uppercase; }
        td { padding: 12px; border-bottom: 1px solid var(--border-color); vertical-align: middle; }
        .badge { padding: 4px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
        .bg-green { background: rgba(16, 185, 129, 0.15); color: var(--success); }
        .bg-yellow { background: rgba(245, 158, 11, 0.15); color: var(--warning); }
        .bg-red { background: rgba(239, 68, 68, 0.15); color: var(--danger); }

        /* QR Alanı */
        .qr-box { background: #fff; padding: 10px; border-radius: 8px; border: 1px solid var(--border-color); display: inline-block; margin-bottom: 15px; }
        .wallet-box { background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px dashed var(--border-color); position: relative; word-break: break-all; font-family: monospace; font-size: 13px; color: var(--text-main); }
        .copy-btn { position: absolute; right: 8px; top: 8px; border: none; background: #fff; border: 1px solid var(--border-color); border-radius: 6px; width: 30px; height: 30px; cursor: pointer; display: flex; align-items: center; justify-content: center; color: var(--text-muted); transition: all 0.2s; }
        .copy-btn:hover { border-color: var(--primary); color: var(--primary); }
    </style>
</head>
<body>

<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    
    <div class="main-content">
        <div class="topbar" style="margin-bottom: 30px;">
            <h1 style="margin:0; font-size:24px; font-weight:800;">Bakiye Yükleme Merkezi</h1>
            <p style="margin:5px 0 0; color:var(--text-muted);">Panel bakiyenizi artırmak için USDT transferi yapın.</p>
        </div>
        
        <?php if($msg): ?><div class="alert alert-success"><i class="ri-checkbox-circle-fill"></i> <?= $msg ?></div><?php endif; ?>
        <?php if($err): ?><div class="alert alert-danger"><i class="ri-error-warning-fill"></i> <?= $err ?></div><?php endif; ?>

        <div class="card">
            <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap:40px;">
                
                <div>
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:20px;">
                        <div style="width:30px; height:30px; background:var(--primary); color:#fff; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:bold;">1</div>
                        <h3 style="margin:0; font-size:18px;">Transfer Yapın</h3>
                    </div>
                    
                    <div style="text-align:center; margin-bottom:20px;">
                        <div class="qr-box">
                            <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=<?= $walletAddr ?>" alt="QR Code" width="140">
                        </div>
                        <div style="font-size:12px; color:var(--text-muted); font-weight:600;">Ağ: <?= htmlspecialchars($network) ?> (USDT)</div>
                    </div>

                    <label style="font-size:12px; font-weight:700; color:var(--text-muted); display:block; margin-bottom:5px;">Cüzdan Adresi</label>
                    <div class="wallet-box">
                        <?= htmlspecialchars($walletAddr) ?>
                        <button class="copy-btn" onclick="copyWallet('<?= $walletAddr ?>')" title="Kopyala">
                            <i class="ri-file-copy-line"></i>
                        </button>
                    </div>
                    <p style="font-size:12px; color:var(--danger); margin-top:10px;">
                        <i class="ri-alert-fill"></i> Lütfen sadece <b><?= $network ?></b> ağından gönderim yapın. Yanlış ağ gönderimleri kaybolabilir.
                    </p>
                </div>

                <div style="border-left: 1px solid var(--border-color); padding-left: 40px;">
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:20px;">
                        <div style="width:30px; height:30px; background:var(--text-main); color:#fff; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:bold;">2</div>
                        <h3 style="margin:0; font-size:18px;">Bildirim Gönderin</h3>
                    </div>
                    
                    <p style="font-size:14px; color:var(--text-muted); margin-bottom:20px; line-height:1.6;">
                        Transfer işleminiz tamamlandıktan sonra, gönderdiğiniz tutarı (TL karşılığı olarak anlaşmanıza göre) aşağıya girip bildirim oluşturun.
                    </p>

                    <form method="post">
                        <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
                        
                        <div style="margin-bottom:20px;">
                            <label style="display:block; font-size:13px; font-weight:600; color:var(--text-muted); margin-bottom:8px;">Yüklenen Tutar (TL)</label>
                            <input type="number" name="amount" class="form-control" placeholder="0.00" step="0.01" min="100" required style="font-size:16px; font-weight:bold;">
                        </div>

                        <button class="btn btn-primary">
                            <i class="ri-send-plane-fill"></i> Bildirimi Gönder
                        </button>
                    </form>
                </div>

            </div>
        </div>

        <div class="card">
            <h3 style="margin:0 0 20px 0; font-size:18px;">Geçmiş Talepler</h3>
            <div style="overflow-x:auto;">
                <table>
                    <thead>
                        <tr>
                            <th>Talep ID</th>
                            <th>Tutar</th>
                            <th>Talep Tarihi</th>
                            <th>İşlem Tarihi</th>
                            <th style="text-align:right;">Durum</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($rows as $r): ?>
                        <tr>
                            <td style="font-family:monospace; color:var(--text-muted);">#<?= $r['id'] ?></td>
                            <td style="font-weight:700; color:var(--text-main);"><?= number_format($r['amount'], 2) ?> ₺</td>
                            <td style="color:var(--text-muted); font-size:13px;"><?= date('d.m.Y H:i', strtotime($r['created_at'])) ?></td>
                            <td style="color:var(--text-muted); font-size:13px;">
                                <?= $r['processed_at'] ? date('d.m.Y H:i', strtotime($r['processed_at'])) : '-' ?>
                            </td>
                            <td style="text-align:right;">
                                <?php 
                                if($r['status']=='approved') echo '<span class="badge bg-green"><i class="ri-check-double-line"></i> ONAYLANDI</span>';
                                elseif($r['status']=='pending') echo '<span class="badge bg-yellow"><i class="ri-time-line"></i> BEKLİYOR</span>';
                                else echo '<span class="badge bg-red"><i class="ri-close-line"></i> REDDEDİLDİ</span>'; 
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($rows)): ?>
                            <tr><td colspan="5" style="text-align:center; padding:30px; color:var(--text-muted);">Henüz talep bulunmuyor.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<script>
    function copyWallet(text) {
        navigator.clipboard.writeText(text).then(() => {
            const btn = document.querySelector('.copy-btn');
            const originalHTML = btn.innerHTML;
            
            btn.innerHTML = '<i class="ri-check-line" style="color:var(--success)"></i>';
            btn.style.borderColor = 'var(--success)';
            
            setTimeout(() => {
                btn.innerHTML = originalHTML;
                btn.style.borderColor = 'var(--border-color)';
            }, 2000);
        });
    }
</script>

</body>
</html>