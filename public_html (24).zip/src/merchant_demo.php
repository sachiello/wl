<?php
// merchant_demo.php
require __DIR__ . '/../config/config.php';

// Sekabet'i DB'den çek
$stmt = $pdo->prepare("SELECT * FROM sites WHERE slug = 'sekabet' LIMIT 1");
$stmt->execute();
$site = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$site) {
    die('Sekabet merchant bulunamadı.');
}

// Normalde bunlar sitedeki yatırım formundan gelir:
$orderId = 'ORD' . rand(10000,99999);
$amount  = 500.00; // TRY
$ts      = time();

$params = [
    'merchant_id' => $site['id'],
    'order_id'    => $orderId,
    'amount'      => $amount,
    'currency'    => 'TRY',
    'ts'          => $ts,
];

$sig = make_signature($site['api_secret'], $params);

// Betwallet ödeme sayfası URL'si
$payUrl = 'http://localhost/betwallet_demo/pay.php?' . http_build_query(array_merge($params, [
    'sig' => $sig,
]));
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="utf-8">
<title>Sekabet – Betwallet Demo</title>
</head>
<body>
<h1>Sekabet – Betwallet Demo</h1>
<p>Bu sayfa, Sekabet'in Betwallet'e yönlendirme mantığını simüle eder.</p>
<p>Order ID: <strong><?= htmlspecialchars($orderId) ?></strong></p>
<p>Tutar: <strong><?= htmlspecialchars($amount) ?> ₺</strong></p>

<p>
    <a href="<?= htmlspecialchars($payUrl) ?>">Betwallet ile ödemeye git</a>
</p>
</body>
</html>
