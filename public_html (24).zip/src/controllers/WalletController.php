<?php

require_once __DIR__ . '/../helpers/wallet_helpers.php';
require_once __DIR__ . '/../services/WalletService.php';

class WalletController
{
    private WalletService $service;
    private array $config;
    private string $baseUrl;
    private string $redirectBase;

    public function __construct(PDO $pdo)
    {
        wallet_require_session();

        $this->config       = require __DIR__ . '/../config/wallet.php';
        $this->redirectBase = $_SERVER['PHP_SELF'] ?? '/wallet';
        $this->service      = new WalletService($pdo, $this->config, $this->redirectBase);
        $this->baseUrl      = $this->computeBaseUrl();
    }

    public function handle(): void
    {
        $this->ensureAuthenticated();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $redirect = $this->service->handlePost($_POST);
            header('Location: ' . $redirect);
            exit;
        }

        $viewData = $this->service->buildViewData();

        // Görünüme özel ek parametreler
        $viewData['baseUrl']       = $this->baseUrl;
        $viewData['statusApiUrl']  = $this->baseUrl . ($this->config['status_api_path'] ?? '/src/controllers/get_user_status.php');
        $viewData['twofaEnabled']  = !empty($_SESSION['2fa_verified']);

        $this->render($viewData);
    }

    private function ensureAuthenticated(): void
    {
        if (empty($_SESSION['user_id']) || empty($_SESSION['2fa_verified'])) {
            header('Location: /?v=login');
            exit;
        }
    }

    private function computeBaseUrl(): string
    {
        $basePath = dirname($_SERVER['SCRIPT_NAME']);
        return ($basePath === '/' || $basePath === '\\') ? '' : $basePath;
    }

    private function render(array $data): void
    {
        $viewFile = __DIR__ . '/../views/wallet/view.php';
        extract($data);
        require $viewFile;
    }
}
