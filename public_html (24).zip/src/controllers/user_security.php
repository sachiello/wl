<?php
// src/controllers/user_security.php
session_start();
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/GoogleAuthenticator.php';

header('Content-Type: application/json; charset=utf-8');

$response = ['success' => false, 'message' => 'Bilinmeyen hata.'];

if (empty($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Oturum bulunamadı.'
    ]);
    exit;
}

$userId = (int) $_SESSION['user_id'];

if (!csrf_validate_request()) {
    echo json_encode([
        'success' => false,
        'message' => 'Oturum doğrulaması başarısız. Lütfen sayfayı yenileyip tekrar deneyin.'
    ]);
    exit;
}

$action = $_POST['action'] ?? '';

try {
    // 1) Kullanıcıyı çek – tabloya göre doğru alanlar
    $stmt = $pdo->prepare("
        SELECT id, username, password_hash,
               two_factor_secret, two_factor_enabled, is_2fa_enabled
        FROM users
        WHERE id = :id
        LIMIT 1
    ");
    $stmt->execute([':id' => $userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        throw new Exception('Kullanıcı bulunamadı.');
    }

    switch ($action) {

        // -------------------------
        // 1) ŞİFRE DEĞİŞTİR
        // -------------------------
        case 'change_password':
            $current = $_POST['current_password'] ?? '';
            $new     = $_POST['new_password'] ?? '';
            $new2    = $_POST['new_password_confirmation'] ?? '';

            if ($new !== $new2) {
                throw new Exception('Yeni şifreler birbiriyle uyuşmuyor.');
            }

            if (strlen($new) < 8) {
                throw new Exception('Yeni şifre en az 8 karakter olmalıdır.');
            }

            if (!password_verify($current, $user['password_hash'])) {
                throw new Exception('Mevcut şifreniz hatalı.');
            }

            $newHash = password_hash($new, PASSWORD_DEFAULT);

            $up = $pdo->prepare("UPDATE users SET password_hash = :ph WHERE id = :id");
            $up->execute([
                ':ph' => $newHash,
                ':id' => $userId,
            ]);

            $response['success'] = true;
            $response['message'] = 'Şifreniz başarıyla güncellendi.';
            break;

        // -------------------------
        // 2) 2FA BAŞLAT (SECRET ÜRET)
        // -------------------------
        case 'init_2fa':
            if ((int)$user['two_factor_enabled'] === 1 || (int)$user['is_2fa_enabled'] === 1) {
                throw new Exception('2FA zaten aktif.');
            }

            $ga = new GoogleAuthenticator();
            $secret = $ga->createSecret();

            // Secret kaydı, 2FA henüz aktif değil
            $up = $pdo->prepare("
                UPDATE users
                SET two_factor_secret = :sec,
                    two_factor_enabled = 0,
                    is_2fa_enabled = 0
                WHERE id = :id
            ");
            $up->execute([
                ':sec' => $secret,
                ':id'  => $userId,
            ]);

            $issuer = 'BetWallet';
            $label  = $issuer . ' (' . $user['username'] . ')';
            $qrUrl  = $ga->getQRCodeGoogleUrl($label, $secret, $issuer);

            $response['success'] = true;
            $response['message'] = '2FA kurulumu başlatıldı.';
            $response['data'] = [
                'secret' => $secret,
                'qr_url' => $qrUrl,
            ];
            break;

        // -------------------------
        // 3) KODU DOĞRULA & 2FA AKTİF ET
        // -------------------------
        case 'verify_enable_2fa':
            $code = $_POST['otp_code'] ?? '';

            if (empty($user['two_factor_secret'])) {
                throw new Exception('Önce 2FA kurulumu başlatılmalıdır.');
            }

            $ga = new GoogleAuthenticator();
            $window = 2;

            if (!$ga->verifyCode($user['two_factor_secret'], $code, $window)) {
                throw new Exception('Girilen doğrulama kodu geçersiz.');
            }

            $up = $pdo->prepare("
                UPDATE users
                SET two_factor_enabled = 1,
                    is_2fa_enabled     = 1
                WHERE id = :id
            ");
            $up->execute([':id' => $userId]);

            $response['success'] = true;
            $response['message'] = 'İki adımlı doğrulama başarıyla aktifleştirildi.';
            break;

        // -------------------------
        // 4) 2FA KAPAT
        // -------------------------
        case 'disable_2fa':
            $current = $_POST['current_password'] ?? '';

            if (!password_verify($current, $user['password_hash'])) {
                throw new Exception('Mevcut şifreniz hatalı.');
            }

            $up = $pdo->prepare("
                UPDATE users
                SET two_factor_enabled = 0,
                    is_2fa_enabled     = 0,
                    two_factor_secret  = NULL
                WHERE id = :id
            ");
            $up->execute([':id' => $userId]);

            $response['success'] = true;
            $response['message'] = 'İki adımlı doğrulama devre dışı bırakıldı.';
            break;

        default:
            throw new Exception('Geçersiz işlem tipi.');
    }

} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
exit;
