<?php
// src/controllers/get_user_status.php

declare(strict_types=1);

session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../config/config.php';

function json_response(int $httpCode, array $payload): void {
    http_response_code($httpCode);
    echo json_encode($payload);
    exit;
}

// 1) Kullanıcı oturumu
$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    json_response(401, [
        'status'  => 'error',
        'message' => 'Oturum bulunamadı.'
    ]);
}

$userId = (int) $userId;

// ========================================================
// NOT:
// Bu endpoint temel olarak "durum sorgulama" (GET polling)
// için kullanılıyor. Bunun yanında sistemsel küçük
// temizlik (expire olmuş yatırımları işaretleme) de yapıyor.
// ========================================================

// Session kilidini serbest bırak (polling endpoint'i)
session_write_close();

// 3) SÜRESİ GEÇMİŞ PENDING YATIRIMLARI GENEL OLARAK EXPIRE YAP
// Artık sadece bu kullanıcının değil, sistemdeki tüm user'ların
// expire_at < NOW() olan pending yatırımları 'expired' oluyor.
$expireSql = "
    UPDATE deposit_orders
    SET status = 'expired'
    WHERE status = 'pending'
      AND expire_at < NOW()
";
try {
    $pdo->exec($expireSql);
} catch (Throwable $e) {
    // Sessizce yutuyoruz; status sorgusunu bozmasın
    // error_log('get_user_status expireSql error: ' . $e->getMessage());
}

// 4) Kullanıcı cüzdan bakiyesi (sadece USDT)
$balStmtUsdt = $pdo->prepare("
    SELECT balance 
    FROM wallets 
    WHERE user_id = ? 
      AND coin_type = 'USDT' 
    LIMIT 1
");
$balStmtUsdt->execute([$userId]);
$usdtBalance = (float) ($balStmtUsdt->fetchColumn() ?? 0.0);

// 5) Aktif deposit var mı? (Sadece bu kullanıcıya bakıyoruz)
$depStmt = $pdo->prepare("
    SELECT *
    FROM deposit_orders
    WHERE user_id = ? 
      AND status = 'pending'
    LIMIT 1
");
$depStmt->execute([$userId]);
$activeDeposit = $depStmt->fetch(PDO::FETCH_ASSOC);

$activeDepositId  = 0;
$activeExpiryMs   = 0;

if ($activeDeposit) {
    $activeDepositId = (int) $activeDeposit['id'];
    if (!empty($activeDeposit['expire_at'])) {
        // JavaScript'e milisaniye cinsinden zamanı gönder
        $activeExpiryMs = strtotime($activeDeposit['expire_at']) * 1000;
    }
}

// 6) JSON cevabı
json_response(200, [
    'status' => 'success',
    'data'   => [
        'user_balance_usdt'             => $usdtBalance,
        'active_deposit_id'             => $activeDepositId,
        'active_deposit_expiry_time_ms' => $activeExpiryMs,
    ]
]);
