<?php
// src/controllers/wallet_bootstrap.php
// Eski akışta kullanılan bootstrap, artık controller + service mimarisi ile değiştirildi.
// Bu dosya geriye dönük uyumluluk için küçük bir yardımcı olarak tutuluyor.

require_once __DIR__ . '/WalletController.php';
require_once __DIR__ . '/../config/wallet.php';

function wallet_bootstrap_service(PDO $pdo): WalletService
{
    $config       = require __DIR__ . '/../config/wallet.php';
    $redirectBase = $_SERVER['PHP_SELF'] ?? '/wallet';

    return new WalletService($pdo, $config, $redirectBase);
}
