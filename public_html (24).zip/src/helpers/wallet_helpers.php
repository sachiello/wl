<?php

/**
 * Basit session ve flash yardımcıları.
 */
function wallet_require_session(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function wallet_set_flash(string $type, string $message): void
{
    wallet_require_session();
    $_SESSION["wallet_{$type}"] = $message;
}

function wallet_pop_flash(): array
{
    wallet_require_session();

    $error   = $_SESSION['wallet_error'] ?? null;
    $success = $_SESSION['wallet_success'] ?? null;

    unset($_SESSION['wallet_error'], $_SESSION['wallet_success']);

    return [
        'error'   => $error,
        'success' => $success,
    ];
}

// ---------------------------------------------------------------------
// HTTP yardımcıları
// ---------------------------------------------------------------------
if (!function_exists('http_get_json')) {
    function http_get_json(string $url): string
    {
        if (function_exists('curl_init')) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            $data = curl_exec($ch);
            curl_close($ch);
            return $data ?: '[]';
        }

        if (ini_get('allow_url_fopen')) {
            return file_get_contents($url) ?: '[]';
        }

        throw new Exception("API çağrısı için cURL veya allow_url_fopen gerekiyor.");
    }
}

// ---------------------------------------------------------------------
// IBAN seçici
// ---------------------------------------------------------------------
if (!function_exists('bw_find_best_iban')) {
    function bw_find_best_iban(PDO $pdo, float $amount, ?int $preferredIbanId = null): ?array
    {
        if ($amount <= 0) {
            return null;
        }

        $sql = "
            SELECT 
                i.*,
                COALESCE(
                    CASE WHEN a.role = 'agent' THEN a.system_balance END,
                    parent.system_balance
                ) AS agent_system_balance,
                COALESCE(
                    CASE WHEN a.role = 'agent' THEN a.current_cash END,
                    parent.current_cash
                ) AS agent_current_cash,
                a.id   AS iban_owner_id,
                a.name AS iban_owner_name,
                a.role AS iban_owner_role,
                parent.id   AS parent_agent_id,
                parent.name AS parent_agent_name
            FROM deposit_ibans i
            LEFT JOIN deposit_agents a 
                    ON i.agent_id = a.id
            LEFT JOIN deposit_agents parent
                    ON a.parent_id = parent.id
            WHERE 
                i.is_active = 1
                AND i.min_deposit_limit <= :amount 
                AND i.max_deposit_limit >= :amount 
                AND i.current_daily_txn < i.max_daily_txn
                AND (
                    i.agent_id IS NULL 
                    OR (
                        COALESCE(
                            CASE WHEN a.role = 'agent' THEN a.is_active END,
                            parent.is_active
                        ) = 1
                        AND COALESCE(
                            CASE WHEN a.role = 'agent' THEN a.system_balance END,
                            parent.system_balance
                        ) >= :amount
                    )
                )
                AND (
                    :iban_id IS NULL OR i.id = :iban_id
                )
            ORDER BY 
                (i.quota_limit - i.quota_used) DESC,
                RAND()
            LIMIT 1
        ";

        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':amount', $amount, PDO::PARAM_STR);
        $stmt->bindValue(':iban_id', $preferredIbanId ?: null, $preferredIbanId ? PDO::PARAM_INT : PDO::PARAM_NULL);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row ?: null;
    }
}

// ---------------------------------------------------------------------
// Telegram bildirim
// ---------------------------------------------------------------------
if (!function_exists('bw_send_telegram_alert')) {
    function bw_send_telegram_alert(string $message): void
    {
        $token   = "8578330928:AAHtvldJx_NRnZrE-qrqKa9asts6rplgUDM";
        $chat_id = "7054375811";

        if (empty($chat_id) || $chat_id === "BURAYA_CHAT_ID_GELECEK") {
            return;
        }

        $url  = "https://api.telegram.org/bot$token/sendMessage";
        $data = [
            'chat_id'    => $chat_id,
            'text'       => $message,
            'parse_mode' => 'HTML'
        ];

        $options = [
            'http' => [
                'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
                'method'  => 'POST',
                'content' => http_build_query($data),
                'timeout' => 2
            ]
        ];

        $context = stream_context_create($options);
        @file_get_contents($url, false, $context);
    }
}
