
<?php
// ajax_wallet_status.php – Cüzdan + yatırım durumu için hafif API
session_start();
require __DIR__ . '/../config/config.php';

header('Content-Type: application/json; charset=utf-8');

$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    echo json_encode(['ok' => false, 'error' => 'not_logged_in']);
    exit;
}

$depositHasIban  = bw_table_has_column($pdo, 'deposit_orders', 'iban_id');
$depositHasAgent = bw_table_has_column($pdo, 'deposit_orders', 'agent_id');

// Balans
$balances = ['trx' => 0.0, 'usdt' => 0.0];
$wq = $pdo->prepare("SELECT coin_type, balance FROM wallets WHERE user_id = ?");
$wq->execute([$userId]);
while ($row = $wq->fetch(PDO::FETCH_ASSOC)) {
    if ($row['coin_type'] === 'TRX')  $balances['trx']  = (float)$row['balance'];
    if ($row['coin_type'] === 'USDT') $balances['usdt'] = (float)$row['balance'];
}

$totalText = trim(
    ($balances['usdt'] > 0 ? number_format($balances['usdt'], 2) . ' USDT' : '') .
    ($balances['usdt'] > 0 && $balances['trx'] > 0 ? ' + ' : '') .
    ($balances['trx'] > 0 ? number_format($balances['trx'], 2) . ' TRX' : '')
);
if ($totalText === '') {
    $totalText = '0,00 (Henüz bakiyen yok)';
}

// Pending yatırım
$pending = null;
$pendingExpired = false;
$pendingSql = $depositHasIban
    ? "
        SELECT d.*, di.iban AS deposit_iban
        FROM deposit_orders d
        LEFT JOIN deposit_ibans di ON di.id = d.iban_id
        WHERE d.user_id = ? AND d.status = 'pending'
        ORDER BY d.id DESC
        LIMIT 1
      "
    : "
        SELECT *
        FROM deposit_orders
        WHERE user_id = ? AND status = 'pending'
        ORDER BY id DESC
        LIMIT 1
      ";

$pq = $pdo->prepare($pendingSql);
$pq->execute([$userId]);
$pRow = $pq->fetch(PDO::FETCH_ASSOC);

if ($pRow) {
    $now = new DateTimeImmutable('now');
    $exp = new DateTimeImmutable($pRow['expire_at']);

    if ($exp <= $now) {
        $up = $pdo->prepare("UPDATE deposit_orders SET status = 'expired' WHERE id = ? AND status = 'pending'");
        $up->execute([$pRow['id']]);
        $pendingExpired = true;
    } else {
        $pending = [
            'id'         => (int)$pRow['id'],
            'amount_try' => (float)$pRow['amount_try'],
            'coin_type'  => $pRow['coin_type'],
            'coin_amount'=> isset($pRow['coin_amount']) ? (float)$pRow['coin_amount'] : null,
            'expire_at'  => $pRow['expire_at'],
            'iban'       => $pRow['deposit_iban'] ?? null,
            'iban_id'    => $depositHasIban ? ($pRow['iban_id'] ?? null) : null,
            'agent_id'   => $depositHasAgent ? ($pRow['agent_id'] ?? null) : null,
        ];
    }
}

// Son confirmed yatırım
$confirmed = null;
$confirmedSql = $depositHasIban
    ? "
        SELECT d.*, di.iban AS deposit_iban
        FROM deposit_orders d
        LEFT JOIN deposit_ibans di ON di.id = d.iban_id
        WHERE d.user_id = ? AND d.status = 'confirmed'
        ORDER BY d.id DESC
        LIMIT 1
      "
    : "
        SELECT *
        FROM deposit_orders
        WHERE user_id = ? AND status = 'confirmed'
        ORDER BY id DESC
        LIMIT 1
      ";
$cq = $pdo->prepare($confirmedSql);
$cq->execute([$userId]);
$cRow = $cq->fetch(PDO::FETCH_ASSOC);

if ($cRow) {
    $confirmed = [
        'id'           => (int)$cRow['id'],
        'amount_try'   => (float)$cRow['amount_try'],
        'coin_type'    => $cRow['coin_type'],
        'coin_amount'  => isset($cRow['coin_amount']) ? (float)$cRow['coin_amount'] : null,
        'confirmed_at' => $cRow['confirmed_at'] ?? null,
        'iban'         => $cRow['deposit_iban'] ?? null,
    ];
}

// Yeni talep için güncel IBAN
$availableIban = bw_get_available_iban($pdo);
$availableIbanPayload = $availableIban ? [
    'id'        => (int)$availableIban['id'],
    'iban'      => $availableIban['iban'],
    'agent_id'  => $availableIban['agent_id'] ?? null,
    'agent_name'=> $availableIban['agent_name'] ?? null,
] : null;

echo json_encode([
    'ok'             => true,
    'balances'       => $balances,
    'total_text'     => $totalText,
    'pending'        => $pending,
    'pending_expired'=> $pendingExpired,
    'last_confirmed' => $confirmed,
    'available_iban' => $availableIbanPayload,
]);