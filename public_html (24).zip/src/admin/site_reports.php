<?php
// admin/site_reports.php
session_start();
require __DIR__ . '/../../config/config.php';

// Güvenlik
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

$pageTitle = 'Site Bazlı Raporlama';

// ===================== AYARLAR =====================
$SITE_DEPOSIT_COMMISSION_RATE   = 0.04; // Örn: %4
$SITE_WITHDRAW_COMMISSION_RATE  = 0.01; // Örn: %1

// Tarih aralığı filtresi
$range      = $_GET['range']   ?? '7d'; // today, yesterday, 7d, 30d, all
$siteFilter = isset($_GET['site_id']) ? (int)$_GET['site_id'] : 0;

$hasDateFilter = $range !== 'all';
$startDate     = null;
$endDate       = null;
$periodLabel   = 'Tüm Zamanlar';

if ($hasDateFilter) {
    $today = new DateTimeImmutable('today');
    switch ($range) {
        case 'today':
            $start = $today;
            $end   = $today;
            $periodLabel = 'Bugün';
            break;
        case 'yesterday':
            $start = $today->modify('-1 day');
            $end   = $today->modify('-1 day');
            $periodLabel = 'Dün';
            break;
        case '30d':
            $start = $today->modify('-29 days');
            $end   = $today;
            $periodLabel = 'Son 30 Gün';
            break;
        case '7d':
        default:
            $start = $today->modify('-6 days');
            $end   = $today;
            $periodLabel = 'Son 7 Gün';
            break;
    }
    $startDate = $start->format('Y-m-d 00:00:00');
    $endDate   = $end->format('Y-m-d 23:59:59');
} else {
    $startDate = null;
    $endDate   = null;
}

// Tüm siteleri dropdown için çek
$sitesStmt = $pdo->query("SELECT id, name FROM sites ORDER BY name ASC");
$allSites  = $sitesStmt->fetchAll(PDO::FETCH_ASSOC);

// Ana rapor sorgusu (site başı temel metrikler)
$sql = "
    SELECT 
        s.id,
        s.name,
        s.slug,
        s.logo_url,
        s.is_active,
        COALESCE(ds.total_deposit, 0)      AS total_deposit_try,
        COALESCE(ds.deposit_count, 0)      AS deposit_count,
        COALESCE(ds.unique_users, 0)       AS deposit_users,
        COALESCE(us.linked_users, 0)       AS linked_users,
        COALESCE(us.total_site_balance, 0) AS total_site_balance_try,
        COALESCE(sw.total_withdrawn, 0)    AS total_site_withdrawn
    FROM sites s
    LEFT JOIN (
        SELECT 
            site_id,
            SUM(amount_try)         AS total_deposit,
            COUNT(*)                AS deposit_count,
            COUNT(DISTINCT user_id) AS unique_users
        FROM deposit_orders
        WHERE status = 'confirmed'
          AND site_id IS NOT NULL
";

$params = [];
if ($hasDateFilter) {
    $sql .= " AND created_at BETWEEN :start_date AND :end_date";
    $params[':start_date'] = $startDate;
    $params[':end_date']   = $endDate;
}

$sql .= "
        GROUP BY site_id
    ) ds ON ds.site_id = s.id
    LEFT JOIN (
        SELECT 
            site_id,
            COUNT(*)              AS linked_users,
            SUM(site_balance_try) AS total_site_balance
        FROM user_sites
        GROUP BY site_id
    ) us ON us.site_id = s.id
    LEFT JOIN (
        SELECT 
            site_id,
            SUM(amount) AS total_withdrawn
        FROM site_withdrawals
        WHERE status = 'completed'
";

if ($hasDateFilter) {
    $sql .= " AND created_at BETWEEN :start_date2 AND :end_date2";
    $params[':start_date2'] = $startDate;
    $params[':end_date2']   = $endDate;
}

$sql .= "
        GROUP BY site_id
    ) sw ON sw.site_id = s.id
    WHERE 1=1
";

if ($siteFilter > 0) {
    $sql .= " AND s.id = :site_id";
    $params[':site_id'] = $siteFilter;
}

$sql .= "
    ORDER BY s.is_active DESC, s.name ASC
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Genel özetler
$totalDepositAll   = 0.0;
$totalWithdrawAll  = 0.0;
$totalLinkedUsers  = 0;
$totalCurrentBal   = 0.0;

foreach ($rows as $r) {
    $totalDepositAll   += (float)$r['total_deposit_try'];
    $totalWithdrawAll  += (float)$r['total_site_withdrawn'];
    $totalLinkedUsers  += (int)$r['linked_users'];
    $totalCurrentBal   += (float)$r['total_site_balance_try'];
}

// BetWallet kazançları (toplam)
$bwEarnDepositAll  = $totalDepositAll  * $SITE_DEPOSIT_COMMISSION_RATE;
$bwEarnWithdrawAll = $totalWithdrawAll * $SITE_WITHDRAW_COMMISSION_RATE;
$bwEarnTotalAll    = $bwEarnDepositAll + $bwEarnWithdrawAll;

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        /* TEMA DEĞİŞKENLERİ */
        :root { --primary: #c2273f; --primary-light: #fff1f2; --bg-body: #f1f5f9; --bg-card: #ffffff; --text-main: #1f2937; --text-muted: #6b7280; --border-color: #e5e7eb; --radius-md: 8px; }
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; }
        
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        .main-content { flex: 1; padding: 30px; overflow-y: auto; }
        
        .topbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
        .topbar h1 { font-size: 24px; font-weight: 800; margin: 0; color: var(--text-main); }
        .topbar p { margin: 5px 0 0; color: var(--text-muted); font-size: 14px; }
        
        /* FİLTRE BAR */
        .filter-bar { display: flex; gap: 10px; margin-bottom: 20px; overflow-x: auto; padding-bottom: 5px; }
        .filter-btn { 
            display: inline-flex; align-items: center; gap: 6px; padding: 10px 16px; 
            background: #fff; border: 1px solid var(--border-color); border-radius: 30px; 
            color: var(--text-muted); font-size: 13px; font-weight: 600; text-decoration: none; transition: all 0.2s; white-space: nowrap;
        }
        .filter-btn:hover { border-color: var(--primary); color: var(--primary); }
        .filter-btn.active { background: var(--primary); border-color: var(--primary); color: #fff; }

        /* SITE SEÇİM FORMU */
        .site-filter-card { background: var(--bg-card); padding: 15px 20px; border-radius: 12px; border: 1px solid var(--border-color); display: flex; align-items: center; gap: 15px; margin-bottom: 25px; }
        .form-select { padding: 8px 12px; border: 1px solid var(--border-color); border-radius: 6px; font-size: 14px; outline: none; min-width: 200px; }
        .btn-filter { background: var(--text-main); color: #fff; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 13px; font-weight: 600; }
        
        /* TABS */
        .tabs-nav { display: flex; gap: 5px; background: #e2e8f0; padding: 4px; border-radius: 10px; width: fit-content; margin-bottom: 25px; }
        .tab-btn { padding: 8px 20px; border: none; background: transparent; border-radius: 8px; font-size: 13px; font-weight: 600; color: var(--text-muted); cursor: pointer; transition: all 0.2s; }
        .tab-btn.active { background: #fff; color: var(--text-main); box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .tab-content { display: none; animation: fadeIn 0.3s; }
        .tab-content.active { display: block; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }

        /* KPI KARTLARI */
        .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .kpi-card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); padding: 20px; display: flex; flex-direction: column; }
        .kpi-label { font-size: 12px; font-weight: 600; color: var(--text-muted); text-transform: uppercase; margin-bottom: 8px; }
        .kpi-value { font-size: 24px; font-weight: 800; color: var(--text-main); }
        
        /* TABLO */
        .card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .custom-table { width: 100%; border-collapse: collapse; }
        .custom-table th { text-align: left; padding: 14px 20px; font-size: 12px; font-weight: 600; text-transform: uppercase; color: var(--text-muted); border-bottom: 1px solid var(--border-color); background: #f8fafc; }
        .custom-table td { padding: 14px 20px; border-bottom: 1px solid var(--border-color); font-size: 13px; color: var(--text-main); vertical-align: middle; }
        .custom-table tr:hover td { background-color: #f8fafc; }
        
        .badge { padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; }
        .badge-success { background: #ecfdf5; color: #065f46; }
        .badge-secondary { background: #f3f4f6; color: #4b5563; }
        
        .net-pos { color: #16a34a; font-weight: 700; }
        .net-neg { color: #dc2626; font-weight: 700; }
    </style>
</head>
<body>

<div class="app-wrapper">
    
    <?php include __DIR__ . '/_admin_header.php'; ?>

    <div class="main-content">
        
        <div class="topbar">
            <div>
                <h1>Site Raporları</h1>
                <p>Site bazlı performans ve finansal analiz.</p>
            </div>
            <div style="font-size: 13px; color: var(--text-muted); background: #fff; padding: 8px 16px; border-radius: 30px; border: 1px solid var(--border-color); font-weight: 500;">
                <i class="ri-calendar-event-line" style="vertical-align: text-bottom;"></i> 
                <?= htmlspecialchars($periodLabel) ?>
            </div>
        </div>

        <div class="filter-bar">
            <?php 
            $sQuery = $siteFilter > 0 ? '&site_id=' . $siteFilter : ''; 
            ?>
            <a href="?range=today<?= $sQuery ?>" class="filter-btn <?= $range=='today'?'active':'' ?>">Bugün</a>
            <a href="?range=yesterday<?= $sQuery ?>" class="filter-btn <?= $range=='yesterday'?'active':'' ?>">Dün</a>
            <a href="?range=7d<?= $sQuery ?>" class="filter-btn <?= $range=='7d'?'active':'' ?>">Son 7 Gün</a>
            <a href="?range=30d<?= $sQuery ?>" class="filter-btn <?= $range=='30d'?'active':'' ?>">Son 30 Gün</a>
            <a href="?range=all<?= $sQuery ?>" class="filter-btn <?= $range=='all'?'active':'' ?>">Tüm Zamanlar</a>
        </div>

        <div class="site-filter-card">
            <form method="get" style="display:flex; align-items:center; gap:10px; width:100%;">
                <input type="hidden" name="range" value="<?= htmlspecialchars($range) ?>">
                <i class="ri-building-2-line" style="color:var(--text-muted); font-size:20px;"></i>
                <select name="site_id" class="form-select">
                    <option value="0">Tüm Siteler</option>
                    <?php foreach ($allSites as $s): ?>
                        <option value="<?= (int)$s['id'] ?>" <?= $siteFilter === (int)$s['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($s['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn-filter">Uygula</button>
                <?php if($siteFilter > 0): ?>
                    <a href="?range=<?= $range ?>" style="font-size:13px; color:var(--primary); text-decoration:none; margin-left:10px;">Temizle</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="tabs-nav">
            <button class="tab-btn active" onclick="switchTab('classic', this)">
                <i class="ri-bar-chart-box-line"></i> Klasik Özet
            </button>
            <button class="tab-btn" onclick="switchTab('betwallet', this)">
                <i class="ri-money-dollar-circle-line"></i> BetWallet Finans
            </button>
        </div>

        <div id="classic" class="tab-content active">
            <div class="kpi-grid">
                <div class="kpi-card">
                    <div class="kpi-label">Toplam Yatırım</div>
                    <div class="kpi-value" style="color: #2563eb;"><?= number_format($totalDepositAll, 2) ?> ₺</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-label">Toplam Site Çekimi</div>
                    <div class="kpi-value"><?= number_format($totalWithdrawAll, 2) ?> ₺</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-label">Site İçi Bakiye</div>
                    <div class="kpi-value" style="color: #059669;"><?= number_format($totalCurrentBal, 2) ?> ₺</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-label">Bağlı Kullanıcı</div>
                    <div class="kpi-value"><?= number_format($totalLinkedUsers) ?></div>
                </div>
            </div>

            <div class="card">
                <table class="custom-table">
                    <thead>
                        <tr>
                            <th>Site</th>
                            <th>Durum</th>
                            <th>Yatırım</th>
                            <th>İşlem</th>
                            <th>Bakiye</th>
                            <th>Çekim</th>
                            <th>Net</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$rows): ?>
                            <tr><td colspan="7" style="text-align:center; padding:30px; color:var(--text-muted);">Kayıt bulunamadı.</td></tr>
                        <?php else: ?>
                            <?php foreach ($rows as $row): 
                                $net = (float)$row['total_deposit_try'] - (float)$row['total_site_withdrawn'];
                            ?>
                            <tr>
                                <td>
                                    <strong><?= htmlspecialchars($row['name']) ?></strong><br>
                                    <span style="font-size:11px; color:var(--text-muted);"><?= htmlspecialchars($row['slug']) ?></span>
                                </td>
                                <td>
                                    <?= (int)$row['is_active'] === 1 
                                        ? '<span class="badge badge-success">Aktif</span>' 
                                        : '<span class="badge badge-secondary">Pasif</span>' ?>
                                </td>
                                <td><?= number_format($row['total_deposit_try'], 2) ?> ₺</td>
                                <td>
                                    <?= (int)$row['deposit_count'] ?> <small style="color:#9ca3af;">(<?= (int)$row['deposit_users'] ?> üye)</small>
                                </td>
                                <td><?= number_format($row['total_site_balance_try'], 2) ?> ₺</td>
                                <td><?= number_format($row['total_site_withdrawn'], 2) ?> ₺</td>
                                <td class="<?= $net >= 0 ? 'net-pos' : 'net-neg' ?>">
                                    <?= number_format($net, 2) ?> ₺
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div id="betwallet" class="tab-content">
            <div class="kpi-grid">
                <div class="kpi-card">
                    <div class="kpi-label">Yönlendirilen Hacim</div>
                    <div class="kpi-value"><?= number_format($totalDepositAll, 2) ?> ₺</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-label">Yatırım Komisyonu</div>
                    <div class="kpi-value" style="color: #2563eb;"><?= number_format($bwEarnDepositAll, 2) ?> ₺</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-label">Çekim Komisyonu</div>
                    <div class="kpi-value" style="color: #2563eb;"><?= number_format($bwEarnWithdrawAll, 2) ?> ₺</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-label">Toplam Kazanç</div>
                    <div class="kpi-value" style="color: #16a34a;"><?= number_format($bwEarnTotalAll, 2) ?> ₺</div>
                </div>
            </div>

            <div class="card">
                <table class="custom-table">
                    <thead>
                        <tr>
                            <th>Site</th>
                            <th>Yatırım Hacmi</th>
                            <th>Site Çekimi</th>
                            <th>Yatırımdan Pay</th>
                            <th>Çekimden Pay</th>
                            <th>Toplam Kazanç</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$rows): ?>
                            <tr><td colspan="6" style="text-align:center; padding:30px; color:var(--text-muted);">Kayıt bulunamadı.</td></tr>
                        <?php else: ?>
                            <?php foreach ($rows as $row): 
                                $dep      = (float)$row['total_deposit_try'];
                                $wd       = (float)$row['total_site_withdrawn'];
                                $earnDep  = $dep * $SITE_DEPOSIT_COMMISSION_RATE;
                                $earnWd   = $wd  * $SITE_WITHDRAW_COMMISSION_RATE;
                                $earnSite = $earnDep + $earnWd;
                            ?>
                            <tr>
                                <td>
                                    <strong><?= htmlspecialchars($row['name']) ?></strong>
                                </td>
                                <td><?= number_format($dep, 2) ?> ₺</td>
                                <td><?= number_format($wd, 2) ?> ₺</td>
                                <td><?= number_format($earnDep, 2) ?> ₺</td>
                                <td><?= number_format($earnWd, 2) ?> ₺</td>
                                <td style="font-weight:700; color:#16a34a;">
                                    <?= number_format($earnSite, 2) ?> ₺
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<script>
function switchTab(tabId, btn) {
    // Tüm içerikleri gizle
    document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
    // Tüm buton aktifliklerini kaldır
    document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
    
    // Seçileni aç
    document.getElementById(tabId).classList.add('active');
    btn.classList.add('active');
}
</script>

<?php include __DIR__ . '/_admin_footer.php'; ?>
</body>
</html>