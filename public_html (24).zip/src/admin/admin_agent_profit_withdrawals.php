<?php
// admin/admin_agent_profit_withdrawals.php - Agent Kâr Çekim Taleplerini Yönetme
require __DIR__ . '/require_admin.php';

$pageTitle = 'Agent Kâr Çekim Talepleri';
$activeNav = 'agent_withdrawals';

$adminError   = null;
$adminSuccess = null;
$adminId      = (int)($currentAdmin['id'] ?? 0);

// =================================================================
// PRG: Yönlendirmeden gelen başarılı/hatalı mesajları al
// =================================================================
if (isset($_SESSION['admin_status'])) {
    if ($_SESSION['admin_status']['type'] === 'success') {
        $adminSuccess = $_SESSION['admin_status']['message'] ?? null;
    } elseif ($_SESSION['admin_status']['type'] === 'error') {
        $adminError = $_SESSION['admin_status']['message'] ?? null;
    }
    unset($_SESSION['admin_status']);
}

// =================================================================
// POST İŞLEMLERİ (ONAY/RED) – CSRF + PRG
// =================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 1) CSRF kontrolü
    if (!function_exists('validate_csrf_token')) {
        $_SESSION['admin_status'] = [
            'type'    => 'error',
            'message' => 'CSRF doğrulama fonksiyonu tanımsız. Güvenlik yapılandırmasını kontrol edin.'
        ];
        header('Location: admin_agent_profit_withdrawals.php');
        exit;
    }

    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $_SESSION['admin_status'] = [
            'type'    => 'error',
            'message' => 'Oturum doğrulaması başarısız. Lütfen sayfayı yenileyip tekrar deneyin.'
        ];
        header('Location: admin_agent_profit_withdrawals.php');
        exit;
    }

    $requestId = (int)($_POST['request_id'] ?? 0);
    $action    = $_POST['action'] ?? ''; // 'approve' veya 'reject'

    if ($requestId <= 0 || !in_array($action, ['approve', 'reject'], true)) {
        $_SESSION['admin_status'] = [
            'type'    => 'error',
            'message' => 'Geçersiz talep ID veya işlem tipi.'
        ];
        header('Location: admin_agent_profit_withdrawals.php');
        exit;
    }

    try {
        $pdo->beginTransaction();

        // 2) Talebi kilitle ve agent kâr bakiyesiyle birlikte çek
        $stmt = $pdo->prepare("
            SELECT r.*, a.agent_profit_balance
            FROM agent_profit_withdraw_requests r
            JOIN deposit_agents a ON a.id = r.agent_id
            WHERE r.id = ? AND r.status = 'pending'
            FOR UPDATE
        ");
        $stmt->execute([$requestId]);
        $request = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$request) {
            throw new Exception("Talep bulunamadı veya zaten işlenmiş.");
        }

        $agentId    = (int)$request['agent_id'];
        $amount     = (float)$request['amount'];      // Agent'ın istediği toplam (brüt)
        $netAmount  = (float)$request['net_amount'];  // Agent'a geçecek net
        $feeAmount  = (float)$request['fee_amount'];  // %1 fee
        $feeRate    = (float)$request['fee_rate'];    // oran bilgisi
        $curProfit  = (float)$request['agent_profit_balance'];

        if ($action === 'approve') {
            // NOT: Bu senaryoda kâr bakiyesi talep oluşturulurken zaten düşülmüş varsayımıyla hareket ediyoruz.
            // Bu yüzden burada tekrar düşmüyoruz, sadece "çekilen kâr" istatistiğini güncelliyoruz.

            // 2a) Agent toplam çekilen kâr istatistiğini artır
            $pdo->prepare("
                UPDATE deposit_agents
                SET total_profit_withdrawn = total_profit_withdrawn + :net_amount
                WHERE id = :agent_id
            ")->execute([
                ':net_amount' => $netAmount,
                ':agent_id'   => $agentId,
            ]);

            // 2b) Talebi paid yap
            $pdo->prepare("
                UPDATE agent_profit_withdraw_requests
                SET status = 'paid',
                    admin_id = ?,
                    processed_at = NOW()
                WHERE id = ?
            ")->execute([$adminId, $requestId]);

            // 2c) Log: çekim tamamlandı
            $pdo->prepare("
                INSERT INTO agent_profit_logs
                    (agent_id, type, amount, fee_amount, description, created_at)
                VALUES
                    (:agent_id, 'profit_withdraw', :amount, :fee, :description, NOW())
            ")->execute([
                ':agent_id'    => $agentId,
                ':amount'      => -$netAmount, // log için net çıkış
                ':fee'         => $feeAmount,
                ':description' => "Kâr çekim talebi onaylandı (Talep #{$requestId}, net: {$netAmount} TL, fee: {$feeAmount} TL)"
            ]);

            $_SESSION['admin_status'] = [
                'type'    => 'success',
                'message' => "Kâr çekim talebi onaylandı. Agent'a {$netAmount} TL (net) ödemiş sayıldın."
            ];

        } elseif ($action === 'reject') {
            // RED: Bekleme sürecinde kâr kasasından düşülmüş brüt tutarı iade et.
            // Bu senaryoda, talep oluşurken agent_profit_balance'dan 'amount' düşüldüğü kabul ediliyor.

            // 2a) Agent kâr bakiyesine iade
            $pdo->prepare("
                UPDATE deposit_agents
                SET agent_profit_balance = agent_profit_balance + :amount
                WHERE id = :agent_id
            ")->execute([
                ':amount'   => $amount,
                ':agent_id' => $agentId,
            ]);

            // 2b) Talebi rejected yap
            $pdo->prepare("
                UPDATE agent_profit_withdraw_requests
                SET status = 'rejected',
                    admin_id = ?,
                    processed_at = NOW()
                WHERE id = ? AND status = 'pending'
            ")->execute([$adminId, $requestId]);

            // 2c) Log: iade
            $pdo->prepare("
                INSERT INTO agent_profit_logs
                    (agent_id, type, amount, fee_amount, description, created_at)
                VALUES
                    (:agent_id, 'profit_withdraw_refund', :amount, 0, :description, NOW())
            ")->execute([
                ':agent_id'    => $agentId,
                ':amount'      => $amount, // iade edilen brüt
                ':description' => "Kâr çekim talebi reddedildi, brüt tutar iade edildi (Talep #{$requestId}, iade: {$amount} TL)"
            ]);

            $_SESSION['admin_status'] = [
                'type'    => 'success',
                'message' => "Kâr çekim talebi reddedildi. Agent'ın kâr bakiyesine {$amount} TL iade edildi."
            ];
        }

        $pdo->commit();

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $_SESSION['admin_status'] = [
            'type'    => 'error',
            'message' => 'İşlem hatası: ' . $e->getMessage()
        ];
    }

    // POST → REDIRECT
    header('Location: admin_agent_profit_withdrawals.php');
    exit;
}

// =================================================================
// VERİ ÇEKME (Tüm talepler, bekleyenler en üstte)
// =================================================================
$sql = "
    SELECT 
        r.*, 
        a.name AS agent_name, 
        a.agent_profit_balance AS agent_profit 
    FROM agent_profit_withdraw_requests r
    JOIN deposit_agents a ON a.id = r.agent_id
    ORDER BY r.status = 'pending' DESC, r.created_at DESC
";
$requests = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/_admin_header.php';
?>

<style>
/* ===========================
   BETWALLET ADMIN PAGE THEME
   =========================== */
.admin-page-root {
    --adm-bg: #f9fafb;
    --adm-surface: #ffffff;
    --adm-border: #e5e7eb;
    --adm-primary: #dc2626;
    --adm-primary-soft: rgba(220, 38, 38, 0.08);
    --adm-text-main: #111827;
    --adm-text-muted: #6b7280;
    --adm-success: #16a34a;
    --adm-danger: #b91c1c;
    --adm-warning: #eab308;
    --adm-radius: 14px;
    --adm-shadow-soft: 0 10px 24px rgba(15, 23, 42, 0.04);

    padding: 20px 24px 32px;
    color: var(--adm-text-main);
    background: var(--adm-bg);
}

@media (max-width: 768px) {
    .admin-page-root {
        padding: 16px;
    }
}

.admin-page-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 16px;
    margin-bottom: 18px;
    flex-wrap: wrap;
}

.admin-page-title h1 {
    margin: 0;
    font-size: 20px;
    font-weight: 800;
    color: var(--adm-text-main);
    display: flex;
    align-items: center;
    gap: 8px;
}

.admin-page-title p {
    margin: 6px 0 0;
    font-size: 13px;
    color: var(--adm-text-muted);
}

.admin-page-chip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 10px;
    border-radius: 999px;
    border: 1px solid var(--adm-border);
    background: #ffffff;
    font-size: 11px;
    color: var(--adm-text-muted);
    margin-top: 6px;
}
.admin-page-chip strong { color: var(--adm-primary); }

/* Alert kutuları (varsa global yoksa buradan) */
.alert-box {
    padding: 10px 12px;
    border-radius: 10px;
    font-size: 13px;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.alert-success {
    background: #dcfce7;
    border: 1px solid #bbf7d0;
    color: #166534;
}
.alert-danger {
    background: #fee2e2;
    border: 1px solid #fecaca;
    color: #b91c1c;
}

/* Kart + tablo */
.admin-card {
    background: var(--adm-surface);
    border-radius: var(--adm-radius);
    border: 1px solid var(--adm-border);
    padding: 14px 16px 16px;
    box-shadow: var(--adm-shadow-soft);
    margin-top: 4px;
}

.admin-card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
    margin-bottom: 10px;
}

.admin-card-header h2 {
    margin: 0;
    font-size: 16px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 6px;
    color: var(--adm-text-main);
}

.admin-card-header span.note {
    font-size: 11px;
    color: var(--adm-text-muted);
}

.table-container {
    margin-top: 4px;
    border-radius: 12px;
    overflow: hidden;
    border: 1px solid rgba(209, 213, 219, 0.9);
}

.admin-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 12px;
    background: #ffffff;
}

.admin-table thead {
    background: linear-gradient(
        135deg,
        rgba(248, 113, 113, 0.08),
        rgba(254, 242, 242, 0.95)
    );
}

.admin-table thead th {
    padding: 9px 10px;
    text-align: left;
    font-size: 11px;
    font-weight: 600;
    color: #7f1d1d;
    border-bottom: 1px solid rgba(248, 113, 113, 0.35);
    white-space: nowrap;
}

.admin-table tbody td {
    padding: 9px 10px;
    border-bottom: 1px solid #f3f4f6;
    vertical-align: top;
    color: var(--adm-text-main);
}

.admin-table tbody tr:last-child td {
    border-bottom: none;
}

.admin-table tbody tr:hover {
    background: #f9fafb;
}

.pending-row {
    background: #fffbeb;
    box-shadow: inset 3px 0 0 0 rgba(234, 179, 8, 0.9);
}

/* Status badges */
.badge-status {
    padding: 3px 8px;
    border-radius: 999px;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    border: 1px solid transparent;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.status-pending {
    background: #fef3c7;
    color: #92400e;
    border-color: #fde68a;
}
.status-paid {
    background: #dcfce7;
    color: #166534;
    border-color: #bbf7d0;
}
.status-rejected {
    background: #fee2e2;
    color: #b91c1c;
    border-color: #fecaca;
}

/* Butonlar */
.btn-sm {
    padding: 6px 10px;
    font-size: 11px;
    border-radius: 8px;
    border: none;
    font-weight: 600;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 4px;
}

.btn-approve {
    background: #16a34a;
    color: #ffffff;
}
.btn-approve:hover {
    background: #15803d;
}

.btn-reject {
    background: #fee2e2;
    color: #b91c1c;
}
.btn-reject:hover {
    background: #fecaca;
}

/* Pending sayacı chip */
.pending-counter-chip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 10px;
    border-radius: 999px;
    background: #fef3c7;
    border: 1px solid #fde68a;
    font-size: 11px;
    color: #92400e;
    font-weight: 600;
}
</style>

<div class="admin-page-root">

    <div class="admin-page-header">
        <div class="admin-page-title">
            <h1>
                <i class="ri-coins-line"></i> <?= htmlspecialchars($pageTitle) ?>
            </h1>
            <p>Agent kâr cüzdanından yapılan çekim taleplerini, net ödemeleri ve %1 komisyon gelirlerini buradan yönetirsin.</p>
            <div class="admin-page-chip">
                <i class="ri-information-line"></i>
                <span>
                    Model: <strong>Agent kârı, yatırımdan kazanılır</strong>. Kâr çekiminde %1 fee BetWallet’a kalır.
                    Talep reddedilirse, bekleyen brüt tutar agent kâr cüzdanına iade edilir.
                </span>
            </div>
        </div>

        <?php
        $pendingCount = count(array_filter($requests, fn($r) => $r['status'] === 'pending'));
        ?>
        <div>
            <div class="pending-counter-chip">
                <i class="ri-time-line"></i>
                <span><?= (int)$pendingCount ?> bekleyen talep</span>
            </div>
        </div>
    </div>

    <?php if ($adminError): ?>
        <div class="alert-box alert-danger">
            <i class="ri-error-warning-line"></i>
            <?= htmlspecialchars($adminError) ?>
        </div>
    <?php endif; ?>

    <?php if ($adminSuccess): ?>
        <div class="alert-box alert-success">
            <i class="ri-checkbox-circle-line"></i>
            <?= htmlspecialchars($adminSuccess) ?>
        </div>
    <?php endif; ?>

    <div class="admin-card">
        <div class="admin-card-header">
            <h2><i class="ri-list-check-3"></i> Kâr Çekim Talep Listesi</h2>
            <span class="note">
                Brüt = Agent’ın talep ettiği tutar, Net = Agent’a geçen, Fee = BetWallet’a kalan %1 komisyon.
                Reddedilen taleplerde brüt tutar kâr cüzdanına geri yüklenir.
            </span>
        </div>

        <div class="table-container">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID / Agent</th>
                        <th>Adres / Bilgi</th>
                        <th>Toplam (Brüt)</th>
                        <th>Kesinti / Net</th>
                        <th>Agent Kâr (Mevcut)</th>
                        <th>Durum</th>
                        <th style="text-align:right;">İşlem</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!empty($requests)): ?>
                    <?php foreach ($requests as $req): 
                        $status = $req['status'];
                        $statusClass = 'status-pending';
                        if ($status === 'paid') {
                            $statusClass = 'status-paid';
                        } elseif ($status === 'rejected') {
                            $statusClass = 'status-rejected';
                        }

                        $amount    = (float)$req['amount'];
                        $netAmount = (float)$req['net_amount'];
                        $feeAmount = (float)$req['fee_amount'];
                        $feeRate   = (float)$req['fee_rate'];
                    ?>
                    <tr class="<?= $status === 'pending' ? 'pending-row' : '' ?>">
                        <td>
                            <div style="font-weight:700; color:var(--adm-text-main);">
                                #<?= (int)$req['id'] ?>
                            </div>
                            <div style="color:var(--adm-primary); font-weight:600; font-size:13px;">
                                <?= htmlspecialchars($req['agent_name']) ?>
                            </div>
                            <div style="font-size:11px; color:var(--adm-text-muted);">
                                Talep: <?= date('d.m.Y H:i', strtotime($req['created_at'])) ?>
                            </div>
                        </td>

                        <td>
                            <div style="font-family:monospace; font-size:13px; color:var(--adm-text-main);">
                                <?= htmlspecialchars($req['trc20_address']) ?>
                            </div>
                            <div style="font-size:11px; color:var(--adm-text-muted);">
                                Ağ: TRC20 / Coin: USDT
                            </div>
                        </td>

                        <td>
                            <div style="font-weight:700; color:var(--adm-text-main);">
                                <?= number_format($amount, 2, ',', '.') ?> ₺
                            </div>
                        </td>

                        <td>
                            <div style="font-weight:700; color:var(--adm-success);">
                                <?= number_format($netAmount, 2, ',', '.') ?> ₺ NET
                            </div>
                            <div style="font-size:11px; color:var(--adm-danger);">
                                Kesinti: <?= number_format($feeAmount, 2, ',', '.') ?> ₺ (%<?= number_format($feeRate, 2, ',', '.') ?>)
                            </div>
                        </td>

                        <td>
                            <div style="font-weight:700; color:var(--adm-success);">
                                <?= number_format($req['agent_profit'] ?? 0, 2, ',', '.') ?> ₺
                            </div>
                            <div style="font-size:11px; color:var(--adm-text-muted);">
                                Güncel kâr cüzdanı
                            </div>
                        </td>

                        <td>
                            <span class="badge-status <?= $statusClass ?>">
                                <?= strtoupper(htmlspecialchars($status)) ?>
                            </span>
                        </td>

                        <td style="text-align:right;">
                            <?php if ($status === 'pending'): ?>
                                <form method="post" style="display:inline-block; margin-right:4px;">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="request_id" value="<?= (int)$req['id'] ?>">
                                    <button type="submit"
                                            name="action"
                                            value="approve"
                                            class="btn-sm btn-approve"
                                            onclick="return confirm('Agent: <?= htmlspecialchars($req['agent_name']) ?>\nNet Ödenecek: <?= number_format($netAmount, 2, ',', '.') ?> ₺\n\nGerçek ödemeyi yaptıysan ONAYLA.');">
                                        Ödeme Yapıldı / Onayla
                                    </button>
                                </form>
                                <form method="post" style="display:inline-block;">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="request_id" value="<?= (int)$req['id'] ?>">
                                    <button type="submit"
                                            name="action"
                                            value="reject"
                                            class="btn-sm btn-reject"
                                            onclick="return confirm('Talebi reddedeceksin.\nBrüt tutar (<?= number_format($amount, 2, ',', '.') ?> ₺) agent kâr cüzdanına İADE EDİLECEK.\nOnaylıyor musun?');">
                                        Reddet / İade Et
                                    </button>
                                </form>
                            <?php else: ?>
                                <span style="font-size:11px; color:var(--adm-text-muted);">
                                    İşlendi
                                </span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" style="padding:32px; text-align:center; color:var(--adm-text-muted);">
                            Henüz kâr çekim talebi yok.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php include __DIR__ . '/_admin_footer.php'; ?>
