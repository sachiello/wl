<?php
// admin/admin_merchant_withdraws.php
session_start();
require __DIR__ . '/../../config/config.php';

// 1. YETKİ KONTROLÜ
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

// CSRF Fonksiyonu
if (!function_exists('csrf_field')) {
    function csrf_field() {
        if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        return '<input type="hidden" name="csrf_token" value="' . $_SESSION['csrf_token'] . '">';
    }
}

$msg = []; 

// -------------------------------------------------------------------
// 2. İŞLEM HANDLER (ONAY / RED)
// -------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("Güvenlik Hatası: Token Geçersiz.");
    }

    $reqId  = (int)$_POST['request_id'];
    $action = $_POST['action'];
    $adminId = $_SESSION['admin_id'];

    // Talebi Çek
    $stmt = $pdo->prepare("SELECT * FROM merchant_player_withdraws WHERE id = ?");
    $stmt->execute([$reqId]);
    $req = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($req && $req['status'] === 'pending') {
        
        // --- ONAY İŞLEMİ ---
        if ($action === 'approve') {
            try {
                $pdo->beginTransaction();

                // A. Kur Bilgisi
                $rateStmt = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'usdt_try_rate'");
                $rate = (float)$rateStmt->fetchColumn();
                if ($rate <= 0) throw new Exception("Sistemde USDT kuru tanımlı değil!");

                // B. Hesaplamalar (Komisyon Siteden Kesilir)
                $amountRequested = (float)$req['amount']; // Kullanıcıya gidecek net TL değeri
                $commissionRate  = 0.01; // %1
                $commissionFee   = $amountRequested * $commissionRate; 
                $totalSiteDeduction = $amountRequested + $commissionFee; // Siteden düşecek TOPLAM tutar

                $coinAmount = $amountRequested / $rate; // Kullanıcıya gidecek USDT

                // C. Site Bakiyesi Kontrolü
                $siteCheck = $pdo->prepare("SELECT net_balance FROM sites WHERE id = ?");
                $siteCheck->execute([$req['site_id']]);
                $siteBal = (float)$siteCheck->fetchColumn();

                if ($siteBal < $totalSiteDeduction) {
                    throw new Exception("Sitenin bakiyesi yetersiz! (Gerekli: " . number_format($totalSiteDeduction, 2) . " TL, Mevcut: " . number_format($siteBal, 2) . " TL)");
                }

                // D. Siteden Düş
                $updSite = $pdo->prepare("UPDATE sites SET net_balance = net_balance - ? WHERE id = ?");
                if (!$updSite->execute([$totalSiteDeduction, $req['site_id']])) {
                    throw new Exception("Site bakiyesi güncellenemedi.");
                }

                // E. Kullanıcıya Ekle
                // Cüzdan var mı?
                $walletCheck = $pdo->prepare("SELECT id FROM wallets WHERE user_id = ? AND coin_type = 'USDT'");
                $walletCheck->execute([$req['user_id']]);
                $walletId = $walletCheck->fetchColumn();

                if (!$walletId) {
                    $pdo->prepare("INSERT INTO wallets (user_id, coin_type, balance) VALUES (?, 'USDT', ?)")
                        ->execute([$req['user_id'], $coinAmount]);
                } else {
                    $pdo->prepare("UPDATE wallets SET balance = balance + ? WHERE id = ?")
                        ->execute([$coinAmount, $walletId]);
                }

                // F. Kaydı Güncelle
                $logNote = "Onaylandı. Site: -" . number_format($totalSiteDeduction, 2) . " TL (%1 Komisyon Dahil). Kullanıcı: +" . number_format($coinAmount, 2) . " USDT";
                
                $updReq = $pdo->prepare("UPDATE merchant_player_withdraws SET status = 'approved', coin_amount = ?, processed_at = NOW(), admin_note = ? WHERE id = ?");
                $updReq->execute([$coinAmount, $logNote, $reqId]);

                $pdo->commit();
                $msg = ['type' => 'success', 'text' => 'İşlem başarılı! Site bakiyesinden %1 komisyonlu tutar düşüldü, kullanıcıya net tutar eklendi.'];

            } catch (Exception $e) {
                $pdo->rollBack();
                $msg = ['type' => 'error', 'text' => 'Hata: ' . $e->getMessage()];
            }
        } 
        
        // --- RED İŞLEMİ ---
        elseif ($action === 'reject') {
            $upd = $pdo->prepare("UPDATE merchant_player_withdraws SET status = 'rejected', processed_at = NOW() WHERE id = ?");
            $upd->execute([$reqId]);
            $msg = ['type' => 'warning', 'text' => 'Talep reddedildi. Site bakiyesine dokunulmadı.'];
        }
    }
}

// 3. VERİ ÇEKME VE FİLTRELEME
$filterStatus = $_GET['status'] ?? 'all';
$search = $_GET['search'] ?? '';

// Site bakiyesini de çekiyoruz ki tabloda "Yetersiz Bakiye" uyarısı verebilelim
$sql = "
    SELECT 
      w.*, 
      s.name as site_name, 
      s.net_balance as current_site_balance,
      u.username as bw_username,
      u.id as bw_user_id
    FROM merchant_player_withdraws w
    LEFT JOIN sites s ON w.site_id = s.id
    LEFT JOIN users u ON w.user_id = u.id
    WHERE 1=1
";

$params = [];

if ($filterStatus !== 'all') {
    $sql .= " AND w.status = ?";
    $params[] = $filterStatus;
}

if ($search) {
    $sql .= " AND (u.username LIKE ? OR w.order_id LIKE ? OR s.name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$sql .= " ORDER BY w.created_at DESC LIMIT 100";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Site -> Cüzdan Transferleri';
include __DIR__ . '/_admin_header.php';
?>

<style>
    .toolbar-container { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; gap: 15px; flex-wrap: wrap; }
    .modern-tabs { display: inline-flex; background: #fff; padding: 5px; border-radius: var(--radius-md); box-shadow: var(--shadow-soft); border: 1px solid var(--border-light); gap: 5px; }
    .tab-btn { padding: 8px 16px; border-radius: var(--radius-sm); color: var(--text-muted); font-size: 13px; font-weight: 600; display: flex; align-items: center; gap: 6px; cursor: pointer; border: none; background: transparent; text-decoration: none; transition: all 0.2s; }
    .tab-btn:hover { background: #f1f5f9; color: var(--primary); }
    .tab-btn.is-active { background: var(--primary); color: #fff; box-shadow: 0 4px 10px rgba(59, 130, 246, 0.3); }
    
    .toolbar-actions { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    .search-wrapper { position: relative; }
    .search-wrapper i { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--text-muted); font-size: 16px; }
    .search-input { padding: 10px 10px 10px 36px; border-radius: var(--radius-md); border: 1px solid var(--border-light); background: #fff; font-size: 13px; width: 200px; color: var(--text-main); outline: none; box-shadow: var(--shadow-soft); }
    
    .badge-method { padding: 4px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; text-transform: uppercase; display: inline-flex; align-items: center; gap: 4px; }
    .badge-site { background: #e0e7ff; color: #4338ca; border: 1px solid #c7d2fe; } 
    
    .action-group { display: flex; gap: 6px; justify-content: flex-end; }
    .btn-icon { width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; border-radius: 6px; border: none; cursor: pointer; transition: all 0.2s; }
    .btn-approve { background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; }
    .btn-approve:hover { background: #16a34a; color: #fff; transform: translateY(-2px); }
    .btn-reject { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
    .btn-reject:hover { background: #dc2626; color: #fff; transform: translateY(-2px); }

    .alert-box { padding: 15px; border-radius: 8px; margin-bottom: 20px; font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 10px; animation: slideDown 0.3s ease-out; }
    .alert-success { background: #f0fdf4; color: #15803d; border: 1px solid #bbf7d0; }
    .alert-error { background: #fef2f2; color: #b91c1c; border: 1px solid #fecaca; }
    .alert-warning { background: #fffbeb; color: #b45309; border: 1px solid #fcd34d; }
    @keyframes slideDown { from { opacity:0; transform:translateY(-10px); } to { opacity:1; transform:translateY(0); } }

    /* Bakiye Uyarısı */
    .bal-warning { font-size: 10px; color: #dc2626; background: #fef2f2; padding: 2px 6px; border-radius: 4px; border: 1px solid #fecaca; margin-top: 3px; display: inline-block; font-weight: 600; }
    .bal-ok { font-size: 10px; color: #16a34a; background: #f0fdf4; padding: 2px 6px; border-radius: 4px; border: 1px solid #bbf7d0; margin-top: 3px; display: inline-block; font-weight: 600; }
</style>

<div class="page-content">

    <?php if ($msg): ?>
        <div class="alert-box alert-<?= $msg['type'] ?>">
            <i class="ri-<?= $msg['type'] == 'success' ? 'checkbox-circle' : 'error-warning' ?>-fill" style="font-size:18px;"></i>
            <?= htmlspecialchars($msg['text']) ?>
        </div>
    <?php endif; ?>

    <div class="toolbar-container">
        <div class="modern-tabs">
            <a href="?status=all" class="tab-btn <?= $filterStatus == 'all' ? 'is-active' : '' ?>">
                <i class="ri-apps-line"></i> Tümü
            </a>
            <a href="?status=pending" class="tab-btn <?= $filterStatus == 'pending' ? 'is-active' : '' ?>">
                <i class="ri-time-line"></i> Bekleyenler
            </a>
            <a href="?status=approved" class="tab-btn <?= $filterStatus == 'approved' ? 'is-active' : '' ?>">
                <i class="ri-check-double-line"></i> Onaylananlar
            </a>
            <a href="?status=rejected" class="tab-btn <?= $filterStatus == 'rejected' ? 'is-active' : '' ?>">
                <i class="ri-close-line"></i> Reddedilenler
            </a>
        </div>

        <div class="toolbar-actions">
            <form method="get" style="display:flex; align-items:center;">
                <div class="search-wrapper">
                    <i class="ri-search-line"></i>
                    <input type="text" name="search" class="search-input" placeholder="Kullanıcı, Sipariş No..." value="<?= htmlspecialchars($search) ?>">
                </div>
            </form>
        </div>
    </div>

    <div class="table-container">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Kaynak Site / Bakiye</th>
                    <th>BW Kullanıcı</th>
                    <th>İstenen Tutar</th>
                    <th>Cüzdan Karşılığı</th>
                    <th>Sipariş Kodu</th>
                    <th>Tarih</th>
                    <th>Durum</th>
                    <th style="text-align: right;">İşlem</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $r): 
                    // Durumlar
                    $st = $r['status'];
                    $stClass = 'pending'; $stLabel = 'Bekliyor'; $stIcon = 'ri-time-line';
                    if($st=='approved') { $stClass='success'; $stLabel='Onaylandı'; $stIcon='ri-check-double-line'; }
                    if($st=='rejected') { $stClass='danger';  $stLabel='Reddedildi'; $stIcon='ri-close-line'; }

                    // Bakiye Kontrolü (Canlı)
                    $needed = $r['amount'] * 1.01; // %1 komisyon dahil
                    $siteHasBalance = ($r['current_site_balance'] >= $needed);
                ?>
                <tr>
                    <td><span style="font-family: monospace; color: var(--text-muted);">#<?= $r['id'] ?></span></td>
                    <td>
                        <div style="font-weight:600; display:flex; align-items:center; gap:5px;">
                            <i class="ri-global-line" style="color:var(--primary)"></i> <?= htmlspecialchars($r['site_name']) ?>
                        </div>
                        <!-- Site Bakiye Durumu Uyarısı -->
                        <?php if ($st === 'pending'): ?>
                            <?php if ($siteHasBalance): ?>
                                <span class="bal-ok"><i class="ri-check-line"></i> Bakiye Uygun</span>
                            <?php else: ?>
                                <span class="bal-warning" title="Sitenin bakiyesi: <?= $r['current_site_balance'] ?> TL">
                                    <i class="ri-alert-line"></i> Bakiye Yetersiz
                                </span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div style="font-weight: 600; color: var(--text-main);">
                            <?= htmlspecialchars($r['bw_username']) ?>
                        </div>
                        <div style="font-size:11px; color:var(--text-muted);">ID: <?= $r['user_id'] ?></div>
                    </td>
                    <td>
                        <div style="font-weight: 700; color: var(--text-main);">
                            <?= number_format($r['amount'], 2) ?> <small>TL</small>
                        </div>
                        <div style="font-size:10px; color:var(--text-muted);">+ %1 Komisyon</div>
                    </td>
                    <td>
                        <?php if($r['coin_amount'] > 0): ?>
                            <div style="font-family:monospace; font-weight:600; color:#10b981;">
                                +<?= number_format($r['coin_amount'], 2) ?> USDT
                            </div>
                        <?php else: ?>
                            <span style="color:#94a3b8; font-size:12px;">Hesaplanacak</span>
                        <?php endif; ?>
                    </td>
                    <td style="font-size: 12px; font-family: monospace; color: var(--text-muted);">
                        <?= htmlspecialchars($r['order_id']) ?>
                    </td>
                    <td style="font-size: 12px; color: var(--text-muted);">
                        <?= date('d.m H:i', strtotime($r['created_at'])) ?>
                    </td>
                    <td>
                        <span class="badge <?= $stClass ?>">
                            <i class="<?= $stIcon ?>"></i> <?= $stLabel ?>
                        </span>
                    </td>
                    <td style="text-align: right;">
                        <?php if ($st === 'pending'): ?>
                            <div class="action-group">
                                
                                <?php if ($siteHasBalance): ?>
                                    <form method="post" onsubmit="return confirm('ONAYLIYOR MUSUNUZ?\n\nSite Bakiyesinden Düşülecek: <?= number_format($needed, 2) ?> TL\nKullanıcıya Gidecek: <?= number_format($r['amount'], 2) ?> TL Karşılığı USDT');">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                                        <input type="hidden" name="action" value="approve">
                                        <button type="submit" class="btn-icon btn-approve" title="Onayla">
                                            <i class="ri-check-line"></i>
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <!-- Bakiye yoksa onay butonu pasif -->
                                    <button type="button" class="btn-icon" style="background:#eee; color:#999; cursor:not-allowed;" title="Bakiye Yetersiz">
                                        <i class="ri-prohibited-line"></i>
                                    </button>
                                <?php endif; ?>
                                
                                <form method="post" onsubmit="return confirm('Bu talebi reddetmek istediğinize emin misiniz?');">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                                    <input type="hidden" name="action" value="reject">
                                    <button type="submit" class="btn-icon btn-reject" title="Reddet">
                                        <i class="ri-close-line"></i>
                                    </button>
                                </form>
                            </div>
                        <?php else: ?>
                            <i class="ri-checkbox-circle-fill" style="color: #cbd5e1; font-size: 20px;"></i>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>

                <?php if (empty($rows)): ?>
                    <tr>
                        <td colspan="9" style="text-align:center; padding: 40px; color: var(--text-muted);">
                            <i class="ri-inbox-line" style="font-size: 48px; display: block; margin-bottom: 10px; opacity: 0.5;"></i>
                            Kayıt bulunamadı.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/_admin_footer.php'; ?>