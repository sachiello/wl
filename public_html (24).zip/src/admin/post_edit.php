<?php
// admin/post_edit.php
// require_admin.php'deki yetki kontrolünü ve jeton oluşturmayı çalıştır
require 'require_admin.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // 1. 🚨 CSRF KONTROLÜ
    // POST verisinde csrf_token var mı?
    $token_from_request = $_POST['csrf_token'] ?? '';
    
    if (!validate_csrf_token($token_from_request)) {
        // Güvenlik İhlali!
        http_response_code(403);
        die('CSRF Güvenlik İhlali: Geçersiz Jeton!');
    }
    
    // 2. Veri İşleme (Sadece Jeton geçerliyse bu kısım çalışır)
    // ... Durum değiştiren işlemleri burada yap (INSERT, UPDATE, DELETE) ...
    
    // 3. Post/Redirect/Get (PRG) Kuralını Uygula
    // Kullanıcıya bir mesaj gösterip yeni bir sayfaya yönlendir
    header('Location: post_list.php?status=success'); 
    exit; 
}
// ... Sayfanın geri kalan HTML içeriği ...
?>