<?php
// admin/admin_support.php
session_start();
require __DIR__ . '/../../config/config.php';

// 1. GÜVENLİK
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

// Admin bilgisi
$stmtAdmin = $pdo->prepare("SELECT username FROM admins WHERE id = ?");
$stmtAdmin->execute([$_SESSION['admin_id']]);
$adminRow  = $stmtAdmin->fetch(PDO::FETCH_ASSOC);
$adminName = $adminRow['username'] ?? 'Admin';

// ---------------------------------------------------------------------
// 2. FİLTRELEME VE VERİ ÇEKME
// ---------------------------------------------------------------------
$statusFilter = $_GET['status'] ?? 'open'; // Varsayılan: Açık biletler

// SQL Sorgusu Hazırlığı
$sql = "
    SELECT 
        t.*, 
        u.username AS user_username,
        (SELECT COUNT(*) FROM support_messages WHERE ticket_id = t.id) as msg_count
    FROM support_tickets t
    JOIN users u ON t.user_id = u.id
";

$params = [];
if ($statusFilter !== 'all') {
    $sql .= " WHERE t.status = ?";
    $params[] = $statusFilter;
}

$sql .= " ORDER BY t.updated_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);

// İstatistikler
$stats = [
    'open'     => $pdo->query("SELECT COUNT(*) FROM support_tickets WHERE status = 'open'")->fetchColumn(),
    'answered' => $pdo->query("SELECT COUNT(*) FROM support_tickets WHERE status = 'answered'")->fetchColumn(),
    'closed'   => $pdo->query("SELECT COUNT(*) FROM support_tickets WHERE status = 'closed'")->fetchColumn(),
    'all'      => $pdo->query("SELECT COUNT(*) FROM support_tickets")->fetchColumn()
];

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Destek Merkezi - Yönetim</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        /* TEMA DEĞİŞKENLERİ */
        :root { --primary: #c2273f; --primary-light: #fff1f2; --bg-body: #f1f5f9; --bg-card: #ffffff; --text-main: #1f2937; --text-muted: #6b7280; --border-color: #e5e7eb; --radius-md: 8px; }
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; }
        
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        .main-content { flex: 1; padding: 30px; overflow-y: auto; }
        
        /* ÜST ALAN */
        .topbar { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 25px; }
        .topbar h1 { font-size: 24px; font-weight: 800; margin: 0; color: var(--text-main); }
        .topbar p { margin: 5px 0 0; color: var(--text-muted); font-size: 14px; }
        
        /* KART YAPISI */
        .card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); padding: 0; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); overflow: hidden; }
        .card-header { padding: 20px 24px; border-bottom: 1px solid var(--border-color); display: flex; align-items: center; justify-content: space-between; }
        .card-title { font-size: 16px; font-weight: 700; margin: 0; display: flex; align-items: center; gap: 8px; }

        /* TAB / FİLTRE BUTONLARI */
        .filter-bar { display: flex; gap: 10px; margin-bottom: 20px; overflow-x: auto; padding-bottom: 5px; }
        .filter-btn { 
            display: inline-flex; align-items: center; gap: 6px; padding: 10px 16px; 
            background: #fff; border: 1px solid var(--border-color); border-radius: 30px; 
            color: var(--text-muted); font-size: 13px; font-weight: 600; text-decoration: none; transition: all 0.2s; 
        }
        .filter-btn:hover { border-color: var(--primary); color: var(--primary); }
        .filter-btn.active { background: var(--primary); border-color: var(--primary); color: #fff; }
        .filter-btn .badge { 
            background: rgba(0,0,0,0.1); padding: 2px 8px; border-radius: 10px; font-size: 11px; 
        }
        .filter-btn.active .badge { background: rgba(255,255,255,0.2); color: #fff; }

        /* TABLO */
        .custom-table { width: 100%; border-collapse: collapse; }
        .custom-table th { text-align: left; padding: 15px 24px; font-size: 12px; font-weight: 600; text-transform: uppercase; color: var(--text-muted); border-bottom: 1px solid var(--border-color); background: #f8fafc; }
        .custom-table td { padding: 16px 24px; border-bottom: 1px solid var(--border-color); font-size: 14px; color: var(--text-main); vertical-align: middle; }
        .custom-table tr:last-child td { border-bottom: none; }
        .custom-table tr:hover { background-color: #f8fafc; }

        /* ETİKETLER */
        .status-badge { padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 600; text-transform: uppercase; display: inline-block; }
        .status-open { background: #fff7ed; color: #c2410c; border: 1px solid #fdba74; }
        .status-answered { background: #ecfdf5; color: #047857; border: 1px solid #6ee7b7; }
        .status-closed { background: #f3f4f6; color: #4b5563; border: 1px solid #d1d5db; }
        
        .user-pill { display: inline-flex; align-items: center; gap: 6px; font-weight: 500; font-size: 13px; background: #f1f5f9; padding: 4px 10px; border-radius: 6px; color: var(--text-main); }
        
        .btn-action { padding: 6px 12px; border: 1px solid var(--border-color); border-radius: 6px; background: #fff; color: var(--text-main); font-size: 12px; font-weight: 600; text-decoration: none; transition: all 0.2s; display: inline-flex; align-items: center; gap: 4px; }
        .btn-action:hover { border-color: var(--primary); color: var(--primary); background: var(--primary-light); }

        .empty-state { padding: 60px; text-align: center; color: var(--text-muted); }
        .empty-icon { font-size: 48px; margin-bottom: 10px; color: #cbd5e1; }
    </style>
</head>
<body>

<div class="app-wrapper">
    
    <?php include __DIR__ . '/_admin_header.php'; ?>

    <div class="main-content">
        
        <div class="topbar">
            <div>
                <h1>Destek Merkezi</h1>
                <p>Üyelerden gelen talepleri ve yanıtları yönetin.</p>
            </div>
            <div style="text-align: right;">
                 <span style="font-size: 13px; color: var(--text-muted); background: #fff; padding: 6px 12px; border: 1px solid var(--border-color); border-radius: 20px;">
                    Toplam Bilet: <strong><?= $stats['all'] ?></strong>
                 </span>
            </div>
        </div>

        <div class="filter-bar">
            <a href="?status=open" class="filter-btn <?= $statusFilter === 'open' ? 'active' : '' ?>">
                <i class="ri-mail-open-line"></i> Açık <span class="badge"><?= $stats['open'] ?></span>
            </a>
            <a href="?status=answered" class="filter-btn <?= $statusFilter === 'answered' ? 'active' : '' ?>">
                <i class="ri-chat-check-line"></i> Cevaplandı <span class="badge"><?= $stats['answered'] ?></span>
            </a>
            <a href="?status=closed" class="filter-btn <?= $statusFilter === 'closed' ? 'active' : '' ?>">
                <i class="ri-lock-2-line"></i> Kapalı <span class="badge"><?= $stats['closed'] ?></span>
            </a>
            <a href="?status=all" class="filter-btn <?= $statusFilter === 'all' ? 'active' : '' ?>">
                <i class="ri-archive-line"></i> Tümü <span class="badge"><?= $stats['all'] ?></span>
            </a>
        </div>

        <div class="card">
            <?php if (count($tickets) > 0): ?>
            <table class="custom-table">
                <thead>
                    <tr>
                        <th width="80">ID</th>
                        <th>Konu & Detay</th>
                        <th>Üye</th>
                        <th>Durum</th>
                        <th>Son İşlem</th>
                        <th style="text-align: right;">Yönet</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tickets as $ticket): ?>
                    <?php
                        $sClass = 'status-closed';
                        $sText = 'Kapalı';
                        if ($ticket['status'] == 'open') { $sClass = 'status-open'; $sText = 'Bekliyor'; }
                        if ($ticket['status'] == 'answered') { $sClass = 'status-answered'; $sText = 'Cevaplandı'; }
                    ?>
                    <tr>
                        <td><strong>#<?= $ticket['id'] ?></strong></td>
                        <td>
                            <a href="admin_ticket_detail.php?id=<?= $ticket['id'] ?>" style="font-weight: 600; color: var(--text-main); text-decoration: none; font-size: 14px; display: block; margin-bottom: 2px;">
                                <?= htmlspecialchars($ticket['subject']) ?>
                            </a>
                            <span style="font-size: 12px; color: var(--text-muted); display: inline-flex; align-items: center; gap: 4px;">
                                <i class="ri-message-2-line"></i> <?= $ticket['msg_count'] ?> mesaj
                            </span>
                        </td>
                        <td>
                            <span class="user-pill">
                                <i class="ri-user-3-line" style="font-size:12px;"></i> <?= htmlspecialchars($ticket['user_username']) ?>
                            </span>
                        </td>
                        <td>
                            <span class="status-badge <?= $sClass ?>"><?= $sText ?></span>
                        </td>
                        <td style="color: var(--text-muted); font-size: 13px;">
                            <?= date('d.m.Y H:i', strtotime($ticket['updated_at'])) ?>
                        </td>
                        <td style="text-align: right;">
                            <a href="admin_ticket_detail.php?id=<?= $ticket['id'] ?>" class="btn-action">
                                İncele <i class="ri-arrow-right-s-line"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
                <div class="empty-state">
                    <i class="ri-inbox-line empty-icon"></i>
                    <p>Bu filtrede görüntülenecek bilet bulunamadı.</p>
                </div>
            <?php endif; ?>
        </div>

    </div>
</div>

</body>
</html>