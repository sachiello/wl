<?php
// src/admin/require_admin.php

// 1) CONFIG
require_once __DIR__ . '/../../config/config.php';

// 2) SESSION (config.php CSRF helper'ları da session_start kullanıyor ama güvenli)
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// 3) ADMIN LOGIN KONTROLÜ
if (empty($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

// 4) GÜNCEL ADMIN BİLGİSİ
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ? LIMIT 1");
$stmt->execute([$_SESSION['admin_id']]);
$currentAdmin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$currentAdmin) {
    session_destroy();
    header('Location: admin_login.php');
    exit;
}
