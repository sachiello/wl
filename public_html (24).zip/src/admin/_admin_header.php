<?php
// _admin_header.php
// GEREKLİ BAĞIMLILIKLARIN (DB connection vb.) YÜKLENDİĞİ VARSAYILIR.

// 2FA Kontrolü
$twofa_exempt_pages = ['admin_2fa_setup.php', 'admin_2fa_verify.php'];
$currentFile = basename($_SERVER['PHP_SELF']);
if (!in_array($currentFile, $twofa_exempt_pages)) {
    if (!empty($currentAdmin['twofa_enabled']) && empty($_SESSION['admin_2fa_pass'])) {
        header("Location: admin_2fa_verify.php");
        exit;
    }
}

// Varsayılan Değişkenler
$pageTitle   = $pageTitle   ?? 'Admin Panel';
$activeNav   = $activeNav   ?? '';
$displayName = isset($me['name']) ? $me['name'] : 'Admin User';

// ================= SAYAÇ HESAPLAMALARI (ACTION CENTER İÇİN) =================
if (isset($pdo)) {
    $counts = [];
    try {
        // Kullanıcı
        $counts['deposits']           = (int)$pdo->query("SELECT COUNT(*) FROM deposit_orders        WHERE status = 'pending'")->fetchColumn();
        $counts['user_withdrawals']   = (int)$pdo->query("SELECT COUNT(*) FROM agent_withdraw_orders WHERE status = 'pending'")->fetchColumn();
        // YENİ: Kasa üstü çekimler (overflow)
        $counts['overflow_withdrawals'] = (int)$pdo->query("SELECT COUNT(*) FROM agent_withdraw_overflow WHERE status = 'waiting'")->fetchColumn();
        
        // Site
        $counts['site_withdrawals']     = (int)$pdo->query("SELECT COUNT(*) FROM site_withdrawals       WHERE status = 'pending'")->fetchColumn();
        $counts['site_balance_requests']= (int)$pdo->query("SELECT COUNT(*) FROM site_balance_requests  WHERE status = 'pending'")->fetchColumn();
        $counts['site_deposit_requests']= (int)$pdo->query("SELECT COUNT(*) FROM site_deposit_requests  WHERE status = 'pending'")->fetchColumn();
        
        // Agent
        $counts['agent_requests']    = (int)$pdo->query("SELECT COUNT(*) FROM agent_balance_requests WHERE status = 'pending'")->fetchColumn();
        $counts['agent_withdrawals'] = (int)$pdo->query("SELECT COUNT(*) FROM agent_withdraw_orders  WHERE status = 'pending'")->fetchColumn();

    } catch (Throwable $e) {
        $counts = [];
    }

    // Tekil Badge Helper
    $badge = function (string $key) use (&$counts) {
        $val     = $counts[$key] ?? 0;
        $display = ($val > 0) ? 'inline-flex' : 'none';
        return '<span class="nav-badge" id="badge_' . $key . '" style="display:' . $display . ';">' . (int)$val . '</span>';
    };

    // Bölüm Toplamı Badge Helper (Action Center için kritik)
    $totalActionCount  = array_sum($counts);
    $actionCenterBadge = ($totalActionCount > 0) 
        ? '<span class="nav-badge nav-badge-section">' . $totalActionCount . '</span>' 
        : '';
        
} else {
    $badge            = fn($key) => '';
    $actionCenterBadge = '';
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?></title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Orbitron:wght@400;600;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link rel="stylesheet" href="../../public/assets/admin.css">

    <style>
        :root {
            --primary: #c2273f; 
            --primary-dark: #9f1239;
            --bg-sidebar: #1e1e24;
            --bg-body: #f3f4f6;
            --text-main: #1f2937;
            --text-muted: #6b7280;
            --border-color: rgba(255,255,255,0.08);
        }

        body.dark-mode {
            --bg-sidebar: #111827;
            --bg-body: #0f0f13;
            --text-main: #e5e7eb;
            --text-muted: #9ca3af;
        }

        /* Sidebar Base */
        .admin-sidebar {
            background: var(--bg-sidebar);
            border-right: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
            width: 280px;
            height: 100vh;
            position: fixed;
            top: 0; left: 0;
            z-index: 1000;
            transition: all 0.3s ease;
            color: #fff;
        }

        /* Header */
        .sidebar-header { padding: 25px 20px 20px 20px; }
        .brand-wrapper { display: flex; align-items: center; gap: 12px; text-decoration: none; }
        .brand-icon {
            width: 42px; height: 42px;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            color: #fff; font-size: 22px;
            box-shadow: 0 4px 15px rgba(194, 39, 63, 0.4);
        }
        .brand-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 18px;
            font-weight: 800;
            color: #fff;
            letter-spacing: 1px;
        }
        .brand-subtitle {
            font-size: 11px;
            color: rgba(255,255,255,0.5);
            font-weight: 600;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }

        /* Nav */
        .admin-nav { flex: 1; padding: 10px 16px; overflow-y: auto; }

        /* Categories */
        .nav-category-toggle {
            width: 100%;
            border: none;
            background: transparent;
            color: rgba(255,255,255,0.7);
            font-family: 'Inter', sans-serif;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 15px 12px 8px 12px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            cursor: pointer;
            transition: 0.2s;
            margin-top: 5px;
        }
        .nav-category-toggle:hover { color: #fff; }
        .nav-category-title {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .nav-category-arrow {
            transition: transform 0.2s ease;
            font-size: 14px;
            opacity: 0.5;
        }
        .nav-section:not(.collapsed) .nav-category-arrow {
            transform: rotate(180deg);
        }
        
        /* Accordion Body */
        .nav-section.collapsed .nav-section-body {
            max-height: 0;
            opacity: 0;
            pointer-events: none;
        }
        .nav-section-body {
            overflow: hidden;
            transition: max-height 0.3s ease, opacity 0.3s ease;
            max-height: 600px;
            opacity: 1;
            padding-bottom: 5px;
        }

        /* Links */
        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 11px 14px;
            color: rgba(255,255,255,0.6);
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            border-radius: 10px;
            transition: all 0.2s ease;
            margin-bottom: 2px;
            position: relative;
        }
        .sidebar-link i {
            font-size: 18px;
            opacity: 0.8;
            transition: all 0.2s;
        }
        .sidebar-link:hover {
            background: rgba(255,255,255,0.05);
            color: #fff;
            transform: translateX(3px);
        }
        .sidebar-link.is-active {
            background: rgba(194, 39, 63, 0.15);
            color: var(--primary);
            font-weight: 700;
        }
        .sidebar-link.is-active i {
            color: var(--primary);
            opacity: 1;
        }

        /* Badges */
        .nav-badge {
            background: var(--primary);
            color: #fff;
            font-size: 10px;
            font-weight: 800;
            min-width: 18px;
            height: 18px;
            padding: 0 5px;
            border-radius: 9px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-left: auto;
            box-shadow: 0 0 8px rgba(194, 39, 63, 0.6);
            animation: pulse-badge 2s infinite;
        }
        .nav-badge-section {
            margin-left: 6px;
        }
        @keyframes pulse-badge {
            0%   { box-shadow: 0 0 0 0 rgba(194, 39, 63, 0.7); }
            70%  { box-shadow: 0 0 0 6px rgba(194, 39, 63, 0); }
            100% { box-shadow: 0 0 0 0 rgba(194, 39, 63, 0); }
        }

        /* Footer & Main */
        .sidebar-footer {
            padding: 16px;
            border-top: 1px solid var(--border-color);
            background: rgba(0,0,0,0.1);
        }
        .dm-toggle {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 14px;
            border-radius: 10px;
            cursor: pointer;
            background: rgba(255,255,255,0.03);
            color: rgba(255,255,255,0.8);
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 8px;
        }
        .logout-link {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 10px;
            border-radius: 10px;
            color: #ef4444;
            font-weight: 600;
            font-size: 13px;
            text-decoration: none;
            background: rgba(239, 68, 68, 0.1);
            transition: 0.2s;
        }
        .logout-link:hover {
            background: rgba(239, 68, 68, 0.2);
        }
        
        .admin-main {
            margin-left: 280px;
            transition: margin-left 0.3s ease;
            background: var(--bg-body);
            min-height: 100vh;
        }
        .admin-header {
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: transparent;
        }
        
        /* Mobile */
        .mobile-menu-btn {
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: var(--bg-sidebar);
            color: #fff;
            border: none;
            padding: 8px;
            border-radius: 8px;
            cursor: pointer;
            display: none;
        }
        .sidebar-overlay {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 999;
            display: none;
            backdrop-filter: blur(2px);
        }
        .sidebar-overlay.active { display: block; }
        @media (max-width: 768px) {
            .admin-sidebar { transform: translateX(-100%); width: 260px; }
            .admin-sidebar.active { transform: translateX(0); }
            .admin-main { margin-left: 0; }
            .mobile-menu-btn { display: block; }
        }
    </style>
</head>
<body class="<?= isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark' ? 'dark-mode' : '' ?>">

<button class="mobile-menu-btn" onclick="toggleSidebar()">
    <i class="ri-menu-2-line" style="font-size:20px;"></i>
</button>

<div class="sidebar-overlay" onclick="toggleSidebar()"></div>

<div class="admin-layout">

    <aside class="admin-sidebar" id="appSidebar">
        <div class="sidebar-header">
            <a href="index.php" class="brand-wrapper">
                <div class="brand-icon">
                    <i class="ri-command-fill"></i>
                </div>
                <div class="brand-text">
                    <div class="brand-title">BETWALLET</div>
                    <div class="brand-subtitle">ADMIN PANEL</div>
                </div>
            </a>
        </div>

        <nav class="admin-nav">
            
            <div class="nav-section" data-section="dashboard">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title">
                        <i class="ri-dashboard-line"></i> KOKPİT
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <a href="index.php" class="sidebar-link <?= $activeNav === 'dashboard' ? 'is-active' : '' ?>">
                        <i class="ri-home-5-line"></i>
                        <span>Genel Bakış</span>
                    </a>
                    <a href="performance.php" class="sidebar-link <?= $activeNav === 'performance' ? 'is-active' : '' ?>">
                        <i class="ri-pie-chart-2-line"></i>
                        <span>Performans Analizi</span>
                    </a>
                    <a href="site_reports.php" class="sidebar-link <?= $activeNav === 'site_reports' ? 'is-active' : '' ?>">
                        <i class="ri-file-chart-line"></i>
                        <span>Site Raporları</span>
                    </a>
                </div>
            </div>

            <div class="nav-section" data-section="actions">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title" style="color: var(--primary);">
                        <i class="ri-notification-badge-line"></i> ONAY MERKEZİ
                        <?= $actionCenterBadge ?>
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <div style="padding: 5px 15px; font-size:10px; color:rgba(255,255,255,0.3); font-weight:700;">KULLANICI (OYUNCU)</div>
                    <a href="deposits.php" class="sidebar-link <?= $activeNav === 'deposits' ? 'is-active' : '' ?>">
                        <i class="ri-arrow-left-down-line"></i>
                        <span>Yatırım Talepleri</span>
                        <?= $badge('deposits') ?>
                    </a>
                    <a href="withdrawals.php" class="sidebar-link <?= $activeNav === 'withdrawals' ? 'is-active' : '' ?>">
                        <i class="ri-arrow-right-up-line"></i>
                        <span>Çekim Talepleri</span>
                        <?= $badge('user_withdrawals') ?>
                    </a>
                    <!-- Kasa Üstü Çekimler -->
                    <a href="admin_overflow_withdrawals.php" class="sidebar-link <?= $activeNav === 'overflow_withdrawals' ? 'is-active' : '' ?>">
                        <i class="ri-error-warning-line"></i>
                        <span>Kasa Üstü Çekimler</span>
                        <?= $badge('overflow_withdrawals') ?>
                    </a>

                    <div style="padding: 10px 15px 5px 15px; font-size:10px; color:rgba(255,255,255,0.3); font-weight:700;">KURUMSAL (SİTE)</div>
                    <a href="admin_site_requests.php" class="sidebar-link <?= $activeNav === 'site_requests' ? 'is-active' : '' ?>">
                        <i class="ri-bank-card-2-line"></i>
                        <span>Site Bakiye Yükleme</span>
                        <?= $badge('site_balance_requests') ?>
                    </a>

                    <a href="site_withdrawals.php" class="sidebar-link <?= $activeNav === 'site_withdrawals' ? 'is-active' : '' ?>">
                        <i class="ri-exchange-dollar-line"></i>
                        <span>Site Mutabakat/Çekim</span>
                        <?= $badge('site_withdrawals') ?>
                    </a>

                    <div style="padding: 10px 15px 5px 15px; font-size:10px; color:rgba(255,255,255,0.3); font-weight:700;">KURUMSAL (AGENT)</div>
                    <a href="admin_agent_requests.php" class="sidebar-link <?= $activeNav === 'agent_requests' ? 'is-active' : '' ?>">
                        <i class="ri-inbox-line"></i>
                        <span>Agent Bakiye</span>
                        <?= $badge('agent_requests') ?>
                    </a>
                    <a href="admin_agent_profit_withdrawals.php" class="sidebar-link <?= $activeNav === 'agent_withdrawals' ? 'is-active' : '' ?>">
                        <i class="ri-wallet-2-line"></i>
                        <span>Agent Çekim</span>
                        <?= $badge('agent_withdrawals') ?>
                    </a>
                </div>
            </div>

            <div class="nav-section" data-section="entities">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title">
                        <i class="ri-folder-user-line"></i> VARLIK YÖNETİMİ
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <a href="users.php" class="sidebar-link <?= $activeNav === 'users' ? 'is-active' : '' ?>">
                        <i class="ri-user-3-line"></i>
                        <span>Kullanıcı Listesi</span>
                    </a>
                    <a href="admin_sites.php" class="sidebar-link <?= $activeNav === 'sites' ? 'is-active' : '' ?>">
                        <i class="ri-global-line"></i>
                        <span>Site Listesi</span>
                    </a>
                    <a href="user_sites.php" class="sidebar-link <?= $activeNav === 'user_sites' ? 'is-active' : '' ?>">
                        <i class="ri-links-line"></i>
                        <span>Kullanıcı <-> Site Bağları</span>
                    </a>
                    <a href="admin_deposit_agents.php" class="sidebar-link <?= $activeNav === 'agents' ? 'is-active' : '' ?>">
                        <i class="ri-user-star-line"></i>
                        <span>Aracılar (Agents)</span>
                    </a>
                    <a href="admins.php" class="sidebar-link <?= $activeNav === 'admins' ? 'is-active' : '' ?>">
                        <i class="ri-shield-user-line"></i>
                        <span>Yöneticiler</span>
                    </a>
                </div>
            </div>

            <div class="nav-section" data-section="treasury">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title">
                        <i class="ri-safe-2-line"></i> FİNANS & KASA
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <a href="admin_merchant_withdraws.php" class="sidebar-link <?= $activeNav === 'merchant_withdraws' ? 'is-active' : '' ?>">
                        <i class="ri-send-plane-line"></i>
                        <span>Site -> Cüzdan Transfer</span>
                    </a>
                    <a href="admin_deposit_ibans.php" class="sidebar-link <?= $activeNav === 'ibans' ? 'is-active' : '' ?>">
                        <i class="ri-bank-card-line"></i>
                        <span>IBAN Yönetimi</span>
                    </a>
                    <a href="admin_crypto_wallets.php" class="sidebar-link <?= $activeNav === 'crypto_wallets' ? 'is-active' : '' ?>">
                        <i class="ri-qr-code-line"></i>
                        <span>Kripto Cüzdanları</span>
                    </a>
                </div>
            </div>

            <div class="nav-section" data-section="system">
                <button type="button" class="nav-category-toggle">
                    <span class="nav-category-title">
                        <i class="ri-settings-4-line"></i> SİSTEM & LOG
                    </span>
                    <i class="ri-arrow-down-s-line nav-category-arrow"></i>
                </button>
                <div class="nav-section-body">
                    <a href="admin_settings.php" class="sidebar-link <?= $activeNav === 'settings' ? 'is-active' : '' ?>">
                        <i class="ri-settings-3-line"></i>
                        <span>Genel Ayarlar</span>
                    </a>
                    <a href="admin_2fa_setup.php" class="sidebar-link <?= $activeNav === '2fa' ? 'is-active' : '' ?>">
                        <i class="ri-shield-keyhole-line"></i>
                        <span>2FA Güvenliği</span>
                    </a>

                    <!-- YENİ: Destek Talepleri -->
                    <a href="admin_supports.php" class="sidebar-link <?= $activeNav === 'supports' ? 'is-active' : '' ?>">
                        <i class="ri-customer-service-2-line"></i>
                        <span>Destek Talepleri</span>
                    </a>

                    <a href="admin_logs.php" class="sidebar-link <?= $activeNav === 'logs' ? 'is-active' : '' ?>">
                        <i class="ri-history-line"></i>
                        <span>İşlem Geçmişi</span>
                    </a>
                    <a href="agent_cash_logs.php" class="sidebar-link <?= $activeNav === 'agent_balance_logs' ? 'is-active' : '' ?>">
                        <i class="ri-list-ordered-2"></i>
                        <span>Agent Kasa Logları</span>
                    </a>
                    <a href="agent_personnel_logs.php" class="sidebar-link <?= $activeNav === 'agent_personnel_logs' ? 'is-active' : '' ?>">
                        <i class="ri-user-settings-line"></i>
                        <span>Personel Logları</span>
                    </a>
                </div>
            </div>

        </nav>

        <div class="sidebar-footer">
            <div class="dm-toggle" onclick="toggleDarkMode()">
                <span style="display:flex; align-items:center; gap:8px;">
                    <i class="ri-moon-clear-line"></i> Görünüm
                </span>
                <i class="ri-toggle-line" style="font-size:20px; opacity:0.5;" id="dmToggleIcon"></i>
            </div>
            <a href="admin_logout.php" class="logout-link">
                <i class="ri-logout-circle-r-line"></i>
                <span>Güvenli Çıkış</span>
            </a>
            <div style="text-align:center; margin-top:10px; font-size:10px; color:rgba(255,255,255,0.2);">
                <?= htmlspecialchars($displayName) ?>
            </div>
        </div>
    </aside>

    <main class="admin-main">
        <div class="admin-content-scroll">
            <header class="admin-header">
               
            </header>


<script>
function toggleSidebar() {
    const sidebar = document.getElementById('appSidebar');
    const overlay = document.querySelector('.sidebar-overlay');
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    const isDark = document.body.classList.contains('dark-mode');
    document.cookie = "theme=" + (isDark ? 'dark' : 'light') + "; path=/; max-age=31536000";
    updateDmIcon();
}

function updateDmIcon() {
    const icon = document.getElementById('dmToggleIcon');
    if(document.body.classList.contains('dark-mode')) {
        icon.className = 'ri-toggle-fill';
        icon.style.color = 'var(--primary)';
        icon.style.opacity = '1';
    } else {
        icon.className = 'ri-toggle-line';
        icon.style.color = '';
        icon.style.opacity = '0.5';
    }
}

updateDmIcon();
if (document.cookie.indexOf('theme=dark') !== -1) document.body.classList.add('dark-mode');

document.addEventListener('DOMContentLoaded', function () {
    const sections = document.querySelectorAll('.nav-section');
    sections.forEach(section => {
        const toggle = section.querySelector('.nav-category-toggle');
        if(section.querySelector('.sidebar-link.is-active')) {
            section.classList.remove('collapsed');
        } else {
            section.classList.add('collapsed');
        }
        toggle.addEventListener('click', () => {
            section.classList.toggle('collapsed');
        });
    });
});
</script>
