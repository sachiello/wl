<?php
// admin/api/live_counts.php
header('Content-Type: application/json');
require_once __DIR__ . '/../../../config/config.php';

// Admin girişi kontrolü (Güvenlik)
session_start();
if (!isset($_SESSION['admin_id'])) { http_response_code(403); exit; }

try {
    $counts = [];
    // Bekleyen işlemleri say
    $counts['deposits'] = (int)$pdo->query("SELECT COUNT(*) FROM deposit_orders WHERE status = 'pending'")->fetchColumn();
    $counts['user_withdrawals'] = (int)$pdo->query("SELECT COUNT(*) FROM agent_withdraw_orders WHERE status = 'pending'")->fetchColumn();
    $counts['site_withdrawals'] = (int)$pdo->query("SELECT COUNT(*) FROM site_withdrawals WHERE status = 'pending'")->fetchColumn();
    $counts['agent_requests'] = (int)$pdo->query("SELECT COUNT(*) FROM agent_balance_requests WHERE status = 'pending'")->fetchColumn();
    $counts['agent_withdrawals'] = (int)$pdo->query("SELECT COUNT(*) FROM agent_withdraw_orders WHERE status = 'pending'")->fetchColumn();
    $counts['site_balance_requests'] = (int)$pdo->query("SELECT COUNT(*) FROM site_balance_requests WHERE status = 'pending'")->fetchColumn();
    
    // Toplam (Bildirim sesi için)
    $totalPending = array_sum($counts);
    
    echo json_encode([
        'status' => 'success',
        'counts' => $counts,
        'total'  => $totalPending
    ]);
} catch (Exception $e) {
    echo json_encode(['status' => 'error']);
}
?>