<?php
// admin/includes/functions.php

// CSRF Token Oluştur
function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// CSRF Token Doğrula
function verifyCsrfToken($token) {
    if (!isset($_SESSION['csrf_token']) || $token !== $_SESSION['csrf_token']) {
        die('Güvenlik Hatası: Geçersiz CSRF Token. Lütfen sayfayı yenileyin.');
    }
    return true;
}

// Güvenli SQL Sorgusu (Hata Bastırmalı)
function safeQuery($pdo, $sql, $params = [], $default = 0) {
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        // Eğer SELECT COUNT/SUM ise tek değer dön, değilse tüm satırları dön
        if (strpos(strtoupper($sql), 'SELECT COUNT') === 0 || strpos(strtoupper($sql), 'SELECT SUM') === 0) {
            return $stmt->fetchColumn() ?: $default;
        }
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        // Loglama yapılabilir: error_log($e->getMessage());
        return is_array($default) ? [] : $default;
    }
}

// Para Formatı
function money($amount, $currency = '₺') {
    return number_format((float)$amount, 2, ',', '.') . ' <small>' . $currency . '</small>';
}

// Renkli Yüzde Göstergesi
function riskBadge($current, $limit) {
    if ($limit == 0) return '<span class="badge bg-secondary">N/A</span>';
    $ratio = ($current / $limit) * 100;
    if ($ratio >= 90) return '<span class="badge bg-danger">Riskli (%'.round($ratio).')</span>';
    if ($ratio >= 70) return '<span class="badge bg-warning text-dark">Dikkat (%'.round($ratio).')</span>';
    return '<span class="badge bg-success">Güvenli (%'.round($ratio).')</span>';
}
?>