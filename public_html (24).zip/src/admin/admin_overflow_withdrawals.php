<?php
// DEBUG: Hata gör diye (canlıda kapat)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// admin/admin_overflow_withdrawals.php
require __DIR__ . '/require_admin.php'; // $pdo, $currentAdmin, CSRF helper vb.

$pageTitle = 'Kasa Üstü Çekimler';
$activeNav = 'overflow_withdrawals';

$adminError   = null;
$adminSuccess = null;

// ===================== POST – ÇEKİMİ DAĞIT =====================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['distribute_id'])) {
    if (!csrf_validate_request()) {
        $adminError = "Oturum doğrulaması başarısız. Sayfayı yenileyip tekrar deneyin.";
    } else {
        $overflowId = (int)$_POST['distribute_id'];

        try {
            $pdo->beginTransaction();

            // 1) Overflow kaydını kilitle (JOIN YOK)
            $stmt = $pdo->prepare("
                SELECT *
                FROM agent_withdraw_overflow
                WHERE id = ?
                  AND status = 'waiting'
                FOR UPDATE
            ");
            $stmt->execute([$overflowId]);
            $ov = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$ov) {
                throw new Exception("Kayıt bulunamadı veya zaten işlenmiş.");
            }

            $amountTry   = (float)$ov['amount_try'];
            $userId      = (int)$ov['user_id'];
            $bankName    = $ov['to_bank_name'];
            $iban        = $ov['to_iban'];
            $fullName    = $ov['to_full_name'];
            $requestId   = (int)$ov['withdraw_request_id'];

            // 2) Uygun agent bul
            $agentStmt = $pdo->prepare("
                SELECT 
                    a.id, a.current_cash
                FROM deposit_agents a
                WHERE a.is_active = 1
                  AND a.current_cash >= :amt
                ORDER BY a.current_cash DESC
                LIMIT 1
            ");
            $agentStmt->execute([':amt' => $amountTry]);
            $agent = $agentStmt->fetch(PDO::FETCH_ASSOC);

            if (!$agent) {
                throw new Exception("Şu anda uygun kasaya sahip agent yok. Daha sonra tekrar deneyin.");
            }

            $agentId = (int)$agent['id'];

            // 3) Agent kasasından TL düş
            $updAgent = $pdo->prepare("
                UPDATE deposit_agents
                SET current_cash = current_cash - ?
                WHERE id = ?
            ");
            $updAgent->execute([$amountTry, $agentId]);

            if ($updAgent->rowCount() === 0) {
                throw new Exception("Agent kasası güncellenemedi.");
            }

            // 4) Agent görev kaydı aç
            $aw = $pdo->prepare("
                INSERT INTO agent_withdraw_orders
                (agent_id, user_id, amount, to_bank_name, to_iban, to_full_name, status, created_at, withdraw_request_id)
                VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW(), ?)
            ");
            $aw->execute([
                $agentId,
                $userId,
                $amountTry,
                $bankName,
                $iban,
                $fullName,
                $requestId
            ]);

            // 5) Overflow kaydını güncelle
            $updOv = $pdo->prepare("
                UPDATE agent_withdraw_overflow
                SET status = 'assigned',
                    updated_at = NOW()
                WHERE id = ?
            ");
            $updOv->execute([$overflowId]);

            $pdo->commit();
            $adminSuccess = "Çekim başarıyla agent ID {$agentId} üzerine dağıtıldı.";

        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $adminError = $e->getMessage();
        }
    }
}

// ===================== LİSTE – BEKLEYEN OVERFLOW KAYITLARI =====================
$rows = [];
try {
    $listStmt = $pdo->query("
        SELECT 
            o.id,
            o.withdraw_request_id,
            o.user_id,
            o.amount_try,
            o.coin_amount,
            o.coin_type,
            o.to_bank_name,
            o.to_iban,
            o.to_full_name,
            o.created_at
        FROM agent_withdraw_overflow o
        WHERE o.status = 'waiting'
        ORDER BY o.created_at ASC
    ");
    $rows = $listStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    // Tablo yoksa veya kolon hatası varsa buraya düşer
    $adminError = "Veri okunurken hata oluştu: " . $e->getMessage();
    $rows = [];
}

// ===================== HEADER (LAYOUT + SIDEBAR) =====================
require __DIR__ . '/_admin_header.php';
?>

<style>
    .admin-page-inner {
        padding: 0 30px 30px 30px;
    }
    .admin-page-title {
        font-size: 22px;
        font-weight: 700;
        margin: 0 0 10px 0;
        color: var(--text-main, #111827);
    }
    .admin-page-sub {
        font-size: 13px;
        color: var(--text-muted, #6b7280);
        margin-bottom: 18px;
    }
    .admin-card {
        background: #ffffff;
        border-radius: 16px;
        border: 1px solid #e5e7eb;
        box-shadow: 0 4px 10px rgba(15,23,42,0.03);
        padding: 18px 20px;
    }
    body.dark-mode .admin-card {
        background: #020617;
        border-color: #1f2937;
    }
    .alert {
        border-radius: 10px;
        padding: 10px 14px;
        font-size: 14px;
        margin-bottom: 12px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .alert-success {
        background: #ecfdf5;
        border: 1px solid #6ee7b7;
        color: #065f46;
    }
    .alert-error {
        background: #fef2f2;
        border: 1px solid #fecaca;
        color: #991b1b;
    }
    body.dark-mode .alert-success {
        background: rgba(22,163,74,0.1);
        border-color: rgba(16,185,129,0.5);
        color: #bbf7d0;
    }
    body.dark-mode .alert-error {
        background: rgba(239,68,68,0.08);
        border-color: rgba(248,113,113,0.6);
        color: #fecaca;
    }
    .admin-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
    }
    .admin-table th,
    .admin-table td {
        padding: 10px 12px;
        border-bottom: 1px solid #e5e7eb;
        text-align: left;
        vertical-align: top;
    }
    .admin-table th {
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: .04em;
        color: #6b7280;
        background: #f9fafb;
    }
    body.dark-mode .admin-table th {
        background: #020617;
        color: #9ca3af;
        border-color: #1f2937;
    }
    body.dark-mode .admin-table td {
        border-color: #1f2937;
        color: #e5e7eb;
    }
    .amount {
        font-weight: 600;
    }
    .iban {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
        font-size: 12px;
        word-break: break-all;
    }
    .btn {
        border: none;
        border-radius: 999px;
        padding: 6px 14px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }
    .btn-distribute {
        background: #0f766e;
        color: #ecfeff;
    }
    .btn-distribute:hover {
        background: #115e59;
    }
    body.dark-mode .btn-distribute {
        background: #14b8a6;
        color: #022c22;
    }
    .badge-user {
        display: inline-flex;
        flex-direction: column;
        font-size: 12px;
    }
    .badge-user span:first-child {
        font-weight: 600;
    }
    .badge-user span:last-child {
        color: #6b7280;
    }
    body.dark-mode .badge-user span:last-child {
        color: #9ca3af;
    }
    .empty-state {
        text-align: center;
        padding: 40px;
        color: #6b7280;
        font-size: 14px;
    }
    body.dark-mode .empty-state {
        color: #9ca3af;
    }
</style>

<div class="admin-page-inner">
    <div style="margin-bottom: 18px;">
        <h1 class="admin-page-title">Kasa Üstü Çekimler</h1>
        <div class="admin-page-sub">
            Agent kasalarının yetersiz kaldığı kullanıcı çekim talepleri. Buradan uygun kasaya sahip agenta manuel dağıtım yapabilirsiniz.
        </div>
    </div>

    <div class="admin-card">
        <?php if ($adminSuccess): ?>
            <div class="alert alert-success">
                <i class="ri-checkbox-circle-fill"></i>
                <?= htmlspecialchars($adminSuccess) ?>
            </div>
        <?php endif; ?>

        <?php if ($adminError): ?>
            <div class="alert alert-error">
                <i class="ri-error-warning-fill"></i>
                <?= htmlspecialchars($adminError) ?>
            </div>
        <?php endif; ?>

        <?php if (!$rows): ?>
            <div class="empty-state">
                <i class="ri-inbox-line" style="font-size:32px;display:block;margin-bottom:8px;opacity:0.4;"></i>
                Bekleyen kasa üstü çekim bulunmuyor.
            </div>
        <?php else: ?>
            <div class="table-container">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Req ID</th>
                            <th>Kullanıcı</th>
                            <th>Tutar (TRY)</th>
                            <th>Coin</th>
                            <th>Banka / IBAN</th>
                            <th>Tarih</th>
                            <th style="text-align:right;">İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($rows as $r): ?>
                        <tr>
                            <td>#<?= (int)$r['id'] ?></td>
                            <td><?= (int)$r['withdraw_request_id'] ?></td>
                            <td>
                                <div class="badge-user">
                                    <span><?= 'User #' . (int)$r['user_id'] ?></span>
                                </div>
                            </td>
                            <td class="amount">
                                ₺<?= number_format($r['amount_try'], 2, ',', '.') ?>
                            </td>
                            <td>
                                <?= htmlspecialchars($r['coin_amount']) . ' ' . htmlspecialchars($r['coin_type']) ?>
                            </td>
                            <td>
                                <div style="font-size:12px;">
                                    <div><?= htmlspecialchars($r['to_bank_name']) ?></div>
                                    <div class="iban"><?= htmlspecialchars($r['to_iban']) ?></div>
                                    <div><?= htmlspecialchars($r['to_full_name']) ?></div>
                                </div>
                            </td>
                            <td><?= htmlspecialchars($r['created_at']) ?></td>
                            <td style="text-align:right;">
                                <form method="post" style="display:inline;">
                                    <?php if (function_exists('csrf_field')) echo csrf_field(); ?>
                                    <input type="hidden" name="distribute_id" value="<?= (int)$r['id'] ?>">
                                    <button type="submit" class="btn btn-distribute">
                                        <i class="ri-share-forward-line"></i>
                                        Çekimi Dağıt
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
// footer'ın varsa burada çağırabilirsin.
// require __DIR__ . '/_admin_footer.php';
?>
