<?php
// admin/deposits_update.php
session_start();
require __DIR__ . '/../../config/config.php';

$adminId = $_SESSION['admin_id'] ?? null;
$agentId = $_SESSION['agent_id'] ?? null;

$operatorId = $adminId ?? $agentId;
$operatorType = $adminId ? 'admin' : 'agent';

if (!$operatorId) {
    header('Location: admin_login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_validate_request()) {
    header('Location: deposits.php?error=csrf');
    exit;
}

$id     = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$action = $_POST['action'] ?? '';

if ($id <= 0 || !in_array($action, ['confirm', 'reject'], true)) {
    header('Location: deposits.php?error=invalid_params');
    exit;
}

// --- YATIRIM VERİSİNİ ÇEK ---
$stmt = $pdo->prepare("
    SELECT d.*, u.username 
    FROM deposit_orders d 
    JOIN users u ON u.id = d.user_id 
    WHERE d.id = ? 
    LIMIT 1
");
$stmt->execute([$id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    header('Location: deposits.php?error=not_found');
    exit;
}

if ($order['status'] !== 'pending') {
    header('Location: deposits.php?error=already_processed');
    exit;
}

$coinType = $order['coin_type'];
$amountCoin = (float)$order['coin_amount'];
$amountTry = (float)$order['amount_try'];
$orderAgentId = $order['agent_id'] ? (int)$order['agent_id'] : null;

try {
    $pdo->beginTransaction();

    if ($action === 'reject') {
        // REDDETME İŞLEMİ
        $stmt = $pdo->prepare("UPDATE deposit_orders SET status = 'rejected', admin_id = :op_id WHERE id = :id");
        $stmt->execute([':op_id' => $operatorId, ':id' => $id]);
        
        // Loglama
        if (function_exists('bw_log_action')) {
            bw_log_action($pdo, 'deposit', $operatorType, (int)$operatorId, 'reject', ['order_id' => $id]);
        }
        
        $pdo->commit();
        header('Location: deposits.php?ok=rejected');
        exit;

    } elseif ($action === 'confirm') {
        // ONAYLAMA İŞLEMİ
        
        // 1. AGENT BAKİYE KONTROLÜ & GÜNCELLEMESİ (Teminat Düşer, Nakit Artar)
        if ($orderAgentId) {
            // Agent'ı kilitle
            $stmtAgent = $pdo->prepare("SELECT system_balance, current_cash FROM deposit_agents WHERE id = ? FOR UPDATE");
            $stmtAgent->execute([$orderAgentId]);
            $agentData = $stmtAgent->fetch(PDO::FETCH_ASSOC);

            if ($agentData) {
                $currentSystemBal = (float)$agentData['system_balance'];
                
                // Yetersiz Teminat Kontrolü
                if ($currentSystemBal < $amountTry) {
                    throw new Exception("Agent'ın sistem bakiyesi (teminatı) yetersiz! İşlem onaylanamaz.");
                }

                // System Balance DÜŞ, Current Cash ARTIR
                $updAgent = $pdo->prepare("
                    UPDATE deposit_agents 
                    SET system_balance = system_balance - ?, 
                        current_cash = current_cash + ? 
                    WHERE id = ?
                ");
                $updAgent->execute([$amountTry, $amountTry, $orderAgentId]);
            }
        }

        // 2. KULLANICI BAKİYESİNİ ARTIR (wallet update)
        // Eğer bw_wallet_add fonksiyonun varsa onu kullan, yoksa manuel update:
        $stmtWallet = $pdo->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ? AND coin_type = ?");
        $stmtWallet->execute([$amountCoin, $order['user_id'], $coinType]);

        // 3. SİPARİŞ DURUMUNU GÜNCELLE
        $stmt = $pdo->prepare("
            UPDATE deposit_orders 
            SET status = 'confirmed', 
                confirmed_at = NOW(), 
                admin_id = :op_id
            WHERE id = :id
        ");
        $stmt->execute([':op_id' => $operatorId, ':id' => $id]);

        // 4. SİTE BAKİYESİ (Eğer bir site üzerinden geldiyse)
        if (!empty($order['site_id'])) {
             $siteId = (int)$order['site_id'];
             // Komisyon hesapla (%4 kesinti örneği)
             $siteStmt = $pdo->prepare("SELECT commission_rate FROM sites WHERE id = ?");
             $siteStmt->execute([$siteId]);
             $siteInfo = $siteStmt->fetch(PDO::FETCH_ASSOC);
             $commRate = $siteInfo ? (float)$siteInfo['commission_rate'] : 4.0;
             
             $netAmount = $amountTry * ((100 - $commRate) / 100);
             
             $updSite = $pdo->prepare("UPDATE sites SET balance = balance + ?, net_balance = net_balance + ? WHERE id = ?");
             $updSite->execute([$netAmount, $netAmount, $siteId]);
        }

        // Loglama
        if (function_exists('bw_log_action')) {
            bw_log_action($pdo, 'deposit', $operatorType, (int)$operatorId, 'confirm', [
                'order_id'    => $id,
                'user_id'     => (int)$order['user_id'],
                'coin_type'   => $coinType,
                'amount'      => $amountCoin,
                'agent_id'    => $orderAgentId
            ]);
        }

        $pdo->commit();
        header('Location: deposits.php?ok=approved');
        exit;
    }

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    // Hata mesajını session'a atıp gösterebilirsin veya direkt basabilirsin
    die("İşlem Hatası: " . $e->getMessage()); 
}