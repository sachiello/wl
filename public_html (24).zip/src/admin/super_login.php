<?php
require __DIR__ . '/../../config/config.php';
session_start();

// Sadece Admin Girebilir
if (!isset($_SESSION['admin_id'])) { die("Yetkisiz Erişim"); }

$targetAgentId = $_GET['agent_id'];

// Agent bilgilerini al
$stmt = $pdo->prepare("SELECT * FROM deposit_agents WHERE id = ?");
$stmt->execute([$targetAgentId]);
$agent = $stmt->fetch(PDO::FETCH_ASSOC);

if ($agent) {
    // Agent Session'larını Admin Olarak Doldur
    $_SESSION['agent_id'] = $agent['id'];
    $_SESSION['agent_name'] = "SUPER ADMIN (" . $agent['name'] . ")";
    $_SESSION['is_personnel'] = false; // Patron modunda aç
    $_SESSION['permissions'] = ['ALL'];

    // Agent paneline yönlendir
    header("Location: ../agent/index.php");
    exit;
}
?>