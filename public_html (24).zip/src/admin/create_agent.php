<?php
# Tek seferlik agent oluşturma/güncelleme aracı.
# Güvenlik için basit bir SECRET belirleyin ve URL parametresiyle çağırın:
# Örn: /admin/create_agent.php?secret=MYSECRET

require __DIR__ . '/../../config/config.php';

$SECRET = 'CHANGE_ME_ONCE'; // Burayı güvenli bir değere çevir.

$provided = $_GET['secret'] ?? '';
if ($SECRET === 'CHANGE_ME_ONCE') {
    die('Lütfen create_agent.php içindeki $SECRET değerini değiştir.');
}
if ($provided !== $SECRET) {
    http_response_code(403);
    die('Yetkisiz.');
}

$error = null;
$success = null;
$csrfFailed = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !csrf_validate_request()) {
    $csrfFailed = true;
    $error = 'Oturum doğrulaması başarısız. Lütfen formu yenileyip tekrar deneyin.';
}

$hasEmailCol = bw_table_has_column($pdo, 'deposit_agents', 'email');
$hasPassCol  = bw_table_has_column($pdo, 'deposit_agents', 'password_hash');

if (!$hasEmailCol || !$hasPassCol) {
    die('deposit_agents tablosunda email veya password_hash kolonu yok. Lütfen ekleyip tekrar deneyin.');
}

if (!$csrfFailed && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $phone    = trim($_POST['phone'] ?? '');
    $note     = trim($_POST['note'] ?? '');
    $quota    = (float)($_POST['quota'] ?? 0);
    $isActive = isset($_POST['is_active']) ? 1 : 0;

    if ($name === '' || $email === '' || $password === '') {
        $error = 'İsim, email ve şifre zorunlu.';
    } else {
        $hash = password_hash($password, PASSWORD_BCRYPT);

        // Var mı?
        $chk = $pdo->prepare("SELECT id FROM deposit_agents WHERE email = ? LIMIT 1");
        $chk->execute([$email]);
        $id = $chk->fetchColumn();

        if ($id) {
            $stmt = $pdo->prepare(
                "UPDATE deposit_agents
                SET name = ?, phone = ?, note = ?, quota_limit = ?, password_hash = ?, is_active = ?
                WHERE id = ?"
            );
            $stmt->execute([$name, $phone, $note, $quota, $hash, $isActive, $id]);
            $success = "Güncellendi (ID: {$id}).";
        } else {
            $stmt = $pdo->prepare(
                "INSERT INTO deposit_agents (name, phone, note, quota_limit, quota_used, is_active, email, password_hash)
                VALUES (?, ?, ?, ?, 0, ?, ?, ?)"
            );
            $stmt->execute([$name, $phone, $note, $quota, $isActive, $email, $hash]);
            $success = 'Yeni agent eklendi. ID: ' . (int)$pdo->lastInsertId();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Agent Oluştur</title>
  <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
  <div class="admin-container" style="max-width:520px; margin:40px auto;">
    <h1>Agent Oluştur / Güncelle</h1>
    <p class="admin-text-muted">Secret parametresi doğrulandı.</p>

    <?php if ($error): ?>
      <div class="admin-alert admin-alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
      <div class="admin-alert admin-alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="post">
      <?= csrf_field(); ?>
      <div class="admin-form-group">
        <label>Ad</label>
        <input type="text" name="name" class="admin-input" required>
      </div>
      <div class="admin-form-group">
        <label>E-posta (login için)</label>
        <input type="email" name="email" class="admin-input" required>
      </div>
      <div class="admin-form-group">
        <label>Şifre</label>
        <input type="text" name="password" class="admin-input" required>
      </div>
      <div class="admin-form-group">
        <label>Telefon</label>
        <input type="text" name="phone" class="admin-input">
      </div>
      <div class="admin-form-group">
        <label>Not</label>
        <textarea name="note" class="admin-input" rows="2"></textarea>
      </div>
      <div class="admin-form-group">
        <label>Kota (TL) - 0 sınırsız</label>
        <input type="number" name="quota" step="0.01" min="0" class="admin-input" value="0">
      </div>
      <div class="admin-form-group">
        <label>
          <input type="checkbox" name="is_active" checked> Aktif
        </label>
      </div>
      <button type="submit" class="admin-btn admin-btn-primary">Kaydet</button>
    </form>
  </div>
</body>
</html>
