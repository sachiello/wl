<?php
session_start();
require __DIR__ . '/../../config/config.php';

// Kullanıcı şifre aşamasını geçti mi?
if (empty($_SESSION['pending_admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$adminId = $_SESSION['pending_admin_id'];

// Admin bilgisi
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ? LIMIT 1");
$stmt->execute([$adminId]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admin || empty($admin['twofa_secret'])) {
    // 2FA yoksa direkt giriş
    $_SESSION['admin_id'] = $adminId;
    unset($_SESSION['pending_admin_id']);
    header("Location: index.php");
    exit;
}

$error = null;

// ==============================
// GOOGLE AUTH KÜTÜPHANESİ
// ==============================
require __DIR__ . '/../../lib/GoogleAuthenticator.php';
$ga = new GoogleAuthenticator();

// ==============================
// FORM POST → DOĞRULAMA
// ==============================
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    if (!csrf_validate_request()) {
        $error = "Oturum doğrulaması başarısız. Sayfayı yenileyip tekrar deneyin.";
    } else {
        $code = trim($_POST['code'] ?? '');

        if (strlen($code) !== 6 || !ctype_digit($code)) {
            $error = "6 haneli geçerli bir kod giriniz.";
        } else {

            // GOOGLE AUTH LIB ile doğrula
            if ($ga->verifyCode($admin['twofa_secret'], $code, 1)) {

                // BAŞARILI → Admin oturumu aç
                $_SESSION['admin_id'] = $adminId;
                unset($_SESSION['pending_admin_id']);

                header("Location: index.php");
                exit;

            } else {
                $error = "Kod yanlış veya süresi dolmuş.";
            }
        }
    }
}

?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>2FA Doğrulama</title>
<link rel="stylesheet" href="/public/assets/admin.css">

<style>
body {
    background: var(--bg-gradient);
    background-attachment: fixed;
    font-family: 'Plus Jakarta Sans', sans-serif;
    color: var(--text-main);
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.twofa-box {
    width: 360px;
    background: #fff;
    padding: 30px;
    border-radius: 16px;
    box-shadow: var(--shadow-card);
    text-align: center;
}

.twofa-box h2 {
    margin-bottom: 10px;
    font-weight: 700;
}

.twofa-box p {
    color: #64748b;
    font-size: 14px;
    margin-bottom: 20px;
}

.twofa-input {
    width: 100%;
    padding: 12px;
    font-size: 22px;
    text-align: center;
    letter-spacing: 8px;
    font-weight: 600;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    outline: none;
}

.twofa-btn {
    margin-top: 20px;
    width: 100%;
    padding: 12px;
    background: var(--primary);
    color: #fff;
    border: none;
    border-radius: 12px;
    cursor: pointer;
    font-size: 15px;
    font-weight: 600;
}

.twofa-btn:hover {
    background: var(--primary-hover);
}

.alert {
    background: #fee2e2;
    color: #b91c1c;
    padding: 12px;
    border-radius: 10px;
    margin-bottom: 15px;
    font-size: 14px;
}
</style>

</head>
<body>

<div class="twofa-box">
    <h2>2FA Doğrulama</h2>
    <p>Google Authenticator uygulamasındaki 6 haneli kodu girin.</p>

    <?php if ($error): ?>
        <div class="alert"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post">
        <?= csrf_field(); ?>
        <input type="text" name="code" maxlength="6" class="twofa-input" placeholder="------" required>
        <button class="twofa-btn">Giriş Yap</button>
    </form>
</div>

</body>
</html>
