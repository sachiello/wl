<?php
// admin/user_detail.php
require __DIR__ . '/require_admin.php'; // $pdo, $currentAdmin

$pageTitle = 'Kullanıcı Detay – Betwallet Admin';
$activeNav = 'users';

$userId = (int) ($_GET['id'] ?? 0);
if ($userId <= 0) {
    header('Location: users.php');
    exit;
}

// -----------------------
// Kullanıcı Verilerini Çekme
// -----------------------
$stmt = $pdo->prepare("
    SELECT 
        u.id, u.username, u.trc20_address, u.created_at, u.is_banned,
        COALESCE(w_trx.balance, 0) AS trx_balance,
        COALESCE(w_usdt.balance, 0) AS usdt_balance
    FROM users u
    LEFT JOIN wallets w_trx ON w_trx.user_id = u.id AND w_trx.coin_type = 'TRX'
    LEFT JOIN wallets w_usdt ON w_usdt.user_id = u.id AND w_usdt.coin_type = 'USDT'
    WHERE u.id = :id
");
$stmt->execute([':id' => $userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    // Kullanıcı bulunamazsa
    header('Location: users.php?error=notfound');
    exit;
}

// -----------------------
// AKSİYON: Bakiye Düzeltme (Adjustment)
// -----------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'adjust_balance') {
    $amount = (float) ($_POST['amount'] ?? 0);
    $coinType = $_POST['coin_type'] ?? '';
    $reason = trim($_POST['reason'] ?? '');

    if ($amount != 0 && in_array($coinType, ['TRX', 'USDT']) && $reason !== '') {
        try {
            $pdo->beginTransaction();

            $balance_before_key = strtolower($coinType) . '_balance';
            $balance_after = $user[$balance_before_key] + $amount;

            // 1. Cüzdanı Güncelle
            $updateStmt = $pdo->prepare("
                UPDATE wallets 
                SET balance = balance + :amount 
                WHERE user_id = :user_id AND coin_type = :coin_type
            ");
            $updateStmt->execute([
                ':amount'    => $amount,
                ':user_id'   => $userId,
                ':coin_type' => $coinType
            ]);

            // 2. Activity Log'a yaz (Düzeltme Kanıtı)
            $meta = json_encode([
                'user_id' => $userId,
                'coin_type' => $coinType,
                'amount' => $amount,
                'balance_before' => $user[$balance_before_key],
                'balance_after' => $balance_after,
                'reason' => $reason
            ]);
            $logStmt = $pdo->prepare("
                INSERT INTO activity_logs (actor_type, actor_id, scope, action, meta_json, created_at)
                VALUES ('admin', :admin_id, 'user_wallet', 'adjust_balance', :meta_json, NOW())
            ");
            $logStmt->execute([
                ':admin_id'  => $currentAdmin['id'] ?? null,
                ':meta_json' => $meta,
            ]);

            $pdo->commit();
            header('Location: user_detail.php?id=' . $userId . '&tab=overview&ok=adjustment');
            exit;

        } catch (Exception $e) {
            $pdo->rollBack();
            $error = 'Bakiye düzeltilirken bir hata oluştu: ' . $e->getMessage();
        }
    } else {
        $error = 'Miktar sıfır olamaz ve gerekçe alanı boş bırakılamaz.';
    }
}

// -----------------------
// AKSİYON: Ban / Unban İşlemi
// -----------------------
if (isset($_GET['ban']) || isset($_GET['unban'])) {
    $newStatus = isset($_GET['ban']) ? 1 : 0;

    $stmt = $pdo->prepare("UPDATE users SET is_banned = :banned WHERE id = :id");
    $stmt->execute([
        ':banned' => $newStatus,
        ':id'     => $userId
    ]);

    // Activity log'a yaz
    $action = $newStatus ? 'ban' : 'unban';
    $meta = json_encode(['user_id' => $userId]);
    $logStmt = $pdo->prepare("
        INSERT INTO activity_logs (actor_type, actor_id, scope, action, meta_json, created_at)
        VALUES ('admin', :admin_id, 'user', :action, :meta_json, NOW())
    ");
    $logStmt->execute([
        ':admin_id'  => $currentAdmin['id'] ?? null,
        ':action'    => $action,
        ':meta_json' => $meta,
    ]);

    header('Location: user_detail.php?id=' . $userId . '&tab=overview&ok=' . ($newStatus ? 'banned' : 'unbanned'));
    exit;
}

// -----------------------
// SEKME VERİLERİ
// -----------------------
$currentTab = $_GET['tab'] ?? 'overview';
$ok = $_GET['ok'] ?? null;

// Sadece 'transactions' sekmesi için gerekenler
if ($currentTab === 'transactions') {
    // Toplam Yatırım (TRY)
    $totalDeposit = $pdo->prepare("
        SELECT SUM(amount_try) FROM deposit_orders 
        WHERE user_id = :id AND status = 'confirmed'
    ");
    $totalDeposit->execute([':id' => $userId]);
    $totalDepositTry = (float) $totalDeposit->fetchColumn();

    // Toplam Çekim (Coin)
    $totalWithdraw = $pdo->prepare("
        SELECT SUM(amount) FROM withdraw_requests
        WHERE user_id = :id AND status = 'approved'
    ");
    $totalWithdraw->execute([':id' => $userId]);
    $totalWithdrawCoin = (float) $totalWithdraw->fetchColumn();

    // Yatırım Emirleri (Son 20)
    $depositOrders = $pdo->prepare("
        SELECT id, coin_type, amount_try, coin_amount, status, created_at, confirmed_at, admin_id
        FROM deposit_orders
        WHERE user_id = :id
        ORDER BY id DESC
        LIMIT 20
    ");
    $depositOrders->execute([':id' => $userId]);
    $deposits = $depositOrders->fetchAll(PDO::FETCH_ASSOC);

    // Çekim Talepleri (Son 20)
    $withdrawRequests = $pdo->prepare("
        SELECT id, coin_type, amount, status, created_at
        FROM withdraw_requests
        WHERE user_id = :id
        ORDER BY id DESC
        LIMIT 20
    ");
    $withdrawRequests->execute([':id' => $userId]);
    $withdraws = $withdrawRequests->fetchAll(PDO::FETCH_ASSOC);

} elseif ($currentTab === 'sites_activity') {
    // Bağlı Siteler
    $userSites = $pdo->prepare("
        SELECT us.site_username, us.site_balance_try, us.linked_at, s.name AS site_name
        FROM user_sites us
        JOIN sites s ON s.id = us.site_id
        WHERE us.user_id = :id
        ORDER BY us.linked_at DESC
    ");
    $userSites->execute([':id' => $userId]);
    $sites = $userSites->fetchAll(PDO::FETCH_ASSOC);

    // Kullanıcı Aktiviteleri (Son 50)
    $activityLogs = $pdo->prepare("
        SELECT al.actor_type, al.action, al.meta_json, al.created_at, a.username AS admin_name
        FROM activity_logs al
        LEFT JOIN admins a ON a.id = al.actor_id AND al.actor_type = 'admin'
        WHERE (al.actor_type = 'user' AND al.actor_id = :id) OR (al.scope = 'user' AND JSON_EXTRACT(al.meta_json, '$.user_id') = :id) OR (al.scope = 'user_wallet' AND JSON_EXTRACT(al.meta_json, '$.user_id') = :id)
        ORDER BY al.id DESC
        LIMIT 50
    ");
    $activityLogs->execute([':id' => $userId]);
    $logs = $activityLogs->fetchAll(PDO::FETCH_ASSOC);
}

// -----------------------
// POPUP MODU (AJAX / MODAL)
// -----------------------
$isPopup = isset($_GET['popup']) && $_GET['popup'] === '1';

if ($isPopup) {
    ?>
    <div class="user-detail-popup">

        <div class="user-detail-popup-header">
            <div class="user-detail-popup-header-left">
                <h3><?= htmlspecialchars($user['username']) ?></h3>
                <p>
                    ID: #<?= (int)$user['id'] ?> · 
                    Kayıt: <?= htmlspecialchars($user['created_at']) ?> · 
                    Durum:
                    <?php if ($user['is_banned']): ?>
                        <span class="badge badge-danger">BANLI</span>
                    <?php else: ?>
                        <span class="badge badge-success">AKTİF</span>
                    <?php endif; ?>
                </p>
            </div>
            <div class="user-detail-popup-header-right">
                <?php if ($user['is_banned']): ?>
                    <a href="user_detail.php?id=<?= $userId ?>&unban=1&popup=1"
                       class="btn btn-xs btn-success"
                       onclick="return confirm('Banı kaldırmak istediğine emin misin?');">
                        Banı Kaldır
                    </a>
                <?php else: ?>
                    <a href="user_detail.php?id=<?= $userId ?>&ban=1&popup=1"
                       class="btn btn-xs btn-danger"
                       onclick="return confirm('Bu kullanıcıyı banlamak istediğine emin misin?');">
                        Banla
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <div class="user-detail-grid">
            <!-- Sol: Temel Bilgiler -->
            <div>
                <div class="user-detail-section-title">Temel Bilgiler</div>
                <div class="user-detail-box">
                    <p><span class="user-detail-label">Username:</span> <?= htmlspecialchars($user['username']) ?></p>
                    <p><span class="user-detail-label">Kullanıcı ID:</span> #<?= (int)$user['id'] ?></p>
                    <p>
                        <span class="user-detail-label">TRC20 Adresi:</span><br>
                        <code style="font-size:11px;"><?= htmlspecialchars($user['trc20_address']) ?></code>
                    </p>
                    <p><span class="user-detail-label">Kayıt Tarihi:</span> <?= htmlspecialchars($user['created_at']) ?></p>
                </div>
            </div>

            <!-- Sağ: Cüzdan & Bakiye Düzeltme -->
            <div>
                <div class="user-detail-section-title">Cüzdan Bakiyeleri</div>
                <div class="user-detail-box">
                    <p>
                        <span class="user-detail-label">TRX:</span>
                        <span class="badge badge-primary">
                            <?= number_format($user['trx_balance'], 6) ?> TRX
                        </span>
                    </p>
                    <p>
                        <span class="user-detail-label">USDT:</span>
                        <span class="badge badge-primary">
                            <?= number_format($user['usdt_balance'], 6) ?> USDT
                        </span>
                    </p>
                </div>

                <div class="user-detail-section-title" style="margin-top:14px;">Manuel Bakiye Düzeltme</div>
                <div class="user-detail-box">
                    <form method="post" action="user_detail.php?id=<?= $userId ?>&popup=1">
                        <input type="hidden" name="action" value="adjust_balance">

                        <div class="filter-group" style="margin-bottom:8px;">
                            <label>Coin Tipi</label>
                            <select name="coin_type" required>
                                <option value="TRX">TRX</option>
                                <option value="USDT">USDT</option>
                            </select>
                        </div>

                        <div class="filter-group" style="margin-bottom:8px;">
                            <label>Miktar (+/-)</label>
                            <input type="number" step="0.000001" name="amount" placeholder="Örn: 100.00 veya -50.5" required>
                        </div>

                        <div class="filter-group" style="margin-bottom:10px;">
                            <label>Gerekçe (Zorunlu)</label>
                            <input type="text" name="reason" placeholder="Örn: Hata Düzeltme, Bonus Yükleme" required>
                        </div>

                        <button type="submit" class="btn btn-warning btn-xs">
                            Bakiye Düzelt
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Alt tarafa kısa özet: toplam yatırım / çekim -->
        <?php
        // küçük özet: toplam yatırım - çekim
        $sumDepositStmt = $pdo->prepare("
            SELECT SUM(amount_try) FROM deposit_orders 
            WHERE user_id = :id AND status = 'confirmed'
        ");
        $sumDepositStmt->execute([':id' => $userId]);
        $sumDepositTryPopup = (float)$sumDepositStmt->fetchColumn();

        $sumWithdrawStmt = $pdo->prepare("
            SELECT SUM(amount) FROM withdraw_requests
            WHERE user_id = :id AND status = 'approved'
        ");
        $sumWithdrawStmt->execute([':id' => $userId]);
        $sumWithdrawCoinPopup = (float)$sumWithdrawStmt->fetchColumn();
        ?>

        <div style="margin-top:18px; display:grid; grid-template-columns: repeat(auto-fit, minmax(200px,1fr)); gap:10px;">
            <div class="user-detail-box">
                <div class="user-detail-label">Toplam Yatırım (Onaylı)</div>
                <div style="font-size:15px; font-weight:600; color:#111827;">
                    <?= number_format($sumDepositTryPopup, 2) ?> TL
                </div>
            </div>
            <div class="user-detail-box">
                <div class="user-detail-label">Toplam Çekim (Onaylı)</div>
                <div style="font-size:15px; font-weight:600; color:#111827;">
                    <?= number_format($sumWithdrawCoinPopup, 6) ?> COIN
                </div>
            </div>
        </div>

    </div>
    <?php
    exit;
}

// Header
include __DIR__ . '/_admin_header.php';
?>

<div class="admin-page">
    <div class="admin-page-header">
        <h1>Kullanıcı Detayı: <?= htmlspecialchars($user['username']) ?></h1>
        <p>ID: #<?= (int) $user['id'] ?> |
           Kayıt: <?= htmlspecialchars($user['created_at']) ?> |
           Durum:
           <?php if ($user['is_banned']): ?>
               <span class="badge badge-danger">BANLI</span>
           <?php else: ?>
               <span class="badge badge-success">AKTİF</span>
           <?php endif; ?>
        </p>
    </div>

    <?php if ($ok === 'banned'): ?>
        <div class="alert alert-warning">Kullanıcı başarıyla banlandı.</div>
    <?php elseif ($ok === 'unbanned'): ?>
        <div class="alert alert-success">Kullanıcının banı kaldırıldı.</div>
    <?php elseif ($ok === 'adjustment'): ?>
        <div class="alert alert-success">Bakiye düzeltme işlemi başarıyla tamamlandı.</div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="admin-tabs">
        <a href="?id=<?= $userId ?>&tab=overview"
           class="tab-link <?= $currentTab === 'overview' ? 'is-active' : '' ?>">
            Genel Bakış & Cüzdan
        </a>
        <a href="?id=<?= $userId ?>&tab=transactions"
           class="tab-link <?= $currentTab === 'transactions' ? 'is-active' : '' ?>">
            İşlem Geçmişi
        </a>
        <a href="?id=<?= $userId ?>&tab=sites_activity"
           class="tab-link <?= $currentTab === 'sites_activity' ? 'is-active' : '' ?>">
            Bağlı Siteler & Aktiviteler
        </a>
    </div>

    <div class="admin-tab-content">
        <?php if ($currentTab === 'overview'): ?>
            <div class="admin-grid-2">
                <div class="admin-card">
                    <div class="admin-card-header">
                        <h2>Temel Bilgiler</h2>
                    </div>
                    <div class="admin-detail-list">
                        <p><strong>Username:</strong> <?= htmlspecialchars($user['username']) ?></p>
                        <p><strong>ID:</strong> #<?= (int) $user['id'] ?></p>
                        <p><strong>TRC20 Adresi:</strong> <code style="font-size: 11px;"><?= htmlspecialchars($user['trc20_address']) ?></code></p>
                        <p><strong>Kayıt Tarihi:</strong> <?= htmlspecialchars($user['created_at']) ?></p>
                    </div>

                    <div style="margin-top: 15px;">
                        <?php if ($user['is_banned']): ?>
                            <a href="user_detail.php?id=<?= $userId ?>&unban=1"
                               class="btn btn-success"
                               onclick="return confirm('Banı kaldırmak istediğine emin misin?');">
                                <i class="fa fa-unlock"></i> Banı Kaldır
                            </a>
                        <?php else: ?>
                            <a href="user_detail.php?id=<?= $userId ?>&ban=1"
                               class="btn btn-danger"
                               onclick="return confirm('Bu kullanıcıyı banlamak istediğine emin misin?');">
                                <i class="fa fa-ban"></i> Banla
                            </a>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="admin-card">
                    <div class="admin-card-header">
                        <h2>Cüzdan Bakiyeleri</h2>
                    </div>
                    <div class="admin-detail-list">
                        <p><strong>TRX Bakiyesi:</strong> <span class="badge badge-primary"><?= number_format($user['trx_balance'], 6) ?> TRX</span></p>
                        <p><strong>USDT Bakiyesi:</strong> <span class="badge badge-primary"><?= number_format($user['usdt_balance'], 6) ?> USDT</span></p>
                    </div>

                    <h3 style="margin-top: 20px;">Manuel Bakiye Düzeltme</h3>
                    <form method="post" action="user_detail.php?id=<?= $userId ?>&tab=overview">
                        <input type="hidden" name="action" value="adjust_balance">
                        <div class="filter-group">
                            <label>Coin Tipi</label>
                            <select name="coin_type" required>
                                <option value="TRX">TRX</option>
                                <option value="USDT">USDT</option>
                            </select>
                        </div>
                        <div class="filter-group">
                            <label>Miktar (+/-)</label>
                            <input type="number" step="0.000001" name="amount" placeholder="Örn: 100.00 veya -50.5" required>
                        </div>
                        <div class="filter-group">
                            <label>Gerekçe (Zorunlu)</label>
                            <input type="text" name="reason" placeholder="Örn: Hata Düzeltme, Bonus Yükleme" required>
                        </div>
                        <button type="submit" class="btn btn-warning">Bakiye Düzelt</button>
                    </form>
                </div>
            </div>

        <?php elseif ($currentTab === 'transactions'): ?>
            <div class="admin-stats-grid">
                <div class="admin-card">
                    <div class="admin-card-title">Toplam Yatırım (Onaylı)</div>
                    <div class="admin-card-value"><?= number_format($totalDepositTry, 2) ?> TL</div>
                </div>
                <div class="admin-card">
                    <div class="admin-card-title">Toplam Çekim (Onaylı)</div>
                    <div class="admin-card-value"><?= number_format($totalWithdrawCoin, 6) ?> COIN</div>
                </div>
            </div>

            <div class="admin-card" style="margin-top: 20px;">
                <div class="admin-card-header">
                    <h3>Son Yatırım Emirleri (Deposit Orders)</h3>
                </div>
                <div class="admin-table-wrapper">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Coin</th>
                                <th>TRY Miktarı</th>
                                <th>Coin Miktarı</th>
                                <th>Durum</th>
                                <th>Oluşturulma</th>
                                <th>Onaylanma</th>
                                <th>Admin ID</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!$deposits): ?>
                                <tr><td colspan="8" style="text-align:center;">Yatırım kaydı bulunamadı.</td></tr>
                            <?php else: ?>
                                <?php foreach ($deposits as $d): ?>
                                    <tr>
                                        <td>#<?= (int) $d['id'] ?></td>
                                        <td><?= htmlspecialchars($d['coin_type']) ?></td>
                                        <td><?= number_format((float)$d['amount_try'], 2) ?> TL</td>
                                        <td><?= number_format((float)$d['coin_amount'], 6) ?></td>
                                        <td><span class="badge badge-<?= $d['status'] === 'confirmed' ? 'success' : ($d['status'] === 'rejected' ? 'danger' : 'warning') ?>"><?= htmlspecialchars($d['status']) ?></span></td>
                                        <td><?= htmlspecialchars($d['created_at']) ?></td>
                                        <td><?= $d['confirmed_at'] ? htmlspecialchars($d['confirmed_at']) : '-' ?></td>
                                        <td><?= $d['admin_id'] ?? '-' ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="admin-card" style="margin-top: 20px;">
                <div class="admin-card-header">
                    <h3>Son Çekim Talepleri (Withdraw Requests)</h3>
                </div>
                <div class="admin-table-wrapper">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Coin</th>
                                <th>Miktar</th>
                                <th>Durum</th>
                                <th>Oluşturulma</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!$withdraws): ?>
                                <tr><td colspan="5" style="text-align:center;">Çekim talebi bulunamadı.</td></tr>
                            <?php else: ?>
                                <?php foreach ($withdraws as $w): ?>
                                    <tr>
                                        <td>#<?= (int) $w['id'] ?></td>
                                        <td><?= htmlspecialchars($w['coin_type']) ?></td>
                                        <td><?= number_format((float)$w['amount'], 6) ?></td>
                                        <td><span class="badge badge-<?= $w['status'] === 'approved' ? 'success' : ($w['status'] === 'rejected' ? 'danger' : 'warning') ?>"><?= htmlspecialchars($w['status']) ?></span></td>
                                        <td><?= htmlspecialchars($w['created_at']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        <?php elseif ($currentTab === 'sites_activity'): ?>
            <div class="admin-card">
                <div class="admin-card-header">
                    <h3>Bağlı Bahis Siteleri (User Sites)</h3>
                </div>
                <div class="admin-table-wrapper">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Site Adı</th>
                                <th>Site Username</th>
                                <th>Site Bakiyesi (TRY)</th>
                                <th>Bağlantı Tarihi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!$sites): ?>
                                <tr><td colspan="4" style="text-align:center;">Bağlı site kaydı bulunamadı.</td></tr>
                            <?php else: ?>
                                <?php foreach ($sites as $s): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($s['site_name']) ?></td>
                                        <td><?= htmlspecialchars($s['site_username']) ?></td>
                                        <td><?= number_format((float)$s['site_balance_try'], 2) ?> TL</td>
                                        <td><?= htmlspecialchars($s['linked_at']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="admin-card" style="margin-top: 20px;">
                <div class="admin-card-header">
                    <h3>Kullanıcı Aktivite Kayıtları (Son 50)</h3>
                </div>
                <div class="admin-table-wrapper">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Tarih</th>
                                <th>Taraf</th>
                                <th>Eylem</th>
                                <th>Detaylar</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!$logs): ?>
                                <tr><td colspan="4" style="text-align:center;">Aktivite kaydı bulunamadı.</td></tr>
                            <?php else: ?>
                                <?php foreach ($logs as $l): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($l['created_at']) ?></td>
                                        <td>
                                            <span class="badge badge-<?= $l['actor_type'] === 'admin' ? 'danger' : 'secondary' ?>">
                                                <?= $l['actor_type'] === 'admin' ? 'ADM: ' . ($l['admin_name'] ?? 'Bilinmeyen') : 'Kullanıcı' ?>
                                            </span>
                                        </td>
                                        <td><?= htmlspecialchars($l['action']) ?></td>
                                        <td style="font-size: 11px; white-space: pre-wrap;">
                                            <?= htmlspecialchars($l['meta_json']) ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        <?php endif; ?>
    </div>
</div>

<?php
// Footer
include __DIR__ . '/_admin_footer.php';