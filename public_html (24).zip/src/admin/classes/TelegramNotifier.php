<?php
// admin/classes/TelegramNotifier.php

class TelegramNotifier {
    
    // Senin verdiğin bilgiler
    private string $token = "8578330928:AAHtvldJx_NRnZrE-qrqKa9asts6rplgUDM";
    private string $chatId = "7054375811";

    public function send(string $message): void {
        // Mesaj boşsa gönderme
        if (empty($message)) return;

        // Emoji ekle (Otomatik)
        $message = "🤖 <b>BetWallet Supervisor</b>\n\n" . $message;

        $url = "https://api.telegram.org/bot" . $this->token . "/sendMessage";
        $data = [
            'chat_id' => $this->chatId,
            'text' => $message,
            'parse_mode' => 'HTML' // Kalın/İtalik yazı desteği
        ];

        // cURL ile isteği at (En sağlam yöntem)
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // SSL hatası almamak için
        
        $result = curl_exec($ch);
        curl_close($ch);
    }
}