<?php
declare(strict_types=1);

class BwIntelligence {

    private PDO $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    // Güvenli toplama (Asla float hatası yapmaz)
    private function getSum(string $sql, array $params = []): float {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return (float)($stmt->fetchColumn() ?? 0);
    }

    // BU FONKSİYON DURUMU KAYDEDER (Hafıza)
    public function recordSnapshot(): void {
        // 1. Verileri Topla
        $totalAgentCollateral = $this->getSum("SELECT SUM(system_balance) FROM deposit_agents WHERE role = 'agent'");
        $totalSiteDeposits = $this->getSum("SELECT SUM(amount_try) FROM site_deposit_requests WHERE status = 'completed'");
        
        $siteWithdrawPaid = $this->getSum("SELECT SUM(amount) FROM site_withdrawals WHERE status = 'completed'");
        $agentProfitPaid = $this->getSum("SELECT SUM(amount_after_fee) FROM agent_profit_withdraw_requests WHERE status = 'paid'");

        $pendingSite = $this->getSum("SELECT SUM(amount) FROM site_withdrawals WHERE status = 'pending'");
        $pendingAgent = $this->getSum("SELECT SUM(amount_after_fee) FROM agent_profit_withdraw_requests WHERE status = 'pending'");

        // 2. Hesapla
        $grossIn = $totalAgentCollateral + $totalSiteDeposits;
        $totalOut = $siteWithdrawPaid + $agentProfitPaid;
        
        $bossPoolNow = $grossIn - $totalOut;
        $shortTermLiability = $pendingSite + $pendingAgent;
        $netPosition = $bossPoolNow - $shortTermLiability;

        // 3. Veritabanına Kaydet
        $sql = "INSERT INTO system_metrics_history (boss_pool_balance, short_term_liability, net_position) VALUES (?, ?, ?)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$bossPoolNow, $shortTermLiability, $netPosition]);
    }

    // BU FONKSİYON GELECEĞİ TAHMİN EDER (Zeka)
    public function getAnalysis(): array {
        // En son veri
        $currentSql = "SELECT * FROM system_metrics_history ORDER BY id DESC LIMIT 1";
        $stmt = $this->pdo->query($currentSql);
        $current = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$current) {
            return [
                'prediction' => 'Veri toplanıyor... Henüz yeterli kayıt yok.',
                'tone' => 'neutral',
                'risk_score' => 0
            ];
        }

        // 1 Saat önceki veri (Trend için)
        $pastSql = "SELECT * FROM system_metrics_history WHERE created_at < DATE_SUB(NOW(), INTERVAL 1 HOUR) ORDER BY id DESC LIMIT 1";
        $stmt = $this->pdo->query($pastSql);
        $past = $stmt->fetch(PDO::FETCH_ASSOC);

        $bossPool = (float)$current['boss_pool_balance'];
        $liability = (float)$current['short_term_liability'];
        
        $burnRate = 0;
        $trend = 'stable';

        if ($past) {
            $pastPool = (float)$past['boss_pool_balance'];
            $diff = $bossPool - $pastPool;
            
            if ($diff < 0) {
                $burnRate = abs($diff); // Saatte eriyen miktar
                $trend = 'burning';
            }
        }

        // KARAR MEKANİZMASI
        $response = [
            'risk_score' => 0,
            'prediction' => '',
            'tone' => 'neutral' // safe, warning, danger, panic
        ];

        // 1. İFLAS DURUMU
        if ($liability > $bossPool) {
            $response['risk_score'] = 100;
            $response['tone'] = 'panic';
            $response['prediction'] = "KRİTİK İFLAS RİSKİ: Bekleyen ödemeler ($liability TL), eldeki parayı aşıyor. Ödemeleri hemen durdur!";
        }
        // 2. ERİME DURUMU
        elseif ($trend === 'burning' && $burnRate > 0) {
            $hoursLeft = $bossPool > 0 ? ($bossPool / $burnRate) : 0;
            
            if ($hoursLeft < 24) {
                $response['risk_score'] = 90;
                $response['tone'] = 'danger';
                $response['prediction'] = "KASA ERİYOR: Saatte " . number_format($burnRate,0) . " TL kaybediyorsun. Bu hızla $hoursLeft saat sonra kasa SIFIRLANACAK.";
            } else {
                $response['risk_score'] = 50;
                $response['tone'] = 'warning';
                $response['prediction'] = "DİKKAT: Nakit akışı negatif. Saatte ortalama " . number_format($burnRate,0) . " TL erime var.";
            }
        }
        // 3. GÜVENLİ
        else {
            $response['risk_score'] = 10;
            $response['tone'] = 'safe';
            $response['prediction'] = "Sistem stabil. Nakit akışı dengeli veya pozitif. Sorun yok.";
        }

        return $response;
    }
}