<?php
// admin/performance.php
session_start();
require __DIR__ . '/../../config/config.php';

// Güvenlik
if (!isset($_SESSION['admin_id']) && !isset($_SESSION['agent_id'])) {
    header('Location: admin_login.php');
    exit;
}

$pageTitle = 'Performans Analizi';

// --- TARİH FİLTRESİ ---
$range = $_GET['range'] ?? '7d'; 
$startDate = date('Y-m-d');
$endDate   = date('Y-m-d');
$periodTitle = "Son 7 Gün";

if ($range === 'today') {
    $startDate = date('Y-m-d');
    $periodTitle = "Bugün";
} elseif ($range === 'yesterday') {
    $startDate = date('Y-m-d', strtotime('-1 day'));
    $endDate   = date('Y-m-d', strtotime('-1 day'));
    $periodTitle = "Dün";
} elseif ($range === '7d') {
    $startDate = date('Y-m-d', strtotime('-6 days'));
    $periodTitle = "Son 7 Gün";
} elseif ($range === '30d') {
    $startDate = date('Y-m-d', strtotime('-29 days'));
    $periodTitle = "Son 30 Gün";
} elseif ($range === 'this_month') {
    $startDate = date('Y-m-01');
    $periodTitle = "Bu Ay";
} elseif ($range === 'all') {
    $startDate = '2020-01-01';
    $periodTitle = "Tüm Zamanlar";
}

$startTs = "$startDate 00:00:00";
$endTs   = "$endDate 23:59:59";

// SQL Koşulları
// Not: Prepared statement kullanımı güvenlik için daha iyidir ancak 
// mevcut yapıya dokunmadan sadece tema giydiriyoruz.
$dateSqlSimple = " AND created_at BETWEEN '$startTs' AND '$endTs' ";
$dateSqlJoined = " AND d.created_at BETWEEN '$startTs' AND '$endTs' ";

// --- SORGULAR ---

// 1. Temel Toplamlar
$stmt = $pdo->query("SELECT COALESCE(SUM(amount_try),0) FROM deposit_orders WHERE status IN ('approved','confirmed') $dateSqlSimple");
$totalDeposit = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM deposit_orders WHERE status IN ('approved','confirmed') $dateSqlSimple");
$totalTxn = $stmt->fetchColumn();

// 2. Agent Performansı
$agentPerf = $pdo->query("
    SELECT da.id, da.name, COUNT(d.id) as total_cnt, SUM(d.amount_try) as total_vol, AVG(d.amount_try) as avg_amount
    FROM deposit_orders d
    JOIN deposit_agents da ON da.id = d.agent_id
    WHERE d.status IN ('approved','confirmed') $dateSqlJoined
    GROUP BY d.agent_id, da.id, da.name
    ORDER BY total_vol DESC
")->fetchAll(PDO::FETCH_ASSOC);

// 3. Site Performansı
$sitePerf = $pdo->query("
    SELECT s.id, s.name, s.logo_url, COUNT(d.id) as total_cnt, SUM(d.amount_try) as total_vol
    FROM deposit_orders d
    JOIN sites s ON s.id = d.site_id
    WHERE d.status IN ('approved','confirmed') $dateSqlJoined
    GROUP BY d.site_id, s.id, s.name, s.logo_url
    ORDER BY total_vol DESC
")->fetchAll(PDO::FETCH_ASSOC);

// 4. En İyi Müşteriler
$topUsers = $pdo->query("
    SELECT u.id, u.username, COUNT(d.id) as cnt, SUM(d.amount_try) as total 
    FROM deposit_orders d
    JOIN users u ON u.id = d.user_id
    WHERE d.status IN ('approved','confirmed') $dateSqlJoined
    GROUP BY d.user_id, u.id, u.username
    ORDER BY total DESC LIMIT 20
")->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?> - BetWallet</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        /* TEMA DEĞİŞKENLERİ */
        :root { --primary: #c2273f; --primary-light: #fff1f2; --bg-body: #f1f5f9; --bg-card: #ffffff; --text-main: #1f2937; --text-muted: #6b7280; --border-color: #e5e7eb; --radius-md: 8px; }
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; }
        
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        .main-content { flex: 1; padding: 30px; overflow-y: auto; }
        
        /* TOPBAR */
        .topbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
        .topbar h1 { font-size: 24px; font-weight: 800; margin: 0; color: var(--text-main); }
        .topbar p { margin: 5px 0 0; color: var(--text-muted); font-size: 14px; }
        
        /* FİLTRE BUTONLARI */
        .filter-bar { display: flex; gap: 10px; margin-bottom: 25px; overflow-x: auto; padding-bottom: 5px; }
        .filter-btn { 
            display: inline-flex; align-items: center; gap: 6px; padding: 10px 16px; 
            background: #fff; border: 1px solid var(--border-color); border-radius: 30px; 
            color: var(--text-muted); font-size: 13px; font-weight: 600; text-decoration: none; transition: all 0.2s; white-space: nowrap;
        }
        .filter-btn:hover { border-color: var(--primary); color: var(--primary); }
        .filter-btn.active { background: var(--primary); border-color: var(--primary); color: #fff; }

        /* KPI KARTLARI */
        .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .kpi-card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); padding: 24px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); display: flex; align-items: center; justify-content: space-between; }
        .kpi-content div:first-child { font-size: 13px; font-weight: 600; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }
        .kpi-content div:last-child { font-size: 26px; font-weight: 800; color: var(--text-main); margin-top: 5px; }
        .kpi-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 24px; }
        .icon-green { background: #ecfdf5; color: #059669; }
        .icon-blue { background: #eff6ff; color: #2563eb; }

        /* TABLOLAR VE KARTLAR */
        .content-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px; }
        .card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .card-header { padding: 20px 24px; border-bottom: 1px solid var(--border-color); display: flex; align-items: center; gap: 10px; }
        .card-header h3 { font-size: 16px; font-weight: 700; margin: 0; color: var(--text-main); display: flex; align-items: center; gap: 8px; }

        .custom-table { width: 100%; border-collapse: collapse; }
        .custom-table th { text-align: left; padding: 14px 20px; font-size: 12px; font-weight: 600; text-transform: uppercase; color: var(--text-muted); border-bottom: 1px solid var(--border-color); background: #f8fafc; }
        .custom-table td { padding: 14px 20px; border-bottom: 1px solid var(--border-color); font-size: 13px; color: var(--text-main); vertical-align: middle; cursor: pointer; transition: background 0.1s; }
        .custom-table tr:hover td { background-color: #f8fafc; }
        .custom-table tr:last-child td { border-bottom: none; }

        .amount-bold { font-weight: 700; color: var(--text-main); }
        .rank-badge { width: 24px; height: 24px; background: #f1f5f9; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 700; color: var(--text-muted); margin-right: 8px; }
        .top-1 { background: #fef3c7; color: #d97706; } /* Altın */
        .top-2 { background: #f1f5f9; color: #64748b; } /* Gümüş */
        .top-3 { background: #ffedd5; color: #ea580c; } /* Bronz */

        /* MODAL */
        .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: none; align-items: center; justify-content: center; backdrop-filter: blur(4px); }
        .modal-content { background: #fff; width: 90%; max-width: 800px; border-radius: 16px; max-height: 85vh; display: flex; flex-direction: column; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25); animation: modalIn 0.2s ease-out; }
        .modal-header { padding: 20px 24px; border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center; }
        .modal-header h3 { margin: 0; font-size: 18px; font-weight: 700; }
        .modal-close { background: none; border: none; font-size: 24px; color: var(--text-muted); cursor: pointer; transition: color 0.2s; }
        .modal-close:hover { color: var(--text-main); }
        .modal-body { padding: 0; overflow-y: auto; flex: 1; }

        @keyframes modalIn { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
        
        /* Loader */
        .spinning-icon { animation: spin 1s linear infinite; }
        @keyframes spin { 100% { transform: rotate(360deg); } }
    </style>
</head>
<body>

<div class="app-wrapper">
    
    <?php include __DIR__ . '/_admin_header.php'; ?>

    <div class="main-content">
        
        <div class="topbar">
            <div>
                <h1>Performans Analizi</h1>
                <p>Finansal verilerin ve operasyonel metriklerin özeti.</p>
            </div>
            <div style="font-size: 13px; color: var(--text-muted); background: #fff; padding: 8px 16px; border-radius: 30px; border: 1px solid var(--border-color); font-weight: 500;">
                <i class="ri-calendar-event-line" style="vertical-align: text-bottom;"></i> 
                Dönem: <strong><?= htmlspecialchars($periodTitle) ?></strong>
            </div>
        </div>

        <div class="filter-bar">
            <a href="?range=today" class="filter-btn <?= $range=='today'?'active':'' ?>">Bugün</a>
            <a href="?range=yesterday" class="filter-btn <?= $range=='yesterday'?'active':'' ?>">Dün</a>
            <a href="?range=7d" class="filter-btn <?= $range=='7d'?'active':'' ?>">Son 7 Gün</a>
            <a href="?range=30d" class="filter-btn <?= $range=='30d'?'active':'' ?>">Son 30 Gün</a>
            <a href="?range=this_month" class="filter-btn <?= $range=='this_month'?'active':'' ?>">Bu Ay</a>
            <a href="?range=all" class="filter-btn <?= $range=='all'?'active':'' ?>">Tüm Zamanlar</a>
        </div>

        <div class="kpi-grid">
            <div class="kpi-card">
                <div class="kpi-content">
                    <div>Toplam Ciro</div>
                    <div><?= number_format($totalDeposit, 2, ',', '.') ?> ₺</div>
                </div>
                <div class="kpi-icon icon-green">
                    <i class="ri-wallet-3-line"></i>
                </div>
            </div>
            <div class="kpi-card">
                <div class="kpi-content">
                    <div>Toplam İşlem</div>
                    <div><?= number_format($totalTxn) ?> <span style="font-size:14px; font-weight:500; color:var(--text-muted);">Adet</span></div>
                </div>
                <div class="kpi-icon icon-blue">
                    <i class="ri-exchange-funds-line"></i>
                </div>
            </div>
        </div>

        <div class="content-grid">
            
            <div class="card">
                <div class="card-header">
                    <h3><i class="ri-user-star-line" style="color:#9333ea;"></i> Aracı Performansı</h3>
                </div>
                <table class="custom-table">
                    <thead><tr><th>Sıra</th><th>Aracı</th><th style="text-align:center;">İşlem</th><th style="text-align:right;">Hacim</th></tr></thead>
                    <tbody>
                        <?php $i=1; foreach($agentPerf as $a): 
                            $rankClass = ($i==1)?'top-1':(($i==2)?'top-2':(($i==3)?'top-3':''));
                        ?>
                        <tr onclick="openDetail('agent', <?= $a['id'] ?>, '<?= htmlspecialchars($a['name']) ?>')">
                            <td width="50"><span class="rank-badge <?= $rankClass ?>"><?= $i++ ?></span></td>
                            <td style="font-weight:600;"><?= htmlspecialchars($a['name']) ?></td>
                            <td style="text-align:center;"><?= $a['total_cnt'] ?></td>
                            <td style="text-align:right;" class="amount-bold"><?= number_format($a['total_vol'], 0, ',', '.') ?> ₺</td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($agentPerf)): ?><tr><td colspan="4" style="text-align:center; padding:20px; color:var(--text-muted);">Veri yok.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3><i class="ri-global-line" style="color:#0ea5e9;"></i> Site Performansı</h3>
                </div>
                <table class="custom-table">
                    <thead><tr><th>Sıra</th><th>Site</th><th style="text-align:center;">İşlem</th><th style="text-align:right;">Hacim</th></tr></thead>
                    <tbody>
                        <?php $i=1; foreach($sitePerf as $s): 
                             $rankClass = ($i==1)?'top-1':(($i==2)?'top-2':(($i==3)?'top-3':''));
                        ?>
                        <tr onclick="openDetail('site', <?= $s['id'] ?>, '<?= htmlspecialchars($s['name']) ?>')">
                            <td width="50"><span class="rank-badge <?= $rankClass ?>"><?= $i++ ?></span></td>
                            <td>
                                <div style="display:flex; align-items:center; gap:8px; font-weight:600;">
                                    <?php if($s['logo_url']): ?><img src="<?= $s['logo_url'] ?>" width="20" height="20" style="border-radius:4px; object-fit:contain;"><?php endif; ?>
                                    <?= htmlspecialchars($s['name']) ?>
                                </div>
                            </td>
                            <td style="text-align:center;"><?= $s['total_cnt'] ?></td>
                            <td style="text-align:right;" class="amount-bold"><?= number_format($s['total_vol'], 0, ',', '.') ?> ₺</td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($sitePerf)): ?><tr><td colspan="4" style="text-align:center; padding:20px; color:var(--text-muted);">Veri yok.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="card" style="grid-column: 1 / -1;">
                <div class="card-header">
                    <h3><i class="ri-vip-crown-line" style="color:#f59e0b;"></i> En Yüksek Yatırımcılar (Whales)</h3>
                </div>
                <table class="custom-table">
                    <thead><tr><th>Sıra</th><th>Kullanıcı</th><th style="text-align:center;">İşlem Adedi</th><th style="text-align:right;">Toplam Yatırım</th></tr></thead>
                    <tbody>
                        <?php $i=1; foreach($topUsers as $u): 
                            $rankClass = ($i==1)?'top-1':(($i==2)?'top-2':(($i==3)?'top-3':''));
                        ?>
                        <tr onclick="openDetail('user', <?= $u['id'] ?>, '<?= htmlspecialchars($u['username']) ?>')">
                            <td width="50"><span class="rank-badge <?= $rankClass ?>"><?= $i++ ?></span></td>
                            <td style="font-weight:600; color:var(--text-main);"><?= htmlspecialchars($u['username']) ?></td>
                            <td style="text-align:center;"><?= $u['cnt'] ?></td>
                            <td style="text-align:right; color:#16a34a; font-weight:700;"><?= number_format($u['total'], 2, ',', '.') ?> ₺</td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($topUsers)): ?><tr><td colspan="4" style="text-align:center; padding:20px; color:var(--text-muted);">Veri yok.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>

    </div>

</div>

<div id="detailModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalTitle">Detaylar</h3>
            <button class="modal-close" onclick="closeModal()"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body" id="modalBody">
            <div style="text-align:center; padding:50px; color:var(--text-muted);">
                <i class="ri-loader-4-line spinning-icon" style="font-size:32px;"></i><br>Yükleniyor...
            </div>
        </div>
    </div>
</div>

<script>
function openDetail(type, id, name) {
    const modal = document.getElementById('detailModal');
    const title = document.getElementById('modalTitle');
    const body  = document.getElementById('modalBody');

    modal.style.display = 'flex';
    title.innerText = name + " - Detaylı Analiz";
    body.innerHTML = '<div style="text-align:center; padding:50px; color:#64748b;"><i class="ri-loader-4-line spinning-icon" style="font-size:32px;"></i><br><br>Veriler Yükleniyor...</div>';

    // TARİHLERİ GÜVENLİ HALE GETİR
    const start = encodeURIComponent('<?= $startTs ?>');
    const end   = encodeURIComponent('<?= $endTs ?>');

    // AJAX İSTEĞİ (Backend tarafında ajax_get_performance_detail.php dosyası olmalı)
    fetch(`ajax_get_performance_detail.php?type=${type}&id=${id}&start=${start}&end=${end}`)
        .then(response => {
            if (!response.ok) throw new Error("Veri çekilemedi.");
            return response.text();
        })
        .then(html => {
            body.innerHTML = html;
        })
        .catch(error => {
            body.innerHTML = `<div style="text-align:center; padding:30px; color:#dc2626;">
                                <i class="ri-error-warning-line" style="font-size:32px;"></i><br>
                                <strong>Hata!</strong><br><small>${error.message}</small>
                              </div>`;
        });
}

function closeModal() {
    document.getElementById('detailModal').style.display = 'none';
}

// Modal dışına tıklayınca kapat
window.onclick = function(event) {
    const modal = document.getElementById('detailModal');
    if (event.target == modal) {
        closeModal();
    }
}
</script>

<?php include __DIR__ . '/_admin_footer.php'; ?>
</body>
</html>