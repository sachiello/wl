<?php
// admin/ajax_get_performance_detail.php


session_start();
require __DIR__ . '/../../config/config.php';

if (!isset($_SESSION['admin_id'])) exit('<div style="color:red; padding:20px;">Yetkisiz Erişim</div>');

$type  = $_GET['type'] ?? '';
$id    = (int)($_GET['id'] ?? 0);
$start = $_GET['start'] ?? date('Y-m-d 00:00:00');
$end   = $_GET['end']   ?? date('Y-m-d 23:59:59');

if (!$id || !$type) exit('<div style="color:red; padding:20px;">Eksik Parametre</div>');

try {

    // =========================================================
    // 1. AGENT (ARACI) DETAYLARI
    // =========================================================
    if ($type === 'agent') {
        // Agent Bilgisi
        $stmt = $pdo->prepare("SELECT * FROM deposit_agents WHERE id = ?");
        $stmt->execute([$id]);
        $agent = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$agent) exit('<p style="text-align:center; padding:20px;">Aracı bulunamadı.</p>');

        // IBAN
        $stmt = $pdo->prepare("SELECT COUNT(*) as total, SUM(is_active) as active FROM deposit_ibans WHERE agent_id = ?");
        $stmt->execute([$id]);
        $ibanStats = $stmt->fetch(PDO::FETCH_ASSOC);

        // Performans
        $stmt = $pdo->prepare("SELECT COUNT(*) as cnt, COALESCE(SUM(amount_try),0) as vol FROM deposit_orders WHERE agent_id=? AND status IN ('approved','confirmed') AND created_at BETWEEN ? AND ?");
        $stmt->execute([$id, $start, $end]);
        $perf = $stmt->fetch(PDO::FETCH_ASSOC);

        // Kota
        $limit = (float)$agent['quota_limit'];
        $used = (float)$agent['quota_used'];
        $pct = ($limit > 0) ? min(100, ($used/$limit)*100) : 0;
        $barColor = $pct > 90 ? '#ef4444' : '#3b82f6';

        ?>
        <style>
            .info-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; }
            .info-card { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 15px; position: relative; overflow: hidden; }
            .lbl { font-size: 11px; color: #64748b; font-weight: 700; text-transform: uppercase; margin-bottom: 5px; }
            .val { font-size: 18px; font-weight: 800; color: #0f172a; }
            .icn { position: absolute; top: 15px; right: 15px; font-size: 24px; opacity: 0.1; color: #0f172a; }
        </style>

        <div style="display:flex; align-items:center; gap:15px; margin-bottom:20px; padding-bottom:20px; border-bottom:1px solid #f1f5f9;">
            <div style="width:50px; height:50px; background:#eff6ff; color:#3b82f6; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:24px;"><i class="ri-user-star-line"></i></div>
            <div>
                <h2 style="margin:0; font-size:18px;"><?= htmlspecialchars($agent['name']) ?></h2>
                <div style="font-size:13px; color:#64748b;"><?= $agent['phone'] ?: 'Telefon Yok' ?> • <?= $agent['is_active']?'Aktif':'Pasif' ?></div>
            </div>
            <div style="margin-left:auto; text-align:right;">
                <div class="lbl">Bakiye</div>
                <div style="font-size:20px; font-weight:800; color:#3b82f6;"><?= number_format($agent['balance'],2) ?> ₺</div>
            </div>
        </div>

        <div class="info-grid">
            <div class="info-card" style="background:#f0fdf4; border-color:#bbf7d0;">
                <i class="ri-money-dollar-circle-line icn" style="color:#16a34a; opacity:0.2;"></i>
                <div class="lbl" style="color:#15803d;">Dönem Cirosu</div>
                <div class="val" style="color:#166534;"><?= number_format($perf['vol'], 2) ?> ₺</div>
                <div style="font-size:11px; color:#15803d; margin-top:4px;"><?= $perf['cnt'] ?> İşlem</div>
            </div>
            <div class="info-card">
                <i class="ri-percent-line icn"></i>
                <div class="lbl">Komisyon</div>
                <div class="val">%<?= number_format($agent['commission_rate'], 2) ?></div>
            </div>
            <div class="info-card">
                <i class="ri-bank-card-line icn"></i>
                <div class="lbl">IBAN Durumu</div>
                <div class="val"><?= $ibanStats['total'] ?> <small style="font-size:12px; font-weight:600; color:#64748b;">Adet</small></div>
                <div style="font-size:11px; color:#64748b; margin-top:4px;"><?= (int)$ibanStats['active'] ?> Aktif</div>
            </div>
            <div class="info-card">
                <i class="ri-pie-chart-line icn"></i>
                <div class="lbl">Kota</div>
                <?php if($limit > 0): ?>
                    <div class="val" style="font-size:15px;"><?= number_format($used,0,'','.') ?> / <?= number_format($limit,0,'','.') ?></div>
                    <div style="height:4px; background:#e2e8f0; margin-top:8px; border-radius:2px;"><div style="width:<?= $pct ?>%; height:100%; background:<?= $barColor ?>;"></div></div>
                <?php else: ?>
                    <div class="val" style="color:#3b82f6;">Sınırsız</div>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    // =========================================================
    // 2. USER (KULLANICI) DETAYLARI
    // =========================================================
    elseif ($type === 'user') {
        // Kullanıcı Bilgisi
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$user) exit('<p style="text-align:center;">Kullanıcı bulunamadı.</p>');

        // Cüzdan Bakiyeleri
        $stmt = $pdo->prepare("SELECT coin_type, balance FROM wallets WHERE user_id = ?");
        $stmt->execute([$id]);
        $wallets = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

        // --- SQL UNION (DÜZELTİLMİŞ VERSİYON) ---
        // CAST(... AS CHAR) kullanarak Collation hatasını engelliyoruz.
        
        $sqlHistory = "
            (SELECT 
                CAST('deposit' AS CHAR) as txn_type, 
                id, 
                amount_try as amount, 
                CAST(status AS CHAR) as status, 
                created_at, 
                CAST(payment_method AS CHAR) as info 
             FROM deposit_orders WHERE user_id = :uid)
            
            UNION ALL
            
            (SELECT 
                CAST('withdraw' AS CHAR) as txn_type, 
                id, 
                amount, 
                CAST(status AS CHAR) as status, 
                created_at, 
                CAST(coin_type AS CHAR) as info 
             FROM withdraw_requests WHERE user_id = :uid)
            
            UNION ALL
            
            (SELECT 
                CAST('site_transfer' AS CHAR) as txn_type, 
                sdr.id, 
                sdr.amount_try as amount, 
                CAST(sdr.status AS CHAR) as status, 
                sdr.created_at, 
                CAST(s.name AS CHAR) as info 
             FROM site_deposit_requests sdr 
             JOIN sites s ON s.id = sdr.site_id 
             WHERE sdr.user_id = :uid)
             
            ORDER BY created_at DESC LIMIT 100
        ";
        
        $stmt = $pdo->prepare($sqlHistory);
        $stmt->execute([':uid' => $id]);
        $history = $stmt->fetchAll(PDO::FETCH_ASSOC);

        ?>
        <style>
            .wallet-box { background: #1e293b; color: #fff; padding: 15px; border-radius: 10px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
            .wb-title { font-size: 12px; opacity: 0.7; text-transform: uppercase; font-weight: 600; }
            .wb-amount { font-size: 20px; font-weight: 700; letter-spacing: 0.5px; }
            .wb-icon { width: 40px; height: 40px; background: rgba(255,255,255,0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 20px; }

            .hist-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            .hist-table th { text-align: left; font-size: 11px; color: #64748b; text-transform: uppercase; padding: 10px 5px; border-bottom: 1px solid #e2e8f0; }
            .hist-table td { padding: 12px 5px; border-bottom: 1px solid #f8fafc; font-size: 13px; color: #334155; }
            
            .txn-icon { width: 32px; height: 32px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 16px; }
            .txn-deposit { background: #dcfce7; color: #15803d; }
            .txn-withdraw { background: #fee2e2; color: #b91c1c; }
            .txn-site { background: #eff6ff; color: #1d4ed8; }

            .st-badge { padding: 2px 8px; border-radius: 4px; font-size: 10px; font-weight: 700; text-transform: uppercase; }
            .st-pending { background: #ffedd5; color: #9a3412; }
            .st-success { background: #dcfce7; color: #15803d; }
            .st-danger { background: #fee2e2; color: #b91c1c; }
        </style>

        <div style="display:flex; align-items:center; gap:15px; margin-bottom:20px; padding-bottom:15px; border-bottom:1px solid #f1f5f9;">
            <div style="width:50px; height:50px; background:#f1f5f9; color:#475569; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:24px; font-weight:700;">
                <?= strtoupper(substr($user['username'], 0, 1)) ?>
            </div>
            <div>
                <h2 style="margin:0; font-size:18px;"><?= htmlspecialchars($user['username']) ?></h2>
                <div style="font-size:12px; color:#64748b;">
                    Kayıt: <?= date('d.m.Y', strtotime($user['created_at'])) ?> • ID: #<?= $user['id'] ?>
                </div>
            </div>
            <div style="margin-left:auto;">
                <?php if($user['is_banned']): ?>
                    <span style="background:#fee2e2; color:#991b1b; padding:5px 10px; border-radius:20px; font-size:11px; font-weight:700;">YASAKLI</span>
                <?php else: ?>
                    <span style="background:#dcfce7; color:#166534; padding:5px 10px; border-radius:20px; font-size:11px; font-weight:700;">AKTİF</span>
                <?php endif; ?>
            </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
            <div class="wallet-box" style="background: linear-gradient(135deg, #0f172a, #334155);">
                <div>
                    <div class="wb-title">USDT Bakiyesi</div>
                    <div class="wb-amount"><?= number_format($wallets['USDT'] ?? 0, 2) ?> <small>USDT</small></div>
                </div>
                <div class="wb-icon"><i class="ri-money-dollar-circle-line"></i></div>
            </div>
            <div class="wallet-box" style="background: linear-gradient(135deg, #dc2626, #ef4444);">
                <div>
                    <div class="wb-title">TRX Bakiyesi</div>
                    <div class="wb-amount"><?= number_format($wallets['TRX'] ?? 0, 2) ?> <small>TRX</small></div>
                </div>
                <div class="wb-icon"><i class="ri-exchange-funds-line"></i></div>
            </div>
        </div>

        <div style="margin-top:10px; padding:10px 15px; background:#f8fafc; border-radius:8px; border:1px solid #e2e8f0;">
            <div style="font-size:11px; color:#64748b; font-weight:700; text-transform:uppercase;">TRC20 Adresi</div>
            <div style="font-family:monospace; color:#334155; font-size:12px; word-break:break-all; margin-top:2px;">
                <?= htmlspecialchars($user['trc20_address']) ?>
            </div>
        </div>

        <h3 style="margin: 25px 0 10px 0; font-size: 15px; color: #1e293b; display: flex; align-items: center; gap: 8px;">
            <i class="ri-history-line"></i> Tüm Hareketler
        </h3>
        
        <div style="max-height: 400px; overflow-y: auto;">
            <table class="hist-table">
                <thead>
                    <tr>
                        <th style="width: 50px;">Tür</th>
                        <th>Detay</th>
                        <th>Tutar</th>
                        <th>Durum</th>
                        <th style="text-align: right;">Tarih</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($history)): ?>
                        <tr><td colspan="5" style="text-align:center; padding:20px; color:#94a3b8;">Henüz işlem yok.</td></tr>
                    <?php else: ?>
                        <?php foreach($history as $h): 
                            $icon = 'ri-question-line';
                            $class = 'txn-deposit';
                            $label = 'Bilinmiyor';
                            $amountColor = '#334155';
                            $prefix = '';

                            if ($h['txn_type'] === 'deposit') {
                                $icon = 'ri-arrow-left-down-line'; 
                                $class = 'txn-deposit';
                                $label = 'Yatırım (' . strtoupper($h['info']) . ')';
                                $amountColor = '#16a34a'; 
                                $prefix = '+';
                            } elseif ($h['txn_type'] === 'withdraw') {
                                $icon = 'ri-arrow-right-up-line'; 
                                $class = 'txn-withdraw';
                                $label = 'Çekim (' . strtoupper($h['info']) . ')';
                                $amountColor = '#dc2626'; 
                                $prefix = '-';
                            } elseif ($h['txn_type'] === 'site_transfer') {
                                $icon = 'ri-share-forward-line'; 
                                $class = 'txn-site';
                                $label = 'Site: ' . htmlspecialchars($h['info']);
                                $amountColor = '#2563eb'; 
                                $prefix = '-';
                            }

                            $stClass = 'st-pending';
                            $stLabel = 'Bekliyor';
                            $rawSt = strtolower($h['status']);
                            if(in_array($rawSt, ['approved','confirmed','completed','success'])) {
                                $stClass = 'st-success'; $stLabel = 'Onaylı';
                            } elseif(in_array($rawSt, ['rejected','failed','canceled'])) {
                                $stClass = 'st-danger'; $stLabel = 'Red/Hata';
                            } elseif($rawSt == 'expired') {
                                $stClass = 'st-danger'; $stLabel = 'Süre Doldu';
                            }
                        ?>
                        <tr>
                            <td><div class="txn-icon <?= $class ?>"><i class="<?= $icon ?>"></i></div></td>
                            <td>
                                <div style="font-weight: 600;"><?= $label ?></div>
                                <div style="font-size: 11px; color: #64748b;">ID: #<?= $h['id'] ?></div>
                            </td>
                            <td style="font-weight: 700; font-size: 14px; color: <?= $amountColor ?>;">
                                <?= $prefix . number_format($h['amount'], 2) ?>
                            </td>
                            <td><span class="st-badge <?= $stClass ?>"><?= $stLabel ?></span></td>
                            <td style="text-align: right; font-size: 11px; color: #64748b;">
                                <?= date('d.m.Y', strtotime($h['created_at'])) ?><br>
                                <?= date('H:i', strtotime($h['created_at'])) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    // =========================================================
    // 3. SITE DETAYLARI
    // =========================================================
    elseif ($type === 'site') {
        $sql = "SELECT * FROM deposit_orders WHERE site_id = ? AND status IN ('approved','confirmed') AND created_at BETWEEN ? AND ? ORDER BY id DESC LIMIT 50";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id, $start, $end]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($rows)) {
            echo '<p style="text-align:center; padding:20px; color:#94a3b8;">Kayıt yok.</p>';
        } else {
            echo '<table style="width:100%; border-collapse:collapse;"><thead><tr style="text-align:left; color:#64748b; font-size:11px; text-transform:uppercase;"><th style="padding:10px;">Tarih</th><th>Kullanıcı</th><th>Tutar</th></tr></thead><tbody>';
            foreach ($rows as $r) {
                echo '<tr style="border-bottom:1px solid #f1f5f9; font-size:13px;">';
                echo '<td style="padding:10px;">' . date('d.m H:i', strtotime($r['created_at'])) . '</td>';
                echo '<td>User #' . $r['user_id'] . '</td>';
                echo '<td style="font-weight:700; color:#16a34a;">' . number_format($r['amount_try'], 2) . ' ₺</td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
        }
    }

} catch (Exception $e) {
    echo '<div style="color:red; padding:10px; border:1px solid red; background:#fee2e2;">
            <strong>SQL Hatası:</strong> ' . $e->getMessage() . '
          </div>';
}
?>