<?php
// admin/admin_sites.php
require __DIR__ . '/require_admin.php'; // $pdo + $currentAdmin

$pageTitle = 'Site Yönetimi';
$activeNav = 'sites';

$adminError   = null;
$adminSuccess = null;
$csrfFailed   = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !csrf_validate_request()) {
    $csrfFailed = true;
    $adminError = 'Oturum doğrulaması başarısız. Lütfen formu yenileyip tekrar deneyin.';
}

// Silme
if (!$csrfFailed && isset($_POST['delete_site'])) {
    $id = (int)$_POST['delete_site'];
    $stmt = $pdo->prepare("DELETE FROM sites WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: admin_sites.php?ok=deleted');
    exit;
}

// Kaydetme (yeni / düzenle)
if (!$csrfFailed && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_site'])) {
    $id             = isset($_POST['id']) && $_POST['id'] !== '' ? (int)$_POST['id'] : null;
    $name           = trim($_POST['name'] ?? '');
    $slug           = trim($_POST['slug'] ?? '');
    $logoUrl        = trim($_POST['logo_url'] ?? '');
    $registerUrl    = trim($_POST['register_url'] ?? '');
    $commissionRate = (float)($_POST['commission_rate'] ?? 4.0);
    $siteUsername   = trim($_POST['site_username'] ?? '');
    $sitePassword   = trim($_POST['site_password'] ?? '');
    $isActive       = isset($_POST['is_active']) ? 1 : 0;

    if ($name === '' || $slug === '' || $siteUsername === '') {
        $adminError = 'Site adı, slug ve site kullanıcı adı zorunlu.';
    } else {
        if ($id) {
            // GÜNCELLE
            $passwordSql = '';
            $params = [$name, $slug, $logoUrl, $registerUrl, $isActive, $commissionRate, $siteUsername];
            if ($sitePassword !== '') {
                $hashedPassword = password_hash($sitePassword, PASSWORD_DEFAULT);
                $passwordSql = ', site_password = ?';
                $params[] = $hashedPassword;
            }
            $params[] = $id;

            $stmt = $pdo->prepare("
                UPDATE sites
                SET name = ?, slug = ?, logo_url = ?, register_url = ?, is_active = ?,
                    commission_rate = ?, site_username = ?
                    $passwordSql
                WHERE id = ?
            ");
            $stmt->execute($params);
            $adminSuccess = 'Site başarıyla güncellendi.';
        } else {
            // YENİ EKLE
            if ($sitePassword === '') {
                 $adminError = 'Yeni site için şifre zorunludur.';
            } else {
                $hashedPassword = password_hash($sitePassword, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("
                    INSERT INTO sites (name, slug, logo_url, register_url, is_active, commission_rate, site_username, site_password, balance)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
                ");
                $stmt->execute([$name, $slug, $logoUrl, $registerUrl, $isActive, $commissionRate, $siteUsername, $hashedPassword]);
                $adminSuccess = 'Yeni site sisteme eklendi.';
            }
        }
    }
}

// Düzenlenecek kayıt
$editSite = null;
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM sites WHERE id = ? LIMIT 1");
    $stmt->execute([$id]);
    $editSite = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Liste
$listStmt = $pdo->query("SELECT * FROM sites ORDER BY id DESC");
$sites = $listStmt->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/_admin_header.php';
?>

<style>
    /* Grid Form Yapısı */
    .form-card {
        background: #fff;
        padding: 24px;
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-soft);
        margin-bottom: 30px;
        border: 1px solid var(--border-light);
    }
    
    .form-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        padding-bottom: 15px;
        border-bottom: 1px solid var(--border-light);
    }
    
    .form-header h2 { margin: 0; font-size: 18px; color: var(--text-main); display: flex; align-items: center; gap: 8px; }

    .admin-form-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
    }

    .form-group { margin-bottom: 0; }
    .form-group label { display: block; font-size: 13px; font-weight: 600; color: var(--text-muted); margin-bottom: 6px; }
    .form-input { 
        width: 100%; padding: 10px 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-light); 
        background: #f8fafc; color: var(--text-main); font-size: 14px; transition: all 0.2s; 
    }
    .form-input:focus { outline: none; border-color: var(--primary); background: #fff; box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1); }
    
    .full-width { grid-column: 1 / -1; }

    /* Butonlar */
    .btn-submit {
        background: var(--primary); color: #fff; border: none; padding: 12px 24px; border-radius: var(--radius-sm);
        font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; transition: all 0.2s;
    }
    .btn-submit:hover { background: #2563eb; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(37,99,235,0.2); }

    .btn-cancel {
        background: #f1f5f9; color: var(--text-muted); border: 1px solid var(--border-light); padding: 12px 20px; border-radius: var(--radius-sm);
        text-decoration: none; font-size: 14px; font-weight: 500; display: inline-flex; align-items: center; gap: 5px;
    }
    .btn-cancel:hover { background: #e2e8f0; color: var(--text-main); }

    /* Tablo Badge */
    .status-badge { padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
    .status-active { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
    .status-passive { background: #f1f5f9; color: #64748b; border: 1px solid #e2e8f0; }

    /* Alert */
    .alert-box { padding: 15px; border-radius: var(--radius-sm); margin-bottom: 20px; display: flex; align-items: center; gap: 10px; font-size: 14px; }
    .alert-danger { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
    .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; }

    /* İkon Butonlar */
    .action-btn { width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; text-decoration: none; transition: all 0.2s; }
    .btn-edit { background: #eff6ff; color: var(--primary); }
    .btn-edit:hover { background: var(--primary); color: #fff; }
    .btn-del { background: #fef2f2; color: #dc2626; }
    .btn-del:hover { background: #dc2626; color: #fff; }
</style>

<div class="page-content">

    <?php if ($adminError): ?>
        <div class="alert-box alert-danger">
            <i class="ri-error-warning-fill" style="font-size: 18px;"></i>
            <?= htmlspecialchars($adminError) ?>
        </div>
    <?php endif; ?>
    
    <?php if ($adminSuccess || (isset($_GET['ok']) && $_GET['ok'] == 'deleted')): ?>
        <div class="alert-box alert-success">
            <i class="ri-checkbox-circle-fill" style="font-size: 18px;"></i>
            <?= htmlspecialchars($adminSuccess ?? 'İşlem başarıyla tamamlandı.') ?>
        </div>
    <?php endif; ?>

    <div class="form-card">
        <div class="form-header">
            <h2>
                <i class="ri-global-line" style="color: var(--primary);"></i>
                <?= $editSite ? 'Siteyi Düzenle' : 'Yeni Site Ekle' ?>
            </h2>
            <?php if ($editSite): ?>
                <a href="admin_sites.php" class="btn-cancel"><i class="ri-close-line"></i> İptal</a>
            <?php endif; ?>
        </div>

        <form method="post">
            <?= csrf_field(); ?>
            <?php if ($editSite): ?>
                <input type="hidden" name="id" value="<?= (int)$editSite['id'] ?>">
            <?php endif; ?>

            <div class="admin-form-grid">
                <div class="form-group">
                    <label>Site Adı</label>
                    <input type="text" name="name" class="form-input" placeholder="Örn: BetWallet Bet"
                           value="<?= htmlspecialchars($editSite['name'] ?? '') ?>" required>
                </div>

                <div class="form-group">
                    <label>Slug (Kısa Kod)</label>
                    <input type="text" name="slug" class="form-input" placeholder="Örn: betwallet"
                           value="<?= htmlspecialchars($editSite['slug'] ?? '') ?>" required>
                </div>

                <div class="form-group">
                    <label>Logo URL</label>
                    <input type="text" name="logo_url" class="form-input" placeholder="https://..."
                           value="<?= htmlspecialchars($editSite['logo_url'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label>Kayıt Linki</label>
                    <input type="text" name="register_url" class="form-input" placeholder="https://site.com/register"
                           value="<?= htmlspecialchars($editSite['register_url'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label>Komisyon Oranı (%)</label>
                    <input type="number" step="0.01" min="0" name="commission_rate" class="form-input"
                           value="<?= htmlspecialchars($editSite['commission_rate'] ?? '4.0') ?>">
                </div>

                <div class="form-group">
                    <label>Panel Kullanıcı Adı</label>
                    <input type="text" name="site_username" class="form-input" autocomplete="off"
                           value="<?= htmlspecialchars($editSite['site_username'] ?? '') ?>" required>
                </div>

                <div class="form-group">
                    <label>Panel Şifresi</label>
                    <input type="password" name="site_password" class="form-input" autocomplete="new-password"
                           placeholder="<?= $editSite ? 'Değişmeyecekse boş bırakın' : 'Şifre belirleyin' ?>">
                </div>

                <div class="form-group" style="display: flex; align-items: flex-end;">
                    <label class="checkbox-label" style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-weight: 600; color: var(--text-main);">
                        <input type="checkbox" name="is_active" style="width: 18px; height: 18px;"
                            <?= isset($editSite['is_active']) ? ($editSite['is_active'] ? 'checked' : '') : 'checked' ?>>
                        <span>Siteyi Aktif Et</span>
                    </label>
                </div>

                <div class="full-width" style="margin-top: 10px;">
                    <button type="submit" name="save_site" class="btn-submit">
                        <i class="ri-save-line"></i>
                        <?= $editSite ? 'Değişiklikleri Kaydet' : 'Siteyi Oluştur' ?>
                    </button>
                </div>
            </div>
        </form>
    </div>

    <div class="table-container">
        <table class="admin-table">
            <thead>
                <tr>
                    <th style="width: 50px;">ID</th>
                    <th>Site Bilgisi</th>
                    <th>Komisyon</th>
                    <th>Bakiye</th>
                    <th>Durum</th>
                    <th style="text-align: right;">İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($sites as $s): ?>
                <tr>
                    <td><span style="font-family: monospace; color: var(--text-muted);">#<?= (int)$s['id'] ?></span></td>
                    
                    <td>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <?php if(!empty($s['logo_url'])): ?>
                                <img src="<?= htmlspecialchars($s['logo_url']) ?>" style="width: 24px; height: 24px; object-fit: contain; border-radius: 4px;">
                            <?php else: ?>
                                <div style="width: 24px; height: 24px; background: #f1f5f9; border-radius: 4px; display: flex; align-items: center; justify-content: center;">
                                    <i class="ri-image-line" style="color: #94a3b8; font-size: 12px;"></i>
                                </div>
                            <?php endif; ?>
                            <div>
                                <div style="font-weight: 600; color: var(--text-main);"><?= htmlspecialchars($s['name']) ?></div>
                                <div style="font-size: 11px; color: var(--text-muted);"><?= htmlspecialchars($s['slug']) ?></div>
                            </div>
                        </div>
                    </td>

                    <td>
                        <span style="font-weight: 600; color: var(--text-main);">%<?= number_format($s['commission_rate'] ?? 0, 2) ?></span>
                    </td>
                    
                    <td>
                        <span style="font-family: monospace; font-weight: 600; color: var(--primary);">
                            <?= number_format($s['balance'] ?? 0, 2, ',', '.') ?> <small>TL</small>
                        </span>
                    </td>

                    <td>
                        <?php if($s['is_active']): ?>
                            <span class="status-badge status-active">Aktif</span>
                        <?php else: ?>
                            <span class="status-badge status-passive">Pasif</span>
                        <?php endif; ?>
                    </td>

                    <td style="text-align: right;">
                        <div style="display: inline-flex; gap: 5px;">
                            <a href="admin_sites.php?edit=<?= (int)$s['id'] ?>" class="action-btn btn-edit" title="Düzenle">
                                <i class="ri-pencil-line"></i>
                            </a>
                            <form method="post" style="display:inline;" onsubmit="return confirm('<?= htmlspecialchars($s['name']) ?> sitesini silmek istediğinize emin misiniz?');">
                                <?= csrf_field(); ?>
                                <input type="hidden" name="delete_site" value="<?= (int)$s['id'] ?>">
                                <button type="submit" class="action-btn btn-del" title="Sil" style="border:none; background:none; cursor:pointer;">
                                    <i class="ri-delete-bin-line"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                
                <?php if(empty($sites)): ?>
                <tr>
                    <td colspan="6" style="text-align: center; padding: 40px; color: var(--text-muted);">
                        <i class="ri-global-line" style="font-size: 48px; opacity: 0.5; margin-bottom: 10px; display: block;"></i>
                        Henüz hiç site eklenmemiş.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/_admin_footer.php'; ?>
