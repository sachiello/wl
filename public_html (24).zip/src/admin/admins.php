<?php
// admin/admins.php – Yöneticiler Yönetimi
require __DIR__ . '/require_admin.php'; // $pdo, $currentAdmin, csrf helpers vs.

$pageTitle  = 'Yöneticiler';
$activeNav  = 'admins';

$adminError   = null;
$adminSuccess = null;
$csrfFailed   = false;
$editIdFromPost = null;
$adminId = (int)($currentAdmin['id'] ?? 0);

// =====================================================
// CSRF KONTROL
// =====================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!function_exists('csrf_validate_request') || !csrf_validate_request()) {
        $csrfFailed   = true;
        $adminError   = 'Oturum doğrulaması başarısız. Lütfen sayfayı yenileyip tekrar deneyin.';
    }
}

// =====================================================
// 2FA SIFIRLAMA
// =====================================================
if (!$csrfFailed && isset($_POST['reset_2fa'])) {
    $targetId = (int)$_POST['reset_2fa'];

    $stmt = $pdo->prepare("UPDATE admins SET twofa_secret = NULL, twofa_enabled = 0 WHERE id = ?");
    $stmt->execute([$targetId]);

    // Basit PRG
    header('Location: admins.php?edit=' . $targetId . '&ok=twofa_reset');
    exit;
}

// =====================================================
// YÖNETİCİ SİLME
// =====================================================
if (!$csrfFailed && isset($_POST['delete_admin'])) {
    $targetId = (int)$_POST['delete_admin'];

    if ($targetId === $adminId) {
        $adminError = "Kendi hesabınızı silemezsiniz.";
    } else {
        $stmt = $pdo->prepare("DELETE FROM admins WHERE id = ?");
        $stmt->execute([$targetId]);
        header('Location: admins.php?ok=deleted');
        exit;
    }
}

// =====================================================
// YÖNETİCİ KAYDET (YENİ / GÜNCELLE)
// =====================================================
if (
    !$csrfFailed &&
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['save_admin'])
) {
    $id       = isset($_POST['id']) && $_POST['id'] !== '' ? (int)$_POST['id'] : null;
    $username = trim($_POST['username'] ?? '');
    $isActive = isset($_POST['is_active']) ? 1 : 0;

    $quotaLimit = (float)($_POST['deposit_quota_limit'] ?? 0);
    $quotaUsed  = (float)($_POST['deposit_quota_used'] ?? 0);
    if ($quotaLimit < 0) $quotaLimit = 0;
    if ($quotaUsed  < 0) $quotaUsed  = 0;

    $newPassword = trim($_POST['new_password'] ?? '');
    $passwordHash = null;

    if ($username === '') {
        $adminError = 'Kullanıcı adı zorunludur.';
    }

    // Yeni admin için şifre zorunlu, düzenlemede opsiyonel
    if ($id === null && $newPassword === '' && !$adminError) {
        $adminError = 'Yeni yönetici oluştururken şifre alanı boş bırakılamaz.';
    }

    if ($newPassword !== '' && !$adminError) {
        $passwordHash = password_hash($newPassword, PASSWORD_BCRYPT);
    }

    if (!$adminError) {
        try {
            if ($id) {
                // GÜNCELLE
                if ($passwordHash) {
                    $stmt = $pdo->prepare("
                        UPDATE admins
                        SET username = :username,
                            is_active = :is_active,
                            deposit_quota_limit = :q_limit,
                            deposit_quota_used  = :q_used,
                            password_hash = :pwd
                        WHERE id = :id
                    ");
                    $stmt->execute([
                        ':username'  => $username,
                        ':is_active' => $isActive,
                        ':q_limit'   => $quotaLimit,
                        ':q_used'    => $quotaUsed,
                        ':pwd'       => $passwordHash,
                        ':id'        => $id
                    ]);
                    $adminSuccess = 'Yönetici bilgileri ve şifresi güncellendi.';
                } else {
                    $stmt = $pdo->prepare("
                        UPDATE admins
                        SET username = :username,
                            is_active = :is_active,
                            deposit_quota_limit = :q_limit,
                            deposit_quota_used  = :q_used
                        WHERE id = :id
                    ");
                    $stmt->execute([
                        ':username'  => $username,
                        ':is_active' => $isActive,
                        ':q_limit'   => $quotaLimit,
                        ':q_used'    => $quotaUsed,
                        ':id'        => $id
                    ]);
                    $adminSuccess = 'Yönetici bilgileri güncellendi.';
                }
                $editIdFromPost = $id;
            } else {
                // YENİ
                $stmt = $pdo->prepare("
                    INSERT INTO admins
                        (username, password_hash, is_active, deposit_quota_limit, deposit_quota_used, twofa_secret, twofa_enabled)
                    VALUES
                        (:username, :pwd, :is_active, :q_limit, :q_used, NULL, 0)
                ");
                $stmt->execute([
                    ':username'  => $username,
                    ':pwd'       => $passwordHash,
                    ':is_active' => $isActive,
                    ':q_limit'   => $quotaLimit,
                    ':q_used'    => $quotaUsed
                ]);
                $newId = (int)$pdo->lastInsertId();
                $adminSuccess = 'Yeni yönetici oluşturuldu.';
                $editIdFromPost = $newId;
            }
        } catch (Throwable $e) {
            $adminError = 'Kayıt hatası: ' . $e->getMessage();
        }
    }
}

// =====================================================
// DÜZENLENECEK KAYIT
// =====================================================
$editAdminId = null;
if (isset($_GET['edit'])) {
    $editAdminId = (int)$_GET['edit'];
} elseif ($editIdFromPost) {
    $editAdminId = (int)$editIdFromPost;
}

$editAdmin = null;
if ($editAdminId) {
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ? LIMIT 1");
    $stmt->execute([$editAdminId]);
    $editAdmin = $stmt->fetch(PDO::FETCH_ASSOC);
}

// =====================================================
// LİSTE
// =====================================================
$listStmt = $pdo->query("
    SELECT id, username, is_active, deposit_quota_limit, deposit_quota_used, twofa_enabled
    FROM admins
    ORDER BY id ASC
");
$admins = $listStmt->fetchAll(PDO::FETCH_ASSOC);

// URL’den gelen ok parametresi (PRG benzeri)
if (isset($_GET['ok']) && !$adminSuccess) {
    switch ($_GET['ok']) {
        case 'deleted':
            $adminSuccess = 'Yönetici kaydı silindi.';
            break;
        case 'twofa_reset':
            $adminSuccess = 'Yöneticinin 2FA bilgileri sıfırlandı.';
            break;
    }
}

include __DIR__ . '/_admin_header.php';
?>

<style>
:root {
    --primary: #4f46e5;
    --success: #10b981;
    --danger: #dc2626;
    --warning: #f59e0b;
    --text-main: #1f2937;
    --text-muted: #6b7280;
    --border-light: #e5e7eb;
    --shadow-soft: 0 1px 3px rgba(0,0,0,0.05);
    --radius-sm: 6px;
    --radius-lg: 12px;
}

.page-content {
    padding: 24px;
    max-width: 1200px;
    margin: 0 auto;
}

.admin-page-header {
    margin-bottom: 20px;
}
.admin-page-header h1 {
    margin: 0;
    font-size: 22px;
    font-weight: 700;
}
.admin-page-header p {
    margin: 4px 0 0;
    color: var(--text-muted);
    font-size: 13px;
}

/* Alertler */
.alert-box {
    padding: 12px 14px;
    border-radius: var(--radius-sm);
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    border: 1px solid transparent;
}
.alert-danger {
    background: #fef2f2;
    color: var(--danger);
    border-color: #fecaca;
}
.alert-success {
    background: #ecfdf5;
    color: var(--success);
    border-color: #bbf7d0;
}

/* Form kartı */
.form-card {
    background: #ffffff;
    border-radius: var(--radius-lg);
    border: 1px solid var(--border-light);
    box-shadow: var(--shadow-soft);
    padding: 20px 22px;
    margin-bottom: 24px;
}
.form-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 18px;
    border-bottom: 1px solid var(--border-light);
    padding-bottom: 10px;
}
.form-header h2 {
    margin: 0;
    font-size: 16px;
    display: flex;
    align-items: center;
    gap: 6px;
}
.form-header small {
    font-size: 12px;
    color: var(--text-muted);
}

/* Grid */
.admin-form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 16px;
}
.form-group label {
    display: block;
    font-size: 12px;
    font-weight: 600;
    color: var(--text-muted);
    margin-bottom: 4px;
}
.form-input {
    width: 100%;
    padding: 9px 10px;
    border-radius: var(--radius-sm);
    border: 1px solid var(--border-light);
    font-size: 14px;
    box-sizing: border-box;
}
.form-input:focus {
    border-color: var(--primary);
    outline: none;
    box-shadow: 0 0 0 1px rgba(79,70,229,0.12);
}
.full-width {
    grid-column: 1 / -1;
}

/* Checkbox label */
.checkbox-label {
    font-size: 13px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    cursor: pointer;
}

/* Buttons */
.btn-main {
    background: var(--primary);
    color: #fff;
    border: none;
    border-radius: var(--radius-sm);
    padding: 9px 16px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}
.btn-main:hover {
    background: #4338ca;
}
.btn-secondary {
    background: #f3f4f6;
    color: var(--text-main);
    border: 1px solid var(--border-light);
    border-radius: var(--radius-sm);
    padding: 8px 14px;
    font-size: 13px;
    text-decoration: none;
}
.btn-danger-soft {
    background: #fef2f2;
    color: var(--danger);
    border: 1px solid #fecaca;
    border-radius: var(--radius-sm);
    padding: 7px 12px;
    font-size: 12px;
    cursor: pointer;
}

/* Table */
.table-container {
    background: #ffffff;
    border-radius: var(--radius-lg);
    border: 1px solid var(--border-light);
    box-shadow: var(--shadow-soft);
    overflow-x: auto;
}
.admin-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}
.admin-table th {
    background: #f8fafc;
    padding: 10px 12px;
    text-align: left;
    color: var(--text-muted);
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.03em;
}
.admin-table td {
    padding: 10px 12px;
    border-top: 1px solid var(--border-light);
    vertical-align: middle;
}
.admin-table tbody tr:hover {
    background: #f9fafb;
}

/* Status badge */
.badge-status {
    padding: 3px 9px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 600;
}
.badge-active {
    background: #dcfce7;
    color: var(--success);
    border: 1px solid #bbf7d0;
}
.badge-passive {
    background: #f3f4f6;
    color: var(--text-muted);
    border: 1px solid #e5e7eb;
}
.badge-2fa-on {
    background: #eef2ff;
    color: #4f46e5;
}
.badge-2fa-off {
    background: #fee2e2;
    color: #b91c1c;
}

/* Small action buttons */
.action-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 30px;
    height: 30px;
    border-radius: 6px;
    border: 1px solid var(--border-light);
    background: #f9fafb;
    cursor: pointer;
    text-decoration: none;
    font-size: 15px;
    margin-left: 4px;
}
.action-btn:hover {
    background: #eef2ff;
}
.action-btn-danger {
    background: #fef2f2;
    border-color: #fecaca;
    color: var(--danger);
}
</style>

<div class="page-content">
    <div class="admin-page-header">
        <h1>Yöneticiler</h1>
        <p>BetWallet admin paneline erişebilen yöneticileri ve günlük işlem kotalarını yönetin.</p>
    </div>

    <?php if ($adminError): ?>
        <div class="alert-box alert-danger">
            <i class="ri-error-warning-fill"></i> <?= htmlspecialchars($adminError) ?>
        </div>
    <?php endif; ?>

    <?php if ($adminSuccess): ?>
        <div class="alert-box alert-success">
            <i class="ri-checkbox-circle-fill"></i> <?= htmlspecialchars($adminSuccess) ?>
        </div>
    <?php endif; ?>

    <div class="form-card">
        <div class="form-header">
            <div>
                <h2>
                    <i class="ri-shield-user-line"></i>
                    <?= $editAdmin ? 'Yönetici Düzenle' : 'Yeni Yönetici Ekle' ?>
                </h2>
                <small><?= $editAdmin ? 'Mevcut bir yönetici kaydını değiştiriyorsunuz.' : 'Panele erişebilecek yeni bir yönetici oluşturun.' ?></small>
            </div>
            <?php if ($editAdmin): ?>
                <a href="admins.php" class="btn-secondary">
                    <i class="ri-close-line"></i> Yeni Kayıt
                </a>
            <?php endif; ?>
        </div>

        <form method="post">
            <?= csrf_field(); ?>
            <?php if ($editAdmin): ?>
                <input type="hidden" name="id" value="<?= (int)$editAdmin['id'] ?>">
            <?php endif; ?>

            <div class="admin-form-grid">
                <div class="form-group">
                    <label>Kullanıcı Adı</label>
                    <input type="text" name="username" class="form-input" required
                           value="<?= htmlspecialchars($editAdmin['username'] ?? '') ?>"
                           placeholder="örn: admin">
                </div>

                <div class="form-group">
                    <label><?= $editAdmin ? 'Yeni Şifre' : 'Şifre' ?> 
                        <span style="font-weight:400; color:var(--text-muted); font-size:11px;">
                            (<?= $editAdmin ? 'Boş bırakırsanız değişmez' : 'İlk giriş şifresi' ?>)
                        </span>
                    </label>
                    <input type="password" name="new_password" class="form-input"
                           placeholder="<?= $editAdmin ? '********' : 'Şifre belirleyin' ?>">
                </div>

                <div class="form-group">
                    <label>Günlük Yatırım Kota Limiti (TRY)</label>
                    <input type="number" step="0.01" min="0" name="deposit_quota_limit"
                           class="form-input"
                           value="<?= htmlspecialchars($editAdmin['deposit_quota_limit'] ?? '0.00') ?>">
                </div>

                <div class="form-group">
                    <label>Bugüne Kadar Kullanılan Kota (TRY)</label>
                    <input type="number" step="0.01" min="0" name="deposit_quota_used"
                           class="form-input"
                           value="<?= htmlspecialchars($editAdmin['deposit_quota_used'] ?? '0.00') ?>">
                </div>

                <div class="form-group">
                    <label>Durum</label>
                    <label class="checkbox-label">
                        <input type="checkbox" name="is_active" <?= isset($editAdmin['is_active']) ? ($editAdmin['is_active'] ? 'checked' : '') : 'checked' ?>>
                        Aktif Yönetici
                    </label>
                </div>

                <?php if ($editAdmin): ?>
                    <div class="form-group">
                        <label>2FA Durumu</label>
                        <div style="display:flex; align-items:center; gap:8px;">
                            <?php if (!empty($editAdmin['twofa_enabled'])): ?>
                                <span class="badge-status badge-2fa-on">
                                    <i class="ri-shield-check-fill"></i> Aktif
                                </span>
                                <button type="submit" name="reset_2fa" value="<?= (int)$editAdmin['id'] ?>"
                                        class="btn-danger-soft"
                                        onclick="return confirm('Bu yöneticinin 2FA bilgisini sıfırlamak üzeresiniz. Emin misiniz?');">
                                    2FA Sıfırla
                                </button>
                            <?php else: ?>
                                <span class="badge-status badge-2fa-off">
                                    <i class="ri-shield-line"></i> Pasif
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="form-group full-width" style="margin-top:8px;">
                    <button type="submit" name="save_admin" class="btn-main">
                        <i class="ri-save-line"></i>
                        <?= $editAdmin ? 'Değişiklikleri Kaydet' : 'Yönetici Oluştur' ?>
                    </button>
                </div>
            </div>
        </form>
    </div>

    <div class="table-container">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Kullanıcı Adı</th>
                    <th>Durum</th>
                    <th>2FA</th>
                    <th>Kota Limiti (TRY)</th>
                    <th>Kullanılan Kota (TRY)</th>
                    <th style="text-align:right;">İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$admins): ?>
                    <tr>
                        <td colspan="7" style="text-align:center; padding:20px; color:var(--text-muted);">
                            Kayıtlı yönetici bulunamadı.
                        </td>
                    </tr>
                <?php else: foreach ($admins as $row): ?>
                    <tr>
                        <td>#<?= (int)$row['id'] ?></td>
                        <td><?= htmlspecialchars($row['username']) ?></td>
                        <td>
                            <?php if ($row['is_active']): ?>
                                <span class="badge-status badge-active">Aktif</span>
                            <?php else: ?>
                                <span class="badge-status badge-passive">Pasif</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!empty($row['twofa_enabled'])): ?>
                                <span class="badge-status badge-2fa-on">Açık</span>
                            <?php else: ?>
                                <span class="badge-status badge-2fa-off">Kapalı</span>
                            <?php endif; ?>
                        </td>
                        <td><?= number_format((float)$row['deposit_quota_limit'], 2, ',', '.') ?> ₺</td>
                        <td><?= number_format((float)$row['deposit_quota_used'],  2, ',', '.') ?> ₺</td>
                        <td style="text-align:right; white-space:nowrap;">
                            <a href="admins.php?edit=<?= (int)$row['id'] ?>" class="action-btn" title="Düzenle">
                                <i class="ri-pencil-line"></i>
                            </a>
                            <?php if ((int)$row['id'] !== $adminId): ?>
                                <form method="post" style="display:inline;"
                                      onsubmit="return confirm('Bu yönetici hesabını silmek istediğinize emin misiniz?');">
                                    <?= csrf_field(); ?>
                                    <input type="hidden" name="delete_admin" value="<?= (int)$row['id'] ?>">
                                    <button type="submit" class="action-btn action-btn-danger" title="Sil">
                                        <i class="ri-delete-bin-line"></i>
                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/_admin_footer.php'; ?>
