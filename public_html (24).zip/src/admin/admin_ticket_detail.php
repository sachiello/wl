<?php
// admin/admin_ticket_detail.php
session_start();
require __DIR__ . '/../../config/config.php';

// 1. GÜVENLİK KONTROLÜ
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

// CSRF Token Yönetimi
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];

// Bilet ID Kontrolü (Type Casting ile Güvenlik)
$ticketId = (int)($_GET['id'] ?? 0);
if ($ticketId === 0) {
    header('Location: admin_support.php');
    exit;
}

// Admin Bilgisi
$stmtAdmin = $pdo->prepare("SELECT username FROM admins WHERE id = ?");
$stmtAdmin->execute([$_SESSION['admin_id']]);
$adminRow = $stmtAdmin->fetch(PDO::FETCH_ASSOC);
$adminName = $adminRow['username'] ?? 'Admin';

// ---------------------------------------------------------------------
// 2. POST İŞLEMLERİ (PRG DESENİ)
// ---------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // 2.1 CSRF KONTROLÜ
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrfToken) {
        die("Güvenlik İhlali: CSRF Token Geçersiz.");
    }

    $action = $_POST['action'] ?? '';
    $adminId = $_SESSION['admin_id'];

    if ($action === 'send_reply') {
        $message = trim($_POST['message'] ?? '');
        
        if (!empty($message)) {
            try {
                // Mesajı ekle (user_id NULL, is_admin 1)
                $stmt = $pdo->prepare("
                    INSERT INTO support_messages (ticket_id, user_id, is_admin, message, created_at)
                    VALUES (?, NULL, 1, ?, NOW())
                ");
                $stmt->execute([$ticketId, $message]);

                // Bilet durumunu güncelle
                $stmtUpd = $pdo->prepare("UPDATE support_tickets SET status = 'answered', updated_at = NOW() WHERE id = ?");
                $stmtUpd->execute([$ticketId]);

                // Logla
                $logData = json_encode(['ticket_id' => $ticketId]);
                $stmtLog = $pdo->prepare("INSERT INTO activity_logs (actor_type, actor_id, scope, action, meta_json, created_at) VALUES ('admin', ?, 'support', 'reply', ?, NOW())");
                $stmtLog->execute([$adminId, $logData]);

                // PRG: Başarılı yönlendirme
                header("Location: admin_ticket_detail.php?id={$ticketId}&success=reply");
                exit;

            } catch (PDOException $e) {
                header("Location: admin_ticket_detail.php?id={$ticketId}&error=db");
                exit;
            }
        } else {
            header("Location: admin_ticket_detail.php?id={$ticketId}&error=empty");
            exit;
        }

    } elseif ($action === 'change_status') {
        $newStatus = $_POST['new_status'] ?? '';
        $allowed = ['open', 'answered', 'closed'];

        if (in_array($newStatus, $allowed)) {
            $stmtUpd = $pdo->prepare("UPDATE support_tickets SET status = ?, updated_at = NOW() WHERE id = ?");
            $stmtUpd->execute([$newStatus, $ticketId]);

            // Logla
            $logData = json_encode(['ticket_id' => $ticketId, 'status' => $newStatus]);
            $stmtLog = $pdo->prepare("INSERT INTO activity_logs (actor_type, actor_id, scope, action, meta_json, created_at) VALUES ('admin', ?, 'support', 'status_change', ?, NOW())");
            $stmtLog->execute([$adminId, $logData]);

            // PRG
            header("Location: admin_ticket_detail.php?id={$ticketId}&success=status");
            exit;
        }
    }
}

// ---------------------------------------------------------------------
// 3. VERİ ÇEKME (GET)
// ---------------------------------------------------------------------

// Bilet Detayı
$stmt = $pdo->prepare("
    SELECT t.*, u.username AS user_username 
    FROM support_tickets t 
    JOIN users u ON t.user_id = u.id 
    WHERE t.id = ?
");
$stmt->execute([$ticketId]);
$ticket = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$ticket) {
    header('Location: admin_support.php');
    exit;
}

// Mesajlar
$stmtMsg = $pdo->prepare("
    SELECT sm.*, 
           CASE WHEN sm.is_admin = 1 THEN 'Yönetici' ELSE u.username END AS sender_name
    FROM support_messages sm
    LEFT JOIN users u ON sm.user_id = u.id
    WHERE sm.ticket_id = ?
    ORDER BY sm.created_at ASC
");
$stmtMsg->execute([$ticketId]);
$messages = $stmtMsg->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bilet #<?= $ticket['id'] ?> - Yönetim</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        /* settings.php'den alınan temel değişkenler */
        :root { --primary: #c2273f; --primary-light: #fff1f2; --bg-body: #f1f5f9; --bg-card: #ffffff; --text-main: #1f2937; --text-muted: #6b7280; --border-color: #e5e7eb; --radius-md: 8px; }
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; }
        
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        .main-content { flex: 1; padding: 30px; overflow-y: auto; }
        
        .topbar { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px; }
        .topbar h1 { font-size: 24px; font-weight: 800; margin: 0; color: var(--text-main); }
        .topbar p { margin: 5px 0 0; color: var(--text-muted); font-size: 14px; }
        
        .card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); padding: 24px; margin-bottom: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid var(--border-color); }
        .card-title { font-size: 16px; font-weight: 700; margin: 0; display: flex; align-items: center; gap: 8px; }
        
        .alert { padding: 15px; border-radius: var(--radius-md); margin-bottom: 20px; display: flex; align-items: center; gap: 10px; font-weight: 500; font-size: 14px; }
        .alert-green { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
        .alert-red { background: #fef2f2; color: #b91c1c; border: 1px solid #fecaca; }
        
        .form-control { width: 100%; padding: 12px; border: 1px solid var(--border-color); border-radius: var(--radius-md); font-size: 14px; outline: none; box-sizing: border-box; transition: border-color 0.2s; font-family: inherit; }
        .form-control:focus { border-color: var(--primary); }
        
        .btn-primary { width: 100%; padding: 12px; background: var(--primary); color: #fff; border: none; border-radius: var(--radius-md); font-weight: 600; cursor: pointer; transition: opacity 0.2s; display: flex; justify-content: center; align-items: center; gap: 8px; }
        .btn-primary:hover { opacity: 0.9; }
        
        .ticket-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 20px; }
        @media(max-width: 900px) { .ticket-grid { grid-template-columns: 1fr; } }

        /* CHAT ÖZEL STİLLERİ */
        .chat-box { background: #f8fafc; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 20px; max-height: 500px; overflow-y: auto; display: flex; flex-direction: column; gap: 15px; }
        
        .message-bubble { max-width: 80%; padding: 12px 16px; border-radius: 12px; font-size: 14px; line-height: 1.5; position: relative; }
        
        .msg-user { align-self: flex-start; background: #ffffff; border: 1px solid var(--border-color); color: var(--text-main); border-bottom-left-radius: 2px; }
        .msg-admin { align-self: flex-end; background: var(--primary-light); border: 1px solid #fda4af; color: #881337; border-bottom-right-radius: 2px; }
        
        .msg-meta { font-size: 11px; margin-top: 6px; opacity: 0.7; display: flex; align-items: center; gap: 5px; }
        .status-badge { padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 600; text-transform: uppercase; }
        
        /* Durum renkleri */
        .status-open { background: #fff7ed; color: #c2410c; border: 1px solid #fdba74; }
        .status-answered { background: #ecfdf5; color: #047857; border: 1px solid #6ee7b7; }
        .status-closed { background: #f3f4f6; color: #4b5563; border: 1px solid #d1d5db; }
        
        .back-btn { display: inline-flex; align-items: center; gap: 5px; color: var(--text-muted); text-decoration: none; font-size: 13px; font-weight: 500; margin-bottom: 10px; transition: color 0.2s; }
        .back-btn:hover { color: var(--primary); }
    </style>
</head>
<body>

<div class="app-wrapper">
    
    <?php 
    // SIDEBAR BURAYA EKLENDİ. 
    // Dosya ismin farklıysa (örn: sidebar.php) burayı düzelt.
    include __DIR__ . '/_admin_header.php'; 
    ?>

    <div class="main-content">
        
        <a href="admin_support.php" class="back-btn"><i class="ri-arrow-left-line"></i> Listeye Dön</a>

        <div class="topbar">
            <div>
                <h1>Bilet #<?= $ticket['id'] ?></h1>
                <p>Üye: <strong><?= htmlspecialchars($ticket['user_username']) ?></strong> &bull; <?= date('d.m.Y H:i', strtotime($ticket['created_at'])) ?></p>
            </div>
            <div>
                <?php
                $sClass = 'status-closed';
                $sText = 'Kapalı';
                if ($ticket['status'] == 'open') { $sClass = 'status-open'; $sText = 'Açık / Bekliyor'; }
                if ($ticket['status'] == 'answered') { $sClass = 'status-answered'; $sText = 'Cevaplandı'; }
                ?>
                <span class="status-badge <?= $sClass ?>"><?= $sText ?></span>
            </div>
        </div>

        <?php if(isset($_GET['success'])): ?>
            <div class="alert alert-green">
                <i class="ri-checkbox-circle-fill"></i>
                <?php 
                    if($_GET['success'] == 'reply') echo "Yanıtınız başarıyla gönderildi.";
                    if($_GET['success'] == 'status') echo "Bilet durumu güncellendi.";
                ?>
            </div>
        <?php endif; ?>

        <?php if(isset($_GET['error'])): ?>
            <div class="alert alert-red">
                <i class="ri-error-warning-fill"></i> İşlem sırasında bir hata oluştu.
            </div>
        <?php endif; ?>

        <div class="ticket-grid">
            
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><i class="ri-chat-history-line"></i> Mesaj Geçmişi</h3>
                </div>
                
                <div class="chat-box">
                    <?php if (count($messages) == 0): ?>
                        <div style="text-align: center; color: var(--text-muted); padding: 20px;">
                            Henüz mesaj yok.
                        </div>
                    <?php endif; ?>

                    <?php foreach ($messages as $msg): ?>
                        <?php 
                        $isAdminMsg = ($msg['is_admin'] == 1);
                        $bubbleClass = $isAdminMsg ? 'msg-admin' : 'msg-user';
                        ?>
                        <div class="message-bubble <?= $bubbleClass ?>">
                            <?= nl2br(htmlspecialchars($msg['message'])) ?>
                            <div class="msg-meta">
                                <i class="ri-<?= $isAdminMsg ? 'user-settings-line' : 'user-line' ?>"></i>
                                <span><?= htmlspecialchars($msg['sender_name']) ?></span> &bull; 
                                <span><?= date('d.m H:i', strtotime($msg['created_at'])) ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div style="display: flex; flex-direction: column; gap: 20px;">
                
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title"><i class="ri-reply-line"></i> Cevap Yaz</h3>
                    </div>
                    <form method="post">
                        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                        <input type="hidden" name="action" value="send_reply">
                        
                        <div style="margin-bottom: 15px;">
                            <textarea name="message" class="form-control" rows="5" placeholder="Yanıtınızı buraya yazın..." required></textarea>
                        </div>
                        
                        <button type="submit" class="btn-primary">
                            <i class="ri-send-plane-fill"></i> Gönder
                        </button>
                    </form>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title"><i class="ri-toggle-line"></i> Durum Yönetimi</h3>
                    </div>
                    <form method="post">
                        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                        <input type="hidden" name="action" value="change_status">
                        
                        <div style="margin-bottom: 15px;">
                            <label class="form-label" style="display:block; margin-bottom:5px; font-weight:600; font-size:13px;">Bilet Durumu</label>
                            <select name="new_status" class="form-control">
                                <option value="open" <?= $ticket['status'] == 'open' ? 'selected' : '' ?>>Açık (Bekliyor)</option>
                                <option value="answered" <?= $ticket['status'] == 'answered' ? 'selected' : '' ?>>Cevaplandı</option>
                                <option value="closed" <?= $ticket['status'] == 'closed' ? 'selected' : '' ?>>Kapalı (Çözüldü)</option>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn-primary" style="background: #fff; color: var(--text-main); border: 1px solid var(--border-color);">
                            <i class="ri-save-line"></i> Güncelle
                        </button>
                    </form>
                </div>

            </div>
        </div>

    </div>
</div>

</body>
</html>