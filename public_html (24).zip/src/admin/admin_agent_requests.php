<?php
// DEBUG (geliştirme ortamında işine yarıyorsa bırak, canlıda kapat)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// admin/admin_agent_requests.php
// Agent Bakiye / Teminat Talepleri Yönetimi (CSRF korumalı)

require __DIR__ . '/require_admin.php';
// Burada: session start, $pdo, $currentAdmin ve config.php içindeki
// CSRF helper'lar (csrf_token, csrf_field, csrf_validate_request, csrf_reject_if_invalid) yüklüdür.

$pageTitle = 'Agent Bakiye Talepleri';
$activeNav = 'agent_requests';

$adminError   = null;
$adminSuccess = null;
$adminId      = (int)($currentAdmin['id'] ?? 0);

// =================================================================
// PRG: Yönlendirmeden gelen başarılı/hatalı mesajları al
// =================================================================
if (isset($_SESSION['admin_status'])) {
    if ($_SESSION['admin_status']['type'] === 'success') {
        $adminSuccess = $_SESSION['admin_status']['message'];
    } elseif ($_SESSION['admin_status']['type'] === 'error') {
        $adminError = $_SESSION['admin_status']['message'];
    }
    unset($_SESSION['admin_status']); // Mesajı gösterdikten sonra sil
}

// =================================================================
// POST İŞLEMLERİ (ONAY / RED)
// =================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 1) 🚨 CSRF KONTROLÜ – config.php'deki helper kullanılıyor
    if (!csrf_validate_request()) {
        $_SESSION['admin_status'] = [
            'type'    => 'error',
            'message' => 'Güvenlik hatası (CSRF). Lütfen formu yeniden deneyin.'
        ];
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }

    $requestId = (int)($_POST['req_id'] ?? 0);
    $action    = $_POST['action'] ?? '';

    if ($requestId > 0 && ($action === 'approve' || $action === 'reject')) {
        try {
            $pdo->beginTransaction();

            // 2) Talebi kilitle ve çek (yalnızca pending olanlar)
            $stmt = $pdo->prepare("
                SELECT r.*, a.system_balance, a.current_cash
                FROM agent_balance_requests r
                JOIN deposit_agents a ON a.id = r.agent_id
                WHERE r.id = ? AND r.status = 'pending'
                FOR UPDATE
            ");
            $stmt->execute([$requestId]);
            $request = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$request) {
                throw new Exception("Talep bulunamadı veya zaten işlenmiş. İşlem yapılamadı.");
            }

            $agentId = (int)$request['agent_id'];
            $amount  = (float)$request['amount']; // Agent'ın gönderdiği ANA PARA

            // Yeni Mantık: Sadece Teminat Bakiyesine ekle, Kâr/Bonus yok.
            $teminatInc     = $amount;
            $amountCredited = $teminatInc;

            if ($action === 'approve') {
                // 3a) ONAY: Agent'ın teminat bakiyesini güncelle
                $updateAgent = $pdo->prepare("
                    UPDATE deposit_agents
                    SET system_balance = system_balance + :teminat_inc
                    WHERE id = :agent_id
                ");
                $updateAgent->execute([
                    ':teminat_inc' => $teminatInc,
                    ':agent_id'    => $agentId,
                ]);

                // 3b) agent_balance_requests durumunu güncelle
                $pdo->prepare("
                    UPDATE agent_balance_requests
                    SET status = 'approved',
                        amount_credited = ?,
                        admin_id = ?,
                        processed_at = NOW()
                    WHERE id = ?
                ")->execute([$amountCredited, $adminId, $requestId]);

                // 3c) Loglama (agent_balance_logs)
                $beforeBalance = (float)$request['system_balance'];
                $afterBalance  = $beforeBalance + $teminatInc;

                $insertBalanceLog = $pdo->prepare("
                    INSERT INTO agent_balance_logs
                        (agent_id, amount, balance_before, balance_after, source_type, source_id, description)
                    VALUES
                        (:agent_id, :amount, :before, :after, 'manual_load', :source_id, :description)
                ");
                $insertBalanceLog->execute([
                    ':agent_id'    => $agentId,
                    ':amount'      => $teminatInc,
                    ':before'      => $beforeBalance,
                    ':after'       => $afterBalance,
                    ':source_id'   => $requestId,
                    ':description' => 'Admin onaylı teminat yükleme (Ana Para)',
                ]);

                $message = sprintf(
                    "Talep #%d onaylandı. Agent teminatına %s ₺ eklendi.",
                    $requestId,
                    number_format($teminatInc, 2, ',', '.')
                );

            } else { // $action === 'reject'
                // 3) RED: Talebin durumunu güncelle
                $pdo->prepare("
                    UPDATE agent_balance_requests
                    SET status = 'rejected',
                        admin_id = ?,
                        processed_at = NOW()
                    WHERE id = ? AND status = 'pending'
                ")->execute([$adminId, $requestId]);

                $message = sprintf("Talep #%d reddedildi.", $requestId);
            }

            $pdo->commit();

            // 4) PRG: Başarı mesajı yaz ve yönlendir
            $_SESSION['admin_status'] = [
                'type'    => 'success',
                'message' => $message
            ];
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;

        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $_SESSION['admin_status'] = [
                'type'    => 'error',
                'message' => "İşlem hatası: " . $e->getMessage()
            ];
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        }
    } else {
        // Geçersiz ID veya action
        $_SESSION['admin_status'] = [
            'type'    => 'error',
            'message' => "Geçersiz işlem veya talep ID'si."
        ];
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
}

// =================================================================
// VERİ ÇEKME (Tüm talepler, bekleyenler en üstte)
// =================================================================
$sql = "
    SELECT 
        r.*, 
        a.name AS agent_name, 
        a.system_balance AS agent_collateral, 
        a.current_cash AS agent_cash 
    FROM agent_balance_requests r
    JOIN deposit_agents a ON a.id = r.agent_id
    ORDER BY r.status = 'pending' DESC, r.created_at DESC
";

try {
    $requests = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
} catch (\PDOException $e) {
    $adminError = "Veri çekme hatası: " . $e->getMessage();
    $requests   = [];
}
?>

<?php include '_admin_header.php'; ?>

<style>
/* ... (Stilleriniz buraya gelecek) ... */
</style>

<div class="page-content">

    <?php if ($adminError): ?>
        <div class="alert-box alert-danger">
            <i class="ri-error-warning-fill"></i>
            <?= htmlspecialchars($adminError) ?>
        </div>
    <?php endif; ?>

    <?php if ($adminSuccess): ?>
        <div class="alert-box alert-success">
            <i class="ri-checkbox-circle-fill"></i>
            <?= htmlspecialchars($adminSuccess) ?>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header-styled">
            <h3 style="font-weight: 600; font-size: 18px;">Agent Bakiye Talepleri</h3>
            <span class="badge-status status-pending">
                <?= count(array_filter($requests, fn($r) => $r['status'] === 'pending')) ?> BEKLEYEN
            </span>
        </div>

        <div class="table-container">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID / Agent</th>
                        <th>Gönderilen Tutar</th>
                        <th>Yüklenecek Teminat</th>
                        <th>Agent Bakiyesi (Mevcut)</th>
                        <th>Durum</th>
                        <th>Tarih</th>
                        <th class="text-end">İşlem</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!empty($requests)): ?>
                    <?php foreach ($requests as $req):
                        $statusClass = $req['status'] === 'pending'
                            ? 'status-pending'
                            : ($req['status'] === 'approved' ? 'status-approved' : 'status-rejected');

                        $amount     = (float)$req['amount'];
                        $teminatInc = $amount; // Yüklenecek Teminat = Gönderilen Tutar
                    ?>
                        <tr class="<?= $req['status'] === 'pending' ? 'pending-row' : '' ?>">
                            <td>
                                <div class="font-weight-bold" style="color: var(--text-main);">
                                    #<?= (int)$req['id'] ?>
                                </div>
                                <div style="color: var(--primary); font-weight: 600; font-size: 13px;">
                                    <?= htmlspecialchars($req['agent_name']) ?>
                                </div>
                            </td>
                            <td>
                                <div style="font-weight: 700; color: var(--text-main);">
                                    <?= number_format($amount, 2, ',', '.') ?> ₺
                                </div>
                            </td>
                            <td>
                                <div style="font-weight: 700; color: var(--success);">
                                    <?= number_format($teminatInc, 2, ',', '.') ?> ₺
                                </div>
                                <div style="font-size: 11px; color: var(--text-muted);">
                                    (= Gönderilen Tutar)
                                </div>
                            </td>
                            <td>
                                <div style="font-weight: 700; color: var(--text-main);">
                                    T: <?= number_format($req['agent_collateral'], 2, ',', '.') ?> ₺<br>
                                    K: <?= number_format($req['agent_cash'], 2, ',', '.') ?> ₺
                                </div>
                            </td>
                            <td>
                                <span class="badge-status <?= $statusClass ?>">
                                    <?= htmlspecialchars(strtoupper($req['status'])) ?>
                                </span>
                            </td>
                            <td style="color: var(--text-muted);">
                                <?= date('d.m.Y H:i', strtotime($req['created_at'])) ?>
                            </td>
                            <td class="text-end">
                                <?php if ($req['status'] === 'pending'): ?>
                                    <form method="post" style="display:inline-block; margin-right: 5px;">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="req_id" value="<?= (int)$req['id'] ?>">
                                        <button type="submit"
                                                name="action"
                                                value="approve"
                                                class="btn-sm btn-approve"
                                                onclick="return confirm('Agent: <?= htmlspecialchars($req['agent_name']) ?>\nTeminat Yüklenecek: <?= number_format($teminatInc, 2, ',', '.') ?> ₺\n\nONAYLAMAK İSTEDİĞİNİZE EMİN MİSİNİZ?');">
                                            Onayla <i class="ri-check-line"></i>
                                        </button>
                                    </form>

                                    <form method="post" class="d-inline-block">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="req_id" value="<?= (int)$req['id'] ?>">
                                        <button type="submit"
                                                name="action"
                                                value="reject"
                                                class="btn-sm btn-reject"
                                                onclick="return confirm('Talebi reddetmek istediğinize emin misiniz?');">
                                            Reddet
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span style="color: var(--text-muted); font-size: 12px;">İşlendi</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center" style="padding: 30px; color: var(--text-muted);">
                            Bekleyen bakiye/teminat talebi yok.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '_admin_footer.php'; ?>
