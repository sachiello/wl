<?php
// admin/admin_logs.php
require __DIR__ . '/require_admin.php';

$pageTitle = 'İşlem Geçmişi (Logs)';
$activeNav = 'logs';

// Tablo var mı kontrolü
// Burası normalde require_admin içinde bir yerde tanımlı olmalı, varsayıyoruz.
if (!function_exists('bw_table_exists')) {
    function bw_table_exists($pdo, $table) {
        try {
            $pdo->query("SELECT 1 FROM {$table} LIMIT 1");
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
}
$hasTable = bw_table_exists($pdo, 'activity_logs');
$logs = [];

// --- FİLTRELEME PARAMETRELERİ ---
$f_actor_type = $_GET['actor_type'] ?? '';
$f_actor_id = $_GET['actor_id'] ?? '';
$f_scope = $_GET['scope'] ?? '';
$f_action = $_GET['action'] ?? '';
$f_period = $_GET['period'] ?? '24h'; // Varsayılan: Son 24 Saat

if ($hasTable) {
    // Temel Sorgu
    $sql = "SELECT * FROM activity_logs WHERE 1=1";
    $params = [];

    // 1. Zaman Filtresi (Varsayılan 24 Saat)
    if ($f_period === '24h') {
        $sql .= " AND created_at >= NOW() - INTERVAL 24 HOUR";
    } elseif ($f_period === '7d') {
        $sql .= " AND created_at >= NOW() - INTERVAL 7 DAY";
    } elseif ($f_period === '30d') {
        $sql .= " AND created_at >= NOW() - INTERVAL 30 DAY";
    }
    // 'all' seçilirse tarih kısıtlaması yok

    // 2. Diğer Filtreler
    if (!empty($f_actor_type)) {
        $sql .= " AND actor_type = ?";
        $params[] = $f_actor_type;
    }
    if (!empty($f_actor_id)) {
        $sql .= " AND actor_id = ?";
        $params[] = $f_actor_id;
    }
    if (!empty($f_scope)) {
        $sql .= " AND scope = ?";
        $params[] = $f_scope;
    }
    if (!empty($f_action)) {
        $sql .= " AND action = ?";
        $params[] = $f_action;
    }

    // 3. Sıralama ve Limit
    $limit = ($f_period === 'all') ? 1000 : 500;
    $sql .= " ORDER BY id DESC LIMIT $limit";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Scope (Kapsam) Listesi
$scopes = ['deposit', 'withdrawal', 'iban', 'agent', 'site', 'user', 'user_wallet', 'cash'];

include __DIR__ . '/_admin_header.php';
?>

<style>
/* ====================================================
   LOG SAYFASI – BETWALLET RED THEME UYUMLU
   ==================================================== */

:root {
    --primary: #c2273f;
    --primary-dark: #9f1239;
    --text-main: #1f2937;
    --text-muted: #6b7280;
    --border-light: #e5e7eb;
    --bg-card: #ffffff;
    --bg-table-head: #f8fafc;
    --bg-input: #f8fafc;
}

body.dark-mode {
    --text-main: #f9fafb;
    --text-muted: #9ca3af;
    --border-light: #374151;
    --bg-card: #050509;
    --bg-table-head: #0b0b10;
    --bg-input: #0b0b10;
}

/* Sayfa genel alanı */
.page-content {
    padding: 24px;
    max-width: 1400px;
    margin: 0 auto;
}

/* Filtre Kartı */
.filter-card {
    background: var(--bg-card);
    padding: 15px;
    border-radius: 14px;
    box-shadow: 0 14px 40px rgba(0,0,0,0.18);
    margin-bottom: 20px;
    border: 1px solid rgba(248, 113, 113, 0.35);
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    align-items: center;
}
.filter-group {
    display: flex;
    align-items: center;
    gap: 8px;
}

.admin-select,
.admin-input-sm {
    padding: 8px 12px;
    border-radius: 999px;
    border: 1px solid var(--border-light);
    background: var(--bg-input);
    color: var(--text-main);
    font-size: 13px;
    outline: none;
}
.admin-select:focus,
.admin-input-sm:focus {
    border-color: var(--primary);
}

/* Butonlar */
.btn-filter {
    background: var(--primary);
    color: #fff;
    border: none;
    padding: 8px 16px;
    border-radius: 999px;
    cursor: pointer;
    font-size: 13px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 5px;
    box-shadow: 0 10px 30px rgba(194,39,63,0.35);
}
.btn-filter:hover {
    background: var(--primary-dark);
}
.btn-reset {
    background: #f1f5f9;
    color: var(--text-muted);
    border: 1px solid var(--border-light);
    padding: 8px 16px;
    border-radius: 999px;
    cursor: pointer;
    font-size: 13px;
    text-decoration: none;
}
body.dark-mode .btn-reset {
    background: #020617;
    color: #e5e7eb;
}

/* Genel Alert Box */
.alert-box {
    padding: 14px 16px;
    border-radius: 12px;
    margin-bottom: 16px;
    border: 1px solid transparent;
    font-size: 14px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.alert-danger {
    background: rgba(220, 38, 38, 0.08);
    color: #b91c1c;
    border-color: #fecaca;
}

/* Badge'ler – Actor */
.badge-actor {
    padding: 4px 8px;
    border-radius: 10px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
}

/* Açık mod actor rozetleri */
.actor-admin {
    background: rgba(220,38,38,0.08);
    color: #b91c1c;
    border: 1px solid #fecaca;
}
.actor-agent {
    background: rgba(248,113,113,0.10);
    color: #7f1d1d;
    border: 1px solid rgba(248,113,113,0.6);
}
.actor-user {
    background: #f8fafc;
    color: #64748b;
    border: 1px solid #e2e8f0;
}

/* Koyu mod actor rozetleri */
body.dark-mode .actor-admin {
    background: #7f1d1d;
    color: #fecaca;
    border-color: #f97373;
}
body.dark-mode .actor-agent {
    background: #7c2d12;
    color: #fed7aa;
    border-color: #fb923c;
}
body.dark-mode .actor-user {
    background: #020617;
    color: #e5e7eb;
    border-color: #1f2937;
}

/* Action rozetleri */
.badge-action {
    padding: 4px 8px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 600;
    display: inline-block;
}
.action-green {
    color: #166534;
    background: #dcfce7;
}
.action-red {
    color: #991b1b;
    background: #fee2e2;
}
.action-orange {
    color: #9a3412;
    background: #ffedd5;
}
.action-gray {
    color: #475569;
    background: #f1f5f9;
}

/* Koyu mod action rozetleri */
body.dark-mode .action-green {
    color: #bbf7d0;
    background: #14532d;
}
body.dark-mode .action-red {
    color: #fecaca;
    background: #7f1d1d;
}
body.dark-mode .action-orange {
    color: #fed7aa;
    background: #7c2d12;
}
body.dark-mode .action-gray {
    color: #e5e7eb;
    background: #020617;
}

/* Tablo genel */
.table-container {
    background: var(--bg-card);
    border-radius: 18px;
    box-shadow: 0 18px 45px rgba(0,0,0,0.18);
    border: 1px solid rgba(15,23,42,0.5);
    overflow: hidden;
}
.admin-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 14px;
}
.admin-table thead {
    background: var(--bg-table-head);
}
.admin-table th {
    text-align: left;
    padding: 10px 14px;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    color: var(--text-muted);
}
.admin-table td {
    padding: 12px 14px;
    border-top: 1px solid var(--border-light);
    color: var(--text-main);
}
.admin-table tbody tr:hover {
    background: rgba(248,113,113,0.03);
}

/* Log description */
.log-desc {
    font-size: 13px;
    font-weight: 600;
    color: var(--text-main);
    margin-bottom: 4px;
}

/* Meta detay butonu */
.log-meta-btn {
    padding: 4px 9px;
    border-radius: 999px;
    border: 1px solid var(--border-light);
    background: var(--bg-card);
    font-size: 11px;
    color: var(--text-muted);
    cursor: pointer;
}
.log-meta-btn:hover {
    background: var(--bg-input);
}

/* Modal Stilleri */
.admin-modal-backdrop {
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: rgba(0,0,0,0.6);
    z-index: 9999;
    display: flex;
    justify-content: center;
    align-items: center;
}
.admin-modal {
    background: var(--bg-card);
    padding: 20px;
    border-radius: 16px;
    box-shadow: 0 20px 50px rgba(0,0,0,0.3);
    position: relative;
    max-width: 90%;
}
.admin-modal-header h2 {
    margin: 0 0 8px 0;
    font-size: 16px;
    color: var(--text-main);
}
.admin-modal-close {
    position: absolute;
    top: 10px; right: 10px;
    font-size: 24px;
    background: none;
    border: none;
    cursor: pointer;
    color: var(--text-muted);
}
.admin-modal-body {
    font-family: monospace;
    font-size: 12px;
    background: #020617;
    color: #a7f3d0;
    padding: 10px;
    border-radius: 10px;
    white-space: pre-wrap;
    word-break: break-word;
    max-height: 500px;
    overflow-y: auto;
}
</style>

<div class="page-content">

    <div style="margin-bottom: 20px; display:flex; justify-content:space-between; align-items:center;">
        <div>
            <h1 style="margin:0; font-size: 24px; color: var(--text-main);">Sistem Logları</h1>
            <p style="color: var(--text-muted); font-size: 13px; margin-top: 5px;">
                Sistemde yapılan işlemlerin kayıtları.
            </p>
        </div>
        <div style="font-size: 12px; color: var(--text-muted); background: var(--bg-card); padding: 5px 10px; border-radius: 20px; border: 1px solid var(--border-light);">
            <i class="ri-database-2-line"></i> Toplam Gösterilen: <strong><?= count($logs) ?></strong> kayıt
        </div>
    </div>

    <?php if (!$hasTable): ?>
        <div class="alert-box alert-danger" style="padding: 20px; background: #fee2e2; color: #b91c1c;">
            <strong>Tablo Eksik:</strong> `activity_logs` tablosu bulunamadı.
        </div>
    <?php else: ?>

        <form method="get" class="filter-card">
            <div class="filter-group">
                <i class="ri-time-line" style="color: var(--text-muted);"></i>
                <select name="period" class="admin-select" style="font-weight:600; color:var(--primary);">
                    <option value="24h" <?= $f_period === '24h' ? 'selected' : '' ?>>Son 24 Saat</option>
                    <option value="7d"  <?= $f_period === '7d'  ? 'selected' : '' ?>>Son 7 Gün</option>
                    <option value="30d" <?= $f_period === '30d' ? 'selected' : '' ?>>Son 30 Gün</option>
                    <option value="all" <?= $f_period === 'all' ? 'selected' : '' ?>>Tüm Zamanlar</option>
                </select>
            </div>

            <div class="filter-group">
                <select name="actor_type" class="admin-select">
                    <option value="">Rol</option>
                    <option value="admin" <?= $f_actor_type === 'admin' ? 'selected' : '' ?>>Admin</option>
                    <option value="agent" <?= $f_actor_type === 'agent' ? 'selected' : '' ?>>Agent</option>
                    <option value="user"  <?= $f_actor_type === 'user'  ? 'selected' : '' ?>>User</option>
                </select>
            </div>

            <div class="filter-group">
                <input type="number" name="actor_id" class="admin-input-sm" placeholder="ID" style="width: 60px;" value="<?= htmlspecialchars($f_actor_id) ?>">
            </div>

            <div class="filter-group">
                <select name="scope" class="admin-select">
                    <option value="">İşlem Türü</option>
                    <?php foreach ($scopes as $s): ?>
                        <option value="<?= $s ?>" <?= $f_scope === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="filter-group">
                <select name="action" class="admin-select">
                    <option value="">Aksiyon</option>
                    <option value="create"  <?= $f_action === 'create'  ? 'selected' : '' ?>>Create</option>
                    <option value="update"  <?= $f_action === 'update'  ? 'selected' : '' ?>>Update</option>
                    <option value="delete"  <?= $f_action === 'delete'  ? 'selected' : '' ?>>Delete</option>
                    <option value="confirm" <?= $f_action === 'confirm' ? 'selected' : '' ?>>Confirm</option>
                    <option value="reject"  <?= $f_action === 'reject'  ? 'selected' : '' ?>>Reject</option>
                    <option value="login"   <?= $f_action === 'login'   ? 'selected' : '' ?>>Login</option>
                    <option value="ban"           <?= $f_action === 'ban'           ? 'selected' : '' ?>>Ban</option>
                    <option value="unban"         <?= $f_action === 'unban'         ? 'selected' : '' ?>>Unban</option>
                    <option value="adjust_balance" <?= $f_action === 'adjust_balance' ? 'selected' : '' ?>>Balance Adjust</option>
                </select>
            </div>

            <div style="margin-left: auto; display: flex; gap: 10px;">
                <button type="submit" class="btn-filter"><i class="ri-filter-3-line"></i> Uygula</button>
                <a href="admin_logs.php" class="btn-reset">Sıfırla</a>
            </div>
        </form>

        <div class="table-container">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>İşlem Yapan</th>
                        <th>Tür (Scope)</th>
                        <th>Aksiyon</th>
                        <th>Detaylar</th>
                        <th>Tarih</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): 
                        // Renklendirme
                        $actorClass = 'actor-user';
                        if($log['actor_type'] === 'admin') $actorClass = 'actor-admin';
                        if($log['actor_type'] === 'agent') $actorClass = 'actor-agent';

                        $actClass = 'action-gray';
                        if(in_array($log['action'], ['create', 'confirm', 'approve'])) $actClass = 'action-green';
                        if(in_array($log['action'], ['delete', 'reject', 'cancel']))    $actClass = 'action-red';
                        if(in_array($log['action'], ['update', 'edit', 'adjust_balance', 'ban', 'unban'])) $actClass = 'action-orange';

                        // JSON meta
                        $metaData = json_decode($log['meta_json'], true);
                        if (json_last_error() !== JSON_ERROR_NONE) {
                            $metaData = null;
                        }

                        // Hedef kullanıcı username
                        $username = null;
                        if (is_array($metaData) && isset($metaData['user_id']) && $metaData['user_id'] > 0) {
                            $uStmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
                            $uStmt->execute([$metaData['user_id']]);
                            $username = $uStmt->fetchColumn();
                        }
                        
                        // İnsan okunur açıklama (Orijinal mantık korunmuştur)
                        $description = "Bir işlem gerçekleştirildi.";
                        if ($username) {
                            switch ($log['action']) {
                                case 'adjust_balance':
                                    $description = "Admin, {$username} kullanıcısının bakiyesinde manuel işlem yaptı.";
                                    break;
                                case 'ban':
                                    $description = "{$username} kullanıcısı banlandı.";
                                    break;
                                case 'unban':
                                    $description = "{$username} kullanıcısının banı kaldırıldı.";
                                    break;
                                case 'confirm':
                                    $description = "{$username} için bir işlem onaylandı.";
                                    break;
                                case 'reject':
                                    $description = "{$username} için bir işlem reddedildi.";
                                    break;
                                default:
                                    $description = "{$username} için bir işlem kaydı oluşturuldu.";
                                    break;
                            }
                        }

                        // Popup için meta JSON string
                        $metaAttr = $metaData && is_array($metaData)
                            ? htmlspecialchars(json_encode($metaData, JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8')
                            : '';
                        ?>
                    <tr>
                        <td><span style="font-family: monospace; color: var(--text-muted);">#<?= (int)$log['id'] ?></span></td>
                        
                        <td>
                            <span class="badge-actor <?= $actorClass ?>">
                                <?= strtoupper($log['actor_type']) ?> #<?= (int)$log['actor_id'] ?>
                            </span>
                        </td>
                        
                        <td style="font-weight: 600; text-transform: capitalize; color: var(--text-main);">
                            <?= htmlspecialchars($log['scope']) ?>
                        </td>
                        
                        <td>
                            <span class="badge-action <?= $actClass ?>">
                                <?= strtoupper(htmlspecialchars($log['action'])) ?>
                            </span>
                        </td>
                        
                        <td>
                            <div class="log-desc">
                                <?= htmlspecialchars($description) ?>
                                <?php if ($username): ?>
                                    <span style="color:var(--text-muted); font-size:12px;">
                                        (Kullanıcı: <?= htmlspecialchars($username) ?>)
                                    </span>
                                <?php endif; ?>
                            </div>

                            <?php if ($metaAttr !== ''): ?>
                                <button type="button"
                                            class="log-meta-btn js-log-detail"
                                            data-meta="<?= $metaAttr ?>">
                                    Teknik Detayları Görüntüle
                                </button>
                            <?php else: ?>
                                <span style="color: var(--text-muted); font-size:12px;">Ek teknik detay yok.</span>
                            <?php endif; ?>
                        </td>
                        
                        <td style="font-size: 12px; color: var(--text-muted); white-space: nowrap;">
                            <?= date('d.m.Y H:i:s', strtotime($log['created_at'])) ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>

                    <?php if(empty($logs)): ?>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 40px; color: var(--text-muted);">
                                <i class="ri-history-line" style="font-size: 48px; opacity: 0.5;"></i><br>
                                Bu kriterlere uygun kayıt bulunamadı.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    <?php endif; ?>
</div>

<div class="admin-modal-backdrop" id="log-detail-modal" style="display:none;">
    <div class="admin-modal" style="max-width: 700px;">
        <button type="button" class="admin-modal-close" id="log-detail-close">&times;</button>
        <div class="admin-modal-header">
            <h2>Teknik İşlem Detayı</h2>
        </div>
        <div class="admin-modal-body" id="log-detail-content">
            Yükleniyor...
        </div>
    </div>
</div>

<script>
document.addEventListener('click', function(e) {
    const btn = e.target.closest('.js-log-detail');
    if (!btn) return;

    const modal = document.getElementById('log-detail-modal');
    const content = document.getElementById('log-detail-content');
    const metaStr = btn.getAttribute('data-meta');

    if (!metaStr) {
        content.textContent = 'Teknik detay bulunamadı.';
        modal.style.display = 'flex';
        return;
    }

    try {
        const meta = JSON.parse(metaStr);
        content.textContent = JSON.stringify(meta, null, 2);
    } catch (err) {
        content.textContent = metaStr;
    }

    modal.style.display = 'flex';
});

document.getElementById('log-detail-close').addEventListener('click', function () {
    document.getElementById('log-detail-modal').style.display = 'none';
});

// Backdrop tıklandığında kapat
document.getElementById('log-detail-modal').addEventListener('click', function(e) {
    if (e.target === this) {
        this.style.display = 'none';
    }
});
</script>

<?php include __DIR__ . '/_admin_footer.php'; ?>