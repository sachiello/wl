<?php
// ajax_deposit_status.php
session_start();
require __DIR__ . '/../../config/config.php';  // veya index.php'de ne kullanıyorsan

$pdo = $pdo ?? null; // config.php içinde $pdo tanımlıysa gerek yok

header('Content-Type: application/json; charset=utf-8');

$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    echo json_encode([
        'ok'    => false,
        'error' => 'not_logged_in'
    ]);
    exit;
}

// 1) Pending var mı? (aktif yatırım)
$dq = $pdo->prepare("
    SELECT *
    FROM deposit_orders
    WHERE user_id = ? AND status = 'pending'
    ORDER BY id DESC
    LIMIT 1
");
$dq->execute([$userId]);
$pending = $dq->fetch(PDO::FETCH_ASSOC);

// 2) Son confirmed kayıt (bilgi için)
$cq = $pdo->prepare("
    SELECT *
    FROM deposit_orders
    WHERE user_id = ? AND status = 'confirmed'
    ORDER BY id DESC
    LIMIT 1
");
$cq->execute([$userId]);
$confirmed = $cq->fetch(PDO::FETCH_ASSOC);

$response = [
    'ok' => true,
    'has_pending'   => (bool)$pending,
    'has_confirmed' => (bool)$confirmed,
    'pending'   => $pending ? [
        'id'          => (int)$pending['id'],
        'amount_try'  => (float)$pending['amount_try'],
        'coin_type'   => $pending['coin_type'],
        'expire_at'   => $pending['expire_at'],
    ] : null,
    'confirmed' => $confirmed ? [
        'id'          => (int)$confirmed['id'],
        'amount_try'  => (float)$confirmed['amount_try'],
        'coin_type'   => $confirmed['coin_type'],
        'confirmed_at'=> $confirmed['confirmed_at'],
    ] : null,
];

echo json_encode($response);
