<?php
// admin/get_counts.php
// BURAYA require_admin.php'nin yolunu doğru ayarlayın. Örn:
require __DIR__ . '/require_admin.php'; 

// Güvenlik: Sadece JSON çıktısı ver
header('Content-Type: application/json');

// $pdo'nun bağlı olduğunu varsayıyoruz
if (!isset($pdo)) {
    http_response_code(500);
    die(json_encode(['error' => 'DB connection failed']));
}

try {
    $counts = [];

    // Sorgular (Hızlı olması için sadece COUNT kullanıldı)
    $counts['deposits'] = (int)$pdo->query("SELECT COUNT(*) FROM deposit_orders WHERE status = 'pending'")->fetchColumn();
    $counts['user_withdrawals'] = (int)$pdo->query("SELECT COUNT(*) FROM withdraw_requests WHERE status = 'pending'")->fetchColumn(); 
    $counts['site_withdrawals'] = (int)$pdo->query("SELECT COUNT(*) FROM site_withdrawals WHERE status = 'pending'")->fetchColumn();
    $counts['agent_requests'] = (int)$pdo->query("SELECT COUNT(*) FROM agent_balance_requests WHERE status = 'pending'")->fetchColumn();
    
    echo json_encode($counts);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Query error: ' . $e->getMessage()]);
}
?>