<?php
// admin/admin_deposit_agents.php - GÜNCELLENMİŞ FİNANSAL KONTROL SÜRÜMÜ
require __DIR__ . '/require_admin.php';

$pageTitle  = 'Aracı (Agent) Yönetimi';
$activeNav  = 'agents';

$adminError      = null;
$adminSuccess    = null;
$editIdFromPost  = null;
$csrfFailed      = false;
$adminId         = $currentAdmin['id']; // Loglama için Admin ID'sini alıyoruz

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !csrf_validate_request()) {
    $csrfFailed  = true;
    $adminError  = 'Oturum doğrulaması başarısız. Lütfen formu yenileyip tekrar deneyin.';
}

// --- LOGIC: 2FA SIFIRLAMA ---
if (!$csrfFailed && isset($_POST['reset_2fa'])) {
    $id   = (int)$_POST['reset_2fa'];
    $stmt = $pdo->prepare("UPDATE deposit_agents SET two_factor_enabled = 0, two_factor_secret = NULL WHERE id = ?");
    $stmt->execute([$id]);

    if (function_exists('bw_log_action')) {
        bw_log_action($pdo, 'agent', 'admin', $adminId, 'reset_2fa', ['agent_id' => $id]);
    }

    header('Location: admin_deposit_agents.php?edit=' . $id . '&ok=2fa_reset');
    exit;
}

// --- LOGIC: SİLME ---
if (!$csrfFailed && isset($_POST['delete_agent'])) {
    $id   = (int)$_POST['delete_agent'];
    $stmt = $pdo->prepare("DELETE FROM deposit_agents WHERE id = ?");
    $stmt->execute([$id]);

    if (function_exists('bw_log_action')) {
        bw_log_action($pdo, 'agent', 'admin', $adminId, 'delete', ['agent_id' => $id]);
    }

    header('Location: admin_deposit_agents.php?ok=deleted');
    exit;
}

// ==========================================================
// --- LOGIC: MANUEL BAKİYE DÜZENLEME (ADJUST BALANCE) ---
// ==========================================================
if (
    !$csrfFailed &&
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['adjust_agent_id'])
) {
    $targetAgentId = (int)$_POST['adjust_agent_id'];
    $field         = $_POST['balance_field']; // system_balance, current_cash, agent_profit_balance
    $newAmount     = (float)$_POST['new_amount'];
    $reason        = trim($_POST['reason']);
    $editIdFromPost = $targetAgentId;

    if ($newAmount < 0 || $reason === '') {
        $adminError = "Tutar pozitif olmalı ve açıklama zorunludur.";
    } else {
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("SELECT {$field} FROM deposit_agents WHERE id = ? FOR UPDATE");
            $stmt->execute([$targetAgentId]);
            $oldAmount = (float)$stmt->fetchColumn();

            $upd = $pdo->prepare("UPDATE deposit_agents SET {$field} = :amount WHERE id = :id");
            $upd->execute([
                ':amount' => $newAmount,
                ':id'     => $targetAgentId
            ]);

            $logMeta = [
                'agent_id'      => $targetAgentId,
                'field'         => $field,
                'amount_before' => number_format($oldAmount, 2),
                'amount_after'  => number_format($newAmount, 2),
                'reason'        => $reason
            ];

            $logStmt = $pdo->prepare("
                INSERT INTO activity_logs (actor_type, actor_id, scope, action, meta_json, created_at)
                VALUES ('admin', ?, 'agent_finance', 'adjust_balance', ?, NOW())
            ");
            $logStmt->execute([
                $adminId,
                json_encode($logMeta, JSON_UNESCAPED_UNICODE)
            ]);

            $pdo->commit();
            $adminSuccess = "Agent #{$targetAgentId} ({$field}) bakiyesi başarıyla {$newAmount} TL olarak ayarlandı.";
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $adminError = "İşlem Hatası: " . $e->getMessage();
        }
    }
}

// ==========================================================
// --- LOGIC: KAYDET (YENİ / DÜZENLE) - ŞİFRE DAHİL ---
// ==========================================================
if (
    !$csrfFailed &&
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['save_agent'])
) {
    $id              = isset($_POST['id']) && $_POST['id'] !== '' ? (int)$_POST['id'] : null;
    $name            = trim($_POST['name'] ?? '');
    $phone           = trim($_POST['phone'] ?? '');
    $email           = trim($_POST['email'] ?? '');
    $note            = trim($_POST['note'] ?? '');
    $commission_rate = (float)($_POST['commission_rate'] ?? 0);
    $isActive        = isset($_POST['is_active']) ? 1 : 0;

    // Şifre Yönetimi
    $newPassword = trim($_POST['new_password'] ?? '');
    $passwordHash = null;

    if ($id === null && $newPassword === '') {
        // Yeni Agent oluşturuluyorsa şifre zorunlu
        $adminError = 'Yeni Agent oluşturulurken şifre alanı boş bırakılamaz.';
    } elseif ($newPassword !== '') {
        $passwordHash = password_hash($newPassword, PASSWORD_BCRYPT);
    }

    $perms    = isset($_POST['perms']) ? $_POST['perms'] : [];
    $permJson = json_encode($perms);

    if ($name === '') {
        $adminError = 'Aracı adı zorunludur.';
    } elseif ($adminError) {
        // Şifre kontrolünden gelen hata varsa devam etme
    } else {
        try {
            if ($id) {
                // DÜZENLEME
                if ($passwordHash) {
                    $stmt = $pdo->prepare("
                        UPDATE deposit_agents
                        SET name = ?, phone = ?, email = ?, note = ?, is_active = ?, commission_rate = ?, permissions = ?, password_hash = ?
                        WHERE id = ?
                    ");
                    $stmt->execute([
                        $name,
                        $phone,
                        $email,
                        $note,
                        $isActive,
                        $commission_rate,
                        $permJson,
                        $passwordHash,
                        $id
                    ]);
                } else {
                    $stmt = $pdo->prepare("
                        UPDATE deposit_agents
                        SET name = ?, phone = ?, email = ?, note = ?, is_active = ?, commission_rate = ?, permissions = ?
                        WHERE id = ?
                    ");
                    $stmt->execute([
                        $name,
                        $phone,
                        $email,
                        $note,
                        $isActive,
                        $commission_rate,
                        $permJson,
                        $id
                    ]);
                }

                $adminSuccess = 'Aracı bilgileri güncellendi.' . ($passwordHash ? ' (Yeni şifre ayarlandı)' : '');

                if (function_exists('bw_log_action')) {
                    bw_log_action($pdo, 'agent', 'admin', $adminId, 'update_details', ['agent_id' => $id]);
                }
            } else {
                // YENİ OLUŞTURMA
                $stmt = $pdo->prepare("
                    INSERT INTO deposit_agents
                        (name, phone, email, note, quota_limit, quota_used, is_active, commission_rate, balance, permissions, role, password_hash)
                    VALUES
                        (?, ?, ?, ?, 0, 0, ?, ?, 0, ?, 'agent', ?)
                ");
                $stmt->execute([
                    $name,
                    $phone,
                    $email,
                    $note,
                    $isActive,
                    $commission_rate,
                    $permJson,
                    $passwordHash
                ]);

                $adminSuccess = 'Yeni aracı eklendi.';
                $id           = (int)$pdo->lastInsertId();

                if (function_exists('bw_log_action')) {
                    bw_log_action($pdo, 'agent', 'admin', $adminId, 'create', ['agent_id' => $id]);
                }
            }

            $editIdFromPost = $id;
        } catch (Exception $e) {
            $adminError = 'Kayıt Hatası: ' . $e->getMessage();
        }
    }
}

// --- LOGIC: HIZLI IBAN EKLEME ---
if (
    !$csrfFailed &&
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['add_agent_iban'])
) {
    $agentForIban  = isset($_POST['agent_for_iban']) ? (int)$_POST['agent_for_iban'] : 0;
    $editIdFromPost = $agentForIban ?: null;
    $bankName      = trim($_POST['quick_bank_name'] ?? '');
    $holderName    = trim($_POST['quick_holder_name'] ?? '');
    $iban          = trim($_POST['quick_iban'] ?? '');
    $isActive      = isset($_POST['quick_is_active']) ? 1 : 0;

    if ($agentForIban > 0 && $bankName !== '' && $iban !== '') {
        $stmt = $pdo->prepare("
            INSERT INTO deposit_ibans
                (bank_name, holder_name, iban, agent_id, owner_admin_id, quota_limit, quota_used, is_active)
            VALUES
                (?, ?, ?, ?, ?, 0, 0, ?)
        ");
        $stmt->execute([
            $bankName,
            $holderName,
            $iban,
            $agentForIban,
            $adminId,
            $isActive
        ]);

        if (function_exists('bw_log_action')) {
            bw_log_action($pdo, 'iban', 'admin', $adminId, 'create', ['agent_id' => $agentForIban]);
        }

        header('Location: admin_deposit_agents.php?edit=' . $agentForIban . '&ok=iban_added');
        exit;
    } else {
        $adminError = 'Eksik bilgi.';
    }
}

// =============== DÜZENLENECEK KAYIT ===============
$editAgent     = null;
$editTargetId  = null;

if (isset($_GET['edit'])) {
    $editTargetId = (int)$_GET['edit'];
} elseif ($editIdFromPost) {
    $editTargetId = (int)$editIdFromPost;
}

if ($editTargetId) {
    $stmt = $pdo->prepare("SELECT * FROM deposit_agents WHERE id = ? LIMIT 1");
    $stmt->execute([$editTargetId]);
    $editAgent = $stmt->fetch(PDO::FETCH_ASSOC);
}

$editAgentIbans = [];
if ($editAgent) {
    $stmt = $pdo->prepare("
        SELECT *
        FROM deposit_ibans
        WHERE agent_id = ?
        ORDER BY is_active DESC, id DESC
    ");
    $stmt->execute([$editAgent['id']]);
    $editAgentIbans = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$agentPerms = [];
if ($editAgent) {
    $agentPerms = json_decode($editAgent['permissions'] ?? '[]', true);
    if (!is_array($agentPerms)) {
        $agentPerms = [];
    }
} else {
    // Yeni Agent varsayılan yetkiler
    $agentPerms = [
        'approve_deposit',
        'approve_withdraw',
        'manage_ibans',
        'request_balance',
        'manage_personnel',
        'view_reports',
        'view_profit_wallet',
        'view_profit_logs'
    ];
}

// =============== LİSTE (YENİ SORGUSU) ===============
$listStmt = $pdo->query("
    SELECT 
        a.id,
        a.name,
        a.phone,
        a.email,
        a.commission_rate,
        a.is_active,
        a.two_factor_enabled,
        a.system_balance,
        a.current_cash,
        a.agent_profit_balance,
        a.role,
        (SELECT COUNT(*) FROM deposit_ibans di WHERE di.agent_id = a.id) AS iban_count 
    FROM deposit_agents a 
    WHERE a.role = 'agent' OR a.role = 'personnel'
    ORDER BY a.role, a.is_active DESC, a.id DESC
");
$agents = $listStmt->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/_admin_header.php';
?>

<style>
/* ============================
   BetWallet Admin – Agent Yönetimi
   ============================ */

.page-content {
    padding: 24px 32px;
}

/* Toolbar */
.toolbar-container {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 16px;
    flex-wrap: wrap;
    margin-bottom: 20px;
}

.toolbar-title h1 {
    margin: 0;
    font-size: 20px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 8px;
    color: var(--text-main, #111827);
}

.toolbar-title p {
    margin: 4px 0 0;
    font-size: 13px;
    color: var(--text-muted, #6b7280);
}

.toolbar-actions {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}

.chip-metric {
    padding: 6px 12px;
    border-radius: 999px;
    border: 1px solid var(--border-light, #e5e7eb);
    background: #f9fafb;
    font-size: 12px;
    color: var(--text-muted, #6b7280);
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

/* Alerts */
.alert-box {
    padding: 10px 12px;
    border-radius: 10px;
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    border: 1px solid transparent;
}
.alert-danger {
    background: #fef2f2;
    color: #b91c1c;
    border-color: #fecaca;
}
.alert-success {
    background: #ecfdf5;
    color: #15803d;
    border-color: #bbf7d0;
}

/* Form card */
.form-card {
    background: #ffffff;
    padding: 22px 24px;
    border-radius: 18px;
    box-shadow: 0 10px 30px rgba(15, 23, 42, 0.06);
    margin-bottom: 24px;
    border: 1px solid var(--border-light, #e5e7eb);
}

.form-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 18px;
    padding-bottom: 10px;
    border-bottom: 1px solid var(--border-light, #e5e7eb);
}

.form-header h2 {
    margin: 0;
    font-size: 18px;
    color: var(--text-main, #111827);
    display: flex;
    align-items: center;
    gap: 8px;
}

.admin-form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 18px 20px;
}

.form-group label {
    display: block;
    font-size: 12px;
    font-weight: 600;
    color: var(--text-muted, #6b7280);
    margin-bottom: 6px;
    text-transform: uppercase;
    letter-spacing: 0.04em;
}

.form-input,
textarea.form-input,
select.form-input {
    width: 100%;
    padding: 10px 11px;
    border-radius: 10px;
    border: 1px solid var(--border-light, #e5e7eb);
    background: #ffffff;
    color: var(--text-main, #111827);
    font-size: 13px;
    box-sizing: border-box;
}
.form-input:focus,
textarea.form-input:focus,
select.form-input:focus {
    border-color: #c2273f;
    outline: none;
    box-shadow: 0 0 0 1px rgba(194, 39, 63, 0.18);
}

.full-width {
    grid-column: 1 / -1;
}

/* Checkbox group */
.checkbox-wrapper {
    display: flex;
    flex-wrap: wrap;
    gap: 6px 14px;
}
.checkbox-label {
    font-size: 13px;
    color: var(--text-main, #111827);
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

/* Buttons */
.btn-submit {
    background: #c2273f;
    color: #ffffff;
    border: none;
    padding: 10px 18px;
    border-radius: 999px;
    font-weight: 600;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 7px;
    font-size: 13px;
}
.btn-submit:hover {
    opacity: 0.92;
}
.btn-cancel {
    background: #f3f4f6;
    color: var(--text-muted, #6b7280);
    border: 1px solid var(--border-light, #e5e7eb);
    padding: 8px 14px;
    border-radius: 999px;
    text-decoration: none;
    font-size: 13px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

/* Finance Info cards */
.finance-info-block {
    background: #f9fafb;
    padding: 14px 16px;
    border-radius: 10px;
    border: 1px solid #e5e7eb;
}

/* Table */
.table-container {
    background: #ffffff;
    border-radius: 18px;
    box-shadow: 0 10px 30px rgba(15, 23, 42, 0.06);
    overflow-x: auto;
    margin-top: 8px;
    border: 1px solid var(--border-light, #e5e7eb);
}

.admin-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}
.admin-table thead {
    background: linear-gradient(to right, #f9fafb, #fef2f2);
}
.admin-table th {
    text-align: left;
    padding: 10px 14px;
    color: var(--text-muted, #6b7280);
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    border-bottom: 1px solid var(--border-light, #e5e7eb);
}
.admin-table td {
    padding: 10px 14px;
    border-top: 1px solid #f3f4f6;
    vertical-align: middle;
    color: var(--text-main, #111827);
}
.admin-table tbody tr:hover td {
    background: #fef2f2;
}

/* Badges */
.status-badge {
    padding: 3px 9px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
}
.status-active {
    background: #dcfce7;
    color: #15803d;
    border: 1px solid #bbf7d0;
}
.status-passive {
    background: #f3f4f6;
    color: #6b7280;
    border: 1px solid #e5e7eb;
}

.finance-badge {
    padding: 3px 8px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 600;
    display: inline-flex;
    margin-top: 4px;
}
.bg-blue-light {
    background: #eff6ff;
    color: #2563eb;
}
.bg-green-light {
    background: #dcfce7;
    color: #15803d;
}
.bg-yellow-light {
    background: #fef9c3;
    color: #854d0e;
}

/* Row actions */
.action-btn {
    width: 30px;
    height: 30px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    text-decoration: none;
    border: 1px solid transparent;
    margin-left: 4px;
    font-size: 15px;
}
.btn-edit {
    background: #eff6ff;
    color: #1d4ed8;
    border-color: #dbeafe;
}
.btn-del {
    background: #fef2f2;
    color: #b91c1c;
    border-color: #fecaca;
}
.action-btn:hover {
    transform: translateY(-1px);
}

/* Super login */
.btn-super {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    background-color: #f97316;
    color: #ffffff;
    padding: 6px 12px;
    border-radius: 999px;
    text-decoration: none;
    font-size: 11px;
    font-weight: 600;
    border: 1px solid #ea580c;
    margin-right: 4px;
}

/* Inline input */
.admin-input-inline {
    width: 110px;
    padding: 7px 9px;
    border-radius: 999px;
    border: 1px solid #e5e7eb;
    font-size: 12px;
    text-align: right;
}

/* Responsive */
@media (max-width: 768px) {
    .page-content {
        padding: 16px;
    }
    .form-card {
        padding: 18px;
    }
}
</style>

<div class="page-content">

    <div class="toolbar-container">
        <div class="toolbar-title">
            <h1>
                <i class="ri-team-line" style="color:#c2273f;"></i>
                Aracı (Agent) Yönetimi
            </h1>
            <p>Agent ve personel hesaplarını, komisyon oranlarını ve finansal bakiyelerini yönetin.</p>
        </div>
        <div class="toolbar-actions">
            <span class="chip-metric">
                <i class="ri-user-settings-line"></i>
                Toplam Agent / Personel: <?= count($agents) ?>
            </span>
        </div>
    </div>

    <?php if ($adminError): ?>
        <div class="alert-box alert-danger">
            <i class="ri-error-warning-fill"></i>
            <?= htmlspecialchars($adminError) ?>
        </div>
    <?php endif; ?>

    <?php if ($adminSuccess): ?>
        <div class="alert-box alert-success">
            <i class="ri-checkbox-circle-fill"></i>
            <?= htmlspecialchars($adminSuccess) ?>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['ok'])): ?>
        <div class="alert-box alert-success">
            <i class="ri-checkbox-circle-fill"></i>
            İşlem başarılı: <?= htmlspecialchars($_GET['ok']) ?>
        </div>
    <?php endif; ?>

    <div class="form-card">
        <div class="form-header">
            <h2>
                <i class="ri-user-star-line" style="color:#c2273f;"></i>
                <?= $editAgent ? 'Aracı Düzenle' : 'Yeni Aracı Ekle' ?>
            </h2>
            <?php if ($editAgent): ?>
                <a href="admin_deposit_agents.php" class="btn-cancel">
                    <i class="ri-arrow-go-back-line"></i> Yeni Kayıt
                </a>
            <?php endif; ?>
        </div>

        <form method="post">
            <?= csrf_field(); ?>
            <?php if ($editAgent): ?>
                <input type="hidden" name="id" value="<?= (int)$editAgent['id'] ?>">
            <?php endif; ?>

            <div class="admin-form-grid">
                <div class="form-group">
                    <label>Aracı Adı</label>
                    <input
                        type="text"
                        name="name"
                        class="form-input"
                        placeholder="Örn: Hızlı Finans"
                        value="<?= htmlspecialchars($editAgent['name'] ?? '') ?>"
                        required
                    >
                </div>

                <div class="form-group">
                    <label>Telefon</label>
                    <input
                        type="text"
                        name="phone"
                        class="form-input"
                        placeholder="05XX..."
                        value="<?= htmlspecialchars($editAgent['phone'] ?? '') ?>"
                    >
                </div>

                <div class="form-group">
                    <label>Email</label>
                    <input
                        type="email"
                        name="email"
                        class="form-input"
                        placeholder="email@example.com"
                        value="<?= htmlspecialchars($editAgent['email'] ?? '') ?>"
                    >
                </div>

                <div class="form-group">
                    <label>
                        <?= $editAgent ? 'Yeni Şifre' : 'Şifre' ?>
                        <small style="color:var(--text-muted,#6b7280);">
                            (<?= $editAgent ? 'Boş bırakılırsa değişmez' : 'İlk giriş şifresi' ?>)
                        </small>
                    </label>
                    <input
                        type="password"
                        name="new_password"
                        class="form-input"
                        placeholder="<?= $editAgent ? '********' : 'Şifre Belirle' ?>"
                        <?= $editAgent ? '' : 'required' ?>
                    >
                </div>

                <div class="form-group">
                    <label>Komisyon (%)</label>
                    <input
                        type="number"
                        step="0.01"
                        min="0"
                        name="commission_rate"
                        class="form-input"
                        value="<?= htmlspecialchars($editAgent['commission_rate'] ?? '2.50') ?>"
                    >
                </div>

                <div class="form-group full-width">
                    <label>Yetkiler</label>
                    <div class="checkbox-wrapper">
                        <?php
                        $allPerms = [
                            'approve_deposit'    => 'Yatırım Onayı',
                            'approve_withdraw'   => 'Çekim / Ödeme',
                            'manage_ibans'       => 'IBAN Yönetimi',
                            'request_balance'    => 'Bakiye Talep',
                            'manage_personnel'   => 'Personel Yönetimi',
                            'view_reports'       => 'Rapor Görüntüleme',
                            'view_profit_wallet' => 'Kâr Cüzdanı',
                            'view_profit_logs'   => 'Kâr Hareketleri'
                        ];
                        foreach ($allPerms as $key => $label):
                        ?>
                            <label class="checkbox-label">
                                <input
                                    type="checkbox"
                                    name="perms[]"
                                    value="<?= $key ?>"
                                    <?= in_array($key, $agentPerms) ? 'checked' : '' ?>
                                >
                                <?= $label ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="form-group full-width">
                    <label>Notlar</label>
                    <textarea
                        name="note"
                        class="form-input"
                        rows="2"
                        placeholder="Bu agent hakkında iç notlar..."
                    ><?= htmlspecialchars($editAgent['note'] ?? '') ?></textarea>
                </div>

                <?php if ($editAgent): ?>
                <div class="form-group full-width finance-info-block">
                    <div style="display:flex; justify-content:space-between; align-items:center; gap:16px;">
                        <div>
                            <label style="margin:0;">Güvenlik Durumu (2FA)</label>
                            <div style="font-size:13px; margin-top:6px;">
                                <?php if ($editAgent['two_factor_enabled']): ?>
                                    <span style="color:#16a34a; font-weight:600;">
                                        <i class="ri-shield-check-fill"></i> Aktif
                                    </span>
                                <?php else: ?>
                                    <span style="color:#6b7280;">
                                        <i class="ri-shield-line"></i> Pasif
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <?php if ($editAgent['two_factor_enabled']): ?>
                        <button
                            type="submit"
                            name="reset_2fa"
                            value="<?= (int)$editAgent['id'] ?>"
                            class="btn-submit"
                            style="background:#fee2e2; color:#b91c1c; padding-inline:14px;"
                            onclick="return confirm('Bu aracının 2FA korumasını sıfırlamak üzeresiniz. Onaylıyor musunuz?');"
                        >
                            <i class="ri-refresh-line"></i> 2FA Sıfırla
                        </button>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>

                <div class="form-group full-width">
                    <label class="checkbox-label" style="font-weight:600;">
                        <input
                            type="checkbox"
                            name="is_active"
                            <?= isset($editAgent['is_active']) ? ($editAgent['is_active'] ? 'checked' : '') : 'checked' ?>
                        >
                        Aracı Aktif
                    </label>
                </div>

                <div class="full-width" style="margin-top:4px;">
                    <button type="submit" name="save_agent" class="btn-submit">
                        <i class="ri-save-line"></i>
                        <?= $editAgent ? 'Değişiklikleri Kaydet' : 'Aracıyı Oluştur' ?>
                    </button>
                </div>
            </div>
        </form>

        <?php if ($editAgent): ?>
        <hr style="margin:24px 0; border-color:#e5e7eb;">
        <h3 style="margin-bottom:16px; font-size:16px; color:var(--text-main,#111827);">
            <i class="ri-bank-card-2-line" style="color:#c2273f;"></i>
            Finansal Durum & IBAN Yönetimi
        </h3>

        <div style="display:flex; flex-wrap:wrap; gap:18px; align-items:flex-start;">
            <div class="form-card" style="flex:1; margin-bottom:0;">
                <h4 style="margin:0 0 10px 0; font-size:15px;">
                    <i class="ri-tools-line"></i> Manuel Bakiye Ayarlama
                </h4>
                <p style="font-size:12px; color:var(--text-muted,#6b7280); margin:0 0 12px 0;">
                    Girilen tutar, seçtiğiniz alandaki yeni toplam bakiye olarak ayarlanır ve loglanır.
                </p>
                <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="adjust_agent_id" value="<?= (int)$editAgent['id'] ?>">

                    <div class="form-group">
                        <label>Ayarlanacak Alan</label>
                        <select name="balance_field" class="form-input" required>
                            <option value="system_balance">
                                Teminat (<?= number_format($editAgent['system_balance'], 2) ?> TL)
                            </option>
                            <option value="current_cash">
                                Nakit Kasa (<?= number_format($editAgent['current_cash'], 2) ?> TL)
                            </option>
                            <option value="agent_profit_balance">
                                Kâr Bakiyesi (<?= number_format($editAgent['agent_profit_balance'], 2) ?> TL)
                            </option>
                        </select>
                    </div>

                    <div class="form-group" style="margin-top:12px;">
                        <label>Yeni Tutar (TL)</label>
                        <input
                            type="number"
                            step="0.01"
                            min="0"
                            name="new_amount"
                            class="form-input"
                            required
                            placeholder="Yeni toplam bakiyeyi girin"
                        >
                    </div>

                    <div class="form-group" style="margin-top:12px;">
                        <label>Açıklama (Zorunlu)</label>
                        <input
                            type="text"
                            name="reason"
                            class="form-input"
                            required
                            placeholder="Neden düzenleme yapılıyor? (Loglanacak)"
                        >
                    </div>

                    <button
                        type="submit"
                        class="btn-submit"
                        style="background:#dc2626; margin-top:16px;"
                    >
                        <i class="ri-exchange-dollar-line"></i> Bakiyeyi Ayarla
                    </button>
                </form>
            </div>

            <div class="form-card" style="flex:1; margin-bottom:0;">
                <h4 style="margin:0 0 10px 0; font-size:15px;">
                    <i class="ri-bank-card-line"></i> Hızlı IBAN Ekleme
                </h4>
                <p style="font-size:12px; color:var(--text-muted,#6b7280); margin:0 0 12px 0;">
                    Bu aracıya ait yeni bir yatırım IBAN’ı tanımlayın.
                </p>
                <form method="post">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="add_agent_iban" value="1">
                    <input type="hidden" name="agent_for_iban" value="<?= (int)$editAgent['id'] ?>">

                    <div class="form-group">
                        <label>Banka Adı</label>
                        <input type="text" name="quick_bank_name" class="form-input" required>
                    </div>

                    <div class="form-group" style="margin-top:12px;">
                        <label>Hesap Sahibi</label>
                        <input type="text" name="quick_holder_name" class="form-input" required>
                    </div>

                    <div class="form-group" style="margin-top:12px;">
                        <label>IBAN</label>
                        <input type="text" name="quick_iban" class="form-input" required>
                    </div>

                    <div class="form-group" style="margin-top:10px;">
                        <label class="checkbox-label">
                            <input type="checkbox" name="quick_is_active" value="1" checked>
                            IBAN aktif olsun
                        </label>
                    </div>

                    <button
                        type="submit"
                        class="btn-submit"
                        style="background:#059669; margin-top:16px;"
                    >
                        <i class="ri-add-line"></i> IBAN Ekle
                    </button>
                </form>
            </div>
        </div>

        <h4 style="margin-top:22px; margin-bottom:10px; font-size:15px;">
            <i class="ri-list-check-2-line"></i>
            Aracıya Atanmış IBAN'lar (<?= count($editAgentIbans) ?>)
        </h4>
        <div class="table-container">
            <?php if (!$editAgentIbans): ?>
                <div style="padding:16px; font-size:13px; color:var(--text-muted,#6b7280);">
                    Bu aracıya ait tanımlı IBAN bulunmuyor.
                </div>
            <?php else: ?>
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Banka</th>
                            <th>Hesap Sahibi</th>
                            <th>IBAN</th>
                            <th>Aktif</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($editAgentIbans as $ib): ?>
                            <tr>
                                <td>#<?= (int)$ib['id'] ?></td>
                                <td><?= htmlspecialchars($ib['bank_name']) ?></td>
                                <td><?= htmlspecialchars($ib['holder_name']) ?></td>
                                <td style="font-family:monospace; font-size:12px;">
                                    <?= htmlspecialchars($ib['iban']) ?>
                                </td>
                                <td>
                                    <?= $ib['is_active']
                                        ? '<span class="status-badge status-active">Aktif</span>'
                                        : '<span class="status-badge status-passive">Pasif</span>' ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <div class="table-container">
        <div style="padding:10px 14px; border-bottom:1px solid #e5e7eb; display:flex; justify-content:space-between; align-items:center;">
            <h3 style="margin:0; font-size:15px; color:var(--text-main,#111827);">
                Tüm Agent ve Personel Listesi
            </h3>
        </div>

        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID / Rol</th>
                    <th>Aracı Bilgisi</th>
                    <th><i class="ri-coins-line"></i> Teminat (Sistem)</th>
                    <th><i class="ri-wallet-3-line"></i> Nakit Kasa</th>
                    <th><i class="ri-money-dollar-circle-line"></i> Kâr Bakiyesi</th>
                    <th>Komisyon</th>
                    <th>IBAN</th>
                    <th>Durum</th>
                    <th style="text-align:right;">İşlemler</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$agents): ?>
                <tr>
                    <td colspan="9" style="text-align:center; padding:24px; color:var(--text-muted,#6b7280);">
                        Kayıtlı agent bulunamadı.
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($agents as $a): ?>
                <tr<?php if ($a['role'] !== 'agent'): ?> style="background:#f9fafb;"<?php endif; ?>>
                    <td>
                        <span style="font-family:monospace;"><?= (int)$a['id'] ?></span>
                        <div style="margin-top:4px;">
                            <span style="font-size:11px; background:#eef2ff; color:#4f46e5; padding:2px 6px; border-radius:999px; font-weight:600;">
                                <?= htmlspecialchars(strtoupper($a['role'])) ?>
                            </span>
                        </div>
                    </td>
                    <td>
                        <div style="font-weight:600;"><?= htmlspecialchars($a['name']) ?></div>
                        <div style="font-size:11px; color:var(--text-muted,#6b7280);">
                            <?= htmlspecialchars($a['email'] ?: ($a['phone'] ?? '-')) ?>
                        </div>
                    </td>
                    <td>
                        <?= number_format($a['system_balance'] ?? 0, 2) ?> TL
                        <div class="finance-badge bg-blue-light">Teminat</div>
                    </td>
                    <td>
                        <?= number_format($a['current_cash'] ?? 0, 2) ?> TL
                        <div class="finance-badge bg-green-light">Kasa</div>
                    </td>
                    <td>
                        <?= number_format($a['agent_profit_balance'] ?? 0, 2) ?> TL
                        <div class="finance-badge bg-yellow-light">Kâr</div>
                    </td>
                    <td>%<?= number_format($a['commission_rate'] ?? 0, 2) ?></td>
                    <td><?= (int)$a['iban_count'] ?></td>
                    <td>
                        <?= $a['is_active']
                            ? '<span class="status-badge status-active">Aktif</span>'
                            : '<span class="status-badge status-passive">Pasif</span>' ?>
                    </td>
                    <td style="text-align:right; white-space:nowrap;">
                        <a
                            href="super_login.php?agent_id=<?= (int)$a['id'] ?>"
                            target="_blank"
                            class="btn-super"
                        >
                            🔑 Panel
                        </a>
                        <a
                            href="admin_deposit_agents.php?edit=<?= (int)$a['id'] ?>"
                            class="action-btn btn-edit"
                        >
                            <i class="ri-pencil-line"></i>
                        </a>
                        <form
                            method="post"
                            style="display:inline;"
                            onsubmit="return confirm('Bu aracıyı silmek istediğinize emin misiniz?');"
                        >
                            <?= csrf_field(); ?>
                            <input type="hidden" name="delete_agent" value="<?= (int)$a['id'] ?>">
                            <button type="submit" class="action-btn btn-del">
                                <i class="ri-delete-bin-line"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<?php include __DIR__ . '/_admin_footer.php'; ?>
