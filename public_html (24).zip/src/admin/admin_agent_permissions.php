<?php
require __DIR__ . '/require_admin.php'; // Sadece Master Admin erişebilir

$success_msg = null;
$error_msg = null;
$csrfFailed = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !csrf_validate_request()) {
    $csrfFailed = true;
    $error_msg = 'Oturum doğrulaması başarısız. Lütfen formu yenileyip tekrar deneyin.';
}

// Form gönderildi mi?
if (!$csrfFailed && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_permissions'])) {
    $agentId = (int)($_POST['agent_id'] ?? 0);

    if ($agentId > 0) {
        // İzinleri al ve JSON yapısını oluştur
        $permissions = [
            'view_havale' => isset($_POST['perm_view_havale']),
            'view_crypto' => isset($_POST['perm_view_crypto']),
            'view_cc'     => isset($_POST['perm_view_cc']),
            'can_approve' => isset($_POST['perm_can_approve']),
        ];
        $jsonPermissions = json_encode($permissions);

        try {
            $stmt = $pdo->prepare("UPDATE deposit_agents SET permissions = ? WHERE id = ?");
            $stmt->execute([$jsonPermissions, $agentId]);
            $success_msg = "Agent #{$agentId} için yetkiler güncellendi.";
        } catch (PDOException $e) {
            $error_msg = "Veritabanı hatası: " . $e->getMessage();
        }
    } else {
        $error_msg = "Geçersiz agent ID.";
    }
}

// Tüm agent'ları çek
$agents = $pdo->query("SELECT id, name, permissions FROM deposit_agents ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/_admin_header.php';
?>

<div class="admin-container">
    <h1>Agent Yetki Yönetimi</h1>
    <p>Sistemdeki agent'ların hangi yatırım türlerini görebileceğini ve işlem onayı yapıp yapamayacağını buradan yönetebilirsiniz.</p>

    <?php if ($success_msg): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success_msg) ?></div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error_msg) ?></div>
    <?php endif; ?>

    <table class="admin-table">
        <thead>
            <tr>
                <th>Agent ID</th>
                <th>Agent Adı</th>
                <th>Havale Görebilir</th>
                <th>Kripto Görebilir</th>
                <th>K. Kartı Görebilir</th>
                <th>Onay/Red Yapabilir</th>
                <th>İşlem</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($agents as $agent):
                // JSON verisini decode et, eğer yoksa veya hatalıysa varsayılan bir yapı kullan
                $perms = $agent['permissions'] ? json_decode($agent['permissions'], true) : [];
                $canViewHavale = $perms['view_havale'] ?? false;
                $canViewCrypto = $perms['view_crypto'] ?? false;
                $canViewCC = $perms['view_cc'] ?? false;
                $canApprove = $perms['can_approve'] ?? false;
            ?>
            <tr>
                <form method="post">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="agent_id" value="<?= $agent['id'] ?>">
                    <td><?= $agent['id'] ?></td>
                    <td><?= htmlspecialchars($agent['name']) ?></td>
                    <td>
                        <input type="checkbox" name="perm_view_havale" <?= $canViewHavale ? 'checked' : '' ?>>
                    </td>
                    <td>
                        <input type="checkbox" name="perm_view_crypto" <?= $canViewCrypto ? 'checked' : '' ?>>
                    </td>
                    <td>
                        <input type="checkbox" name="perm_view_cc" <?= $canViewCC ? 'checked' : '' ?>>
                    </td>
                    <td>
                        <input type="checkbox" name="perm_can_approve" <?= $canApprove ? 'checked' : '' ?>>
                    </td>
                    <td>
                        <button type="submit" name="update_permissions" class="admin-btn small">Kaydet</button>
                    </td>
                </form>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include __DIR__ . '/_admin_footer.php'; ?>
