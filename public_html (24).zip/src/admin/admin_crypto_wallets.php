<?php
// admin/admin_crypto_wallets.php
require __DIR__ . '/require_admin.php';

$pageTitle    = 'Kripto Cüzdan Ayarları';
$activeNav    = 'settings'; // Menüde ayarlar altında veya ayrı gösterebilirsin

$adminError   = null;
$adminSuccess = null;
$csrfFailed   = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !csrf_validate_request()) {
    $csrfFailed = true;
    $adminError = 'Oturum doğrulaması başarısız. Lütfen formu yenileyip tekrar deneyin.';
}

// 1. Mevcut Cüzdanı Kontrol Et (Yoksa Otomatik Oluştur)
$stmt = $pdo->prepare("SELECT * FROM admin_crypto_wallets WHERE coin_symbol = 'USDT' AND network = 'TRC20' LIMIT 1");
$stmt->execute();
$wallet = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$wallet) {
    // Tablo boşsa varsayılan kaydı oluştur ki hata vermesin
    $pdo->exec("INSERT INTO admin_crypto_wallets (network, coin_symbol, address, is_active) VALUES ('TRC20', 'USDT', 'Lutfen_Guncel_Adresinizi_Girin', 1)");
    header("Refresh:0"); // Sayfayı yenile
    exit;
}

// 2. Form Kaydedildiğinde
if (!$csrfFailed && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_wallet'])) {
    $address  = trim($_POST['address']);
    $isActive = isset($_POST['is_active']) ? 1 : 0;

    if (empty($address)) {
        $adminError = "Cüzdan adresi boş bırakılamaz.";
    } else {
        $update = $pdo->prepare("UPDATE admin_crypto_wallets SET address = ?, is_active = ? WHERE id = ?");
        if ($update->execute([$address, $isActive, $wallet['id']])) {
            $adminSuccess = "Cüzdan adresi başarıyla güncellendi.";
            // Veriyi tazele
            $stmt->execute();
            $wallet = $stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            $adminError = "Güncelleme sırasında hata oluştu.";
        }
    }
}

include __DIR__ . '/_admin_header.php';
?>

<style>
    /* Senin Admin CSS'inle Uyumlu */
    .form-card { background: #fff; padding: 24px; border-radius: var(--radius-lg); box-shadow: var(--shadow-soft); margin-bottom: 30px; border: 1px solid var(--border-light); }
    .form-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid var(--border-light); }
    .form-header h2 { margin: 0; font-size: 18px; color: var(--text-main); display: flex; align-items: center; gap: 8px; }
    .form-group { margin-bottom: 20px; }
    .form-group label { display: block; font-size: 13px; font-weight: 600; color: var(--text-muted); margin-bottom: 8px; }
    .form-input { width: 100%; padding: 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-light); background: #f8fafc; color: var(--text-main); font-size: 14px; transition: all 0.2s; font-family: monospace; }
    .form-input:focus { outline: none; border-color: var(--primary); background: #fff; box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1); }
    
    .btn-submit { background: var(--primary); color: #fff; border: none; padding: 12px 24px; border-radius: var(--radius-sm); font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; transition: all 0.2s; }
    .btn-submit:hover { background: #2563eb; transform: translateY(-2px); }

    .alert-box { padding: 15px; border-radius: var(--radius-sm); margin-bottom: 20px; display: flex; align-items: center; gap: 10px; font-size: 14px; }
    .alert-danger { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
    .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; }
    
    .info-badge { background: #eff6ff; color: #1e40af; padding: 4px 10px; border-radius: 4px; font-size: 12px; font-weight: 600; display: inline-block; margin-bottom: 10px; }
</style>

<div class="page-content">

    <?php if ($adminError): ?>
        <div class="alert-box alert-danger">
            <i class="ri-error-warning-fill" style="font-size: 18px;"></i>
            <?= htmlspecialchars($adminError) ?>
        </div>
    <?php endif; ?>
    
    <?php if ($adminSuccess): ?>
        <div class="alert-box alert-success">
            <i class="ri-checkbox-circle-fill" style="font-size: 18px;"></i>
            <?= htmlspecialchars($adminSuccess) ?>
        </div>
    <?php endif; ?>

    <div class="form-card" style="max-width: 600px; margin: 0 auto;">
        <div class="form-header">
            <h2>
                <i class="ri-qr-code-line" style="color: var(--primary);"></i>
                Yatırım Cüzdanı Yönetimi
            </h2>
        </div>

        <form method="post">
            <?= csrf_field(); ?>
            <div class="form-group">
                <span class="info-badge">USDT - TRC20 Ağı</span>
                <p style="font-size: 13px; color: #64748b; margin-top: 5px; line-height: 1.5;">
                    Buraya gireceğiniz cüzdan adresi, <b>Tüm Agent'ların</b> bakiye yükleme ekranında görünecektir. Lütfen adresi doğru girdiğinizden emin olun.
                </p>
            </div>

            <div class="form-group">
                <label>Cüzdan Adresi (TRC20)</label>
                <input type="text" name="address" class="form-input" 
                       value="<?= htmlspecialchars($wallet['address']) ?>" 
                       placeholder="T..." required>
            </div>

            <div class="form-group">
                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-weight: 600; color: var(--text-main);">
                    <input type="checkbox" name="is_active" style="width: 18px; height: 18px;" 
                        <?= $wallet['is_active'] ? 'checked' : '' ?>>
                    <span>Bu adres Agent panelinde görünsün (Aktif)</span>
                </label>
            </div>

            <div style="margin-top: 20px; text-align: right;">
                <button type="submit" name="save_wallet" class="btn-submit">
                    <i class="ri-save-line"></i> Değişiklikleri Kaydet
                </button>
            </div>
        </form>
    </div>

    <div style="max-width: 600px; margin: 20px auto; text-align: center; opacity: 0.7;">
        <p style="font-size: 12px; color: #94a3b8;">
            <i class="ri-eye-line"></i> Bu adres Agent panelinde otomatik olarak güncellenecektir.
        </p>
    </div>

</div>

<?php include __DIR__ . '/_admin_footer.php'; ?>
