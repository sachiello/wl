<?php
// admin/admin_actions.php
session_start();
require __DIR__ . '/../../config/config.php';
require __DIR__ . '/includes/functions.php';

// Sadece POST isteklerini kabul et
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

// Admin Giriş Kontrolü
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

// CSRF Kontrolü
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    die('Güvenlik İhlali: CSRF Token geçersiz.');
}

$action = $_POST['action'] ?? '';
$id = intval($_POST['id'] ?? 0);

try {
    // =================================================
    // 1. SITE -> CÜZDAN TRANSFER ONAYI
    // =================================================
    if ($action === 'approve_merchant_transfer') {
        
        // 1. Kaydı bul
        $stmt = $pdo->prepare("SELECT * FROM merchant_player_withdraws WHERE id = ? AND status = 'pending'");
        $stmt->execute([$id]);
        $transfer = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$transfer) throw new Exception("Talep bulunamadı veya zaten işlenmiş.");

        $pdo->beginTransaction();

        // 2. Transferi onayla
        $upd = $pdo->prepare("UPDATE merchant_player_withdraws SET status = 'approved', processed_at = NOW() WHERE id = ?");
        $upd->execute([$id]);

        // 3. Kullanıcı bakiyesini güncelle (USDT veya TRY mantığına göre)
        // Burada user_wallet tablosuna coin_amount eklenir
        $walletUpd = $pdo->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ? AND coin_type = 'USDT'");
        $walletUpd->execute([$transfer['coin_amount'], $transfer['user_id']]);

        // 4. Site bakiyesinden düş (Bu genelde talep oluşurken düşer ama emin olmak için check edilebilir)
        // Bu senaryoda talep oluştuğunda site bakiyesinden düştüğünü varsayıyoruz. 
        // Eğer düşmediyse burada: UPDATE sites SET balance = balance - amount WHERE id = site_id

        $pdo->commit();
        header("Location: index.php?status=success&msg=Transfer onaylandı ve bakiye eklendi.");
        exit;
    }

    // =================================================
    // 2. SITE -> CÜZDAN TRANSFER REDDİ
    // =================================================
    if ($action === 'reject_merchant_transfer') {
        // İade mantığı: Reddedilirse para siteye geri dönmeli
        $stmt = $pdo->prepare("SELECT * FROM merchant_player_withdraws WHERE id = ? AND status = 'pending'");
        $stmt->execute([$id]);
        $transfer = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$transfer) throw new Exception("Talep bulunamadı.");

        $pdo->beginTransaction();

        // Durumu güncelle
        $pdo->prepare("UPDATE merchant_player_withdraws SET status = 'rejected', processed_at = NOW() WHERE id = ?")->execute([$id]);

        // Site bakiyesini iade et (amount kadar)
        // Not: Komisyon iadesi politikana göre net_amount veya amount iade edersin.
        // Genelde işlem iptalinde tam tutar iade edilir.
        $pdo->prepare("UPDATE sites SET balance = balance + ? WHERE id = ?")->execute([$transfer['amount'], $transfer['site_id']]);

        $pdo->commit();
        header("Location: index.php?status=success&msg=Talep reddedildi ve site bakiyesi iade edildi.");
        exit;
    }

    // =================================================
    // 3. AGENT KÂR ÇEKİM ONAYI
    // =================================================
    if ($action === 'approve_agent_profit') {
        
        $stmt = $pdo->prepare("SELECT * FROM agent_profit_withdraw_requests WHERE id = ? AND status = 'pending'");
        $stmt->execute([$id]);
        $req = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$req) throw new Exception("Talep geçersiz.");

        $pdo->beginTransaction();

        // Talebi güncelle
        $pdo->prepare("UPDATE agent_profit_withdraw_requests SET status = 'paid', processed_at = NOW(), admin_id = ? WHERE id = ?")
            ->execute([$_SESSION['admin_id'], $id]);

        // Agent'ın kâr bakiyesinden zaten talep oluşurken düşmüştür.
        // Burada sadece statü güncelliyoruz. Eğer manuel bir ödeme ise log atılabilir.

        $pdo->commit();
        header("Location: index.php?status=success&msg=Ödeme onaylandı olarak işaretlendi.");
        exit;
    }

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    header("Location: index.php?status=danger&msg=" . urlencode($e->getMessage()));
    exit;
}