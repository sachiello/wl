<?php
// src/admin/withdrawals.php

session_start();
require __DIR__ . '/../../config/config.php';

// HATA GÖRME (DEBUG) - iş bitince istersen kapat
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 1) GÜVENLİK
$is_admin = isset($_SESSION['admin_id']);
$is_agent = isset($_SESSION['agent_id']);

if (!$is_admin && !$is_agent) {
    header('Location: admin_login.php');
    exit;
}

$pageTitle  = 'Kullanıcı Çekim Talepleri';
$activeNav  = 'withdrawals';

// 2) VERİ ÇEKME
$sql = "
    SELECT
        w.*,
        u.username,
        u.trc20_address,

        awo.id          AS agent_order_id,
        awo.status      AS agent_order_status,
        awo.created_at  AS agent_order_created_at,
        awo.amount      AS agent_amount,      -- TL Tutar
        da.name         AS agent_name

    FROM withdraw_requests w
    JOIN users u 
        ON u.id = w.user_id

    LEFT JOIN agent_withdraw_orders awo
        ON awo.withdraw_request_id = w.id

    LEFT JOIN deposit_agents da
        ON da.id = awo.agent_id

    ORDER BY w.id DESC
    LIMIT 100
";

$rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/_admin_header.php';
?>

<style>
    /* ===========================
       BETWALLET ADMIN PAGE THEME
       =========================== */
    .admin-page-root {
        --adm-bg: #f9fafb;
        --adm-surface: #ffffff;
        --adm-surface-soft: #fef2f2;
        --adm-border: #e5e7eb;
        --adm-primary: #dc2626;
        --adm-primary-soft: rgba(220, 38, 38, 0.08);
        --adm-text-main: #111827;
        --adm-text-muted: #6b7280;
        --adm-radius: 14px;
        --adm-shadow-soft: 0 10px 24px rgba(15, 23, 42, 0.04);

        padding: 20px 24px 32px;
        color: var(--adm-text-main);
        background: var(--adm-bg);
    }

    @media (max-width: 768px) {
        .admin-page-root {
            padding: 16px;
        }
    }

    .admin-page-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 16px;
        margin-bottom: 18px;
        flex-wrap: wrap;
    }

    .admin-page-title h1 {
        margin: 0;
        font-size: 20px;
        font-weight: 800;
        color: var(--adm-text-main);
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .admin-page-title p {
        margin: 6px 0 0;
        font-size: 13px;
        color: var(--adm-text-muted);
    }

    .admin-page-chip {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 10px;
        border-radius: 999px;
        border: 1px solid var(--adm-border);
        background: #ffffff;
        font-size: 11px;
        color: var(--adm-text-muted);
        margin-top: 6px;
    }

    .admin-page-chip strong {
        color: var(--adm-primary);
    }

    /* Toolbar (filtre + search) */
    .toolbar-container { 
        display: flex; 
        justify-content: flex-end; 
        align-items: center; 
        gap: 10px; 
        flex-wrap: wrap; 
        margin-bottom: 16px;
    }

    .toolbar-actions { 
        display: flex; 
        align-items: center; 
        gap: 10px; 
        flex-wrap: wrap; 
    }

    .filter-select { 
        padding: 9px 12px; 
        border-radius: 999px; 
        border: 1px solid var(--adm-border); 
        background: #fff; 
        font-size: 12px; 
        color: var(--adm-text-main); 
        outline: none; 
        cursor: pointer; 
        font-weight: 500; 
        box-shadow: 0 6px 14px rgba(15, 23, 42, 0.04); 
        min-width: 170px;
    }

    .search-wrapper { 
        position: relative; 
    }

    .search-wrapper i { 
        position: absolute; 
        left: 11px; 
        top: 50%; 
        transform: translateY(-50%); 
        color: var(--adm-text-muted); 
        font-size: 15px; 
    }

    .search-input { 
        padding: 9px 10px 9px 32px; 
        border-radius: 999px; 
        border: 1px solid var(--adm-border); 
        background: #fff; 
        font-size: 12px; 
        width: 220px; 
        color: var(--adm-text-main); 
        outline: none; 
        box-shadow: 0 6px 14px rgba(15, 23, 42, 0.04); 
    }

    .search-input::placeholder {
        color: var(--adm-text-muted);
    }

    /* Card + tablo container */
    .admin-card {
        background: var(--adm-surface);
        border-radius: var(--adm-radius);
        border: 1px solid var(--adm-border);
        padding: 14px 16px 16px;
        box-shadow: var(--adm-shadow-soft);
    }

    .admin-card-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 10px;
        margin-bottom: 10px;
    }

    .admin-card-header h2 {
        margin: 0;
        font-size: 14px;
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: 6px;
        color: var(--adm-text-main);
    }

    .admin-card-header span.note {
        font-size: 11px;
        color: var(--adm-text-muted);
    }

    .table-container {
        margin-top: 4px;
        border-radius: 12px;
        overflow: hidden;
        border: 1px solid rgba(209, 213, 219, 0.9);
    }

    .admin-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 12px;
        background: #ffffff;
    }

    .admin-table thead {
        background: linear-gradient(
            135deg,
            rgba(248, 113, 113, 0.08),
            rgba(254, 242, 242, 0.95)
        );
    }

    .admin-table thead th {
        padding: 9px 10px;
        text-align: left;
        font-size: 11px;
        font-weight: 600;
        color: #7f1d1d;
        border-bottom: 1px solid rgba(248, 113, 113, 0.35);
        white-space: nowrap;
    }

    .admin-table tbody td {
        padding: 9px 10px;
        border-bottom: 1px solid #f3f4f6;
        vertical-align: top;
    }

    .admin-table tbody tr:last-child td {
        border-bottom: none;
    }

    .admin-table tbody tr:hover {
        background: #f9fafb;
    }

    .admin-table tbody tr.withdraw-row:hover {
        box-shadow: inset 3px 0 0 0 rgba(220, 38, 38, 0.7);
    }

    /* Method badges */
    .badge-method { 
        padding: 4px 8px; 
        border-radius: 999px; 
        font-size: 10px; 
        font-weight: 700; 
        text-transform: uppercase; 
        display: inline-flex; 
        align-items: center; 
        gap: 4px; 
        letter-spacing: 0.4px;
    }

    .badge-bank { 
        background: #eff6ff; 
        color: #1d4ed8; 
        border: 1px solid #dbeafe; 
    }

    .badge-crypto { 
        background: #fefce8; 
        color: #a16207; 
        border: 1px solid #fef08a; 
    }

    /* Status badges */
    .badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 3px 8px;
        border-radius: 999px;
        font-size: 10px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.35px;
        border: 1px solid transparent;
    }

    .badge-status-pending    { background:#fef3c7; color:#92400e; border-color:#fde68a; }
    .badge-status-processing { background:#e0f2fe; color:#075985; border-color:#bae6fd; }
    .badge-status-confirmed,
    .badge-status_approved   { background:#dcfce7; color:#166534; border-color:#bbf7d0; }
    .badge-status-rejected   { background:#fee2e2; color:#b91c1c; border-color:#fecaca; }
    .badge-status-unknown    { background:#e5e7eb; color:#374151; border-color:#d1d5db; }

    /* Agent chip */
    .agent-chip {
        display:inline-flex; 
        align-items:center; 
        gap:6px; 
        background:#f3f4f6; 
        padding:4px 8px; 
        border-radius:999px; 
        font-size:12px;
        color: var(--adm-text-main);
    }

    /* No data row */
    .no-data-cell {
        text-align:center; 
        padding:40px; 
        color:var(--adm-text-muted);
        background:#f9fafb;
    }

    .no-data-cell i {
        font-size: 40px;
        display:block;
        margin-bottom:8px;
        opacity:.6;
    }
</style>

<div class="admin-page-root">

    <div class="admin-page-header">
        <div class="admin-page-title">
            <h1>
                <i class="ri-hand-coin-line"></i> <?= htmlspecialchars($pageTitle) ?>
            </h1>
            <p>Üyelerin BetWallet cüzdanından yaptığı para çekim taleplerinin agent ve görev durumları.</p>
            <div class="admin-page-chip">
                <i class="ri-information-line"></i>
                <span>
                    Agent çekim modeli: <strong>USDT → TL</strong> dönüşümü agent kasa üzerinden,
                    kâr sadece yatırımlardan geliyor, çekimlerde kâr yazılmıyor.
                </span>
            </div>
        </div>

        <div class="toolbar-container">
            <div class="toolbar-actions">
                <select id="filterStatus" class="filter-select" onchange="masterFilter()">
                    <option value="all">Tüm Durumlar</option>
                    <option value="pending">⏳ Bekleyen</option>
                    <option value="processing">⚙️ İşleniyor</option>
                    <option value="confirmed">✅ Onaylanan</option>
                    <option value="rejected">❌ Reddedilen</option>
                </select>

                <div class="search-wrapper">
                    <i class="ri-search-line"></i>
                    <input type="text"
                           id="searchInput"
                           class="search-input"
                           placeholder="Kullanıcı / IBAN / banka / agent ara..."
                           onkeyup="masterFilter()">
                </div>
            </div>
        </div>
    </div>

    <div class="admin-card">
        <div class="admin-card-header">
            <h2>
                <i class="ri-list-check-3"></i> Çekim Talep Listesi
            </h2>
            <span class="note">
                Üst satır: TL karşılığı; alt satırda ise USDT tutarı gösterilir.
                Agent görev durumu ile istek durumu ayrıştırılmıştır.
            </span>
        </div>

        <div class="table-container">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Kullanıcı</th>
                        <th>Tutar</th>
                        <th>Yöntem</th>
                        <th>Hedef Hesap</th>
                        <th>Atanan Agent</th>
                        <th>Agent Görev Durumu</th>
                        <th>İstek Durumu</th>
                        <th style="text-align:right;">Talep Tarihi</th>
                    </tr>
                </thead>
                <tbody id="withdrawTableBody">
                <?php if (empty($rows)): ?>
                    <tr id="no-data-row">
                        <td colspan="9" class="no-data-cell">
                            <i class="ri-filter-off-line"></i>
                            Kayıtlı çekim talebi bulunamadı.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($rows as $w):

                        // Yöntem
                        $method = $w['method'] ?? 'bank'; // bank / crypto

                        // STATUS KAYNAĞI: Sadece agent_withdraw_orders.status
                        $agentStatusRaw = strtolower(trim($w['agent_order_status'] ?? ''));
                        $reqStatusRaw   = $agentStatusRaw; // İstek durumu da aynı kaynaktan

                        // -------- İSTEK DURUMU BADGE ----------
                        $reqBadgeClass = 'badge-status-unknown';
                        $reqLabel      = $reqStatusRaw ? strtoupper($reqStatusRaw) : '-';

                        if ($reqStatusRaw === 'pending') {
                            $reqBadgeClass = 'badge-status-pending';
                            $reqLabel      = 'BEKLİYOR';
                        } elseif ($reqStatusRaw === 'processing') {
                            $reqBadgeClass = 'badge-status-processing';
                            $reqLabel      = 'İŞLENİYOR';
                        } elseif (in_array($reqStatusRaw, ['paid','completed','confirmed','approved'])) {
                            $reqBadgeClass = 'badge-status-confirmed';
                            $reqLabel      = 'ONAYLANDI';
                        } elseif (in_array($reqStatusRaw, ['rejected','failed'])) {
                            $reqBadgeClass = 'badge-status-rejected';
                            $reqLabel      = 'RED / HATA';
                        }

                        // -------- AGENT GÖREV DURUMU BADGE ----------
                        $agentBadgeClass = 'badge-status-unknown';
                        $agentLabel      = $agentStatusRaw ? strtoupper($agentStatusRaw) : 'ATANMAMIŞ';

                        if ($agentStatusRaw === 'pending') {
                            $agentBadgeClass = 'badge-status-pending';
                            $agentLabel      = 'BEKLİYOR';
                        } elseif (in_array($agentStatusRaw, ['paid','completed','confirmed','approved'])) {
                            $agentBadgeClass = 'badge-status-confirmed';
                            $agentLabel      = 'ÖDENDİ';
                        } elseif (in_array($agentStatusRaw, ['rejected','failed'])) {
                            $agentBadgeClass = 'badge-status-rejected';
                            $agentLabel      = 'RED / HATA';
                        }

                        // -------- HEDEF HESAP ALANI ----------
                        ob_start();
                        if ($method === 'bank') {
                            ?>
                            <div style="font-weight:600; color:var(--adm-text-main);">
                                <?= htmlspecialchars($w['user_bank_name'] ?? '-') ?>
                            </div>
                            <div style="font-family:monospace; font-size:12px; color:var(--adm-text-muted);">
                                <?= htmlspecialchars($w['user_iban'] ?? '-') ?>
                            </div>
                            <div style="font-size:12px; color:var(--adm-text-muted);">
                                <?= htmlspecialchars($w['user_full_name'] ?? '') ?>
                            </div>
                            <?php
                        } else {
                            $addr = $w['address'] ?? $w['trc20_address'] ?? '';
                            ?>
                            <div style="font-weight:600; color:var(--adm-text-main);">Kripto (TRC20)</div>
                            <div style="font-family:monospace; font-size:12px; color:var(--adm-text-muted); max-width:220px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">
                                <?= htmlspecialchars($addr) ?>
                            </div>
                            <?php
                        }
                        $targetCellHtml = ob_get_clean();

                        // Agent adı
                        $agentName = $w['agent_name'] ?? null;

                        // Tutar (coin + varsa TL)
                        $coinAmount = (float)($w['amount'] ?? 0);
                        $coinType   = $w['coin_type'] ?? '';
                        $agentAmt   = isset($w['agent_amount']) ? (float)$w['agent_amount'] : null;

                    ?>
                    <tr class="withdraw-row"
                        data-status="<?= htmlspecialchars($reqStatusRaw) ?>">
                        
                        <td>
                            <span style="font-family:monospace; color:var(--adm-text-muted);">
                                #<?= (int)$w['id'] ?>
                            </span>
                        </td>

                        <td>
                            <div style="font-weight:600; color:var(--adm-text-main);">
                                <?= htmlspecialchars($w['username']) ?>
                            </div>
                            <div style="font-size:11px; color:var(--adm-text-muted);">
                                UID: <?= (int)$w['user_id'] ?>
                            </div>
                        </td>

                        <td>
                            <?php if ($agentAmt !== null && $agentAmt > 0): ?>
                                <div style="font-weight:700; color:#dc2626;">
                                    <?= number_format($agentAmt, 2, ',', '.') ?> 
                                    <span style="font-size:11px; color:var(--adm-text-muted);">TL</span>
                                </div>
                                <div style="font-size:11px; color:var(--adm-text-muted);">
                                    (~<?= number_format($coinAmount, 2, ',', '.') . ' ' . htmlspecialchars($coinType) ?>)
                                </div>
                            <?php else: ?>
                                <div style="font-weight:700; color:#dc2626;">
                                    <?= number_format($coinAmount, 2, ',', '.') ?> 
                                    <span style="font-size:11px; color:var(--adm-text-muted);"><?= htmlspecialchars($coinType) ?></span>
                                </div>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if ($method === 'bank'): ?>
                                <span class="badge-method badge-bank">
                                    <i class="ri-bank-line"></i> BANKA
                                </span>
                            <?php else: ?>
                                <span class="badge-method badge-crypto">
                                    <i class="ri-bit-coin-line"></i> KRİPTO
                                </span>
                            <?php endif; ?>
                        </td>

                        <td style="font-size:13px;">
                            <?= $targetCellHtml ?>
                        </td>

                        <td>
                            <?php if ($agentName): ?>
                                <span class="agent-chip">
                                    <i class="ri-user-star-line"></i> <?= htmlspecialchars($agentName) ?>
                                </span>
                            <?php else: ?>
                                <span style="font-size:11px; color:var(--adm-text-muted); font-style:italic;">
                                    Henüz atanmadı
                                </span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <span class="badge <?= $agentBadgeClass ?>">
                                <?= $agentLabel ?>
                            </span>
                        </td>

                        <td>
                            <span class="badge <?= $reqBadgeClass ?>">
                                <?= $reqLabel ?>
                            </span>
                        </td>

                        <td style="text-align:right; font-size:12px; color:var(--adm-text-muted);">
                            <?= date('d.m.Y H:i', strtotime($w['created_at'])) ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script>
function masterFilter() {
    const statusFilter = document.getElementById('filterStatus').value;
    const searchTerm   = document.getElementById('searchInput').value.toLowerCase().trim();

    const rows = document.querySelectorAll('.withdraw-row');
    let visibleCount = 0;

    rows.forEach(row => {
        const rowStatus = (row.getAttribute('data-status') || '').toLowerCase();
        const rowText   = row.innerText.toLowerCase();

        const statusMatch = (statusFilter === 'all' || rowStatus === statusFilter);
        const searchMatch = (searchTerm === '' || rowText.includes(searchTerm));

        if (statusMatch && searchMatch) {
            row.style.display = '';
            visibleCount++;
        } else {
            row.style.display = 'none';
        }
    });

    const noDataRow = document.getElementById('no-data-row');
    if (noDataRow) {
        noDataRow.style.display = (visibleCount === 0) ? '' : 'none';
    }
}
</script>

<?php include __DIR__ . '/_admin_footer.php'; ?>
