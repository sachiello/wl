<?php
// admin/index.php
session_start();
require __DIR__ . '/../../config/config.php';

// Güvenlik
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

// Admin bilgisi (header için)
$stmtAdmin = $pdo->prepare("SELECT username FROM admins WHERE id = ?");
$stmtAdmin->execute([$_SESSION['admin_id']]);
$adminRow  = $stmtAdmin->fetch(PDO::FETCH_ASSOC);
$adminName = $adminRow['username'] ?? 'Admin';

// ---------------------------------------------------------------------
// TARİH FİLTRESİ (Bugün / Dün / Son 7 Gün / Son 30 Gün / Tüm Zamanlar)
// ---------------------------------------------------------------------
$range      = $_GET['range'] ?? 'today';
$rangeLabel = 'Bugün';
$rangeStart = null;
$rangeEnd   = null;

$todayYmd = date('Y-m-d');

switch ($range) {
    case 'yesterday':
        $rangeLabel = 'Dün';
        $d          = date('Y-m-d', strtotime('-1 day'));
        $rangeStart = $d . ' 00:00:00';
        $rangeEnd   = $d . ' 23:59:59';
        break;

    case '7d':
        $rangeLabel = 'Son 7 Gün';
        $start      = date('Y-m-d', strtotime('-6 days'));
        $rangeStart = $start . ' 00:00:00';
        $rangeEnd   = $todayYmd . ' 23:59:59';
        break;

    case '30d':
        $rangeLabel = 'Son 30 Gün';
        $start      = date('Y-m-d', strtotime('-29 days'));
        $rangeStart = $start . ' 00:00:00';
        $rangeEnd   = $todayYmd . ' 23:59:59';
        break;

    case 'all':
        $rangeLabel = 'Tüm Zamanlar';
        $rangeStart = null;
        $rangeEnd   = null;
        break;

    case 'today':
    default:
        $range      = 'today';
        $rangeLabel = 'Bugün';
        $rangeStart = $todayYmd . ' 00:00:00';
        $rangeEnd   = $todayYmd . ' 23:59:59';
        break;
}

// Ortak: belirli bir tarih kolonu üzerinden BETWEEN filtresi ekleyen yardımcı
function addDateFilterSql(string $baseSql, ?string $rangeStart, ?string $rangeEnd, string $dateColumn = 'created_at'): array
{
    $params = [];
    if ($rangeStart && $rangeEnd) {
        $baseSql .= " AND {$dateColumn} BETWEEN ? AND ?";
        $params[] = $rangeStart;
        $params[] = $rangeEnd;
    }
    return [$baseSql, $params];
}

// -------------------------------------------------------------
// 1) BETWALLET ÖZET METRİKLERİ (BetWallet TABI)
// -------------------------------------------------------------

// Üye sayısı (tüm zaman)
$totalUsers = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();

// Yatırım Tutarı (deposit_orders, confirmed)
$sql = "SELECT COALESCE(SUM(amount_try), 0) FROM deposit_orders WHERE status = 'approved'";
list($sqlDeposit, $pDeposit) = addDateFilterSql($sql, $rangeStart, $rangeEnd, 'created_at');
$stmt = $pdo->prepare($sqlDeposit);
$stmt->execute($pDeposit);
$rangeDepositTry = (float)$stmt->fetchColumn();

// Çekim Tutarı (agent_withdraw_orders, paid)
$sql = "SELECT COALESCE(SUM(amount), 0) FROM agent_withdraw_orders WHERE status = 'paid'";
list($sqlAwd, $pAwd) = addDateFilterSql($sql, $rangeStart, $rangeEnd, 'created_at');
$stmt = $pdo->prepare($sqlAwd);
$stmt->execute($pAwd);
$rangeAgentWithdrawTry = (float)$stmt->fetchColumn();

// Merchant hacmi ve site komisyonu (sitenin BetWallet'a ödediği komisyon)
// Buradaki commission_amount = yatırım_tutarı * site_komisyon_oranı
$sql = "SELECT 
            COALESCE(SUM(amount_try), 0) AS total_volume,
            COALESCE(SUM(commission_amount), 0) AS total_commission
        FROM merchant_orders
        WHERE status = 'success'";
list($sqlMO, $pMO) = addDateFilterSql($sql, $rangeStart, $rangeEnd, 'created_at');
$stmt = $pdo->prepare($sqlMO);
$stmt->execute($pMO);
$moRow               = $stmt->fetch(PDO::FETCH_ASSOC);
$merchantVolumeTry   = (float)($moRow['total_volume'] ?? 0);
$merchantCommission  = (float)($moRow['total_commission'] ?? 0);

// Onaylı merchant çekim tutarı (merchant_player_withdraws)
$sql = "SELECT COALESCE(SUM(amount), 0) 
        FROM merchant_player_withdraws
        WHERE status = 'approved'";
list($sqlMW, $pMW) = addDateFilterSql($sql, $rangeStart, $rangeEnd, 'processed_at');
$stmt = $pdo->prepare($sqlMW);
$stmt->execute($pMW);
$merchantWithdrawApproved = (float)$stmt->fetchColumn();

// Agent kârları (BetWallet için gider)
// Yeni modelde: Agent sadece onayladığı yatırımlardan komisyon alıyor.
// agent_profit_logs toplamı = agent'a ödediğimiz komisyon gideri.
$sql = "SELECT COALESCE(SUM(amount), 0) 
        FROM agent_profit_logs
        WHERE 1=1";
list($sqlAPL, $pAPL) = addDateFilterSql($sql, $rangeStart, $rangeEnd, 'created_at');
$stmt = $pdo->prepare($sqlAPL);
$stmt->execute($pAPL);
$agentProfitCost = (float)$stmt->fetchColumn(); // BetWallet gideri (agent komisyonu)

// Agent kâr cüzdanı çekimlerinden alınan %1 komisyon geliri
$sql = "SELECT COALESCE(SUM(fee_amount), 0) 
        FROM agent_profit_withdraw_requests
        WHERE status = 'paid'";
list($sqlAPW, $pAPW) = addDateFilterSql($sql, $rangeStart, $rangeEnd, 'created_at');
$stmt = $pdo->prepare($sqlAPW);
$stmt->execute($pAPW);
$agentProfitWithdrawFeeIncome = (float)$stmt->fetchColumn();

// Site çekimlerinden alınan %1 komisyon (site_withdrawals)
$sql = "SELECT COALESCE(SUM(amount), 0) 
        FROM site_withdrawals
        WHERE status = 'completed'";
list($sqlSW, $pSW) = addDateFilterSql($sql, $rangeStart, $rangeEnd, 'created_at');
$stmt = $pdo->prepare($sqlSW);
$stmt->execute($pSW);
$siteWithdrawAmount     = (float)$stmt->fetchColumn();
$siteWithdrawFeeIncome  = $siteWithdrawAmount * 0.01; // %1 komisyon

// --------------------------
// BetWallet kâr yapısı:
// 1) Yatırım kârı (spread) = site komisyonu − agent komisyonu
//    = merchantCommission − agentProfitCost
// 2) Çekim kârı = agent profit withdraw fee + site withdraw fee (%1)
// 3) Net Boss Cüzdan = yatırım spread'i + çekim kârı
// --------------------------
$betwalletInvestmentMargin = $merchantCommission - $agentProfitCost; // yatırımlardan kalan
$betwalletFeeIncome        = $agentProfitWithdrawFeeIncome + $siteWithdrawFeeIncome;
$betwalletNetProfit        = $betwalletInvestmentMargin + $betwalletFeeIncome;

// Yatırım bazlı efektif spread yüzdesi (site_oranı − agent_oranı)
$commissionMarginPct = $merchantVolumeTry > 0
    ? ($betwalletInvestmentMargin / $merchantVolumeTry) * 100
    : 0.0;

// -------------------------------------------------------------
// 2) GÜNCEL KASALAR / BAKİYELER (MEVCUT DURUM & KASA ÖZETİ)
// -------------------------------------------------------------

// Üyelerin güncel USDT cüzdan bakiyesi (wallets tablosu)  -> POTANSİYEL YÜKÜMLÜLÜK (USDT)
$stmt = $pdo->query("SELECT COALESCE(SUM(balance), 0) FROM wallets WHERE coin_type = 'USDT'");
$usersTotalWalletUsdt = (float)$stmt->fetchColumn();

// Mevcut teminat toplamı (agent system_balance) -> ŞİRKET LEHİNE TEMİNAT
$stmt = $pdo->query("SELECT COALESCE(SUM(system_balance), 0) FROM deposit_agents");
$totalAgentCollateral = (float)$stmt->fetchColumn();

// Mevcut agent kasa toplamı (sahadaki TL - current_cash) -> SAHADAKİ NAKİT
$stmt = $pdo->query("SELECT COALESCE(SUM(current_cash), 0) FROM deposit_agents");
$totalAgentCash = (float)$stmt->fetchColumn();

// Mevcut agent profit kasa toplamı (agent_profit_balance) -> AGENT'LARA ÖDENEBİLİR KÂR
$stmt = $pdo->query("SELECT COALESCE(SUM(agent_profit_balance), 0) FROM deposit_agents");
$totalAgentProfitBalance = (float)$stmt->fetchColumn();

// Mevcut site bakiyesi toplamı -> SİTELERİN BUGÜNE KADAR YÜKLEDİĞİ BAKİYELER
// (site_deposit_requests tablosunda status = 'completed' olan kayıtların toplamı)

$stmt = $pdo->query("
    SELECT COALESCE(SUM(amount_try), 0)
    FROM site_deposit_requests
    WHERE status = 'completed'
");
$totalSiteBalance = (float)$stmt->fetchColumn();


// BetWallet Cüzdan (operasyonel merkez kasa - TL)
// Giriş: Agent + Site bakiye yükleme (approved)
// Çıkış: Site withdraw + Agent profit withdraw (amount_after_fee)
$stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM agent_balance_requests WHERE status = 'approved'");
$agentTopupsAll = (float)$stmt->fetchColumn();

$stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM site_balance_requests WHERE status = 'approved'");
$siteTopupsAll = (float)$stmt->fetchColumn();

$stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM site_withdrawals WHERE status = 'completed'");
$siteWithdrawPaidAll = (float)$stmt->fetchColumn();

$stmt = $pdo->query("SELECT COALESCE(SUM(amount_after_fee), 0) FROM agent_profit_withdraw_requests WHERE status = 'paid'");
$agentProfitWithdrawPaidAll = (float)$stmt->fetchColumn();

// Şu ana kadar formüle göre oluşan BetWallet merkez kasası
$betwalletOperationalWallet = ($agentTopupsAll + $siteTopupsAll) - ($siteWithdrawPaidAll + $agentProfitWithdrawPaidAll);

// -------------------------------------------------------------
// 2.1 KISA VADEDE ÇIKABİLECEK ÖDEMELER (PENDING TALEPLER)
// -------------------------------------------------------------

// Bekleyen site çekimleri (şirket kasasından çıkacak TL)
$stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM site_withdrawals WHERE status = 'pending'");
$pendingSiteWithdrawAmount = (float)$stmt->fetchColumn();

// Bekleyen agent kâr çekimleri (şirket kasasından çıkacak TL, fee sonrası)
$stmt = $pdo->query("SELECT COALESCE(SUM(amount_after_fee), 0) FROM agent_profit_withdraw_requests WHERE status = 'pending'");
$pendingAgentProfitWithdrawAmount = (float)$stmt->fetchColumn();

// İsterse ayrıca kullanıcı bankaya çekim taleplerini de ayrı takip edebilirsin:
// $stmt = $pdo->query("SELECT COALESCE(SUM(amount_try), 0) FROM withdraw_requests WHERE status = 'pending'");
// $pendingUserBankWithdrawTry = (float)$stmt->fetchColumn();

// ŞİRKET MERKEZ KASASINDAN KISA VADEDE ÇIKABİLECEK TOPLAM
$shortTermOutflowTl = $pendingSiteWithdrawAmount + $pendingAgentProfitWithdrawAmount;

// -------------------------------------------------------------
// 2.2 "ELİMDE OLMASI GEREKEN" KASALAR
// -------------------------------------------------------------
// Merkez kasa (BetWallet operasyon cüzdanı) + sahadaki agent kasaları
// -> Teoride sistem genelinde olması gereken toplam TL (merkez + saha)
$kasadaOlmasiGerekenToplamTl = $betwalletOperationalWallet + $totalAgentCash;

// -------------------------------------------------------------
// 2.3 KISA VADE NET POZİSYON (+ / -)
// -------------------------------------------------------------
// Eğer şu an tüm site çekim + agent kâr çekim talepleri onaylanırsa,
// şirket + saha toplam kasası ne olur?
$netPozisyonKisaVadeTl = $kasadaOlmasiGerekenToplamTl - $shortTermOutflowTl;

// -------------------------------------------------------------
// 2.4 DİĞER POTANSİYEL YÜKÜMLÜLÜK GİBİ GÖRÜLEBİLECEK KALEMLER
// -------------------------------------------------------------
// Bunlar doğrudan şu an çıkacak para değil ama "gidebilecek para" mantığıyla
// uzun vadeli yükümlülük gibi izlenebilir:
//
// - $totalSiteBalance         : sitelerin çekebileceği / mahsuplaşabileceği bakiye
// - $totalAgentProfitBalance  : agent'ların kâr kasasında bekleyen toplam
// - $usersTotalWalletUsdt     : kullanıcı USDT cüzdan toplamı (USDT cinsinden)

// -------------------------------------------------------------
// 2.5 YÖNETİM ÖZETİ İÇİN TEK ARRAY (VIEW'DE KOLAY GÖSTERİM)
// -------------------------------------------------------------
$kasaOzet = [
    // Elinde olması gereken kasalar
    'merkez_kasa_tl'         => $betwalletOperationalWallet,   // BetWallet operasyon hesabı
    'saha_kasasi_tl'         => $totalAgentCash,               // Agent current_cash toplamı
    'toplam_kasa_tl'         => $kasadaOlmasiGerekenToplamTl,  // merkez + saha

    // Kısa vadede çıkabilecek ödemeler
    'bekleyen_site_cekimi_tl'        => $pendingSiteWithdrawAmount,
    'bekleyen_agent_kar_cekimi_tl'   => $pendingAgentProfitWithdrawAmount,
    'kisa_vade_toplam_cikis_tl'      => $shortTermOutflowTl,

    // Net pozisyon (artı / eksi)
    // Pozitif ise "tüm bu talepler ödense bile sistemde kalacak TL",
    // Negatif ise "eksideyiz, bu kadar açık var" şeklinde yorumlanabilir.
    'net_pozisyon_kisa_vade_tl'      => $netPozisyonKisaVadeTl,

    // Uzun vadeli / potansiyel yükümlülük bakiyeleri
    'site_bakiyeleri_tl'             => $totalSiteBalance,
    'agent_kar_bakiyeleri_tl'        => $totalAgentProfitBalance,
    'kullanici_usdt_cuzdan_toplam'   => $usersTotalWalletUsdt,

    // Ek bilgi olarak teminat
    'agent_teminat_toplami_tl'       => $totalAgentCollateral,
];


// -------------------------------------------------------------
// 3) AGENT TAB METRİKLERİ
// -------------------------------------------------------------

// Hacim lig: seçili aralıkta en çok confirmed yatırım alan agent'lar
$sql = "
    SELECT 
        a.id,
        a.name,
        a.commission_rate,
        COALESCE(SUM(d.amount_try), 0) AS total_deposit,
        COUNT(d.id) AS deposit_count
    FROM deposit_agents a
    LEFT JOIN deposit_orders d
        ON d.agent_id = a.id
       AND d.status = 'confirmed'
       AND 1=1
";
list($sqlAgentDep, $pAgentDep) = addDateFilterSql($sql, $rangeStart, $rangeEnd, 'd.created_at');
$sqlAgentDep .= "
    GROUP BY a.id, a.name, a.commission_rate
    ORDER BY total_deposit DESC
    LIMIT 5
";
$stmt = $pdo->prepare($sqlAgentDep);
$stmt->execute($pAgentDep);
$topAgentsByDeposit = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Kâr lig: seçili aralıkta en çok profit yazan agent'lar
$sql = "
    SELECT 
        a.id,
        a.name,
        a.commission_rate,
        COALESCE(SUM(l.amount), 0) AS total_profit
    FROM deposit_agents a
    LEFT JOIN agent_profit_logs l
        ON l.agent_id = a.id
       AND 1=1
";
list($sqlAgentProfit, $pAgentProfit) = addDateFilterSql($sql, $rangeStart, $rangeEnd, 'l.created_at');
$sqlAgentProfit .= "
    GROUP BY a.id, a.name, a.commission_rate
    ORDER BY total_profit DESC
    LIMIT 5
";
$stmt = $pdo->prepare($sqlAgentProfit);
$stmt->execute($pAgentProfit);
$topAgentsByProfit = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Canlı agent kasaları (snapshot)
$stmt = $pdo->query("
    SELECT 
        id,
        name,
        commission_rate,
        system_balance,
        current_cash,
        agent_profit_balance
    FROM deposit_agents
    ORDER BY system_balance DESC
    LIMIT 8
");
$agentSnapshots = $stmt->fetchAll(PDO::FETCH_ASSOC);

// -------------------------------------------------------------
// 4) SITE TAB METRİKLERİ
// -------------------------------------------------------------

// Hacim & komisyon lig: seçili aralıkta en çok hacim yapan siteler
$sql = "
    SELECT
        s.id,
        s.name,
        s.commission_rate,
        COALESCE(SUM(m.amount_try), 0) AS total_volume,
        COALESCE(SUM(m.commission_amount), 0) AS total_commission,
        COUNT(m.id) AS order_count
    FROM sites s
    LEFT JOIN merchant_orders m
        ON m.site_id = s.id
       AND m.status = 'success'
       AND 1=1
";
list($sqlSiteTop, $pSiteTop) = addDateFilterSql($sql, $rangeStart, $rangeEnd, 'm.created_at');
$sqlSiteTop .= "
    GROUP BY s.id, s.name, s.commission_rate
    ORDER BY total_volume DESC
    LIMIT 5
";
$stmt = $pdo->prepare($sqlSiteTop);
$stmt->execute($pSiteTop);
$topSitesByVolume = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Canlı site bakiyeleri (snapshot)
$stmt = $pdo->query("
    SELECT 
        id,
        name,
        balance,
        commission_rate
    FROM sites
    ORDER BY balance DESC
    LIMIT 8
");
$siteSnapshots = $stmt->fetchAll(PDO::FETCH_ASSOC);

// -------------------------------------------------------------
// 5) OPERASYON / RİSK TAB METRİKLERİ
// -------------------------------------------------------------

// Bekleyen iş emirleri sayıları
$pendingDepositOrders = (int)$pdo->query("SELECT COUNT(*) FROM deposit_orders WHERE status = 'pending'")->fetchColumn();
$pendingAgentWithdrawOrders = (int)$pdo->query("SELECT COUNT(*) FROM agent_withdraw_orders WHERE status = 'pending'")->fetchColumn();
$pendingMerchantOrders = (int)$pdo->query("SELECT COUNT(*) FROM merchant_orders WHERE status = 'pending'")->fetchColumn();
$pendingMerchantPlayerWithdraws = (int)$pdo->query("SELECT COUNT(*) FROM merchant_player_withdraws WHERE status = 'pending'")->fetchColumn();
$pendingSiteWithdrawals = (int)$pdo->query("SELECT COUNT(*) FROM site_withdrawals WHERE status = 'pending'")->fetchColumn();
$pendingAgentBalanceRequests = (int)$pdo->query("SELECT COUNT(*) FROM agent_balance_requests WHERE status = 'pending'")->fetchColumn();
$pendingSiteBalanceRequests = (int)$pdo->query("SELECT COUNT(*) FROM site_balance_requests WHERE status = 'pending'")->fetchColumn();

// Basit risk sinyali: teminatı sahadaki kasasından düşük olan agent sayısı
$stmt = $pdo->query("
    SELECT COUNT(*) 
    FROM deposit_agents 
    WHERE system_balance < current_cash
");
$riskyAgentsCount = (int)$stmt->fetchColumn();

// -------------------------------------------------------------
// GÖRÜNÜM
// -------------------------------------------------------------
$pageTitle  = 'Dashboard';
$activeNav  = 'dashboard';
$activeTab  = 'betwallet';
$netPoz   = $kasaOzet['net_pozisyon_kisa_vade_tl'];
$netClass = $netPoz >= 0 ? 'metric-positive' : 'metric-negative';
$netSign  = $netPoz >= 0 ? '+' : '−';
$bizeGecenTeminat      = $kasaOzet['agent_teminat_toplami_tl'];    // Agent system_balance
$bizeGecenSiteBakiyesi = $kasaOzet['site_bakiyeleri_tl'];          // Sitelerin balance toplamı
$bizeGecenToplam       = $bizeGecenTeminat + $bizeGecenSiteBakiyesi;

// Ödememiz gerekenler (kısa vade)
$odeyecegimizSite      = $kasaOzet['bekleyen_site_cekimi_tl'];          // pending site_withdrawals
$odeyecegimizAgentKar  = $kasaOzet['bekleyen_agent_kar_cekimi_tl'];    // pending agent_profit_withdraw
$odeyecegimizToplam    = $odeyecegimizSite + $odeyecegimizAgentKar;

// Net pozisyon
$netPozisyon = $bizeGecenToplam - $odeyecegimizToplam;
$netClass    = $netPozisyon >= 0 ? 'metric-positive' : 'metric-negative';
$netSign     = $netPozisyon >= 0 ? '+' : '−';
// 1) BUGÜN BİZE AİT PARALAR (SNAPSHOT)
$bizeAitTeminat      = $kasaOzet['agent_teminat_toplami_tl'];   // Agent system_balance
$bizeAitSiteBakiye   = $kasaOzet['site_bakiyeleri_tl'];         // Sitelerin mevcut balance toplamı
$bizeAitBugunToplam  = $bizeAitTeminat + $bizeAitSiteBakiye;

// 2) BUGÜNE KADAR ÖDENENLER
$stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM site_withdrawals WHERE status = 'completed'");
$odenmisSiteCekimi = (float)$stmt->fetchColumn();

$stmt = $pdo->query("SELECT COALESCE(SUM(amount_after_fee), 0) FROM agent_profit_withdraw_requests WHERE status = 'paid'");
$odenmisAgentKar   = (float)$stmt->fetchColumn();

$toplamOdenen = $odenmisSiteCekimi + $odenmisAgentKar;

// 3) KISA VADEDE ÖDEMEMİZ GEREKENLER (PENDING)
$pendingSite   = $kasaOzet['bekleyen_site_cekimi_tl'];
$pendingAgent  = $kasaOzet['bekleyen_agent_kar_cekimi_tl'];
$pendingToplam = $pendingSite + $pendingAgent;

// 4) TEORİK TOPLAM KAYNAK (SİSTEME BİZİM TARAFTAN GİRMİŞ PARA)
//    = ŞU AN BİZDE + BUGÜNE KADAR ÖDENMİŞLER
$teorikToplamKaynak = $bizeAitBugunToplam + $toplamOdenen;

// 5) BUGÜN NET POZİSYON (BİZDEKİ PARA – KISA VADE ÖDEME YÜKÜMLÜLÜĞÜ)
$bugunNetPozisyon = $bizeAitBugunToplam - $pendingToplam;
$bugunNetClass    = $bugunNetPozisyon >= 0 ? 'metric-positive' : 'metric-negative';
$bugunNetSign     = $bugunNetPozisyon >= 0 ? '+' : '−';

include __DIR__ . '/_admin_header.php';
?>
<style>
    .admin-dashboard-root {
        --adm-bg: #f9fafb;
        --adm-surface: #ffffff;
        --adm-surface-soft: #fef2f2;
        --adm-border: #e5e7eb;
        --adm-primary: #dc2626;
        --adm-primary-soft: rgba(220, 38, 38, 0.08);
        --adm-text-main: #111827;
        --adm-text-muted: #6b7280;
        --adm-success: #16a34a;
        --adm-warning: #eab308;
        --adm-info: #0ea5e9;
        --adm-danger: #f97316;
        --adm-radius: 14px;

        padding: 20px 24px 32px;
        color: var(--adm-text-main);
        background: var(--adm-bg);
    }

    @media (max-width: 768px) {
        .admin-dashboard-root {
            padding: 16px;
        }
    }
.metric-section-title {
        font-size: 13px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .04em;
        color: var(--text-muted);
        margin-bottom: 6px;
        margin-top: 10px;
    }
    .metric-section-separator {
        margin: 12px 0;
        border-top: 1px dashed rgba(148, 163, 184, 0.4);
    }
    .metric-total {
        font-weight: 800;
        font-size: 16px;
    }
    .metric-positive {
        color: #16a34a; /* + yeşil */
    }
    .metric-negative {
        color: #dc2626; /* - kırmızı */
    }
    .metric-pill {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 4px 10px;
        border-radius: 999px;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        background: rgba(15,23,42,0.04);
        color: var(--text-muted);
    }
    .admin-header-area {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 16px;
        margin-bottom: 18px;
        flex-wrap: wrap;
    }

    .admin-header-title h1 {
        margin: 0;
        font-size: 22px;
        font-weight: 800;
        color: var(--adm-text-main);
    }

    .admin-header-title p {
        margin: 6px 0 0;
        font-size: 13px;
        color: var(--adm-text-muted);
    }

    .admin-range-chip {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 5px 11px;
        border-radius: 999px;
        border: 1px solid var(--adm-border);
        background: #ffffff;
        font-size: 11px;
        color: var(--adm-text-muted);
        margin-top: 8px;
    }

    .admin-range-chip strong {
        color: var(--adm-primary);
    }

    .admin-tabs {
        display: inline-flex;
        background: #ffffff;
        border-radius: 999px;
        padding: 4px;
        border: 1px solid var(--adm-border);
        gap: 4px;
        box-shadow: 0 6px 14px rgba(15, 23, 42, 0.06);
    }

    .admin-tab-item {
        border: none;
        background: transparent;
        color: var(--adm-text-muted);
        font-size: 12px;
        padding: 6px 14px;
        border-radius: 999px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: background 0.15s, color 0.15s;
        white-space: nowrap;
    }

    .admin-tab-item span.badge {
        font-size: 10px;
        padding: 2px 6px;
        border-radius: 999px;
        background: #f9fafb;
        border: 1px solid var(--adm-border);
        color: var(--adm-text-muted);
    }

    .admin-tab-item.is-active {
        background: linear-gradient(
            135deg,
            rgba(248, 113, 113, 0.18),
            rgba(254, 242, 242, 0.95)
        );
        color: #7f1d1d;
        font-weight: 600;
    }

    .admin-tab-item.is-active span.badge {
        border-color: rgba(220, 38, 38, 0.4);
        background: #fee2e2;
        color: #7f1d1d;
    }

    .admin-range-filters {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        margin-top: 12px;
    }

    .admin-range-btn {
        font-size: 11px;
        padding: 5px 10px;
        border-radius: 999px;
        border: 1px solid var(--adm-border);
        background: #ffffff;
        color: var(--adm-text-muted);
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 4px;
        transition: background 0.15s, color 0.15s, border-color 0.15s;
    }

    .admin-range-btn.is-active {
        background: var(--adm-primary-soft);
        border-color: var(--adm-primary);
        color: #7f1d1d;
        font-weight: 600;
    }

    .admin-kpi-grid {
        margin-top: 18px;
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
        gap: 14px;
    }

    .admin-kpi-card {
        background: #ffffff;
        border-radius: var(--adm-radius);
        border: 1px solid var(--adm-border);
        padding: 14px 16px;
        position: relative;
        overflow: hidden;
        box-shadow: 0 10px 24px rgba(15, 23, 42, 0.04);
    }

    .admin-kpi-card::before {
        content: "";
        position: absolute;
        inset: -60%;
        background: radial-gradient(
            circle at 0% 0%,
            rgba(248, 113, 113, 0.22),
            transparent 60%
        );
        opacity: 0;
        transition: opacity 0.2s;
        pointer-events: none;
    }

    .admin-kpi-card:hover::before {
        opacity: 1;
    }

    .admin-kpi-top {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 10px;
    }

    .admin-kpi-label {
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.6px;
        color: var(--adm-text-muted);
    }

    .admin-kpi-value {
        margin-top: 4px;
        font-size: 20px;
        font-weight: 800;
        letter-spacing: -0.3px;
        color: var(--adm-text-main);
    }

    .admin-kpi-sub {
        margin-top: 2px;
        font-size: 11px;
        color: var(--adm-text-muted);
    }

    .admin-kpi-icon {
        width: 34px;
        height: 34px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        background: #fef2f2;
        border: 1px solid #fecaca;
        color: var(--adm-primary);
    }

    .admin-section {
        margin-top: 22px;
        display: grid;
        grid-template-columns: minmax(0, 1.6fr) minmax(0, 1.1fr);
        gap: 16px;
    }

    @media (max-width: 1024px) {
        .admin-section {
            grid-template-columns: minmax(0, 1fr);
        }
    }

    .admin-card {
        background: var(--adm-surface);
        border-radius: var(--adm-radius);
        border: 1px solid var(--adm-border);
        padding: 14px 16px 16px;
        box-shadow: 0 8px 18px rgba(15, 23, 42, 0.03);
    }

    .admin-card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
        gap: 10px;
    }

    .admin-card-header h2 {
        margin: 0;
        font-size: 14px;
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: 6px;
        color: var(--adm-text-main);
    }

    .admin-card-header span.note {
        font-size: 11px;
        color: var(--adm-text-muted);
    }

    .admin-metric-row {
        display: flex;
        justify-content: space-between;
        font-size: 12px;
        padding: 6px 0;
    }

    .admin-metric-row + .admin-metric-row {
        border-top: 1px dashed rgba(209, 213, 219, 0.9);
    }

    .admin-metric-label {
        color: var(--adm-text-muted);
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .admin-metric-value {
        font-weight: 600;
        color: var(--adm-text-main);
    }

    .admin-pill {
        font-size: 10px;
        padding: 2px 6px;
        border-radius: 999px;
        border: 1px solid rgba(209, 213, 219, 0.9);
        background: #f9fafb;
        color: var(--adm-text-muted);
    }

    .admin-metric-section-title {
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #7f1d1d;
        font-weight: 700;
    }

    .admin-tab-panel {
        display: none;
    }

    .admin-tab-panel.is-active {
        display: block;
    }

    .admin-info-box {
        margin-top: 18px;
        padding: 12px 14px;
        border-radius: 10px;
        border: 1px dashed rgba(248, 113, 113, 0.5);
        background: #fef2f2;
        font-size: 12px;
        color: #7f1d1d;
        line-height: 1.5;
    }

    .admin-info-box strong {
        color: #b91c1c;
    }

    .admin-subtitle {
        margin: 4px 0 8px;
        font-size: 12px;
        font-weight: 600;
        color: var(--adm-text-muted);
    }

    .admin-simple-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 11px;
    }

    .admin-simple-table th,
    .admin-simple-table td {
        padding: 4px 6px;
        text-align: left;
        border-bottom: 1px dashed rgba(209, 213, 219, 0.7);
    }

    .admin-simple-table th {
        font-size: 11px;
        color: var(--adm-text-muted);
        font-weight: 600;
    }

    .admin-simple-table tbody tr:last-child td {
        border-bottom: none;
    }

    .admin-chip {
        display: inline-flex;
        align-items: center;
        padding: 2px 6px;
        border-radius: 999px;
        border: 1px solid rgba(209, 213, 219, 0.9);
        font-size: 10px;
        background: #f9fafb;
        color: var(--adm-text-muted);
    }

    .admin-ops-grid {
        margin-top: 10px;
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
        gap: 8px;
        font-size: 12px;
    }

    .admin-ops-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 6px 8px;
        border-radius: 10px;
        background: #f9fafb;
        border: 1px solid rgba(209, 213, 219, 0.7);
    }

    .admin-ops-label {
        color: var(--adm-text-muted);
    }

    .admin-ops-value {
        font-weight: 700;
        color: var(--adm-text-main);
    }

    .admin-ops-value.is-hot {
        color: #b91c1c;
    }

    .admin-ops-value.is-warn {
        color: #d97706;
    }
    .kasa-summary-card .admin-card-header h2 {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 16px;
    }
    .kasa-summary-card .admin-card-header h2 i {
        font-size: 18px;
        color: var(--primary);
    }
    .kasa-summary-card .note {
        font-size: 11px;
        color: var(--text-muted);
    }

    .metric-section-title {
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .05em;
        color: var(--text-muted);
        margin-bottom: 4px;
        margin-top: 8px;
    }
    .metric-section-separator {
        margin: 10px 0;
        border-top: 1px dashed rgba(148, 163, 184, 0.4);
    }
    .metric-total {
        font-weight: 800;
        font-size: 15px;
    }
    .metric-positive {
        color: #16a34a; /* yeşil */
    }
    .metric-negative {
        color: #dc2626; /* kırmızı */
    }
    .metric-pill {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 3px 9px;
        border-radius: 999px;
        font-size: 10px;
        font-weight: 700;
        text-transform: uppercase;
        background: rgba(248, 250, 252, 0.08);
        color: var(--text-muted);
    }
    body.dark-mode .metric-pill {
        background: rgba(15, 23, 42, 0.8);
    }

    .admin-metric-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 4px 0;
        font-size: 13px;
    }
    .admin-metric-label {
        color: var(--text-main);
        max-width: 70%;
    }
    .admin-metric-value {
        font-weight: 600;
        text-align: right;
        white-space: nowrap;
    }
    .admin-metric-value span.subinfo {
        font-size: 11px;
        color: var(--text-muted);
        font-weight: 400;
        display: block;
    }
    .kasa-master-card {
        border-radius: 18px;
        border: 1px solid rgba(148,163,184,0.25);
        background: linear-gradient(135deg, #ffffff 0%, #f9fafb 40%, #fef2f2 100%);
        box-shadow: 0 20px 40px rgba(148, 27, 54, 0.18);
        padding: 18px 18px 20px;
    }
    body.dark-mode .kasa-master-card {
        background: radial-gradient(circle at top left, rgba(248,113,113,0.08), #020617 40%, #020617 100%);
        border-color: rgba(248,113,113,0.25);
        box-shadow: 0 18px 40px rgba(0,0,0,0.7);
    }

    .kasa-card-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 12px;
        margin-bottom: 14px;
    }
    .kasa-card-header-left h2 {
        margin: 0;
        font-size: 16px;
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--text-main);
    }
    .kasa-card-header-left h2 i {
        font-size: 18px;
        color: var(--primary);
    }
    .kasa-card-header-left .note {
        font-size: 11px;
        color: var(--text-muted);
        margin-top: 4px;
        max-width: 360px;
    }

    .kasa-badge-net {
        padding: 6px 10px;
        border-radius: 999px;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        background: #fee2e2;
        color: #b91c1c;
        border: 1px solid #fecaca;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }
    body.dark-mode .kasa-badge-net {
        background: rgba(127,29,29,0.9);
        border-color: rgba(248,113,113,0.6);
        color: #fecaca;
    }

    .kasa-badge-dot {
        width: 7px; height: 7px;
        border-radius: 999px;
        background: #b91c1c;
    }

    .kasa-grid {
        display: grid;
        grid-template-columns: 2fr 2fr 1.5fr;
        gap: 14px;
    }
    @media (max-width: 1024px) {
        .kasa-grid { grid-template-columns: 1fr; }
    }

    .kasa-box {
        padding: 12px 12px 10px;
        border-radius: 12px;
        background: rgba(255,255,255,0.85);
        border: 1px solid rgba(148,163,184,0.35);
    }
    body.dark-mode .kasa-box {
        background: rgba(15,23,42,0.9);
        border-color: rgba(148,163,184,0.35);
    }

    .kasa-box-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 8px;
    }
    .kasa-box-title {
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .06em;
        color: var(--text-muted);
        display: flex;
        align-items: center;
        gap: 6px;
    }
    .kasa-box-chip {
        font-size: 10px;
        padding: 3px 8px;
        border-radius: 999px;
        font-weight: 600;
        border: 1px solid rgba(148,163,184,0.5);
        background: rgba(248,250,252,0.7);
        color: var(--text-muted);
    }
    body.dark-mode .kasa-box-chip {
        background: rgba(15,23,42,0.9);
        border-color: rgba(148,163,184,0.7);
    }

    .admin-metric-row {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        padding: 4px 0;
        font-size: 12.5px;
    }
    .admin-metric-label {
        color: var(--text-main);
        max-width: 70%;
    }
    .admin-metric-label span.subinfo {
        display: block;
        font-size: 11px;
        color: var(--text-muted);
        margin-top: 2px;
    }
    .admin-metric-value {
        font-weight: 600;
        text-align: right;
        white-space: nowrap;
        font-variant-numeric: tabular-nums;
    }
    .admin-metric-value-small {
        font-size: 12px;
        color: var(--text-muted);
    }

    .metric-total {
        font-weight: 800;
        font-size: 13.5px;
    }

    .metric-positive { color: #16a34a; }
    .metric-negative { color: #dc2626; }

    .kasa-main-amount {
        font-size: 18px;
        font-weight: 800;
        font-variant-numeric: tabular-nums;
    }

    .kasa-tag-row {
        display: flex;
        flex-wrap: wrap;
        gap: 4px;
        margin-top: 6px;
    }
    .kasa-tag {
        font-size: 10px;
        padding: 3px 7px;
        border-radius: 999px;
        border: 1px solid rgba(148,163,184,0.5);
        color: var(--text-muted);
        background: rgba(248,250,252,0.9);
    }
    body.dark-mode .kasa-tag {
        background: rgba(15,23,42,0.9);
        border-color: rgba(148,163,184,0.7);
    }
</style>

<div class="admin-dashboard-root">

    <div class="admin-header-area">
        <div class="admin-header-title">
            <h1>BetWallet Komuta Merkezi</h1>
            <p>Seçili tarih aralığında BetWallet tarafının üye, yatırım, çekim ve kâr özetini görüyorsun.</p>
            <div class="admin-range-chip">
                <i class="ri-calendar-line"></i>
                Aralık: <strong><?= htmlspecialchars($rangeLabel) ?></strong>
            </div>
        </div>

        <div>
            <!-- 4 ana tab -->
            <div class="admin-tabs" id="admin-tabs">
                <button type="button"
                        class="admin-tab-item is-active"
                        data-tab="tab-betwallet">
                    <i class="ri-bank-card-line"></i>
                    BetWallet
                    <span class="badge">Core</span>
                </button>
                <button type="button"
                        class="admin-tab-item"
                        data-tab="tab-agent">
                    <i class="ri-user-star-line"></i>
                    Agent
                </button>
                <button type="button"
                        class="admin-tab-item"
                        data-tab="tab-site">
                    <i class="ri-building-2-line"></i>
                    Site
                </button>
                <button type="button"
                        class="admin-tab-item"
                        data-tab="tab-ops">
                    <i class="ri-dashboard-2-line"></i>
                    Operasyon
                </button>
            </div>
        </div>
    </div>

    <!-- Ortak tarih seçiciler -->
    <div class="admin-range-filters">
        <?php
        $ranges = [
            'today'     => 'Bugün',
            'yesterday' => 'Dün',
            '7d'        => 'Son 7 Gün',
            '30d'       => 'Son 30 Gün',
            'all'       => 'Tüm Zamanlar',
        ];
        foreach ($ranges as $key => $label): ?>
            <a href="?range=<?= $key ?>"
               class="admin-range-btn <?= $range === $key ? 'is-active' : '' ?>">
                <?= htmlspecialchars($label) ?>
            </a>
        <?php endforeach; ?>
    </div>

    <!-- ====================== TAB 1: BETWALLET ====================== -->
    <div class="admin-tab-panel is-active" id="tab-betwallet">
        <!-- Üst KPI kartları -->
        <div class="admin-kpi-grid">
            <div class="admin-kpi-card">
                <div class="admin-kpi-top">
                    <div>
                        <div class="admin-kpi-label">ÜYE SAYISI</div>
                        <div class="admin-kpi-value">
                            <?= number_format($totalUsers, 0, ',', '.') ?>
                        </div>
                        <div class="admin-kpi-sub">
                            Sistemde kayıtlı toplam BetWallet hesabı.
                        </div>
                    </div>
                    <div class="admin-kpi-icon">
                        <i class="ri-group-line"></i>
                    </div>
                </div>
            </div>

            <div class="admin-kpi-card">
                <div class="admin-kpi-top">
                    <div>
                        <div class="admin-kpi-label">YATIRIM TUTARI</div>
                        <div class="admin-kpi-value">
                            <?= number_format($rangeDepositTry, 2, ',', '.') ?> ₺
                        </div>
                        <div class="admin-kpi-sub">
                            Seçili aralıkta <strong>deposit_orders (confirmed)</strong> toplamı.
                        </div>
                    </div>
                    <div class="admin-kpi-icon">
                        <i class="ri-arrow-left-down-line"></i>
                    </div>
                </div>
            </div>

            <div class="admin-kpi-card">
                <div class="admin-kpi-top">
                    <div>
                        <div class="admin-kpi-label">ÇEKİM TUTARI</div>
                        <div class="admin-kpi-value">
                            <?= number_format($rangeAgentWithdrawTry, 2, ',', '.') ?> ₺
                        </div>
                        <div class="admin-kpi-sub">
                            Seçili aralıkta <strong>agent_withdraw_orders (paid)</strong> toplamı.
                        </div>
                    </div>
                    <div class="admin-kpi-icon">
                        <i class="ri-arrow-right-up-line"></i>
                    </div>
                </div>
            </div>

            <!-- Boss Cüzdan (bize kalan) -->
            <div class="admin-kpi-card">
                <div class="admin-kpi-top">
                    <div>
                        <div class="admin-kpi-label">BOSS CÜZDAN (NET KÂR)</div>
                        <div class="admin-kpi-value">
                            <?= number_format($betwalletNetProfit, 2, ',', '.') ?> ₺
                        </div>
                        <div class="admin-kpi-sub">
                            Yatırım spread'i (site − agent) + tüm %1 çekim fee gelirleri.
                            <br>
                            Spread: <?= number_format($betwalletInvestmentMargin, 2, ',', '.') ?> ₺
                            (~<?= number_format($commissionMarginPct, 2, ',', '.') ?>%).
                        </div>
                    </div>
                    <div class="admin-kpi-icon">
                        <i class="ri-money-cny-circle-line"></i>
                    </div>
                </div>
            </div>

            <!-- Üyelerin güncel cüzdan bakiyesi (USDT) -->
            <div class="admin-kpi-card">
                <div class="admin-kpi-top">
                    <div>
                        <div class="admin-kpi-label">ÜYELERİN GÜNCEL CÜZDANI</div>
                        <div class="admin-kpi-value">
                            <?= number_format($usersTotalWalletUsdt, 2, ',', '.') ?> USDT
                        </div>
                        <div class="admin-kpi-sub">
                            Wallets tablosundaki toplam USDT bakiyesi (anlık snapshot).
                        </div>
                    </div>
                    <div class="admin-kpi-icon">
                        <i class="ri-wallet-3-line"></i>
                    </div>
                </div>
            </div>

            <!-- Merchant yatırım ve çekim toplamı (seçilen aralık) -->
            <div class="admin-kpi-card">
                <div class="admin-kpi-top">
                    <div>
                        <div class="admin-kpi-label">MERCHANT YATIRIM / ÇEKİM</div>
                        <div class="admin-kpi-value">
                            <?= number_format($merchantVolumeTry, 2, ',', '.') ?> ₺ / <?= number_format($merchantWithdrawApproved, 2, ',', '.') ?> ₺
                        </div>
                        <div class="admin-kpi-sub">
                            Onaylı merchant yatırım (merchant_orders) / onaylı merchant çekim (merchant_player_withdraws).
                        </div>
                    </div>
                    <div class="admin-kpi-icon">
                        <i class="ri-exchange-funds-line"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Gelir / Gider / Toplam & Kasalar -->
    <div class="admin-card kasa-master-card">
    <div class="kasa-card-header">
        <div class="kasa-card-header-left">
            <h2>
                <i class="ri-safe-2-line"></i>
                Kasa Yönetimi & Özet
            </h2>
            <div class="note">
                Bize ait kasalar, bugüne kadar ödenenler, bekleyen ödemeler ve şu anki net pozisyonun tek ekranda özeti.
            </div>
        </div>
        <div>
            <span class="kasa-badge-net">
                <span class="kasa-badge-dot"></span>
                Net Pozisyon:
                <strong><?= $bugunNetSign ?><?= number_format(abs($bugunNetPozisyon), 2, ',', '.') ?> ₺</strong>
            </span>
        </div>
    </div>

    <div class="kasa-grid">
        <!-- 1) BİZE AİT / KAYNAK TARAFI -->
        <div class="kasa-box">
            <div class="kasa-box-header">
                <div class="kasa-box-title">
                    <i class="ri-download-2-line"></i> Bize ait kasalar
                </div>
                <span class="kasa-box-chip">Asset</span>
            </div>

            <div class="admin-metric-row">
                <div class="admin-metric-label">
                    Agent Teminatları
                    <span class="subinfo">Agent system_balance (bizde tutulan teminat)</span>
                </div>
                <div class="admin-metric-value">
                    <?= number_format($bizeAitTeminat, 2, ',', '.') ?> ₺
                </div>
            </div>

            <div class="admin-metric-row">
                <div class="admin-metric-label">
                    Site Bakiyeleri
                    <span class="subinfo">Sitelerin şu anki balance toplamı</span>
                </div>
                <div class="admin-metric-value">
                    <?= number_format($bizeAitSiteBakiye, 2, ',', '.') ?> ₺
                </div>
            </div>

            <div class="admin-metric-row">
                <div class="admin-metric-label metric-total">
                    Bize ait toplam kaynak
                </div>
                <div class="admin-metric-value metric-total">
                    <?= number_format($bizeAitBugunToplam, 2, ',', '.') ?> ₺
                </div>
            </div>

            <div class="admin-metric-row">
                <div class="admin-metric-label">
                    Teorik toplam kaynak
                    <span class="subinfo">Bize ait (bugün) + bugüne kadar ödenenler</span>
                </div>
                <div class="admin-metric-value admin-metric-value-small">
                    <?= number_format($teorikToplamKaynak, 2, ',', '.') ?> ₺
                </div>
            </div>
        </div>

        <!-- 2) ÖDENENLER & BEKLEYENLER -->
        <div class="kasa-box">
            <div class="kasa-box-header">
                <div class="kasa-box-title">
                    <i class="ri-upload-2-line"></i> Ödenenler & Bekleyenler
                </div>
                <span class="kasa-box-chip">Outflow</span>
            </div>

            <!-- ÖDENENLER -->
            <div class="admin-metric-row">
                <div class="admin-metric-label metric-total">
                    Bugüne kadar ödenenler
                </div>
                <div class="admin-metric-value metric-total">
                    − <?= number_format($toplamOdenen, 2, ',', '.') ?> ₺
                </div>
            </div>
            <div class="admin-metric-row">
                <div class="admin-metric-label">
                    Ödenen Site Çekimleri
                </div>
                <div class="admin-metric-value admin-metric-value-small">
                    − <?= number_format($odenmisSiteCekimi, 2, ',', '.') ?> ₺
                </div>
            </div>
            <div class="admin-metric-row">
                <div class="admin-metric-label">
                    Ödenen Agent Kâr Çekimleri
                </div>
                <div class="admin-metric-value admin-metric-value-small">
                    − <?= number_format($odenmisAgentKar, 2, ',', '.') ?> ₺
                </div>
            </div>

            <div class="metric-section-separator"></div>

            <!-- BEKLEYENLER -->
            <div class="admin-metric-row">
                <div class="admin-metric-label metric-total">
                    Kısa vadede ödenecekler (pending)
                </div>
                <div class="admin-metric-value metric-total">
                    − <?= number_format($pendingToplam, 2, ',', '.') ?> ₺
                </div>
            </div>
            <div class="admin-metric-row">
                <div class="admin-metric-label">
                    Bekleyen Site Çekimleri
                </div>
                <div class="admin-metric-value admin-metric-value-small">
                    − <?= number_format($pendingSite, 2, ',', '.') ?> ₺
                </div>
            </div>
            <div class="admin-metric-row">
                <div class="admin-metric-label">
                    Bekleyen Agent Kâr Çekimleri
                </div>
                <div class="admin-metric-value admin-metric-value-small">
                    − <?= number_format($pendingAgent, 2, ',', '.') ?> ₺
                </div>
            </div>
        </div>

        <!-- 3) BUGÜN NET DURUM / BİLGİ AMAÇLI -->
        <div class="kasa-box">
            <div class="kasa-box-header">
                <div class="kasa-box-title">
                    <i class="ri-equalizer-line"></i> Bugünkü net durum
                </div>
                <span class="kasa-box-chip">Net</span>
            </div>

            <div class="admin-metric-row">
                <div class="admin-metric-label">
                    Bugün kasada kalan (bize ait − bekleyen)
                    <div class="kasa-tag-row">
                        <span class="kasa-tag">Agent teminat + site bakiyesi</span>
                        <span class="kasa-tag">− pending çekimler</span>
                    </div>
                </div>
                <div class="admin-metric-value <?= $bugunNetClass ?>">
                    <div class="kasa-main-amount">
                        <?= $bugunNetSign ?><?= number_format(abs($bugunNetPozisyon), 2, ',', '.') ?> ₺
                    </div>
                </div>
            </div>

            <div class="metric-section-separator"></div>

            <div class="metric-section-title">
                Bilgi amaçlı (bizim borcumuz değil)
            </div>
            <div class="admin-metric-row">
                <div class="admin-metric-label">
                    Sahadaki Agent Kasaları
                    <span class="subinfo">deposit_agents.current_cash</span>
                </div>
                <div class="admin-metric-value admin-metric-value-small">
                    <?= number_format($kasaOzet['saha_kasasi_tl'], 2, ',', '.') ?> ₺
                </div>
            </div>
            <div class="admin-metric-row">
                <div class="admin-metric-label">
                    Kullanıcı USDT Cüzdan Toplamı
                    <span class="subinfo">Wallets (USDT) → Çekimi agent öder</span>
                </div>
                <div class="admin-metric-value admin-metric-value-small">
                    <?= number_format($kasaOzet['kullanici_usdt_cuzdan_toplam'], 2, ',', '.') ?> USDT
                </div>
            </div>
        </div>
    </div>
</div>

        <!-- INFO BOX -->
        <div class="admin-info-box">
            <strong>Yorumlama formülü (yeni model):</strong><br>
            Agent artık teminat yüklerken bonus almıyor; yatırdığı tutar kadar teminata geçiyor. Agent sadece onayladığı yatırımlardan
            kendi komisyon oranı kadar kâr kazanıyor. Çekimlerde kâr yazılmıyor, sadece teminat yükseliyor, saha kasası düşüyor.<br><br>

            <strong>BetWallet kârı (Boss Cüzdan)</strong> kabaca:<br>
            Net Kâr = (Yatırım tutarı × (Site komisyon oranı − Agent komisyon oranı)) + Tüm %1 çekim fee gelirleri<br>
            ⇢ Kod tarafında: (merchantCommission − agentProfitCost) + (agent/site withdraw fee’leri).<br><br>

            Sağlıklı bir tabloda yaklaşık olarak:<br>
            <strong>BetWallet Cüzdan + Teminat + Site Bakiyesi ≳ Üye Cüzdanları + Agent Profit Kasası</strong><br>
            ise sistem likidite olarak rahattır. Eğer Boss Cüzdan uzun süre aşağı doğru gidiyorsa veya sol taraf sağ tarafı
            karşılamıyorsa, site/agent komisyon oranlarını, çekim frekansını ve limitleri sıkılaştırman gerekir.
        </div>
    </div>

    <!-- ====================== TAB 2: AGENT ====================== -->
    <div class="admin-tab-panel" id="tab-agent">
        <div class="admin-section">
            <!-- SOL: Hacim & Kâr Ligleri -->
            <div class="admin-card">
                <div class="admin-card-header">
                    <h2><i class="ri-user-star-line"></i> Agent Hacim & Kâr Ligi</h2>
                    <span class="note">Seçili tarih aralığına göre en çok yatırım alan ve en çok kâr üreten agent’lar.</span>
                </div>

                <div class="admin-subtitle">Hacim Ligi (Yatırım)</div>
                <?php if (!empty($topAgentsByDeposit)): ?>
                    <table class="admin-simple-table">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Agent</th>
                            <th>Oran</th>
                            <th>Yatırım</th>
                            <th>Adet</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $rank = 1; foreach ($topAgentsByDeposit as $row): ?>
                            <tr>
                                <td><?= $rank++ ?></td>
                                <td><?= htmlspecialchars($row['name'] ?? ('Agent #' . $row['id'])) ?></td>
                                <td><?= number_format((float)($row['commission_rate'] ?? 0), 2, ',', '.') ?>%</td>
                                <td><?= number_format((float)$row['total_deposit'], 2, ',', '.') ?> ₺</td>
                                <td><?= (int)$row['deposit_count'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="admin-subtitle" style="color:#9ca3af;">Seçili aralıkta hacim bulunamadı.</div>
                <?php endif; ?>

                <div class="admin-subtitle" style="margin-top:12px;">Kâr Ligi (Agent Profit)</div>
                <?php if (!empty($topAgentsByProfit)): ?>
                    <table class="admin-simple-table">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Agent</th>
                            <th>Oran</th>
                            <th>Kâr</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $rank = 1; foreach ($topAgentsByProfit as $row): ?>
                            <tr>
                                <td><?= $rank++ ?></td>
                                <td><?= htmlspecialchars($row['name'] ?? ('Agent #' . $row['id'])) ?></td>
                                <td><?= number_format((float)($row['commission_rate'] ?? 0), 2, ',', '.') ?>%</td>
                                <td><?= number_format((float)$row['total_profit'], 2, ',', '.') ?> ₺</td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="admin-subtitle" style="color:#9ca3af;">Seçili aralıkta agent profit logu yok.</div>
                <?php endif; ?>
            </div>

            <!-- SAĞ: Canlı Agent Kasaları -->
            <div class="admin-card">
                <div class="admin-card-header">
                    <h2><i class="ri-store-3-line"></i> Canlı Agent Kasaları</h2>
                    <span class="note">Teminat, sahadaki kasa ve kâr kasası dağılımı (anlık).</span>
                </div>

                <?php if (!empty($agentSnapshots)): ?>
                    <table class="admin-simple-table">
                        <thead>
                        <tr>
                            <th>Agent</th>
                            <th>Oran</th>
                            <th>Teminat</th>
                            <th>Kasa</th>
                            <th>Kâr Kasa</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($agentSnapshots as $row): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['name'] ?? ('Agent #' . $row['id'])) ?></td>
                                <td><?= number_format((float)($row['commission_rate'] ?? 0), 2, ',', '.') ?>%</td>
                                <td><?= number_format((float)$row['system_balance'], 2, ',', '.') ?> ₺</td>
                                <td><?= number_format((float)$row['current_cash'], 2, ',', '.') ?> ₺</td>
                                <td><?= number_format((float)$row['agent_profit_balance'], 2, ',', '.') ?> ₺</td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="admin-subtitle" style="color:#9ca3af;">Kayıtlı agent bulunamadı.</div>
                <?php endif; ?>

                <div style="margin-top:10px; font-size:11px; color:#6b7280;">
                    Not: Yeni modelde çekimlerde agent’a kâr yazılmıyor; sadece <strong>teminat ↑</strong>, <strong>saha kasası ↓</strong>.
                    Bu tabloyu izleyerek teminat / saha dengesini görebilirsin.
                </div>
            </div>
        </div>
    </div>

    <!-- ====================== TAB 3: SITE ====================== -->
    <div class="admin-tab-panel" id="tab-site">
        <div class="admin-section">
            <!-- SOL: Site Hacim & Komisyon -->
            <div class="admin-card">
                <div class="admin-card-header">
                    <h2><i class="ri-building-2-line"></i> Site Hacim & Komisyon</h2>
                    <span class="note">Seçili aralıkta sitelerin yatırım hacmi ve BetWallet’a bıraktığı komisyon.</span>
                </div>

                <?php if (!empty($topSitesByVolume)): ?>
                    <table class="admin-simple-table">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Site</th>
                            <th>Oran</th>
                            <th>Hacim</th>
                            <th>Komisyon</th>
                            <th>Adet</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $rank = 1; foreach ($topSitesByVolume as $row): ?>
                            <tr>
                                <td><?= $rank++ ?></td>
                                <td><?= htmlspecialchars($row['name'] ?? ('Site #' . $row['id'])) ?></td>
                                <td><?= number_format((float)($row['commission_rate'] ?? 0), 2, ',', '.') ?>%</td>
                                <td><?= number_format((float)$row['total_volume'], 2, ',', '.') ?> ₺</td>
                                <td><?= number_format((float)$row['total_commission'], 2, ',', '.') ?> ₺</td>
                                <td><?= (int)$row['order_count'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="admin-subtitle" style="color:#9ca3af;">Bu aralıkta herhangi bir site hacmi yok.</div>
                <?php endif; ?>
            </div>

            <!-- SAĞ: Canlı Site Bakiyeleri -->
            <div class="admin-card">
                <div class="admin-card-header">
                    <h2><i class="ri-safe-2-line"></i> Canlı Site Bakiyeleri</h2>
                    <span class="note">Anlık site bakiyeleri ve komisyon oranları.</span>
                </div>

                <?php if (!empty($siteSnapshots)): ?>
                    <table class="admin-simple-table">
                        <thead>
                        <tr>
                            <th>Site</th>
                            <th>Oran</th>
                            <th>Bakiye</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($siteSnapshots as $row): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['name'] ?? ('Site #' . $row['id'])) ?></td>
                                <td><?= number_format((float)($row['commission_rate'] ?? 0), 2, ',', '.') ?>%</td>
                                <td><?= number_format((float)$row['balance'], 2, ',', '.') ?> ₺</td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="admin-subtitle" style="color:#9ca3af;">Kayıtlı site bulunamadı.</div>
                <?php endif; ?>

                <div style="margin-top:10px; font-size:11px; color:#6b7280;">
                    Not: Site komisyon oranı, yatırım başına BetWallet tarafının brüt gelir oranıdır.
                    Agent oranlarını düşürdükçe spread (site − agent) Boss Cüzdan’a kâr olarak yansır.
                </div>
            </div>
        </div>
    </div>

    <!-- ====================== TAB 4: OPERASYON ====================== -->
    <div class="admin-tab-panel" id="tab-ops">
        <div class="admin-section">
            <!-- SOL: Bekleyen İşlemler -->
            <div class="admin-card">
                <div class="admin-card-header">
                    <h2><i class="ri-dashboard-2-line"></i> Bekleyen İşlemler</h2>
                    <span class="note">Onay bekleyen yatırım, çekim ve bakiye işlemleri.</span>
                </div>

                <div class="admin-ops-grid">
                    <div class="admin-ops-item">
                        <div class="admin-ops-label">Yatırımlar (deposit_orders)</div>
                        <div class="admin-ops-value <?= $pendingDepositOrders > 0 ? 'is-hot' : '' ?>">
                            <?= $pendingDepositOrders ?>
                        </div>
                    </div>
                    <div class="admin-ops-item">
                        <div class="admin-ops-label">Agent Çekimleri</div>
                        <div class="admin-ops-value <?= $pendingAgentWithdrawOrders > 0 ? 'is-warn' : '' ?>">
                            <?= $pendingAgentWithdrawOrders ?>
                        </div>
                    </div>
                    <div class="admin-ops-item">
                        <div class="admin-ops-label">Merchant Yatırımları</div>
                        <div class="admin-ops-value <?= $pendingMerchantOrders > 0 ? 'is-warn' : '' ?>">
                            <?= $pendingMerchantOrders ?>
                        </div>
                    </div>
                    <div class="admin-ops-item">
                        <div class="admin-ops-label">Merchant Çekimleri</div>
                        <div class="admin-ops-value <?= $pendingMerchantPlayerWithdraws > 0 ? 'is-warn' : '' ?>">
                            <?= $pendingMerchantPlayerWithdraws ?>
                        </div>
                    </div>
                    <div class="admin-ops-item">
                        <div class="admin-ops-label">Site Çekimleri</div>
                        <div class="admin-ops-value <?= $pendingSiteWithdrawals > 0 ? 'is-warn' : '' ?>">
                            <?= $pendingSiteWithdrawals ?>
                        </div>
                    </div>
                    <div class="admin-ops-item">
                        <div class="admin-ops-label">Agent Bakiye Talepleri</div>
                        <div class="admin-ops-value <?= $pendingAgentBalanceRequests > 0 ? 'is-hot' : '' ?>">
                            <?= $pendingAgentBalanceRequests ?>
                        </div>
                    </div>
                    <div class="admin-ops-item">
                        <div class="admin-ops-label">Site Bakiye Talepleri</div>
                        <div class="admin-ops-value <?= $pendingSiteBalanceRequests > 0 ? 'is-hot' : '' ?>">
                            <?= $pendingSiteBalanceRequests ?>
                        </div>
                    </div>
                </div>

                <div style="margin-top:10px; font-size:11px; color:#6b7280;">
                    Not: Buradaki sayılar, onaylayarak sisteme likidite akışını hızlandırman gereken iş listesini özetler.
                    Kırmızı görünenler doğrudan Boss Cüzdan / operasyonel kasaya etki eden kalemlerdir.
                </div>
            </div>

            <!-- SAĞ: Risk & Sağlık Göstergesi -->
            <div class="admin-card">
                <div class="admin-card-header">
                    <h2><i class="ri-shield-keyhole-line"></i> Operasyon & Risk Özeti</h2>
                    <span class="note">Agent teminat / kasa dengesi ve genel sağlık notu.</span>
                </div>

                <div class="admin-metric-row">
                    <div class="admin-metric-label">
                        Teminatı saha kasasından düşük olan agent sayısı
                    </div>
                    <div class="admin-metric-value <?= $riskyAgentsCount > 0 ? 'is-hot' : '' ?>">
                        <?= $riskyAgentsCount ?>
                    </div>
                </div>

                <div class="admin-metric-row">
                    <div class="admin-metric-label">
                        Toplam Agent Teminatı
                    </div>
                    <div class="admin-metric-value">
                        <?= number_format($totalAgentCollateral, 2, ',', '.') ?> ₺
                    </div>
                </div>

                <div class="admin-metric-row">
                    <div class="admin-metric-label">
                        Toplam Agent Kasa (Saha)
                    </div>
                    <div class="admin-metric-value">
                        <?= number_format($totalAgentCash, 2, ',', '.') ?> ₺
                    </div>
                </div>

                <div class="admin-metric-row">
                    <div class="admin-metric-label">
                        Toplam Site Bakiyesi
                    </div>
                    <div class="admin-metric-value">
                        <?= number_format($totalSiteBalance, 2, ',', '.') ?> ₺
                    </div>
                </div>

                <div class="admin-metric-row">
                    <div class="admin-metric-label">
                        Üyelerin USDT Cüzdan Toplamı
                    </div>
                    <div class="admin-metric-value">
                        <?= number_format($usersTotalWalletUsdt, 2, ',', '.') ?> USDT
                    </div>
                </div>

                <div style="margin-top:10px; font-size:11px; color:#6b7280;">
                    Agent çekimlerinde kâr yazılmadığı için, uzun vadede <strong>teminat + site bakiyesi</strong> tarafını,
                    <strong>üye cüzdanı + agent profit kasası</strong> ile birlikte takip etmen önemli.
                    Riskli agent sayısı yükseliyorsa, ilgili agent’ların komisyon oranı, günlük limitleri veya çekim frekansı
                    yeniden düzenlenmelidir.
                </div>
            </div>
        </div>
    </div>

</div>

<script>
    (function () {
        const tabs   = document.querySelectorAll('.admin-tab-item');
        const panels = document.querySelectorAll('.admin-tab-panel');

        tabs.forEach(function (btn) {
            btn.addEventListener('click', function () {
                const targetId = btn.getAttribute('data-tab');

                tabs.forEach(t => t.classList.remove('is-active'));
                panels.forEach(p => p.classList.remove('is-active'));

                btn.classList.add('is-active');
                const panel = document.getElementById(targetId);
                if (panel) {
                    panel.classList.add('is-active');
                }
            });
        });
    })();
</script>

<?php include __DIR__ . '/_admin_footer.php'; ?>
