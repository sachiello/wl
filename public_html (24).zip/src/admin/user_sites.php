<?php
// admin/user_sites.php
require __DIR__ . '/require_admin.php'; // $pdo, $currentAdmin, CSRF helpers

$pageTitle = 'Kullanıcı & Site Eşleşmeleri';
$activeNav = 'user_sites';

$error = null;

// --- Filtreler ---
$search     = trim($_GET['q'] ?? '');
$siteFilter = $_GET['site_id'] ?? '';
$page       = max(1, (int)($_GET['page'] ?? 1));
$perPage    = 50;
$offset     = ($page - 1) * $perPage;

// ======================================================================
// POST İŞLEMLERİ (CSRF Korumalı + PRG)
// ======================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!function_exists('validate_csrf_token') || !validate_csrf_token()) {
        $error = "Oturum doğrulaması başarısız. Lütfen sayfayı yenileyip tekrar deneyin.";
    } else {

        // --- Yeni Ekleme İşlemi ---
        if (isset($_POST['add_link'])) {
            $userId        = (int)($_POST['user_id'] ?? 0);
            $siteId        = (int)($_POST['site_id'] ?? 0);
            $siteUsername  = trim($_POST['site_username'] ?? '');

            if ($userId > 0 && $siteId > 0 && $siteUsername !== '') {

                // Aynı kullanıcı + aynı site daha önce eklenmiş mi?
                $check = $pdo->prepare("SELECT id FROM user_sites WHERE user_id = ? AND site_id = ?");
                $check->execute([$userId, $siteId]);

                if (!$check->fetch()) {
                    $stmt = $pdo->prepare("
                        INSERT INTO user_sites (user_id, site_id, site_username, site_balance_try, linked_at)
                        VALUES (:user_id, :site_id, :site_username, 0, NOW())
                    ");
                    $stmt->execute([
                        ':user_id'       => $userId,
                        ':site_id'       => $siteId,
                        ':site_username' => $siteUsername
                    ]);

                    // Log ekle
                    $meta = json_encode([
                        'user_id'       => $userId,
                        'site_id'       => $siteId,
                        'site_username' => $siteUsername
                    ], JSON_UNESCAPED_UNICODE);

                    $log = $pdo->prepare("
                        INSERT INTO activity_logs (actor_type, actor_id, scope, action, meta_json, created_at)
                        VALUES ('admin', :admin_id, 'site_link', 'create', :meta_json, NOW())
                    ");
                    $log->execute([
                        ':admin_id'  => $currentAdmin['id'],
                        ':meta_json' => $meta
                    ]);

                    header("Location: user_sites.php?ok=added");
                    exit;
                } else {
                    $error = "Bu kullanıcı bu siteye zaten bağlı.";
                }
            } else {
                $error = "Lütfen kullanıcı, site ve site username alanlarını doldurun.";
            }
        }

        // --- Bakiye Güncelleme ---
        if (isset($_POST['update_balance'])) {
            $id     = (int)($_POST['id'] ?? 0);
            $amount = (float)($_POST['site_balance_try'] ?? 0);

            if ($id > 0) {
                $stmt = $pdo->prepare("UPDATE user_sites SET site_balance_try = :bal WHERE id = :id");
                $stmt->execute([
                    ':bal' => $amount,
                    ':id'  => $id
                ]);

                header("Location: user_sites.php?ok=balance_updated");
                exit;
            } else {
                $error = "Geçersiz kayıt ID'si.";
            }
        }

        // --- Silme (POST) ---
        if (isset($_POST['delete_id'])) {
            $id = (int)($_POST['delete_id'] ?? 0);

            if ($id > 0) {
                // Önce meta almak için kayıt çek
                $info = $pdo->prepare("SELECT user_id, site_id FROM user_sites WHERE id = ?");
                $info->execute([$id]);
                $row = $info->fetch(PDO::FETCH_ASSOC);

                if ($row) {
                    $pdo->prepare("DELETE FROM user_sites WHERE id = ?")->execute([$id]);

                    // Log
                    $meta = json_encode($row, JSON_UNESCAPED_UNICODE);
                    $log = $pdo->prepare("
                        INSERT INTO activity_logs (actor_type, actor_id, scope, action, meta_json, created_at)
                        VALUES ('admin', :admin_id, 'site_link', 'delete', :meta_json, NOW())
                    ");
                    $log->execute([
                        ':admin_id'  => $currentAdmin['id'],
                        ':meta_json' => $meta
                    ]);
                }

                header("Location: user_sites.php?ok=deleted");
                exit;
            } else {
                $error = "Silinecek kayıt bulunamadı.";
            }
        }
    }
}

// ======================================================================
// Sorgu Oluşturma
// ======================================================================
$where  = [];
$params = [];

if ($search !== '') {
    $where[]            = "(u.username LIKE :q OR us.site_username LIKE :q)";
    $params[':q']       = '%' . $search . '%';
}

if ($siteFilter !== '') {
    $where[]              = "us.site_id = :site_id";
    $params[':site_id']   = $siteFilter;
}

$whereSql = $where ? "WHERE " . implode(" AND ", $where) : "";

// Toplam kayıt sayısı
$countSql  = "
    SELECT COUNT(*) 
    FROM user_sites us 
    JOIN users u ON u.id = us.user_id 
    JOIN sites s ON s.id = us.site_id 
    $whereSql
";
$countStmt = $pdo->prepare($countSql);
$countStmt->execute($params);
$totalRows  = $countStmt->fetchColumn();
$totalPages = max(1, ceil($totalRows / $perPage));

// Liste Sorgusu
$sql = "
SELECT 
    us.id,
    u.username,
    u.id AS user_id,
    s.name AS site_name,
    s.id AS site_id,
    us.site_username,
    us.site_balance_try,
    us.linked_at
FROM user_sites us
JOIN users u ON u.id = us.user_id
JOIN sites s ON s.id = us.site_id
$whereSql
ORDER BY us.id DESC
LIMIT $perPage OFFSET $offset
";
$stmt  = $pdo->prepare($sql);
$stmt->execute($params);
$links = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Tüm siteler dropdown için
$sites = $pdo->query("SELECT id, name FROM sites ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Header
include __DIR__ . '/_admin_header.php';
?>

<style>
    /* ============================
       BetWallet Admin – User Sites
       ============================ */

    .page-content {
        padding: 24px 32px;
    }

    .toolbar-container {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 16px;
        flex-wrap: wrap;
        margin-bottom: 24px;
    }

    .toolbar-title h1 {
        margin: 0;
        font-size: 20px;
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--text-main);
    }

    .toolbar-title p {
        margin: 4px 0 0;
        font-size: 13px;
        color: var(--text-muted);
    }

    .toolbar-actions {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
    }

    .search-wrapper {
        position: relative;
    }

    .search-wrapper i {
        position: absolute;
        left: 10px;
        top: 50%;
        transform: translateY(-50%);
        font-size: 16px;
        color: var(--text-muted);
    }

    .search-input {
        padding: 9px 10px 9px 32px;
        border-radius: 999px;
        border: 1px solid var(--border-light, #e5e7eb);
        background: #ffffff;
        font-size: 13px;
        min-width: 220px;
        outline: none;
        color: var(--text-main);
        box-shadow: 0 6px 16px rgba(15, 23, 42, 0.06);
    }

    .search-input::placeholder {
        color: var(--text-muted);
    }

    .filter-select {
        padding: 9px 12px;
        border-radius: 999px;
        border: 1px solid var(--border-light, #e5e7eb);
        background: #ffffff;
        font-size: 13px;
        color: var(--text-main);
        outline: none;
        min-width: 170px;
        box-shadow: 0 6px 16px rgba(15, 23, 42, 0.06);
    }

    .btn-pill {
        border-radius: 999px;
        padding-inline: 16px;
        font-size: 13px;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        height: 36px;
    }

    .btn-primary {
        background: #c2273f;
        color: #fff;
        border: none;
    }

    .btn-secondary {
        background: #f3f4f6;
        color: #111827;
        border: 1px solid #e5e7eb;
    }

    .btn-success {
        background: #16a34a;
        color: #fff;
        border: none;
    }

    .btn-xs {
        padding: 4px 10px;
        font-size: 11px;
        border-radius: 999px;
        border: none;
        cursor: pointer;
    }

    .btn-warning {
        background: #fef3c7;
        color: #92400e;
        border: 1px solid #facc15;
    }

    .btn-danger {
        background: #fee2e2;
        color: #b91c1c;
        border: 1px solid #fecaca;
    }

    .alert {
        padding: 10px 12px;
        border-radius: 10px;
        font-size: 13px;
        margin-bottom: 16px;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .alert-success {
        background: #ecfdf5;
        color: #15803d;
        border: 1px solid #bbf7d0;
    }

    .alert-danger {
        background: #fef2f2;
        color: #b91c1c;
        border: 1px solid #fecaca;
    }

    .table-container {
        border-radius: 16px;
        border: 1px solid var(--border-light, #e5e7eb);
        background: #ffffff;
        box-shadow: 0 10px 30px rgba(15, 23, 42, 0.08);
        overflow: hidden;
    }

    .admin-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
    }

    .admin-table thead {
        background: linear-gradient(to right, #f9fafb, #fef2f2);
    }

    .admin-table th {
        padding: 10px 14px;
        text-align: left;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        color: var(--text-muted);
        border-bottom: 1px solid var(--border-light, #e5e7eb);
    }

    .admin-table td {
        padding: 10px 14px;
        border-top: 1px solid #f3f4f6;
        color: var(--text-main);
        vertical-align: middle;
    }

    .admin-table tr:nth-child(even) td {
        background: #fcfcfd;
    }

    .admin-table tr:hover td {
        background: #fef2f2;
    }

    .user-label {
        font-weight: 600;
        color: var(--text-main);
        font-size: 13px;
    }

    .user-sub {
        font-size: 11px;
        color: var(--text-muted);
    }

    .site-label {
        font-weight: 600;
        font-size: 13px;
    }

    .site-sub {
        font-size: 11px;
        color: var(--text-muted);
    }

    .admin-input-inline {
        width: 110px;
        padding: 6px 8px;
        border-radius: 999px;
        border: 1px solid #e5e7eb;
        font-size: 12px;
        outline: none;
        text-align: right;
    }

    .badge-site {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 3px 9px;
        border-radius: 999px;
        background: #f3f4ff;
        color: #4f46e5;
        font-size: 11px;
        font-weight: 600;
    }

    .admin-pagination {
        margin-top: 18px;
        display: flex;
        justify-content: center;
        gap: 6px;
    }

    .page-link {
        min-width: 32px;
        height: 32px;
        border-radius: 999px;
        border: 1px solid #e5e7eb;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        color: #4b5563;
        text-decoration: none;
        background: #ffffff;
    }

    .page-link.is-active {
        background: #c2273f;
        color: #ffffff;
        border-color: #c2273f;
        font-weight: 600;
    }

    /* Modal */
    .admin-modal-backdrop {
        position: fixed;
        inset: 0;
        background: rgba(15, 23, 42, 0.65);
        display: none;
        align-items: center;
        justify-content: center;
        z-index: 200;
        padding: 20px;
    }

    .admin-modal {
        background: #ffffff;
        border-radius: 18px;
        padding: 20px 22px 22px;
        max-width: 480px;
        width: 100%;
        box-shadow: 0 24px 70px rgba(15, 23, 42, 0.4);
        position: relative;
    }

    .admin-modal-header h2 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: var(--text-main);
    }

    .admin-modal-header p {
        margin: 4px 0 0;
        font-size: 13px;
        color: var(--text-muted);
    }

    .admin-modal-close {
        position: absolute;
        right: 14px;
        top: 12px;
        width: 28px;
        height: 28px;
        border-radius: 999px;
        border: none;
        background: #f3f4f6;
        color: #6b7280;
        cursor: pointer;
        font-size: 16px;
        line-height: 1;
    }

    .admin-modal-body {
        margin-top: 16px;
        display: flex;
        flex-direction: column;
        gap: 12px;
    }

    .admin-field-label {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-muted);
        text-transform: uppercase;
        letter-spacing: .04em;
    }

    .admin-input, .admin-select {
        width: 100%;
        padding: 10px 11px;
        border-radius: 10px;
        border: 1px solid #e5e7eb;
        font-size: 13px;
        outline: none;
        box-sizing: border-box;
    }

    .admin-input:focus, .admin-select:focus {
        border-color: #c2273f;
    }

    @media (max-width: 768px) {
        .page-content {
            padding: 16px;
        }
        .table-container {
            border-radius: 12px;
        }
        .admin-table {
            font-size: 12px;
        }
    }
</style>

<div class="page-content">

    <div class="toolbar-container">
        <div class="toolbar-title">
            <h1>
                <i class="ri-links-line" style="color:#c2273f;"></i>
                Kullanıcı & Site Bağlantıları
            </h1>
            <p>Üyelerin hangi merchant sitelere hangi kullanıcı adıyla bağlı olduğunu yönetin.</p>
        </div>

        <form method="get" class="toolbar-actions">
            <div class="search-wrapper">
                <i class="ri-search-line"></i>
                <input
                    type="text"
                    name="q"
                    class="search-input"
                    placeholder="Kullanıcı / Site username ara..."
                    value="<?= htmlspecialchars($search) ?>"
                >
            </div>

            <select name="site_id" class="filter-select">
                <option value="">Tüm Siteler</option>
                <?php foreach ($sites as $s): ?>
                    <option value="<?= $s['id'] ?>" <?= ($siteFilter == $s['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($s['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button class="btn btn-primary btn-pill" type="submit">
                <i class="ri-filter-2-line"></i> Filtrele
            </button>

            <a href="user_sites.php" class="btn btn-secondary btn-pill">
                <i class="ri-refresh-line"></i> Sıfırla
            </a>

            <button
                type="button"
                class="btn btn-success btn-pill"
                onclick="document.getElementById('modal-add').style.display='flex';"
            >
                <i class="ri-add-line"></i> Yeni Bağlantı
            </button>
        </form>
    </div>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger">
            <i class="ri-error-warning-fill"></i>
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['ok'])): ?>
        <div class="alert alert-success">
            <i class="ri-checkbox-circle-fill"></i>
            İşlem başarılı: <?= htmlspecialchars($_GET['ok']) ?>
        </div>
    <?php endif; ?>

    <div class="table-container">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Kullanıcı</th>
                    <th>Site</th>
                    <th>Site Username</th>
                    <th>Site Bakiye (TRY)</th>
                    <th>Bağlantı Tarihi</th>
                    <th style="text-align:right;">Aksiyon</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$links): ?>
                    <tr>
                        <td colspan="7" style="text-align:center; padding:32px; color:var(--text-muted);">
                            <i class="ri-filter-off-line" style="font-size:32px; display:block; margin-bottom:6px; opacity:.5;"></i>
                            Kayıt bulunamadı.
                        </td>
                    </tr>
                <?php else: foreach ($links as $row): ?>
                    <tr>
                        <td>
                            <span style="font-family:monospace; color:var(--text-muted);">
                                #<?= (int)$row['id'] ?>
                            </span>
                        </td>

                        <td>
                            <div class="user-label">
                                <?= htmlspecialchars($row['username']) ?>
                            </div>
                            <div class="user-sub">
                                UID: <?= (int)$row['user_id'] ?>
                            </div>
                        </td>

                        <td>
                            <div class="site-label">
                                <?= htmlspecialchars($row['site_name']) ?>
                            </div>
                            <div class="site-sub">
                                Site ID: <?= (int)$row['site_id'] ?>
                            </div>
                        </td>

                        <td>
                            <span class="badge-site">
                                <i class="ri-at-line"></i>
                                <?= htmlspecialchars($row['site_username']) ?>
                            </span>
                        </td>

                        <td>
                            <form method="post" style="display:flex; gap:6px; align-items:center;">
                                <?php if (function_exists('csrf_field')) echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
                                <input
                                    type="number"
                                    step="0.01"
                                    name="site_balance_try"
                                    value="<?= htmlspecialchars($row['site_balance_try']) ?>"
                                    class="admin-input-inline"
                                >
                                <button
                                    type="submit"
                                    name="update_balance"
                                    class="btn-xs btn-warning"
                                >
                                    Güncelle
                                </button>
                            </form>
                        </td>

                        <td style="font-size:12px; color:var(--text-muted);">
                            <?= htmlspecialchars($row['linked_at']) ?>
                        </td>

                        <td style="text-align:right;">
                            <form method="post" style="display:inline-block;">
                                <?php if (function_exists('csrf_field')) echo csrf_field(); ?>
                                <input type="hidden" name="delete_id" value="<?= (int)$row['id'] ?>">
                                <button
                                    type="submit"
                                    class="btn-xs btn-danger"
                                    onclick="return confirm('Bu bağlantıyı silmek istediğinize emin misiniz?');"
                                >
                                    <i class="ri-delete-bin-line"></i> Sil
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>

    <?php if ($totalPages > 1): ?>
        <div class="admin-pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a
                    href="?page=<?= $i ?>&q=<?= urlencode($search) ?>&site_id=<?= urlencode($siteFilter) ?>"
                    class="page-link <?= $page == $i ? 'is-active' : '' ?>"
                >
                    <?= $i ?>
                </a>
            <?php endfor; ?>
        </div>
    <?php endif; ?>

</div>

<!-- Yeni Bağlantı Modal -->
<div class="admin-modal-backdrop" id="modal-add">
    <div class="admin-modal">
        <button class="admin-modal-close" onclick="document.getElementById('modal-add').style.display='none';">
            &times;
        </button>

        <div class="admin-modal-header">
            <h2>Yeni Site Bağlantısı</h2>
            <p>Kullanıcıyı bir merchant site üzerindeki hesabıyla eşle.</p>
        </div>

        <form method="post" class="admin-modal-body">
            <?php if (function_exists('csrf_field')) echo csrf_field(); ?>
            <input type="hidden" name="add_link" value="1">

            <div>
                <div class="admin-field-label">Kullanıcı (User ID)</div>
                <input
                    type="number"
                    name="user_id"
                    placeholder="Örn: 1024"
                    class="admin-input"
                    required
                >
            </div>

            <div>
                <div class="admin-field-label">Site</div>
                <select name="site_id" class="admin-select" required>
                    <option value="">Site seçin...</option>
                    <?php foreach ($sites as $s): ?>
                        <option value="<?= (int)$s['id'] ?>">
                            <?= htmlspecialchars($s['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <div class="admin-field-label">Site Username</div>
                <input
                    type="text"
                    name="site_username"
                    placeholder="Sitedeki kullanıcı adı"
                    class="admin-input"
                    required
                >
            </div>

            <button type="submit" class="btn btn-primary" style="margin-top:6px; width:100%;">
                <i class="ri-link-m"></i>
                Bağlantıyı Kaydet
            </button>
        </form>
    </div>
</div>

<script>
    // Modal backdrop click ile kapatma
    const modalAdd = document.getElementById('modal-add');
    modalAdd.addEventListener('click', function(e) {
        if (e.target === this) {
            this.style.display = 'none';
        }
    });
</script>

<?php include __DIR__ . '/_admin_footer.php'; ?>
