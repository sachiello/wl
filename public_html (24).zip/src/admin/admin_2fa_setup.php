<?php
session_start();
require __DIR__ . '/../../config/config.php';

// ADMIN LOGIN CHECK
if (empty($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$activeNav  = '2fa';
$pageTitle  = "2FA Ayarları";
$adminId    = $_SESSION['admin_id'];
$error      = null;
$success    = null;

// --- GOOGLE AUTH LOADER ---
require __DIR__ . '/../../lib/GoogleAuthenticator.php';

$ga = new GoogleAuthenticator();

// --- ADMIN DATA ---
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$adminId]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

$currentAdmin = $admin;

// =======================================
// 2FA AKTİF DEĞİLSE SECRET + QR OLUŞTUR
// =======================================
if (empty($admin['twofa_enabled'])) {
    $secret = $ga->createSecret();
    $qrUrl  = $ga->getQRCodeGoogleUrl("BetWallet-Admin", $secret);
}

// =======================================
// 2FA AKTİF ET
// =======================================
if (isset($_POST['enable_2fa'])) {

    if (!csrf_validate_request()) {
        $error = "Oturum doğrulaması başarısız!";
    } else {
        $secret = $_POST['secret'];
        $code   = trim($_POST['code']);

        if ($ga->verifyCode($secret, $code, 1)) {

            $stmt = $pdo->prepare("UPDATE admins SET twofa_secret=?, twofa_enabled=1 WHERE id=?");
            $stmt->execute([$secret, $adminId]);

            $success = "2FA başarıyla etkinleştirildi.";
            $admin['twofa_enabled'] = 1;
            $admin['twofa_secret']  = $secret;

        } else {
            $error = "Kod yanlış!";
        }
    }
}

// =======================================
// 2FA KAPAT
// =======================================
if (isset($_POST['disable_2fa'])) {

    if (!csrf_validate_request()) {
        $error = "Oturum doğrulaması başarısız!";
    } else {

        $stmt = $pdo->prepare("UPDATE admins SET twofa_secret=NULL, twofa_enabled=0 WHERE id=?");
        $stmt->execute([$adminId]);

        $success = "2FA kapatıldı.";
        $admin['twofa_enabled'] = 0;
    }
}

// =======================================
// HEADER
// =======================================
require __DIR__ . '/_admin_header.php';
?>

<style>
/* ============================
   ADMIN 2FA – RED THEME STYLING
   ============================ */

/* Sayfa gövdesi */
.admin-page {
    padding: 24px;
    max-width: 960px;
    margin: 0 auto;
}

/* Kart */
.settings-card {
    max-width: 520px;
    background: var(--bg-card, #ffffff);
    margin: 0 auto;
    padding: 24px 22px 22px;
    border-radius: 18px;
    border: 1px solid var(--border-color, #e5e7eb);
    box-shadow: 0 18px 45px rgba(0,0,0,0.16);
}

/* Başlık */
.settings-card h2 {
    margin: 0 0 6px 0;
    font-size: 18px;
    font-weight: 700;
    color: var(--primary, #c2273f);
}
.settings-card p {
    font-size: 13px;
    color: var(--text-muted, #6b7280);
}

/* Alert kutuları */
.alert {
    padding: 10px 12px;
    border-radius: 10px;
    margin-bottom: 12px;
    font-size: 13px;
    display: flex;
    align-items: center;
    gap: 6px;
    border: 1px solid transparent;
}
.alert.error {
    background: rgba(220,38,38,0.06);
    color: #b91c1c;
    border-color: #fecaca;
}
.alert.success {
    background: rgba(16,185,129,0.06);
    color: #166534;
    border-color: #bbf7d0;
}

/* QR */
.qr-img {
    margin: 20px auto 10px auto;
    display: block;
    border-radius: 12px;
    padding: 6px;
    background: #0f172a;
}

/* Secret box */
.secret-box {
    background: #f9fafb;
    padding: 10px 12px;
    border-radius: 10px;
    font-weight: 700;
    text-align: center;
    letter-spacing: 2px;
    font-family: monospace;
    border: 1px dashed #e5e7eb;
    color: #111827;
    margin-bottom: 10px;
}

/* Input (BetWallet style) */
.bw-input {
    width: 100%;
    padding: 10px 12px;
    border-radius: 10px;
    border: 1px solid #e5e7eb;
    font-size: 16px;
    text-align: center;
    letter-spacing: 4px;
    font-weight: 700;
    margin-top: 10px;
    box-sizing: border-box;
}
.bw-input:focus {
    border-color: var(--primary, #c2273f);
    outline: none;
    box-shadow: 0 0 0 1px rgba(194,39,63,0.25);
}

/* Butonlar */
.bw-btn {
    border-radius: 999px;
    border: none;
    padding: 10px 18px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    transition: background-color 0.15s, transform 0.08s, box-shadow 0.15s;
}
.bw-btn-primary {
    background: var(--primary, #c2273f);
    color: #ffffff;
    box-shadow: 0 10px 30px rgba(194,39,63,0.35);
}
.bw-btn-primary:hover {
    background: var(--primary-dark, #9f1239);
    transform: translateY(-1px);
}
.bw-btn-danger {
    background: #b91c1c;
    color: #ffffff;
    box-shadow: 0 10px 30px rgba(185,28,28,0.35);
}
.bw-btn-danger:hover {
    background: #7f1d1d;
    transform: translateY(-1px);
}

/* Form spacing */
.settings-card form {
    margin-top: 12px;
}
</style>

<div class="admin-page">
    <div class="settings-card">

        <h2>2FA Güvenlik Ayarları</h2>
        <p>Admin paneli girişini daha güvenli hale getirmek için Google Authenticator ile 2FA kullanın.</p>

        <?php if ($error): ?>
            <div class="alert error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <?php if (empty($admin['twofa_enabled'])): ?>

            <p style="margin-top:15px; font-size:13px;">
                <b>Google Authenticator</b> veya uyumlu bir uygulama ile aşağıdaki QR kodunu tarayın.
            </p>

            <img src="<?= htmlspecialchars($qrUrl) ?>" width="200" height="200" class="qr-img" alt="2FA QR Code">

            <p style="font-size:13px; margin-top:10px;">Manuel secret kod (gerekirse elle girin):</p>
            <div class="secret-box"><?= htmlspecialchars($secret) ?></div>

            <form method="post">
                <?= csrf_field(); ?>
                <input type="hidden" name="secret" value="<?= htmlspecialchars($secret) ?>">

                <input type="text"
                       name="code"
                       maxlength="6"
                       class="bw-input"
                       placeholder="6 HANELİ KOD"
                       required
                       autocomplete="one-time-code">

                <button class="bw-btn bw-btn-primary" name="enable_2fa" style="margin-top:15px; width:100%;">
                    2FA’yı Etkinleştir
                </button>
            </form>

        <?php else: ?>

            <p style="margin-top:15px; font-size:13px;">
                <b>2FA şu anda aktif.</b> Admin paneline girişte Google Authenticator kodu zorunludur.
            </p>

            <form method="post">
                <?= csrf_field(); ?>
                <button class="bw-btn bw-btn-danger" name="disable_2fa" style="margin-top:18px; width:100%;"
                        onclick="return confirm('2FA korumasını kapatmak istediğinize emin misiniz?');">
                    2FA’yı Kapat
                </button>
            </form>

        <?php endif; ?>

    </div>
</div>

<?php require __DIR__ . '/_admin_footer.php'; ?>
