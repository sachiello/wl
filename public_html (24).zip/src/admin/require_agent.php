<?php
session_start();
require __DIR__ . '/../../config/config.php';

$agentAuthReady = bw_table_has_column($pdo, 'deposit_agents', 'password_hash') &&
                  bw_table_has_column($pdo, 'deposit_agents', 'email');

if (!$agentAuthReady) {
    die('Agent girişi için deposit_agents tablosuna email (VARCHAR) ve password_hash (VARCHAR) kolonu eklenmeli.');
}

if (!isset($_SESSION['agent_id'])) {
    header('Location: agent_login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM deposit_agents WHERE id = ? LIMIT 1");
$stmt->execute([$_SESSION['agent_id']]);
$currentAgent = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$currentAgent || !$currentAgent['is_active']) {
    session_destroy();
    header('Location: agent_login.php');
    exit;
}
