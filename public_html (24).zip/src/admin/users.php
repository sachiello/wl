<?php
// admin/users.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/require_admin.php'; // $pdo, $currentAdmin

$pageTitle = 'Kullanıcı Yönetimi';

// -----------------------
// 1. SIRALAMA (SORTING) MANTIĞI
// -----------------------
$sort  = $_GET['sort'] ?? 'id';
$order = $_GET['order'] ?? 'DESC';

// İzin verilen sıralama sütunları (SQL Injection önlemi)
$allowedSorts = [
    'id', 'username', 'created_at', 
    'trx_balance', 'usdt_balance', 
    'total_deposit_try', 'total_withdraw_try', 'linked_sites'
];

if (!in_array($sort, $allowedSorts)) {
    $sort = 'id';
}
// Order sadece ASC veya DESC olabilir
$order = strtoupper($order) === 'ASC' ? 'ASC' : 'DESC';

// URL oluşturucu fonksiyon (Mevcut filtreleri koruyarak link üretir)
function sortLink($column, $currentSort, $currentOrder, $baseUrlParams) {
    $newOrder = ($currentSort === $column && $currentOrder === 'DESC') ? 'ASC' : 'DESC';
    $icon = '';
    if ($currentSort === $column) {
        $icon = $currentOrder === 'DESC' ? '<i class="ri-arrow-down-s-fill"></i>' : '<i class="ri-arrow-up-s-fill"></i>';
    } else {
        $icon = '<i class="ri-arrow-up-down-line" style="opacity:0.3;"></i>';
    }
    
    // Mevcut parametreleri birleştir
    $params = array_merge($baseUrlParams, ['sort' => $column, 'order' => $newOrder]);
    $queryString = http_build_query($params);
    
    return '<a href="?' . $queryString . '" class="sort-link">' . $icon . '</a>';
}

// -----------------------
// 2. FİLTRELER & SAYFALAMA
// -----------------------
$search = trim($_GET['q'] ?? '');
$status = $_GET['status'] ?? 'all';
$page   = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = 50;
$offset  = ($page - 1) * $perPage;

// URL Parametre Dizisi (Linklerde kullanmak için)
$urlParams = [
    'q'      => $search,
    'status' => $status,
    'page'   => $page
];

// -----------------------
// 3. BAN / UNBAN İŞLEMİ
// -----------------------
if (isset($_GET['ban']) || isset($_GET['unban'])) {
    $targetId = (int)($_GET['ban'] ?? $_GET['unban']);
    if ($targetId > 0) {
        $newStatus = isset($_GET['ban']) ? 1 : 0;
        
        $stmt = $pdo->prepare("UPDATE users SET is_banned = :banned WHERE id = :id");
        $stmt->execute([':banned' => $newStatus, ':id' => $targetId]);

        // Loglama
        $action = $newStatus ? 'ban' : 'unban';
        $meta   = json_encode(['user_id' => $targetId]);
        $logStmt = $pdo->prepare("INSERT INTO activity_logs (actor_type, actor_id, scope, action, meta_json, created_at) VALUES ('admin', :admin_id, 'user', :action, :meta_json, NOW())");
        $logStmt->execute([':admin_id' => $currentAdmin['id'] ?? 0, ':action' => $action, ':meta_json' => $meta]);

        // Redirect (Temiz URL ile)
        $redirParams = $urlParams;
        unset($redirParams['ban'], $redirParams['unban']);
        $redirParams['ok'] = $newStatus ? 'banned' : 'unbanned';
        // Sort ayarlarını koru
        $redirParams['sort'] = $sort;
        $redirParams['order'] = $order;
        
        header('Location: users.php?' . http_build_query($redirParams));
        exit;
    }
}

// -----------------------
// 4. VERİ ÇEKME
// -----------------------

// İstatistikler
$totalUsers   = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$bannedUsers  = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE is_banned = 1")->fetchColumn();
$walletStmt   = $pdo->query("SELECT coin_type, SUM(balance) as bal FROM wallets GROUP BY coin_type");
$walletTotals = $walletStmt->fetchAll(PDO::FETCH_KEY_PAIR); // [TRX => 100, USDT => 500]

// Liste Sorgusu Hazırlığı
$where  = [];
$sqlParams = [];

if ($search !== '') {
    $where[] = '(u.username LIKE :q OR u.trc20_address LIKE :q)';
    $sqlParams[':q'] = '%' . $search . '%';
}
if ($status === 'active') $where[] = 'u.is_banned = 0';
if ($status === 'banned') $where[] = 'u.is_banned = 1';

$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

// Toplam Kayıt
$countStmt = $pdo->prepare("SELECT COUNT(*) FROM users u {$whereSql}");
$countStmt->execute($sqlParams);
$totalRecords = (int)$countStmt->fetchColumn();
$totalPages   = max(1, (int)ceil($totalRecords / $perPage));

// Ana Sorgu
$sql = "
    SELECT 
        u.id,
        u.username,
        u.trc20_address,
        u.created_at,
        u.is_banned,
        COALESCE(w_trx.balance, 0)  AS trx_balance,
        COALESCE(w_usdt.balance, 0) AS usdt_balance,
        COALESCE(d.total_deposit, 0)    AS total_deposit_try,
        COALESCE(wd.total_withdraw, 0)  AS total_withdraw_try,
        COALESCE(sites.linked_sites, 0) AS linked_sites
    FROM users u
    LEFT JOIN wallets w_trx  ON w_trx.user_id = u.id AND w_trx.coin_type = 'TRX'
    LEFT JOIN wallets w_usdt ON w_usdt.user_id = u.id AND w_usdt.coin_type = 'USDT'
    LEFT JOIN (
        SELECT user_id, SUM(amount_try) AS total_deposit FROM deposit_orders WHERE status = 'confirmed' GROUP BY user_id
    ) d ON d.user_id = u.id
    LEFT JOIN (
        SELECT user_id, SUM(amount) AS total_withdraw FROM withdraw_requests WHERE status = 'approved' GROUP BY user_id
    ) wd ON wd.user_id = u.id
    LEFT JOIN (
        SELECT user_id, COUNT(*) AS linked_sites FROM user_sites GROUP BY user_id
    ) sites ON sites.user_id = u.id
    {$whereSql}
    ORDER BY {$sort} {$order}
    LIMIT {$perPage} OFFSET {$offset}
";

$stmt = $pdo->prepare($sql);
$stmt->execute($sqlParams);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

$ok = $_GET['ok'] ?? null;
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        :root { --primary: #c2273f; --primary-light: #fff1f2; --bg-body: #f1f5f9; --bg-card: #ffffff; --text-main: #1f2937; --text-muted: #6b7280; --border-color: #e5e7eb; --radius-md: 8px; }
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; }
        
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        .main-content { flex: 1; padding: 30px; overflow-y: auto; }
        
        .topbar { margin-bottom: 25px; }
        .topbar h1 { font-size: 24px; font-weight: 800; margin: 0; color: var(--text-main); }
        
        /* KPI GRID */
        .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin-bottom: 30px; }
        .kpi-card { background: var(--bg-card); border-radius: 12px; border: 1px solid var(--border-color); padding: 20px; display: flex; flex-direction: column; box-shadow: 0 2px 4px rgba(0,0,0,0.03); }
        .kpi-label { font-size: 11px; font-weight: 600; color: var(--text-muted); text-transform: uppercase; margin-bottom: 6px; letter-spacing: 0.5px; }
        .kpi-value { font-size: 22px; font-weight: 800; color: var(--text-main); }

        /* ALERT */
        .alert { padding: 15px; border-radius: var(--radius-md); margin-bottom: 20px; display: flex; align-items: center; gap: 10px; font-weight: 500; font-size: 14px; }
        .alert-success { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
        .alert-warning { background: #fff7ed; color: #9a3412; border: 1px solid #fed7aa; }

        /* FILTERS */
        .filter-container { display: flex; flex-wrap: wrap; gap: 15px; align-items: center; margin-bottom: 20px; justify-content: space-between; background: #fff; padding: 15px; border-radius: 12px; border: 1px solid var(--border-color); }
        .filter-btns { display: flex; gap: 5px; }
        .filter-btn { padding: 8px 16px; border-radius: 6px; font-size: 13px; font-weight: 600; text-decoration: none; color: var(--text-muted); background: #f1f5f9; transition: all 0.2s; }
        .filter-btn.active { background: var(--primary); color: #fff; }
        
        .search-box { display: flex; align-items: center; border: 1px solid var(--border-color); border-radius: 6px; padding: 0 10px; width: 100%; max-width: 300px; background: #fff; }
        .search-box input { border: none; outline: none; padding: 10px; width: 100%; font-size: 13px; }
        .search-box button { background: none; border: none; cursor: pointer; color: var(--text-muted); }

        /* TABLE */
        .table-card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .table-responsive { overflow-x: auto; }
        .custom-table { width: 100%; border-collapse: collapse; min-width: 1000px; /* Tablo sıkışmasın */ }
        .custom-table th { text-align: left; padding: 14px 20px; font-size: 12px; font-weight: 600; text-transform: uppercase; color: var(--text-muted); border-bottom: 1px solid var(--border-color); background: #f8fafc; white-space: nowrap; }
        .custom-table td { padding: 14px 20px; border-bottom: 1px solid var(--border-color); font-size: 13px; color: var(--text-main); vertical-align: middle; white-space: nowrap; }
        .custom-table tr:hover td { background-color: #f8fafc; }
        .custom-table tr.row-banned td { background-color: #fef2f2; color: #991b1b; }
        
        /* Sort Links */
        .sort-link { display: inline-block; margin-left: 5px; color: var(--text-muted); text-decoration: none; vertical-align: middle; }
        .sort-link:hover { color: var(--primary); }

        /* Address Truncate */
        .addr-text { display: inline-block; max-width: 120px; overflow: hidden; text-overflow: ellipsis; vertical-align: bottom; font-family: monospace; }

        /* Buttons */
        .btn-xs { padding: 4px 8px; font-size: 11px; border-radius: 4px; text-decoration: none; font-weight: 600; display: inline-flex; align-items: center; gap: 4px; border: 1px solid transparent; transition: opacity 0.2s; cursor: pointer; }
        .btn-info { background: #e0f2fe; color: #0369a1; border-color: #bae6fd; }
        .btn-danger { background: #fee2e2; color: #991b1b; border-color: #fecaca; }
        .btn-success { background: #dcfce7; color: #166534; border-color: #bbf7d0; }
        .btn-xs:hover { opacity: 0.85; }

        /* PAGINATION */
        .pagination { display: flex; justify-content: center; gap: 5px; margin-top: 20px; padding-bottom: 20px; }
        .page-link { padding: 8px 12px; border: 1px solid var(--border-color); border-radius: 6px; background: #fff; color: var(--text-muted); text-decoration: none; font-size: 13px; font-weight: 600; }
        .page-link.active { background: var(--primary); color: #fff; border-color: var(--primary); }

        /* MODAL */
        .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 2000; display: none; align-items: center; justify-content: center; backdrop-filter: blur(3px); }
        .modal-content { background: #fff; width: 95%; max-width: 650px; border-radius: 12px; max-height: 90vh; display: flex; flex-direction: column; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25); overflow: hidden; }
        .modal-header { padding: 15px 20px; border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center; background: #f8fafc; }
        .modal-header h3 { margin: 0; font-size: 16px; font-weight: 700; color: var(--text-main); }
        .modal-close { background: none; border: none; font-size: 24px; color: var(--text-muted); cursor: pointer; line-height: 1; }
        .modal-body { padding: 20px; overflow-y: auto; word-wrap: break-word; }
    </style>
</head>
<body>

<div class="app-wrapper">
    
    <?php include __DIR__ . '/_admin_header.php'; ?>

    <div class="main-content">
        
        <div class="topbar">
            <h1>Kullanıcı Yönetimi</h1>
        </div>

        <?php if ($ok === 'banned'): ?>
            <div class="alert alert-warning"><i class="ri-alarm-warning-line"></i> Kullanıcı erişime kapatıldı (Banlandı).</div>
        <?php elseif ($ok === 'unbanned'): ?>
            <div class="alert alert-success"><i class="ri-checkbox-circle-line"></i> Kullanıcının erişim yasağı kaldırıldı.</div>
        <?php endif; ?>

        <div class="kpi-grid">
            <div class="kpi-card">
                <div class="kpi-label">Toplam Kullanıcı</div>
                <div class="kpi-value"><?= number_format($totalUsers) ?></div>
            </div>
            <div class="kpi-card">
                <div class="kpi-label">Aktif</div>
                <div class="kpi-value" style="color:#16a34a;"><?= number_format($totalUsers - $bannedUsers) ?></div>
            </div>
            <div class="kpi-card">
                <div class="kpi-label">Banlı</div>
                <div class="kpi-value" style="color:#dc2626;"><?= number_format($bannedUsers) ?></div>
            </div>
            <div class="kpi-card">
                <div class="kpi-label">Toplam TRX</div>
                <div class="kpi-value"><?= number_format($walletTotals['TRX'] ?? 0, 0) ?></div>
            </div>
            <div class="kpi-card">
                <div class="kpi-label">Toplam USDT</div>
                <div class="kpi-value" style="color:#2563eb;"><?= number_format($walletTotals['USDT'] ?? 0, 0) ?></div>
            </div>
        </div>

        <div class="filter-container">
            <div class="filter-btns">
                <a href="?status=all&q=<?= urlencode($search) ?>" class="filter-btn <?= $status==='all'?'active':'' ?>">Tümü</a>
                <a href="?status=active&q=<?= urlencode($search) ?>" class="filter-btn <?= $status==='active'?'active':'' ?>">Aktif</a>
                <a href="?status=banned&q=<?= urlencode($search) ?>" class="filter-btn <?= $status==='banned'?'active':'' ?>">Banlı</a>
            </div>
            
            <form method="get" class="search-box">
                <input type="hidden" name="status" value="<?= htmlspecialchars($status) ?>">
                <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Kullanıcı adı veya cüzdan ara...">
                <button type="submit"><i class="ri-search-line"></i></button>
            </form>
        </div>

        <div class="table-card">
            <div class="table-responsive">
                <table class="custom-table">
                    <thead>
                        <tr>
                            <th>ID <?= sortLink('id', $sort, $order, ['q'=>$search, 'status'=>$status, 'page'=>$page]) ?></th>
                            <th>Kullanıcı <?= sortLink('username', $sort, $order, ['q'=>$search, 'status'=>$status, 'page'=>$page]) ?></th>
                            <th>Cüzdan</th>
                            <th>Yatırım <?= sortLink('total_deposit_try', $sort, $order, ['q'=>$search, 'status'=>$status, 'page'=>$page]) ?></th>
                            <th>Çekim <?= sortLink('total_withdraw_try', $sort, $order, ['q'=>$search, 'status'=>$status, 'page'=>$page]) ?></th>
                            <th>Site <?= sortLink('linked_sites', $sort, $order, ['q'=>$search, 'status'=>$status, 'page'=>$page]) ?></th>
                            <th>Kayıt <?= sortLink('created_at', $sort, $order, ['q'=>$search, 'status'=>$status, 'page'=>$page]) ?></th>
                            <th style="text-align:right;">İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$users): ?>
                            <tr><td colspan="8" style="text-align:center; padding:30px; color:var(--text-muted);">Kayıt bulunamadı.</td></tr>
                        <?php else: ?>
                            <?php foreach ($users as $u): ?>
                                <tr class="<?= $u['is_banned'] ? 'row-banned' : '' ?>">
                                    <td>#<?= $u['id'] ?></td>
                                    <td>
                                        <div style="font-weight:600;"><?= htmlspecialchars($u['username']) ?></div>
                                        <div style="font-size:11px; color:var(--text-muted);" title="<?= htmlspecialchars($u['trc20_address']) ?>">
                                            <span class="addr-text"><?= htmlspecialchars($u['trc20_address']) ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <div style="font-size:12px;">TRX: <b><?= number_format($u['trx_balance'], 2) ?></b></div>
                                        <div style="font-size:12px; color:#2563eb;">USDT: <b><?= number_format($u['usdt_balance'], 2) ?></b></div>
                                    </td>
                                    <td><?= number_format($u['total_deposit_try'], 2) ?> ₺</td>
                                    <td><?= number_format($u['total_withdraw_try'], 2) ?></td>
                                    <td><span style="background:#f1f5f9; padding:2px 6px; border-radius:4px; font-size:11px;"><?= $u['linked_sites'] ?></span></td>
                                    <td style="font-size:12px; color:var(--text-muted);"><?= date('d.m.y H:i', strtotime($u['created_at'])) ?></td>
                                    <td style="text-align:right;">
                                        <a href="user_detail.php?id=<?= $u['id'] ?>&popup=1" class="btn-xs btn-info js-user-detail">
                                            <i class="ri-eye-line"></i> Detay
                                        </a>
                                        <?php if ($u['is_banned']): ?>
                                            <a href="users.php?unban=<?= $u['id'] ?>&<?= http_build_query(['page'=>$page,'q'=>$search,'status'=>$status,'sort'=>$sort,'order'=>$order]) ?>" 
                                               class="btn-xs btn-success" onclick="return confirm('Yasağı kaldır?')">
                                               <i class="ri-lock-unlock-line"></i> Aç
                                            </a>
                                        <?php else: ?>
                                            <a href="users.php?ban=<?= $u['id'] ?>&<?= http_build_query(['page'=>$page,'q'=>$search,'status'=>$status,'sort'=>$sort,'order'=>$order]) ?>" 
                                               class="btn-xs btn-danger" onclick="return confirm('Kullanıcıyı yasakla?')">
                                               <i class="ri-prohibited-line"></i> Ban
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php if ($totalPages > 1): ?>
            <div class="pagination">
                <?php
                $baseQuery = ['q'=>$search, 'status'=>$status, 'sort'=>$sort, 'order'=>$order];
                
                if ($page > 1) {
                    echo '<a href="?'.http_build_query(array_merge($baseQuery, ['page'=>$page-1])).'" class="page-link"><i class="ri-arrow-left-s-line"></i></a>';
                }
                
                $start = max(1, $page - 2);
                $end   = min($totalPages, $page + 2);
                
                for ($p = $start; $p <= $end; $p++) {
                    $active = ($p === $page) ? 'active' : '';
                    echo '<a href="?'.http_build_query(array_merge($baseQuery, ['page'=>$p])).'" class="page-link '.$active.'">'.$p.'</a>';
                }
                
                if ($page < $totalPages) {
                    echo '<a href="?'.http_build_query(array_merge($baseQuery, ['page'=>$page+1])).'" class="page-link"><i class="ri-arrow-right-s-line"></i></a>';
                }
                ?>
            </div>
        <?php endif; ?>

    </div>
</div>

<div id="detailModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Kullanıcı Detayı</h3>
            <button class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <div class="modal-body" id="modalBody">
            <div style="text-align:center; padding:40px; color:#64748b;">Veriler yükleniyor...</div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById('detailModal');
    const modalBody = document.getElementById('modalBody');

    // Detay butonuna tıklama
    document.body.addEventListener('click', function (e) {
        const btn = e.target.closest('.js-user-detail');
        if (!btn) return;
        e.preventDefault();
        const url = btn.getAttribute('href');

        modalBody.innerHTML = '<div style="text-align:center; padding:40px; color:#64748b;"><i class="ri-loader-4-line" style="animation:spin 1s infinite; font-size:24px;"></i><br>Yükleniyor...</div>';
        modal.style.display = 'flex';

        fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(res => res.text())
            .then(html => { modalBody.innerHTML = html; })
            .catch(err => { modalBody.innerHTML = '<div style="padding:20px; color:red; text-align:center;">Hata: ' + err + '</div>'; });
    });
});

function closeModal() {
    document.getElementById('detailModal').style.display = 'none';
}

window.onclick = function(event) {
    const modal = document.getElementById('detailModal');
    if (event.target == modal) closeModal();
}
</script>
<style>@keyframes spin { 100% { transform: rotate(360deg); } }</style>

<?php include __DIR__ . '/_admin_footer.php'; ?>
</body>
</html>