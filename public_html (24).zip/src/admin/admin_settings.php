<?php
require __DIR__ . '/require_admin.php';
$pageTitle = 'Genel Ayarlar & Duyurular';

$success = null;
$error   = null;
$settingsMsg = null;
$settingsErr = null;

// === Basit HTTP JSON Helper ===
if (!function_exists('http_get_json')) {
    function http_get_json(string $url): string {
        if (function_exists('curl_init')) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            $data = curl_exec($ch);
            curl_close($ch);
            return $data ?: '[]';
        } elseif (ini_get('allow_url_fopen')) {
            return file_get_contents($url) ?: '[]';
        }
        throw new Exception("API çağrısı için gerekli fonksiyonlar mevcut değil.");
    }
}

// =============== POST: KUR GÜNCELLEME ===============
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_usdt_rate'])) {

    if (!function_exists('csrf_validate_request') || !csrf_validate_request()) {
        $settingsErr = "Güvenlik hatası. Lütfen sayfayı yenileyip tekrar deneyin.";
    } else {
        try {
            $url  = 'https://api.coingecko.com/api/v3/simple/price?ids=tether&vs_currencies=try';
            $json = http_get_json($url);
            $data = json_decode($json, true);

            if (!is_array($data) || empty($data['tether']['try'])) {
                throw new Exception("CoinGecko USDT/TRY verisi alınamadı.");
            }

            $newRate = (float)$data['tether']['try'];
            if ($newRate <= 0) {
                throw new Exception("Geçersiz kur değeri döndü: " . $newRate);
            }

            // settings tablosuna yaz
            $stmt = $pdo->prepare("
                INSERT INTO settings (setting_key, setting_value)
                VALUES ('usdt_try_rate', ?)
                ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
            ");
            $stmt->execute([number_format($newRate, 6, '.', '')]);

            $settingsMsg = "USDT kuru güncellendi: 1 USDT = " . number_format($newRate, 2, ',', '.') . " ₺";
        } catch (Exception $e) {
            $settingsErr = "Kur güncellenemedi: " . $e->getMessage();
        }
    }
}

// =============== POST: DUYURU KAYDI ===============
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_announcement'])) {

    if (!function_exists('csrf_validate_request') || !csrf_validate_request()) {
        $error = "Güvenlik hatası. Lütfen sayfayı yenileyip tekrar deneyin.";
    } else {
        $text   = trim($_POST['announcement_text'] ?? '');
        $active = isset($_POST['announcement_active']) ? '1' : '0';

        try {
            $stmt = $pdo->prepare("
                INSERT INTO settings (setting_key, setting_value)
                VALUES ('site_announcement', ?)
                ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
            ");
            $stmt->execute([$text]);

            $stmt2 = $pdo->prepare("
                INSERT INTO settings (setting_key, setting_value)
                VALUES ('site_announcement_active', ?)
                ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
            ");
            $stmt2->execute([$active]);

            $success = "Duyuru ayarları başarıyla güncellendi.";
        } catch (Exception $e) {
            $error = "Hata: " . $e->getMessage();
        }
    }
}

// =============== MEVCUT AYARLAR ===============
$settings = $pdo->query("SELECT setting_key, setting_value FROM settings")->fetchAll(PDO::FETCH_KEY_PAIR);

$annText   = $settings['site_announcement']        ?? '';
$annActive = $settings['site_announcement_active'] ?? '0';
$currentRate = isset($settings['usdt_try_rate']) ? (float)$settings['usdt_try_rate'] : 0.0;

include __DIR__ . '/_admin_header.php';
?>

<style>
/* === GLOBAL RED THEME (BETWALLET ADMIN UI) === */
:root {
    --primary: #c2273f;
    --primary-dark: #9f1239;

    --success: #10b981;
    --danger: #dc2626;
    --warning: #f59e0b;

    --text-main: #1e1e24;
    --text-muted: #6b7280;

    --border-light: #e5e7eb;
    --bg-soft: #fafafa;

    --radius-sm: 6px;
    --radius-lg: 14px;

    --shadow-soft: 0 1px 3px rgba(0,0,0,0.06);
}

/* arkaplan */
.page-content {
    padding: 24px;
    max-width: 1200px;
    margin: 0 auto;
}

/* HEADER */
.admin-page-header {
    margin-bottom: 20px;
}
.admin-page-header h1 {
    margin: 0;
    font-size: 22px;
    font-weight: 700;
    color: var(--primary);
}
.admin-page-header p {
    margin: 4px 0 0;
    color: var(--text-muted);
    font-size: 13px;
}

/* ALERT BOXES */
.alert-box {
    padding: 12px 14px;
    border-radius: var(--radius-sm);
    margin-bottom: 14px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    border: 1px solid transparent;
}
.alert-success {
    background: rgba(16,185,129,0.08);
    color: var(--success);
    border-color: rgba(16,185,129,0.25);
}
.alert-danger {
    background: rgba(220,38,38,0.08);
    color: var(--danger);
    border-color: rgba(220,38,38,0.25);
}

/* CARD */
.form-card {
    background: #ffffff;
    border-radius: var(--radius-lg);
    border: 1px solid var(--border-light);
    box-shadow: var(--shadow-soft);
    padding: 20px;
    margin-bottom: 20px;
}

/* CARD HEADER */
.card-header-row {
    margin-bottom: 16px;
}
.card-header-row h2 {
    margin: 0;
    font-size: 16px;
    display: flex;
    align-items: center;
    gap: 6px;
    color: var(--primary);
}
.card-header-row p {
    font-size: 12px;
    margin: 3px 0 0;
    color: var(--text-muted);
}

/* FORM ELEMENTS */
.form-group {
    margin-bottom: 14px;
}
.form-group label {
    display: block;
    font-size: 12px;
    font-weight: 600;
    margin-bottom: 6px;
    color: var(--text-muted);
}
.form-control-bw {
    width: 100%;
    padding: 10px;
    border-radius: var(--radius-sm);
    border: 1px solid var(--border-light);
    font-size: 14px;
    background: #fff;
}
.form-control-bw:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 1px rgba(194,39,63,0.25);
    outline: none;
}

/* SWITCH */
.switch-row {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
}
.switch-input {
    width: 40px;
    height: 20px;
}

/* BUTTONS */
.btn-main {
    background: var(--primary);
    color: #fff;
    border: none;
    border-radius: var(--radius-sm);
    padding: 10px 18px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}
.btn-main:hover {
    background: var(--primary-dark);
}

.btn-soft {
    background: rgba(194,39,63,0.08);
    color: var(--primary-dark);
    border: 1px solid rgba(194,39,63,0.15);
    border-radius: var(--radius-sm);
    padding: 9px 14px;
    font-size: 13px;
    font-weight: 600;
}
.btn-soft:hover {
    background: rgba(194,39,63,0.12);
}

/* GRID */
.settings-grid {
    display: grid;
    grid-template-columns: 2fr 1.4fr;
    gap: 18px;
}
@media(max-width: 992px){
    .settings-grid {
        grid-template-columns: 1fr;
    }
}

/* RATE BOX */
.rate-box {
    padding: 10px 12px;
    background: var(--bg-soft);
    border-radius: var(--radius-sm);
    border: 1px solid var(--border-light);
    margin-bottom: 10px;
    font-size: 14px;
}

/* small text */
.small-muted {
    font-size: 12px;
    color: var(--text-muted);
}

</style>

<div class="page-content">
    <div class="admin-page-header">
        <h1>Genel Ayarlar & Duyurular</h1>
        <p>Merchant panellerinde görünen duyuru barını ve sistemin USDT/TRY kurunu yönetin.</p>
    </div>

    <?php if ($success): ?>
        <div class="alert-box alert-success">
            <i class="ri-checkbox-circle-fill"></i> <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert-box alert-danger">
            <i class="ri-error-warning-fill"></i> <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <?php if ($settingsMsg): ?>
        <div class="alert-box alert-success">
            <i class="ri-exchange-dollar-line"></i> <?= htmlspecialchars($settingsMsg) ?>
        </div>
    <?php endif; ?>

    <?php if ($settingsErr): ?>
        <div class="alert-box alert-danger">
            <i class="ri-error-warning-fill"></i> <?= htmlspecialchars($settingsErr) ?>
        </div>
    <?php endif; ?>

    <div class="settings-grid">
        <!-- DUYURU KARTI -->
        <div class="form-card">
            <div class="card-header-row">
                <div>
                    <h2><i class="ri-megaphone-line" style="color: var(--primary);"></i> Site Paneli Duyuru Ayarı</h2>
                    <p>Site (merchant) panellerinde en üstte görünen bilgilendirme duyurusunu buradan yönetebilirsiniz.</p>
                </div>
            </div>

            <form method="post">
                <?= csrf_field() ?>

                <div class="form-group">
                    <label for="announcement_text">Duyuru Metni</label>
                    <textarea
                        name="announcement_text"
                        id="announcement_text"
                        class="form-control-bw"
                        rows="3"
                        placeholder="Site panellerinde görünecek duyuruyu buraya yazın..."
                    ><?= htmlspecialchars($annText) ?></textarea>
                    <div class="small-muted" style="margin-top:4px;">
                        Bu metin tüm merchant panellerinde üst kısımda duyuru barı olarak gösterilir.
                    </div>
                </div>

                <div class="form-group">
                    <label>Duyuru Durumu</label>
                    <label class="switch-row">
                        <input type="checkbox"
                               class="switch-input"
                               id="announcement_active"
                               name="announcement_active"
                               value="1"
                            <?= $annActive === '1' ? 'checked' : '' ?>>
                        <span>Duyuru barı aktif / gösterilsin</span>
                    </label>
                </div>

                <div style="margin-top:10px;">
                    <button type="submit" name="save_announcement" class="btn-main">
                        <i class="ri-save-line"></i> Kaydet ve Yayınla
                    </button>
                </div>
            </form>
        </div>

        <!-- KUR AYARLARI KARTI -->
        <div class="form-card">
            <div class="card-header-row">
                <div>
                    <h2><i class="ri-exchange-dollar-line" style="color: var(--success);"></i> Kur Ayarları</h2>
                    <p>BetWallet içinde kullanılan USDT &rarr; TRY çevrim kuru.</p>
                </div>
            </div>

            <div class="rate-box">
                <?php if ($currentRate > 0): ?>
                    Şu anki sistem kuru:
                    <strong>1 USDT = <?= number_format($currentRate, 2, ',', '.') ?> ₺</strong>
                <?php else: ?>
                    Şu an sistemde tanımlı bir USDT kuru bulunmuyor.
                <?php endif; ?>
            </div>

            <div class="small-muted" style="margin-bottom:8px;">
                Kur, kullanıcı cüzdan hareketlerinde ve raporlama ekranlarında referans alınır.
            </div>

            <form method="post" style="margin-top:8px;">
                <?= csrf_field(); ?>
                <button type="submit" name="update_usdt_rate" class="btn-soft">
                    <i class="ri-refresh-line"></i> Kuru CoinGecko'dan Güncelle
                </button>
            </form>
        </div>
    </div>
</div>

<?php include __DIR__ . '/_admin_footer.php'; ?>
