<?php
require __DIR__ . '/require_admin.php';

$pageTitle = 'Site Bakiye Talepleri';
$activeNav = 'site_requests';

$adminSuccess = null;
$adminError = null;

// ONAY / RED
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_validate_request()) {
        $adminError = "Güvenlik hatası.";
    } elseif (isset($_POST['req_id'])) {
        $reqId = (int)$_POST['req_id'];
        $adminId = (int)$currentAdmin['id'];

        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("SELECT * FROM site_balance_requests WHERE id = ? AND status = 'pending' FOR UPDATE");
            $stmt->execute([$reqId]);
            $req = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$req) throw new Exception("Talep bulunamadı.");

            if (isset($_POST['approve'])) {
                $pdo->prepare("
                    UPDATE site_balance_requests 
                    SET status='approved', admin_id=?, processed_at=NOW() 
                    WHERE id=?
                ")->execute([$adminId, $reqId]);

                $pdo->prepare("
                    UPDATE sites 
                    SET balance = balance + ?, net_balance = net_balance + ? 
                    WHERE id=?
                ")->execute([$req['amount'], $req['amount'], $req['site_id']]);

                $adminSuccess = "Talep ONAYLANDI. Site bakiyesine " . number_format($req['amount'], 2) . " TL eklendi.";
            }
            elseif (isset($_POST['reject'])) {
                $pdo->prepare("
                    UPDATE site_balance_requests 
                    SET status='rejected', admin_id=?, processed_at=NOW() 
                    WHERE id=?
                ")->execute([$adminId, $reqId]);

                $adminSuccess = "Talep REDDEDİLDİ.";
            }

            $pdo->commit();
        } catch (Exception $e) {
            $pdo->rollBack();
            $adminError = "Hata: " . $e->getMessage();
        }
    }
}

// LİSTELEME
$rows = $pdo->query("
    SELECT r.*, s.name as site_name 
    FROM site_balance_requests r 
    JOIN sites s ON s.id = r.site_id 
    WHERE r.status='pending'
    ORDER BY r.created_at ASC
")->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/_admin_header.php';
?>

<div class="admin-page">

    <!-- BAŞLIK -->
    <div class="admin-page-header">
        <h1>Site Bakiye Talepleri</h1>
        <p>Sitelere gönderilen bakiye taleplerinin yönetimi.</p>
    </div>

    <!-- ALERTLER -->
    <?php if ($adminSuccess): ?>
        <div class="alert alert-success"><?= $adminSuccess ?></div>
    <?php endif; ?>

    <?php if ($adminError): ?>
        <div class="alert alert-danger"><?= $adminError ?></div>
    <?php endif; ?>

    <!-- TABLO -->
    <div class="admin-table-wrapper">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Site</th>
                    <th>Tutar</th>
                    <th>Tarih</th>
                    <th>İşlem</th>
                </tr>
            </thead>
            <tbody>

                <?php if (empty($rows)): ?>
                    <tr>
                        <td colspan="5" style="text-align:center; padding:40px; color:#6b7280;">
                            Bekleyen talep yok.
                        </td>
                    </tr>
                <?php endif; ?>

                <?php foreach ($rows as $r): ?>
                <tr>
                    <td>#<?= $r['id'] ?></td>

                    <td>
                        <strong><?= htmlspecialchars($r['site_name']) ?></strong>
                    </td>

                    <td>
                        <span style="color:#16a34a; font-weight:600;">
                            <?= number_format($r['amount'], 2) ?> ₺
                        </span>
                    </td>

                    <td>
                        <?= date('d.m.Y H:i', strtotime($r['created_at'])) ?>
                    </td>

                    <td>
                        <form method="post" style="display:flex; gap:8px;">
                            <?= csrf_field() ?>
                            <input type="hidden" name="req_id" value="<?= $r['id'] ?>">

                            <button name="approve" class="btn btn-success btn-xs"
                                    onclick="return confirm('Onaylıyor musunuz?')">
                                Onayla
                            </button>

                            <button name="reject" class="btn btn-danger btn-xs"
                                    onclick="return confirm('Reddediyor musunuz?')">
                                Reddet
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>

            </tbody>
        </table>
    </div>

</div>

<?php include __DIR__ . '/_admin_footer.php'; ?>
