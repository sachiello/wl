<?php
// admin/site_withdrawals.php
require __DIR__ . '/../../config/config.php';

$pageTitle = 'Site Çekim Talepleri';
$activeNav = 'site_withdrawals';
$error = null;
$success = null;
$csrfFailed = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !csrf_validate_request()) {
    $csrfFailed = true;
    $error = 'Oturum doğrulaması başarısız. Lütfen tekrar deneyin.';
}

// --- TALEP DURUM GÜNCELLEME ---
if (!$csrfFailed && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $withdrawalId = (int)$_POST['withdrawal_id'];
    $newStatus = $_POST['new_status'];

    if (!in_array($newStatus, ['completed', 'rejected'])) {
        $error = 'Geçersiz işlem durumu.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM site_withdrawals WHERE id = ? AND status = 'pending'");
        $stmt->execute([$withdrawalId]);
        $withdrawal = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$withdrawal) {
            $error = 'Talep bulunamadı veya zaten işlem görmüş.';
        } else {
            try {
                $pdo->beginTransaction();

                // Reddedilirse bakiyeyi iade et
                if ($newStatus === 'rejected') {
                    $updateSiteBalance = $pdo->prepare("UPDATE sites SET balance = balance + ? WHERE id = ?");
                    $updateSiteBalance->execute([(float)$withdrawal['amount'], (int)$withdrawal['site_id']]);
                }
                
                // Durumu güncelle
                $updateStmt = $pdo->prepare("UPDATE site_withdrawals SET status = ? WHERE id = ?");
                $updateStmt->execute([$newStatus, $withdrawalId]);
                
                $success = "İşlem başarıyla tamamlandı.";

                // Loglama
                if(function_exists('bw_log_action')) {
                    bw_log_action($pdo, 'withdrawal', 'admin', $_SESSION['admin_id'] ?? 0, $newStatus, [
                        'withdrawal_id' => $withdrawalId,
                        'site_id' => (int)$withdrawal['site_id'],
                        'amount' => (float)$withdrawal['amount']
                    ]);
                }

                $pdo->commit();
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = "Hata: " . $e->getMessage();
            }
        }
    }
}

// --- LİSTELEME ---
$stmt = $pdo->query("
    SELECT sw.*, s.name as site_name, s.logo_url
    FROM site_withdrawals sw
    JOIN sites s ON sw.site_id = s.id
    ORDER BY
        CASE sw.status
            WHEN 'pending' THEN 1
            WHEN 'completed' THEN 2
            WHEN 'rejected' THEN 3
        END,
        sw.id DESC
");
$withdrawals = $stmt->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/_admin_header.php';
?>

<style>
    /* Durum Rozetleri */
    .status-badge { padding: 6px 12px; border-radius: 30px; font-size: 11px; font-weight: 700; text-transform: uppercase; display: inline-flex; align-items: center; gap: 5px; }
    .status-pending { background: #fff7ed; color: #c2410c; border: 1px solid #ffedd5; }
    .status-completed { background: #f0fdf4; color: #15803d; border: 1px solid #bbf7d0; }
    .status-rejected { background: #fef2f2; color: #b91c1c; border: 1px solid #fecaca; }

    /* Adres Alanı */
    .wallet-address-box {
        background: #f8fafc; padding: 6px 10px; border-radius: 6px; border: 1px solid #e2e8f0;
        font-family: monospace; font-size: 12px; color: #334155; display: inline-flex; align-items: center; gap: 8px; max-width: 220px;
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis; cursor: pointer; transition: all 0.2s;
    }
    .wallet-address-box:hover { background: #fff; border-color: var(--primary); color: var(--primary); }
    .wallet-address-box i { font-size: 14px; color: var(--text-muted); }

    /* Butonlar */
    .action-btn { width: 34px; height: 34px; display: inline-flex; align-items: center; justify-content: center; border-radius: 8px; border: none; cursor: pointer; transition: all 0.2s; }
    .btn-approve { background: #dcfce7; color: #166534; }
    .btn-approve:hover { background: #16a34a; color: #fff; }
    .btn-reject { background: #fee2e2; color: #991b1b; }
    .btn-reject:hover { background: #dc2626; color: #fff; }

    /* Alert */
    .alert-box { padding: 15px; border-radius: var(--radius-sm); margin-bottom: 20px; display: flex; align-items: center; gap: 10px; font-size: 14px; }
    .alert-danger { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
    .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; }
</style>

<div class="page-content">

    <?php if ($error): ?>
        <div class="alert-box alert-danger">
            <i class="ri-error-warning-fill" style="font-size: 18px;"></i>
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert-box alert-success">
            <i class="ri-checkbox-circle-fill" style="font-size: 18px;"></i>
            <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>

    <div class="table-container">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Site Bilgisi</th>
                    <th>Çekilecek Tutar</th>
                    <th>USDT (TRC20) Adresi</th>
                    <th>Durum</th>
                    <th>Talep Tarihi</th>
                    <th style="text-align: right;">İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($withdrawals as $w): 
                    $statusClass = 'pending';
                    $statusLabel = 'Bekliyor';
                    $statusIcon = 'ri-time-line';

                    if($w['status'] == 'completed') { 
                        $statusClass = 'completed'; $statusLabel = 'Tamamlandı'; $statusIcon = 'ri-check-double-line'; 
                    } elseif($w['status'] == 'rejected') { 
                        $statusClass = 'rejected'; $statusLabel = 'Reddedildi'; $statusIcon = 'ri-close-circle-line'; 
                    }
                ?>
                <tr>
                    <td><span style="font-family: monospace; color: var(--text-muted);">#<?= (int)$w['id'] ?></span></td>
                    
                    <td>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <div style="width: 32px; height: 32px; background: #f1f5f9; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight: 700; color: var(--text-muted);">
                                <?= strtoupper(substr($w['site_name'], 0, 1)) ?>
                            </div>
                            <div style="font-weight: 600; color: var(--text-main);"><?= htmlspecialchars($w['site_name']) ?></div>
                        </div>
                    </td>

                    <td>
                        <span style="font-size: 15px; font-weight: 700; color: var(--text-main);">
                            <?= number_format((float)$w['amount'], 2, ',', '.') ?> 
                            <small style="color: var(--text-muted); font-weight: 500;">TL</small>
                        </span>
                    </td>

                    <td>
                        <div class="wallet-address-box" onclick="copyToClipboard('<?= htmlspecialchars($w['wallet_address']) ?>')" title="Kopyalamak için tıkla">
                            <i class="ri-file-copy-line"></i>
                            <?= htmlspecialchars($w['wallet_address']) ?>
                        </div>
                    </td>

                    <td>
                        <span class="status-badge status-<?= $statusClass ?>">
                            <i class="<?= $statusIcon ?>"></i> <?= $statusLabel ?>
                        </span>
                    </td>

                    <td style="font-size: 12px; color: var(--text-muted);">
                        <?= date('d.m.Y H:i', strtotime($w['created_at'])) ?>
                    </td>

                    <td style="text-align: right;">
                        <?php if ($w['status'] === 'pending'): ?>
                            <div style="display: inline-flex; gap: 5px;">
                                <form method="post" style="margin:0;">
                                    <?= csrf_field(); ?>
                                    <input type="hidden" name="update_status" value="1">
                                    <input type="hidden" name="withdrawal_id" value="<?= (int)$w['id'] ?>">
                                    <input type="hidden" name="new_status" value="completed">
                                    <button type="submit" class="action-btn btn-approve" title="Onayla ve Tamamla" onclick="return confirm('Bu ödemeyi gönderdiğinizi onaylıyor musunuz?')">
                                        <i class="ri-check-line"></i>
                                    </button>
                                </form>

                                <form method="post" style="margin:0;">
                                    <?= csrf_field(); ?>
                                    <input type="hidden" name="update_status" value="1">
                                    <input type="hidden" name="withdrawal_id" value="<?= (int)$w['id'] ?>">
                                    <input type="hidden" name="new_status" value="rejected">
                                    <button type="submit" class="action-btn btn-reject" title="Reddet ve İade Et" onclick="return confirm('Reddetmek istediğinize emin misiniz? Tutar sitenin bakiyesine iade edilecektir.');">
                                        <i class="ri-close-line"></i>
                                    </button>
                                </form>
                            </div>
                        <?php else: ?>
                            <i class="ri-checkbox-circle-fill" style="color: #cbd5e1; font-size: 24px;"></i>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>

                <?php if(empty($withdrawals)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px; color: var(--text-muted);">
                            <i class="ri-inbox-archive-line" style="font-size: 48px; display: block; margin-bottom: 10px; opacity: 0.5;"></i>
                            Henüz bir çekim talebi bulunmuyor.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        // Basit bir bildirim (Toast) eklenebilir, şimdilik konsola yazalım
        // alert("Adres kopyalandı: " + text); 
        // Daha şık olması için butonu geçici olarak yeşil yapabiliriz
    }, function(err) {
        console.error('Kopyalama hatası: ', err);
    });
}
</script>

<?php include __DIR__ . '/_admin_footer.php'; ?>
