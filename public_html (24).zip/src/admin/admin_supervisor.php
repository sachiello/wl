<?php
// admin/admin_supervisor.php
require __DIR__ . '/require_admin.php'; // Admin kontrolü
require_once __DIR__ . '/classes/BwIntelligence.php'; // Zekayı dahil et

$brain = new BwIntelligence($pdo);

// Eski usül hesaplama fonksiyonun (Bunu koruyoruz çünkü ekranda detay gösteriyor)
function bw_calculate_supervisor_metrics(PDO $pdo): array {
    // Yardımcı fonksiyon (Tekrar tanımlamamak için buraya alabilirsin veya global bırakabilirsin)
    // Basitlik için burada doğrudan sorgu yazıyorum:
    $getSum = function($sql) use ($pdo) {
        return (float)($pdo->query($sql)->fetchColumn() ?? 0);
    };

    // 1. Hesaplar
    $totalAgentCollateral = $getSum("SELECT SUM(system_balance) FROM deposit_agents WHERE role = 'agent'");
    $totalSiteDepositsCompleted = $getSum("SELECT SUM(amount_try) FROM site_deposit_requests WHERE status = 'completed'");
    $siteWithdrawPaid = $getSum("SELECT SUM(amount) FROM site_withdrawals WHERE status = 'completed'");
    $agentProfitWithdrawPaid = $getSum("SELECT SUM(amount_after_fee) FROM agent_profit_withdraw_requests WHERE status = 'paid'");
    $pendingSiteWithdraw = $getSum("SELECT SUM(amount) FROM site_withdrawals WHERE status = 'pending'");
    $pendingAgentProfitWithdraw = $getSum("SELECT SUM(amount_after_fee) FROM agent_profit_withdraw_requests WHERE status = 'pending'");

    // Info amaçlı
    $totalSiteBalanceInfo = $getSum("SELECT SUM(balance) FROM sites");
    $totalAgentProfitBalance = $getSum("SELECT SUM(agent_profit_balance) FROM deposit_agents");
    $usersTotalWalletUsdt = $getSum("SELECT SUM(balance) FROM wallets WHERE coin_type = 'USDT'");

    // Matematik
    $grossIncomingPool = $totalAgentCollateral + $totalSiteDepositsCompleted;
    $totalPaidOut = $siteWithdrawPaid + $agentProfitWithdrawPaid;
    $bossPoolNow = $grossIncomingPool - $totalPaidOut;
    $shortTermOut = $pendingSiteWithdraw + $pendingAgentProfitWithdraw;
    $netPosition = $bossPoolNow - $shortTermOut;
    $coverageRatio = $shortTermOut > 0 ? ($bossPoolNow / $shortTermOut) : 0;

    return [
        'totalAgentCollateral'       => $totalAgentCollateral,
        'totalSiteDepositsCompleted' => $totalSiteDepositsCompleted,
        'grossIncomingPool'          => $grossIncomingPool,
        'siteWithdrawPaid'           => $siteWithdrawPaid,
        'agentProfitWithdrawPaid'    => $agentProfitWithdrawPaid,
        'totalPaidOut'               => $totalPaidOut,
        'bossPoolNow'                => $bossPoolNow,
        'pendingSiteWithdraw'        => $pendingSiteWithdraw,
        'pendingAgentProfitWithdraw' => $pendingAgentProfitWithdraw,
        'shortTermOut'               => $shortTermOut,
        'totalSiteBalanceInfo'       => $totalSiteBalanceInfo,
        'totalAgentProfitBalance'    => $totalAgentProfitBalance,
        'usersTotalWalletUsdt'       => $usersTotalWalletUsdt,
        'netPosition'   => $netPosition,
        'coverageRatio' => $coverageRatio,
        'generatedAt'   => date('H:i:s'),
    ];
}

// AJAX İSTEĞİ GELDİĞİNDE
if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
    header('Content-Type: application/json; charset=utf-8');
    
    // 1. Standart metrikleri al
    $metrics = bw_calculate_supervisor_metrics($pdo);
    
    // 2. Yapay Zeka Analizini al
    $aiAnalysis = $brain->getAnalysis();

    echo json_encode([
        'metrics' => $metrics,
        'ai' => $aiAnalysis
    ]);
    exit;
}

$metrics = bw_calculate_supervisor_metrics($pdo);
$aiInit = $brain->getAnalysis(); // Sayfa ilk açılışta da görsün

include __DIR__ . '/_admin_header.php';
?>

<style>
/* Supervisor Panel – red/white theme uyumlu */

.page-content {
    padding: 24px 30px 40px;
    max-width: 1300px;
    margin: 0 auto;
}

.supervisor-grid {
    display: grid;
    grid-template-columns: minmax(0, 1.4fr) minmax(0, 1.6fr);
    gap: 20px;
}

@media (max-width: 1024px) {
    .supervisor-grid {
        grid-template-columns: minmax(0, 1fr);
    }
}

.supervisor-card {
    background: var(--bg-card, #ffffff);
    border-radius: 16px;
    border: 1px solid rgba(148, 163, 184, 0.35);
    box-shadow: 0 12px 40px rgba(15, 23, 42, 0.18);
    padding: 18px 20px 18px;
    position: relative;
    overflow: hidden;
}

.supervisor-card-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    margin-bottom: 12px;
    gap: 8px;
}

.supervisor-card-header h2 {
    margin: 0;
    font-size: 16px;
    font-weight: 700;
    color: var(--text-main, #0f172a);
    display: flex;
    align-items: center;
    gap: 8px;
}

.supervisor-card-header h2 i {
    font-size: 18px;
    color: var(--primary, #c2273f);
}

.supervisor-note {
    font-size: 11px;
    color: var(--text-muted, #6b7280);
}

/* Risk badge */
.risk-pill {
    padding: 4px 10px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: .03em;
    text-transform: uppercase;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

.risk-pill.safe {
    background: #dcfce7;
    color: #166534;
    border: 1px solid #bbf7d0;
}
.risk-pill.warning {
    background: #fef9c3;
    color: #854d0e;
    border: 1px solid #facc15;
}
.risk-pill.danger {
    background: #fee2e2;
    color: #991b1b;
    border: 1px solid #fecaca;
}
.risk-pill.neutral {
    background: #e5e7eb;
    color: #374151;
    border: 1px solid #d1d5db;
}

/* Big status text */

.supervisor-status-text {
    font-size: 18px;
    font-weight: 700;
    margin-bottom: 4px;
    color: var(--text-main, #0f172a);
}

.supervisor-advice {
    font-size: 13px;
    color: var(--text-muted, #6b7280);
}

/* Metric rows */

.metric-group-title {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    color: #9ca3af;
    margin-top: 10px;
    margin-bottom: 4px;
}

.metric-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 6px 0;
    gap: 12px;
    border-bottom: 1px dashed rgba(148, 163, 184, 0.35);
    font-size: 13px;
}

.metric-row:last-of-type {
    border-bottom: none;
    padding-bottom: 2px;
}

.metric-label {
    color: var(--text-main, #0f172a);
}

.metric-label span.sub {
    display: block;
    font-size: 11px;
    color: var(--text-muted, #6b7280);
}

.metric-value {
    font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
    font-size: 13px;
    font-weight: 600;
    white-space: nowrap;
}

.metric-value.positive {
    color: #16a34a;
}
.metric-value.negative {
    color: #dc2626;
}
.metric-value.muted {
    color: var(--text-muted, #6b7280);
}

.metric-value strong {
    font-size: 14px;
}

/* Split layout on right */

.supervisor-right-grid {
    display: grid;
    grid-template-columns: minmax(0, 1.1fr) minmax(0, 1fr);
    gap: 14px;
}

@media (max-width: 1024px) {
    .supervisor-right-grid {
        grid-template-columns: minmax(0, 1fr);
    }
}

/* Small section chips */

.section-chip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    padding: 2px 8px;
    border-radius: 999px;
    background: rgba(248, 250, 252, 0.9);
    color: #6b7280;
    border: 1px solid rgba(226, 232, 240, 0.8);
}

/* Net pozisyon highlight */

.net-box {
    margin-top: 8px;
    padding: 8px 10px;
    border-radius: 10px;
    background: linear-gradient(135deg, rgba(194, 39, 63, 0.06), rgba(15, 23, 42, 0.75));
    border: 1px solid rgba(248, 250, 252, 0.06);
    color: #e5e7eb;
}

.net-box-title {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    opacity: 0.9;
    margin-bottom: 2px;
}

.net-box-value {
    font-family: 'Roboto Mono', ui-monospace;
    font-size: 16px;
    font-weight: 700;
}

/* Son güncelleme */

.supervisor-updated {
    font-size: 11px;
    color: var(--text-muted, #6b7280);
    margin-top: 4px;
}

/* Dark mode tweaks */

body.dark-mode .supervisor-card {
    background: #020617;
    border-color: rgba(15, 23, 42, 0.9);
    box-shadow: 0 16px 45px rgba(0, 0, 0, 0.65);
}

body.dark-mode .section-chip {
    background: rgba(15, 23, 42, 0.9);
    color: #9ca3af;
    border-color: rgba(31, 41, 55, 0.9);
}

body.dark-mode .metric-row {
    border-bottom-color: rgba(30, 64, 175, 0.25);
}
</style>

<div class="page-content">

    <div style="margin-bottom: 18px; display:flex; justify-content:space-between; align-items:flex-end; gap:10px;">
        <div>
            <h1 style="margin:0; font-size:22px; font-weight:700; color:var(--text-main);">
                BetWallet Supervisor
            </h1>
            <p style="margin:2px 0 0; font-size:12px; color:var(--text-muted);">
                Sistem kasası, kısa vade yükümlülükler ve net pozisyonu gerçek zamanlı izleyen karar destek ekranı.
            </p>
        </div>
        <div class="supervisor-updated">
            Son güncelleme: <span id="js-updated"><?= htmlspecialchars($metrics['generatedAt']) ?></span>
        </div>
    </div>

    <div class="supervisor-grid" id="js-supervisor-root">

        <!-- SOL: ÖZET DURUM & AI YORUMU -->
        <div class="supervisor-card">
            <div class="supervisor-card-header">
                <div>
                    <h2><i class="ri-cpu-line"></i> Anlık Durum & AI Yorumu</h2>
                    <div class="supervisor-note">
                        Boss havuz, kısa vade yük ve risk değerlendirmesi.
                    </div>
                </div>
                <div>
                    <span class="risk-pill" id="js-risk-pill">
                        <!-- JS risk label dolduracak -->
                    </span>
                </div>
            </div>

            <div class="supervisor-status-text" id="js-risk-message">
                <?= htmlspecialchars($metrics['riskMessage']) ?>
            </div>
            <div class="supervisor-advice" id="js-advice-text">
                <?= htmlspecialchars($metrics['advice']) ?>
            </div>

            <div class="metric-group-title" style="margin-top:14px;">
                Boss Havuz Özeti
            </div>

            <div class="metric-row">
                <div class="metric-label">
                    Bize giren toplam para
                    <span class="sub">Agent teminat + site yatırımları (completed)</span>
                </div>
                <div class="metric-value" id="js-gross-incoming">
                    <?= number_format($metrics['grossIncomingPool'], 2, ',', '.') ?> ₺
                </div>
            </div>

            <div class="metric-row">
                <div class="metric-label">
                    Şu ana kadar ödenenler
                    <span class="sub">Site çekimleri + agent kâr çekimleri (ödenmiş)</span>
                </div>
                <div class="metric-value negative" id="js-total-paid">
                    − <?= number_format($metrics['totalPaidOut'], 2, ',', '.') ?> ₺
                </div>
            </div>

            <div class="metric-row">
                <div class="metric-label">
                    Boss Havuz (Şu an bizde kalması gereken)
                </div>
                <div class="metric-value" id="js-boss-pool">
                    <strong><?= number_format($metrics['bossPoolNow'], 2, ',', '.') ?> ₺</strong>
                </div>
            </div>

            <div class="metric-group-title">
                Kısa Vade Yükler
            </div>

            <div class="metric-row">
                <div class="metric-label">
                    Bekleyen site çekimleri
                </div>
                <div class="metric-value negative" id="js-pending-site">
                    − <?= number_format($metrics['pendingSiteWithdraw'], 2, ',', '.') ?> ₺
                </div>
            </div>

            <div class="metric-row">
                <div class="metric-label">
                    Bekleyen agent kâr çekimleri
                </div>
                <div class="metric-value negative" id="js-pending-agent">
                    − <?= number_format($metrics['pendingAgentProfitWithdraw'], 2, ',', '.') ?> ₺
                </div>
            </div>

            <div class="metric-row">
                <div class="metric-label">
                    Kısa vade toplam potansiyel çıkış
                </div>
                <div class="metric-value negative" id="js-short-out">
                    − <?= number_format($metrics['shortTermOut'], 2, ',', '.') ?> ₺
                </div>
            </div>

            <div class="net-box" id="js-net-box">
                <div class="net-box-title">Kısa Vade Net Pozisyon (Boss Havuz − Kısa Vade Yük)</div>
                <div class="net-box-value" id="js-net-position">
                    <?= ($metrics['netPosition'] >= 0 ? '+' : '−') . ' ' . number_format(abs($metrics['netPosition']), 2, ',', '.') ?> ₺
                </div>
                <div style="font-size:11px; margin-top:3px; opacity:0.9;" id="js-coverage-info">
                    <?php if ($metrics['coverageRatio'] !== null && $metrics['coverageRatio'] > 0): ?>
                        Ödeme karşılama oranı: ≈ <?= number_format($metrics['coverageRatio'], 2, ',', '.') ?>x
                    <?php else: ?>
                        Şu an bekleyen kısa vade ödeme yok.
                    <?php endif; ?>
                </div>
            </div>

        </div>

        <!-- SAĞ: DETAYLI KASA BÖLÜMÜ -->
        <div class="supervisor-right-grid">

            <!-- Bize Ait Kasalar & Girişler -->
            <div class="supervisor-card">
                <div class="supervisor-card-header">
                    <div>
                        <h2><i class="ri-safe-2-line"></i> Bizim Havuz & Girişler</h2>
                        <div class="supervisor-note">
                            Agent teminatı ve sitelerden tahsil ettiğimiz bakiyeler.
                        </div>
                    </div>
                    <span class="section-chip">
                        <i class="ri-download-2-line"></i> Bize Girenler
                    </span>
                </div>

                <div class="metric-group-title">Bize Ait Paralar (Kaynaktan gelen)</div>

                <div class="metric-row">
                    <div class="metric-label">
                        Agent teminat toplamı
                        <span class="sub">system_balance (Bizde duran güvence)</span>
                    </div>
                    <div class="metric-value" id="js-agent-collateral">
                        <?= number_format($metrics['totalAgentCollateral'], 2, ',', '.') ?> ₺
                    </div>
                </div>

                <div class="metric-row">
                    <div class="metric-label">
                        Sitelerden tahsil edilen bakiyeler
                        <span class="sub">site_deposit_requests (completed)</span>
                    </div>
                    <div class="metric-value" id="js-site-deposits">
                        <?= number_format($metrics['totalSiteDepositsCompleted'], 2, ',', '.') ?> ₺
                    </div>
                </div>

                <div class="metric-row">
                    <div class="metric-label">
                        Toplam brüt giriş (Agent teminat + Site yükleme)
                    </div>
                    <div class="metric-value" id="js-gross-incoming-2">
                        <strong><?= number_format($metrics['grossIncomingPool'], 2, ',', '.') ?> ₺</strong>
                    </div>
                </div>

                <div class="metric-group-title">Bugüne Kadar Ödenenler</div>

                <div class="metric-row">
                    <div class="metric-label">
                        Ödenen site çekimleri
                    </div>
                    <div class="metric-value negative" id="js-site-paid">
                        − <?= number_format($metrics['siteWithdrawPaid'], 2, ',', '.') ?> ₺
                    </div>
                </div>

                <div class="metric-row">
                    <div class="metric-label">
                        Ödenen agent kâr çekimleri
                    </div>
                    <div class="metric-value negative" id="js-agent-paid">
                        − <?= number_format($metrics['agentProfitWithdrawPaid'], 2, ',', '.') ?> ₺
                    </div>
                </div>

                <div class="metric-row">
                    <div class="metric-label">
                        Toplam ödenen (Bizim havuzdan çıkmış)
                    </div>
                    <div class="metric-value negative" id="js-total-paid-2">
                        − <?= number_format($metrics['totalPaidOut'], 2, ',', '.') ?> ₺
                    </div>
                </div>

                <div class="metric-row">
                    <div class="metric-label">
                        Şu anda teorik Boss Havuz
                        <span class="sub">Brüt giriş − ödenenler</span>
                    </div>
                    <div class="metric-value" id="js-boss-pool-2">
                        <strong><?= number_format($metrics['bossPoolNow'], 2, ',', '.') ?> ₺</strong>
                    </div>
                </div>
            </div>

            <!-- Potansiyel Yükümlülükler & Info -->
            <div class="supervisor-card">
                <div class="supervisor-card-header">
                    <div>
                        <h2><i class="ri-compass-3-line"></i> Potansiyel Yükümlülükler</h2>
                        <div class="supervisor-note">
                            Uzun vadede gidebilecek paralar; risk radarın.
                        </div>
                    </div>
                    <span class="section-chip">
                        <i class="ri-alert-line"></i> Radar
                    </span>
                </div>

                <div class="metric-group-title">Uzun Vade Potansiyel Çıkışlar</div>

                <div class="metric-row">
                    <div class="metric-label">
                        Sitelerin mevcut bakiyeleri
                        <span class="sub">İleride çekim / mahsuplaşma potansiyeli</span>
                    </div>
                    <div class="metric-value muted" id="js-site-balances">
                        <?= number_format($metrics['totalSiteBalanceInfo'], 2, ',', '.') ?> ₺
                    </div>
                </div>

                <div class="metric-row">
                    <div class="metric-label">
                        Agent kâr kasası toplamı
                        <span class="sub">agent_profit_balance (ileride çekilebilir)</span>
                    </div>
                    <div class="metric-value muted" id="js-agent-profit-balance">
                        <?= number_format($metrics['totalAgentProfitBalance'], 2, ',', '.') ?> ₺
                    </div>
                </div>

                <div class="metric-row">
                    <div class="metric-label">
                        Kullanıcı USDT cüzdan toplamı
                        <span class="sub">Potansiyel USDT yükümlülüğü (agent tarafından karşılanır)</span>
                    </div>
                    <div class="metric-value muted" id="js-user-usdt">
                        <?= number_format($metrics['usersTotalWalletUsdt'], 2, ',', '.') ?> USDT
                    </div>
                </div>

                <div class="metric-group-title">Ek Not</div>
                <div style="font-size:12px; color:var(--text-muted);">
                    Kullanıcı USDT bakiyeleri doğrudan senin kasandan çıkmıyor; agent tarafı karşılıyor.  
                    Supervisor bu rakamları sadece hacim & baskı göstergesi olarak takip ediyor.
                </div>
            </div>

        </div>
    </div>
</div>

<script>
(function() {
    const endpoint = 'admin_supervisor.php?ajax=1';

    function formatNumber(n, suffix) {
        suffix = suffix || '₺';
        const abs = Math.abs(n);
        const formatted = abs.toLocaleString('tr-TR', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
        const sign = n < 0 ? '-' : '';
        return sign + ' ' + formatted + ' ' + suffix;
    }

    function updateRiskPill(tone, label) {
        const pill = document.getElementById('js-risk-pill');
        // Tone: safe, warning, danger, panic
        // CSS classları: safe, warning, danger (panic için danger kullanabiliriz veya ekleyebilirsin)
        let cssClass = tone;
        if (tone === 'panic') cssClass = 'danger'; // CSS'te panic yoksa danger kullan

        pill.className = 'risk-pill ' + cssClass;
        pill.innerHTML = '<i class="ri-pulse-line"></i> ' + (label || tone.toUpperCase());
    }

    async function refreshSupervisor() {
        try {
            const res = await fetch(endpoint, { cache: 'no-store' });
            if (!res.ok) throw new Error('HTTP ' + res.status);
            const data = await res.json();

            const m = data.metrics; // Eski hesaplar
            const ai = data.ai;     // Yeni zeka

            // --- AI ANALİZİ ---
            // Yapay zekadan gelen veriyi ekrana basıyoruz
            updateRiskPill(ai.tone, 'Risk: %' + ai.risk_score);
            document.getElementById('js-risk-message').innerHTML = ai.prediction; 
            // AI tavsiyesini risk mesajının içine gömdük, advice alanını temizleyebilirsin
            document.getElementById('js-advice-text').textContent = "AI Son Analiz Saati: " + m.generatedAt;


            // --- METRİKLER (ESKİ YERLERİNE) ---
            document.getElementById('js-gross-incoming').textContent  = formatNumber(m.grossIncomingPool);
            document.getElementById('js-gross-incoming-2').innerHTML  = '<strong>' + formatNumber(m.grossIncomingPool) + '</strong>';
            document.getElementById('js-total-paid').textContent      = formatNumber(-m.totalPaidOut);
            document.getElementById('js-total-paid-2').textContent    = formatNumber(-m.totalPaidOut);
            document.getElementById('js-boss-pool').innerHTML         = '<strong>' + formatNumber(m.bossPoolNow) + '</strong>';
            document.getElementById('js-boss-pool-2').innerHTML       = '<strong>' + formatNumber(m.bossPoolNow) + '</strong>';

            document.getElementById('js-pending-site').textContent  = formatNumber(-m.pendingSiteWithdraw);
            document.getElementById('js-pending-agent').textContent = formatNumber(-m.pendingAgentProfitWithdraw);
            document.getElementById('js-short-out').textContent     = formatNumber(-m.shortTermOut);

            const net = m.netPosition || 0;
            const netEl = document.getElementById('js-net-position');
            netEl.textContent = formatNumber(net);
            document.getElementById('js-net-box').style.borderColor =
                net >= 0 ? 'rgba(34,197,94,0.7)' : 'rgba(239,68,68,0.85)';

            // Kaynak detayları
            document.getElementById('js-agent-collateral').textContent       = formatNumber(m.totalAgentCollateral);
            document.getElementById('js-site-deposits').textContent          = formatNumber(m.totalSiteDepositsCompleted);
            document.getElementById('js-site-paid').textContent              = formatNumber(-m.siteWithdrawPaid);
            document.getElementById('js-agent-paid').textContent             = formatNumber(-m.agentProfitWithdrawPaid);

            // Radar
            document.getElementById('js-site-balances').textContent          = formatNumber(m.totalSiteBalanceInfo);
            document.getElementById('js-agent-profit-balance').textContent   = formatNumber(m.totalAgentProfitBalance);
            document.getElementById('js-user-usdt').textContent              = formatNumber(m.usersTotalWalletUsdt, 'USDT');

            // Zaman
            document.getElementById('js-updated').textContent = m.generatedAt || '';

        } catch (err) {
            console.error('Supervisor refresh error:', err);
        }
    }

    refreshSupervisor();
    setInterval(refreshSupervisor, 15000); // 15 saniyede bir güncelle
})();
</script>

<?php include __DIR__ . '/_admin_footer.php'; ?>
