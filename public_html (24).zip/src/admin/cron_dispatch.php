<?php
// admin/cron_dispatch.php

// 1. Config Dosyasını Dahil Et (Yolu kendi yapına göre düzelt)
require __DIR__ . '/../config/config.php';

// 2. Güvenlik Önlemi (Sadece sunucu çalıştırabilsin, dışarıdan kimse tetikleyemesin)
if (php_sapi_name() !== 'cli' && !isset($_GET['key'])) {
    die('Yetkisiz Erişim'); // Basit güvenlik. Cron ayarında ?key=gizlisifre kullanabilirsin.
}

echo "Otomatik Dağıtım Başladı...\n";

try {
    // Transaction Başlat
    $pdo->beginTransaction();
    
    // Bekleyen işlemleri çek
    $pendingOrders = $pdo->query("SELECT * FROM withdraw_requests WHERE status = 'pending'")->fetchAll(PDO::FETCH_ASSOC);
    $count = 0;

    foreach ($pendingOrders as $order) {
        $amount = (float)$order['amount'];
        
        // Uygun Agent Bul: Aktif ve Kasası (current_cash) yeterli olan
        $stmt = $pdo->prepare("
            SELECT id, current_cash 
            FROM deposit_agents 
            WHERE is_active = 1 
              AND current_cash >= ? 
            ORDER BY current_cash DESC 
            LIMIT 1
        ");
        $stmt->execute([$amount]);
        $agent = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($agent) {
            // 1. İsteğin durumunu güncelle
            $pdo->prepare("UPDATE withdraw_requests SET status = 'processing' WHERE id = ?")->execute([$order['id']]);

            // 2. Agent'a iş ata
            $siteId = isset($order['site_id']) ? $order['site_id'] : 0;
            $ins = $pdo->prepare("INSERT INTO agent_withdraw_orders (site_id, agent_id, user_id, amount, status, created_at) VALUES (?, ?, ?, ?, 'pending', NOW())");
            $ins->execute([$siteId, $agent['id'], $order['user_id'], $amount]);

            $count++;
            echo "Islem ID: {$order['id']} -> Agent ID: {$agent['id']} atandi.\n";
        }
    }
    
    $pdo->commit();
    echo "Bitti. Toplam $count islem dagitildi.\n";

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo "Hata Olustu: " . $e->getMessage() . "\n";
}
?>