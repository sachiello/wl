<?php
// admin/cron_record_metrics.php

require __DIR__ . '/../../config/config.php'; // Veritabanı bağlantısı ($pdo)
require __DIR__ . '/classes/BwIntelligence.php';
require __DIR__ . '/classes/TelegramNotifier.php';

// Hata ayıklama
if (!isset($pdo)) {
    die("Veritabanı bağlantısı yok!");
}

// 1. SINIFLARI BAŞLAT
$brain = new BwIntelligence($pdo);
$bot = new TelegramNotifier();

// 2. SNAPSHOT AL (Hafızaya kaydet)
$brain->recordSnapshot();

// 3. ANALİZ YAP (Durum ne?)
$analysis = $brain->getAnalysis();

// 4. KARAR VER: PATRONA MESAJ ATALIM MI?
// Risk Skoru: 0 (Güvenli) - 100 (İflas)

if ($analysis['risk_score'] >= 50) {
    // RİSK VARSA KESİN HABER VER
    
    $emoji = "⚠️";
    if ($analysis['risk_score'] >= 90) $emoji = "🚨 ACİL DURUM 🚨";
    
    $msg = "$emoji\n";
    $msg .= "Durum: <b>" . strtoupper($analysis['tone']) . "</b>\n";
    $msg .= "Risk Puanı: %" . $analysis['risk_score'] . "\n\n";
    $msg .= "<i>" . $analysis['prediction'] . "</i>";
    
    $bot->send($msg);
    echo "Risk tespit edildi, mesaj gönderildi.";

} else {
    // DURUM GÜVENLİ İSE...
    
    // Eğer "Her şey yolunda" mesajını da istiyorsan aşağıdaki satırın başındaki // işaretlerini kaldır.
    $bot->send("✅ Sistem stabil. Sorun yok. (Risk: %" . $analysis['risk_score'] . ")");
    
    echo "Durum stabil, rahatsız edilmedi.";
}