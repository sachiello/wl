<?php
// admin/agent_personnel_logs.php
require __DIR__ . '/require_admin.php';

$pageTitle = 'Personel İşlem Logları';
$activeNav = 'agent_personnel_logs';

// Filtre değişkenleri
$f_personnel = $_GET['personnel_id'] ?? '';
$f_start     = $_GET['start_date'] ?? '';
$f_end       = $_GET['end_date'] ?? '';

// Personel listesi
$personnelList = $pdo->query("
    SELECT id, name 
    FROM deposit_agents 
    WHERE role='personnel'
    ORDER BY name ASC
")->fetchAll(PDO::FETCH_ASSOC);

// Loglar
$sql = "
    SELECT 
        al.*, 
        da_personnel.name AS personnel_name,
        da_agent.name AS agent_name
    FROM agent_personnel_logs al
    LEFT JOIN deposit_agents da_personnel ON da_personnel.id = al.personnel_id
    LEFT JOIN deposit_agents da_agent ON da_agent.id = al.agent_id
    WHERE 1=1
";

$params = [];

if ($f_personnel) {
    $sql .= " AND al.personnel_id = :p";
    $params[':p'] = $f_personnel;
}
if ($f_start) {
    $sql .= " AND al.created_at >= :sd";
    $params[':sd'] = $f_start . " 00:00:00";
}
if ($f_end) {
    $sql .= " AND al.created_at <= :ed";
    $params[':ed'] = $f_end . " 23:59:59";
}

$sql .= " ORDER BY al.id DESC LIMIT 500";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/_admin_header.php';
?>

<div class="admin-page">

    <!-- SAYFA BAŞLIK -->
    <div class="admin-page-header">
        <h1>Personel İşlem Logları</h1>
        <p>Personeller tarafından yapılan tüm işlemler.</p>
    </div>

    <!-- FİLTRE ALANI -->
    <form method="GET" class="admin-filters">
        <div class="admin-filter-form">

            <div class="filter-group">
                <label>Personel</label>
                <select name="personnel_id">
                    <option value="">Tümü</option>
                    <?php foreach ($personnelList as $p): ?>
                        <option value="<?= $p['id'] ?>" <?= $f_personnel == $p['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($p['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="filter-group">
                <label>Başlangıç</label>
                <input type="date" name="start_date" value="<?= htmlspecialchars($f_start) ?>">
            </div>

            <div class="filter-group">
                <label>Bitiş</label>
                <input type="date" name="end_date" value="<?= htmlspecialchars($f_end) ?>">
            </div>

        </div>

        <div style="display:flex; gap:10px;">
            <button class="btn-primary" style="padding: 8px 16px;">Filtrele</button>
            <a href="agent_personnel_logs.php" class="btn-glass">Sıfırla</a>
        </div>
    </form>

    <!-- TABLO -->
    <div class="admin-table-wrapper">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Personel</th>
                    <th>Ana Agent</th>
                    <th>Aksiyon</th>
                    <th>Detay</th>
                    <th>Tarih</th>
                </tr>
            </thead>
            <tbody>

                <?php if (empty($logs)): ?>
                    <tr>
                        <td colspan="6" style="text-align:center; padding:40px;">
                            <i class="ri-history-line" style="font-size:48px; opacity:0.4;"></i><br>
                            Bu kriterlere uygun kayıt bulunamadı.
                        </td>
                    </tr>
                <?php endif; ?>

                <?php foreach ($logs as $log): ?>
                <tr class="js-log-row"
                    data-details="<?= htmlspecialchars($log['details']) ?>">

                    <td>#<?= $log['id'] ?></td>

                    <td>
                        <?= htmlspecialchars($log['personnel_name'] ?? 'Bilinmiyor') ?>
                        <div style="font-size:12px; color:#6b7280;">ID: <?= $log['personnel_id'] ?></div>
                    </td>

                    <td>
                        <?= htmlspecialchars($log['agent_name'] ?? 'Yok') ?>
                        <div style="font-size:12px; color:#6b7280;">ID: <?= $log['agent_id'] ?></div>
                    </td>

                    <td>
                        <span class="badge badge-secondary">
                            <?= htmlspecialchars($log['action']) ?>
                        </span>
                    </td>

                    <td style="max-width:300px; white-space:pre-wrap;">
                        <?= htmlspecialchars($log['details']) ?>
                    </td>

                    <td style="white-space:nowrap;">
                        <?= date("d.m.Y H:i:s", strtotime($log['created_at'])) ?>
                    </td>

                </tr>
                <?php endforeach; ?>

            </tbody>
        </table>
    </div>
</div>

<!-- MODAL -->
<div class="admin-modal-backdrop" id="log-modal">
    <div class="admin-modal">
        <button class="admin-modal-close" id="modal-close">&times;</button>

        <div class="admin-modal-header">
            <h2>İşlem Detayı</h2>
        </div>

        <div id="modal-body" class="admin-modal-body"></div>
    </div>
</div>

<script>
document.addEventListener("click", function(e) {
    const row = e.target.closest(".js-log-row");
    if (!row) return;

    const modal = document.getElementById("log-modal");
    const body  = document.getElementById("modal-body");

    body.textContent = row.dataset.details || "Detay bulunamadı.";
    modal.style.display = "flex";
});

document.getElementById("modal-close").onclick = () => {
    document.getElementById("log-modal").style.display = "none";
};

document.getElementById("log-modal").addEventListener("click", function(e) {
    if (e.target === this) this.style.display = "none";
});
</script>

<?php include __DIR__ . '/_admin_footer.php'; ?>
