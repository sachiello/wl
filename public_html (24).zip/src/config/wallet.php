<?php

return [
    // USDT/TL kuru okunamadığında kullanılacak varsayılan değer.
    'default_usdt_rate' => 42.00,

    // Kullanıcı durumu için kullanılan API yolu.
    'status_api_path' => '/src/controllers/get_user_status.php',

    // Yeni havale yatırımları için dakika bazlı son kullanma süresi.
    'deposit_expiry_minutes' => 15,
];
