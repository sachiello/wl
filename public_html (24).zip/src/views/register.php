<?php
// src/views/register.php
// Artık sadece kayıt logic'i, HTML yok.
// NOT: users tablosunda aşağıdaki kolonların olduğunu varsayar:
// id, username, full_name, phone, email, password_hash, trc20_address, created_at, is_banned, ...
// (full_name / phone / email yoksa önce ALTER ile ekle.)

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * CONFIG / DB
 */
require_once __DIR__ . '/../../config/config.php';

// PDO alias (config $db kullanıyorsa)
if (!isset($pdo) && isset($db)) {
    $pdo = $db;
}

if (!isset($pdo)) {
    die('DB bağlantısı bulunamadı.');
}

// Sadece POST kabul et
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /?v=register');
    exit;
}

// AJAX mı?
$isAjax = (($_POST['ajax'] ?? '') === '1');

$errorMsg = null;

// CSRF kontrolü
if (function_exists('csrf_validate_request') && !csrf_validate_request()) {
    $errorMsg = 'Oturum doğrulaması başarısız. Lütfen tekrar deneyin.';
}

// Form verileri
$username   = trim($_POST['username']   ?? '');
$fullName   = trim($_POST['full_name']  ?? '');
$phone      = trim($_POST['phone']      ?? '');
$email      = trim($_POST['email']      ?? '');
$password   = trim($_POST['password']   ?? '');
$password2  = trim($_POST['password2']  ?? '');  // varsa kontrol ederiz, yoksa zorunlu değil
$smsCode    = trim($_POST['sms_code']   ?? '');  // şimdilik sadece gösteriş
// $smsCode şu anlık sadece görsel, backend logic yok

// Basit validasyon
if ($errorMsg === null) {
    if ($username === '' || $fullName === '' || $phone === '' || $password === '') {
        $errorMsg = 'Kullanıcı adı, ad soyad, telefon ve şifre zorunludur.';
    } elseif ($password2 !== '' && $password !== $password2) {
        // Formda şifre tekrar alanı varsa ve doldurulmuşsa, eşit olmasını zorunlu tut
        $errorMsg = 'Şifre ve şifre tekrar aynı olmalıdır.';
    } elseif (strlen($password) < 6) {
        $errorMsg = 'Şifre en az 6 karakter olmalıdır.';
    } elseif (!preg_match('/^[0-9+\s\-]{8,20}$/', $phone)) {
        // Basit telefon kontrolü (isteğe göre sıkılaştırılabilir)
        $errorMsg = 'Lütfen geçerli bir telefon numarası girin.';
    }
}

// Kullanıcı adı mevcut mu?
if ($errorMsg === null) {
    $stmtCheck = $pdo->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
    $stmtCheck->execute([$username]);
    if ($stmtCheck->fetch()) {
        $errorMsg = 'Bu kullanıcı adı alınmış.';
    }
}

// Telefon benzersiz olsun mu? (Aynı telefonla birden fazla hesap açılmasın)
if ($errorMsg === null && $phone !== '') {
    $stmtPhone = $pdo->prepare("SELECT id FROM users WHERE phone = ? LIMIT 1");
    $stmtPhone->execute([$phone]);
    if ($stmtPhone->fetch()) {
        $errorMsg = 'Bu telefon numarası ile daha önce kayıt oluşturulmuş.';
    }
}

// TRC20 adres üretici fonksiyon config'te varsayılıyor
if (!function_exists('generateTrc20Address')) {
    function generateTrc20Address(): string
    {
        // Eğer config'te gerçek fonksiyon varsa bu blok çalışmayacak.
        $random = bin2hex(random_bytes(16)); // 32 hex
        return 'T' . substr($random, 0, 33);
    }
}

// 8 haneli, 18xxxxxx user_id üretici
if (!function_exists('generateUserId')) {
    /**
     * 8 haneli ID üretir: 18xxxxxx
     * Çakışma riskine karşı DB'de kontrol eder.
     */
    function generateUserId(PDO $pdo): int
    {
        do {
            // 18 000000 - 18 999999 aralığı
            $id = 18000000 + random_int(0, 999999);

            $check = $pdo->prepare("SELECT 1 FROM users WHERE id = ? LIMIT 1");
            $check->execute([$id]);
            $exists = $check->fetchColumn();
        } while ($exists);

        return $id;
    }
}

// Kayıt işlemi
if ($errorMsg === null) {
    $generatedAddr = generateTrc20Address();   // Fonksiyon config'te gerçek versiyonla override olabilir
    $passwordHash  = password_hash($password, PASSWORD_BCRYPT);

    try {
        $pdo->beginTransaction();

        // 1) ID üret (18xxxxxx, 8 hane)
        $userId = generateUserId($pdo);

        // 2) Kullanıcı oluştur
        // users tablosunda full_name / phone / email kolonları olduğu varsayılıyor
        $stmt = $pdo->prepare("
            INSERT INTO users (id, username, full_name, phone, email, password_hash, trc20_address, created_at, is_banned)
            VALUES (:id, :username, :full_name, :phone, :email, :password_hash, :trc20_address, NOW(), 0)
        ");

        $stmt->execute([
            ':id'             => $userId,
            ':username'       => $username,
            ':full_name'      => $fullName,
            ':phone'          => $phone,
            ':email'          => ($email !== '' ? $email : null),
            ':password_hash'  => $passwordHash,
            ':trc20_address'  => $generatedAddr,
        ]);

        // 3) Varsayılan cüzdanlar
        $stmtWallet = $pdo->prepare("
            INSERT INTO wallets (user_id, coin_type, balance)
            VALUES (:uid, 'TRX', 0),
                   (:uid, 'USDT', 0)
        ");
        $stmtWallet->execute([':uid' => $userId]);

        $pdo->commit();

        // Giriş yapmış gibi session aç
        $_SESSION['user_id']       = $userId;
        $_SESSION['username']      = $username;
        $_SESSION['trc20_address'] = $generatedAddr;

        // 2FA henüz yok → 2FA'sız tam giriş gibi işaretle
        $_SESSION['2fa_verified']   = true;
        $_SESSION['is_2fa_enabled'] = 0;

        // SMS doğrulama henüz gerçek değil:
        // phone_verified varsayılan 0 kalıyor, smsCode backend'de işlenmiyor.

        if ($isAjax) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'ok'       => true,
                'redirect' => '/wallet'
            ]);
            exit;
        }

        header('Location: /wallet');
        exit;

    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        // error_log($e->getMessage());
        $errorMsg = 'Kayıt başarısız. Lütfen daha sonra tekrar deneyin.';
    }
}

// BURAYA GELDİYSEK HATA VAR

if ($isAjax) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'ok'    => false,
        'error' => $errorMsg ?? 'Bilinmeyen hata.'
    ]);
    exit;
}

// Normal form ise → landing/register’a hata mesajıyla döndür
$redirectError = urlencode($errorMsg ?? 'Bilinmeyen hata.');
header("Location: /?v=register&error={$redirectError}");
exit;
