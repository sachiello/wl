<?php
// src/views/wallet/view.php - yalnızca görsel katman
$amountTryForPreview = isset($activeDeposit['amount_try']) ? (float)$activeDeposit['amount_try'] : 0.0;
$netTry  = $netTry  ?? $amountTryForPreview;
$netUsdt = $netUsdt ?? (($rateUsdt > 0 && $netTry > 0) ? $netTry / $rateUsdt : 0.0);
$activeDepositDetails = $activeDepositDetails ?? [];
$ibanValue  = $activeDepositDetails['iban']
    ?? ($activeDeposit['iban'] ?? ($activeDeposit['target_iban'] ?? 'IBAN henüz atanmadı'));

$ibanHolder = $activeDepositDetails['holder']
    ?? ($activeDeposit['holder'] ?? ($activeDeposit['account_holder'] ?? ''));
    $chipClass = 'bw-history-chip';

?>
<!DOCTYPE html>
<html lang="tr">
    
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>BetWallet - Cüzdan</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>/public/assets/betwallet.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Orbitron:wght@600;700&display=swap" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/remixicon/fonts/remixicon.css" rel="stylesheet">

</head>



    <style>
        .badge-active {
            display: inline-block;
            padding: 6px 14px;
            font-size: 12px;
            font-weight: 700;
            border-radius: 6px;
            color: #fff;
            background: #dc2626; /* Düz kırmızı */
        }

        /* Banka hesabı seçili durumu */
        .bank-account-item.selected {
            border-color: #dc2626;
            background: #fef2f2;
        }

        /* ==== Aktif Yatırım Kartı (White / Red Theme) ==== */
        .bw-active-deposit-wrap {
            margin-top: 12px;
            margin-bottom: 12px;
        }

        .bw-active-deposit-bar {
            background: #ffffff;
            border-radius: 12px;
            border: 1px solid #fee2e2; /* açık kırmızı border */
            box-shadow: 0 6px 16px rgba(220, 38, 38, 0.10);
            overflow: hidden;
        }
        /* Aktif yatırım kartı ve içini beyaz yap (dark theme override) */
.bw-active-deposit-bar {
    background: #ffffff !important;
}

.bw-active-deposit-details {
    background: #ffffff !important;
}

.bw-active-detail-row,
.bw-iban-row {
    background: #ffffff !important;
}

/* IBAN metni de beyaz zeminle uyumlu olsun */
#active-iban-text {
    color: #111827; /* koyu gri */
}


        .bw-active-deposit-toggle {
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 12px 14px;
            border: none;
            background: linear-gradient(135deg, #ffffff, #fff5f5);
            cursor: pointer;
        }

        .bw-active-deposit-toggle:hover {
            background: linear-gradient(135deg, #ffffff, #fee2e2);
        }

        .bw-active-deposit-left {
            display: flex;
            align-items: center;
            gap: 8px;
            min-width: 0;
        }

        .bw-pulse-dot {
            width: 10px;
            height: 10px;
            border-radius: 999px;
            background: #dc2626;
            box-shadow: 0 0 0 0 rgba(220, 38, 38, 0.6);
            animation: bw-pulse 1.5s infinite;
        }

        .bw-active-label {
            font-size: 13px;
            font-weight: 600;
            color: #991b1b;
        }

        .bw-active-amount {
            font-size: 14px;
            font-weight: 700;
            color: #b91c1c;
        }

        .bw-active-deposit-right {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .bw-active-status-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            background: #fee2e2;
            color: #b91c1c;
        }

        .bw-active-chevron {
            font-size: 14px;
            color: #991b1b;
        }

        /* DETAY ALANI – BAŞLANGIÇTA TAMAMEN KAPALI */
        .bw-active-deposit-details {
            display: block;              /* Eski CSS'teki display:none vb. ez */
            max-height: 0;
            overflow: hidden;
            padding: 0;
            border-top: none;
            transition: max-height 0.25s ease;
        }

        /* Açıkken padding + border geliyor, max-height JS'ten */
        .bw-active-deposit-details.is-open {
            padding: 10px 14px 12px;
            border-top: 1px solid #fee2e2;
        }

        /* Satırlar */
        .bw-active-detail-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            padding: 6px 0;
            font-size: 13px;
            color: #374151;
        }

        .bw-active-detail-row span {
            color: #6b7280;
        }

        .bw-active-detail-row strong {
            color: #111827;
        }

        /* IBAN satırı */
        .bw-iban-row {
            padding-bottom: 8px;
            border-bottom: 1px dashed #fecaca;
            margin-bottom: 6px;
        }

        .bw-iban-copy-wrap {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .bw-iban-copy-btn {
            border: 1px solid #fecaca;
            background: #fef2f2;
            color: #b91c1c;
            font-size: 11px;
            padding: 4px 10px;
            border-radius: 999px;
            cursor: pointer;
        }

        .bw-iban-copy-btn:hover {
            background: #dc2626;
            color: #ffffff;
        }

        /* İPTAL BUTONU */
        .bw-btn-cancel-deposit {
            width: 100%;
            margin-top: 10px;
            border-radius: 8px;
            border: 1px solid #fecaca;
           background: #dc2626;
            color: #ffffff;
            font-size: 13px;
            font-weight: 600;
            padding: 8px 10px;
            cursor: pointer;
        }

        /* PULSE ANİMASYON */
        @keyframes bw-pulse {
            0% {
                transform: scale(1);
                box-shadow: 0 0 0 0 rgba(220, 38, 38, 0.6);
            }
            70% {
                transform: scale(1.1);
                box-shadow: 0 0 0 8px rgba(220, 38, 38, 0);
            }
            100% {
                transform: scale(1);
                box-shadow: 0 0 0 0 rgba(220, 38, 38, 0);
            }
        }

        /* Tabs genel marjini, kartla uyumlu */
        .bw-tabs {
            margin-top: 8px;
        }
        /* IBAN satırını dikey blok yap */
.bw-active-detail-row.bw-iban-row {
    flex-direction: column;
    align-items: stretch;
}

/* Label + Ad Soyad bloğu */
.bw-iban-label-block {
    display: flex;
    flex-direction: column;
    gap: 2px;
    margin-bottom: 4px;
}

.bw-iban-label-main {
    font-size: 12px;
    font-weight: 600;
    color: #6b7280;
}

.bw-iban-label-sub {
    font-size: 11px;
    color: #9ca3af;
}

/* IBAN + Kopyala hizası */
.bw-iban-copy-wrap {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    width: 100%;
}

/* Uzun IBAN uyumu – satırı taşırmadan göster */
.bw-iban-text {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
    font-size: 13px;
    color: #111827;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

/* Küçük ekranlarda sarma istersen, yukarıdakileri şöyle değiştirebilirsin:
   white-space: normal;
   word-break: break-all;
*/

/* Kopyala butonu zaten tanımlı ama emin olmak için: */
.bw-iban-copy-btn {
    border: 1px solid #fecaca;
    background: #fef2f2;
    color: #b91c1c;
    font-size: 11px;
    padding: 4px 10px;
    border-radius: 999px;
    cursor: pointer;
}
/**********************************************
 * ACTIVE DEPOSIT + IBAN KUTULARI – DARK MODE
 **********************************************/

/* ana bar */
body.dark-mode .bw-active-deposit-bar,
body[data-theme="dark"] .bw-active-deposit-bar {
    background: #0f172a !important;
    border-color: #1f2937 !important;
    box-shadow: 0 6px 18px rgba(0,0,0,0.6) !important;
}

/* toggle */
body.dark-mode .bw-active-deposit-toggle,
body[data-theme="dark"] .bw-active-deposit-toggle {
    background: linear-gradient(135deg, #1a1a24, #0f172a) !important;
    color: #fff !important;
}

body.dark-mode .bw-active-deposit-toggle:hover,
body[data-theme="dark"] .bw-active-deposit-toggle:hover {
    background: linear-gradient(135deg, #2d2d3a, #1a1a24) !important;
}

/* içinde açılan detay alanı */
body.dark-mode .bw-active-deposit-details,
body[data-theme="dark"] .bw-active-deposit-details {
    background: #0f172a !important;
    border-top-color: #1f2937 !important;
}

/* satırlar */
body.dark-mode .bw-active-detail-row,
body[data-theme="dark"] .bw-active-detail-row {
    background: transparent !important;
    color: #d1d5db !important;
}

body.dark-mode .bw-active-detail-row span,
body[data-theme="dark"] .bw-active-detail-row span {
    color: #9ca3af !important;
}

body.dark-mode .bw-active-detail-row strong,
body[data-theme="dark"] .bw-active-detail-row strong {
    color: #fef2f2 !important;
}

/* IBAN kutuları */
body.dark-mode .bw-iban-row,
body[data-theme="dark"] .bw-iban-row {
    border-bottom-color: rgba(248,113,113,0.35) !important;
}

/* IBAN metni */
body.dark-mode .bw-iban-code,
body[data-theme="dark"] .bw-iban-code,
body.dark-mode .bw-iban-text,
body[data-theme="dark"] .bw-iban-text {
    color: #fef2f2 !important;
}

/* IBAN kutularının kendisi */
body.dark-mode .bw-iban-box,
body[data-theme="dark"] .bw-iban-box {
    background: #0f172a !important;
    border: 1px solid #1f2937 !important;
}

/* copy button */
body.dark-mode .bw-copy-button,
body[data-theme="dark"] .bw-copy-button,
body.dark-mode .bw-iban-copy-btn,
body[data-theme="dark"] .bw-iban-copy-btn {
    background: #dc2626 !important;
    border-color: #dc2626 !important;
    color: #ffffff !important;
}

body.dark-mode .bw-copy-button:hover,
body[data-theme="dark"] .bw-copy-button:hover,
body.dark-mode .bw-iban-copy-btn:hover,
body[data-theme="dark"] .bw-iban-copy-btn:hover {
    background: #b91c1c !important;
    border-color: #b91c1c !important;
    color: #fff !important;
}

/* badge */
body.dark-mode .badge-active,
body[data-theme="dark"] .badge-active {
    background: #b91c1c !important;
    color: #ffffff !important;
}

/* banka seçili durumu */
body.dark-mode .bank-account-item.selected,
body[data-theme="dark"] .bank-account-item.selected {
    border-color: #dc2626 !important;
    background: rgba(220,38,38,0.12) !important;
    color: #fef2f2 !important;
}

/* pulse dot */
body.dark-mode .bw-pulse-dot,
body[data-theme="dark"] .bw-pulse-dot {
    background: #dc2626 !important;
    box-shadow: 0 0 8px rgba(220,38,38,0.6) !important;
}

/* text colors */
body.dark-mode .bw-active-label,
body[data-theme="dark"] .bw-active-label {
    color: #fef2f2 !important;
}

body.dark-mode .bw-active-amount,
body[data-theme="dark"] .bw-active-amount {
    color: #fb7185 !important;
}

/* chevron */
body.dark-mode .bw-active-chevron,
body[data-theme="dark"] .bw-active-chevron {
    color: #fca5a5 !important;
}

/* status badge toggle */
body.dark-mode .bw-active-status-badge,
body[data-theme="dark"] .bw-active-status-badge {
    background: rgba(220,38,38,0.2) !important;
    color: #fecaca !important;
}

/* cancel butonu */
body.dark-mode .bw-btn-cancel-deposit,
body[data-theme="dark"] .bw-btn-cancel-deposit {
    background: #b91c1c !important;
    border-color: #dc2626 !important;
    color: #ffffff !important;
}

/* hover */
body.dark-mode .bw-btn-cancel-deposit:hover,
body[data-theme="dark"] .bw-btn-cancel-deposit:hover {
    background: #ef4444 !important;
    color: #fff !important;
}

/* secondary labels */
body.dark-mode .bw-iban-label-small,
body[data-theme="dark"] .bw-iban-label-small {
    color: #9ca3af !important;
}
.deposit-method-grid {
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 10px;
    margin-bottom: 14px;
}

.deposit-method-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    text-align: center;
    padding: 14px 10px;
    border-radius: 14px;
    border: 1px solid rgba(0,0,0,0.08);
    background: #ffffff;
    cursor: pointer;
    transition: 0.2s;
    user-select: none;
}

.deposit-method-icon i {
    font-size: 38px;
    color: #dc2626;
}

/* title */
.deposit-method-card .title {
    font-size: 13px;
    font-weight: 600;
    color: #991b1b;
    margin-top: 3px;
}

/* hover */
.deposit-method-card:hover {
    transform: translateY(-2px);
    border-color: #dc2626;
    background: #fff5f5;
}

/* disabled */
.deposit-method-card.is-disabled {
    opacity: .35;
    pointer-events: none;
}

/* DARK MODE */
body.dark-mode .deposit-method-card {
    background: #0f172a;
    border-color: #1e293b;
}

body.dark-mode .deposit-method-card:hover {
    background: rgba(220,38,38,0.1);
    border-color: #dc2626;
}

body.dark-mode .deposit-method-icon i {
    color: #fca5a5;
}

body.dark-mode .deposit-method-card .title {
    color: #fca5a5;
}

    </style>
<body>

<div class="app-frame">
    <div id="view-wallet" class="bw-view is-active">
        
        <header class="bw-fixed-header">

            <div style="font-weight: 700; font-family: Orbitron; background: linear-gradient(135deg, #dc2626, #ef4444); -webkit-background-clip: text; -webkit-text-fill-color: transparent; display: inline-block;">
                BetWallet
            </div>

            <div class="theme-toggle" onclick="toggleTheme()">
                <svg class="theme-icon sun" viewBox="0 0 24 24" width="14" height="14">
                    <path fill="currentColor"
                          d="M12 4.5a1 1 0 0 1 1 1V7a1 1 0 1 1-2 0V5.5a1 1 0 0 1 1-1Zm0 10a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm7.5-3a1 1 0 0 1-1 1H17a1 1 0 1 1 0-2h1.5a1 1 0 0 1 1 1Zm-12 0a1 1 0 0 1-1 1H5.5a1 1 0 0 1 0-2H6a1 1 0 0 1 1 1Zm9.243 5.657a1 1 0 0 1-1.414 0l-1.06-1.06a1 1 0 1 1 1.414-1.415l1.06 1.061a1 1 0 0 1 0 1.414Zm-8.486-8.486a1 1 0 0 1-1.415 0l-1.06-1.06A1 1 0 1 1 5.414 6.93l1.061 1.06a1 1 0 0 1 0 1.415Zm0 8.486-1.061-1.06A1 1 0 0 1 5.414 15.1l1.06 1.06a1 1 0 0 1-1.414 1.416Zm8.486-8.486-1.06-1.061a1 1 0 0 1 1.415-1.414l1.06 1.06a1 1 0 1 1-1.414 1.415Z" />
                </svg>

                <svg class="theme-icon moon" viewBox="0 0 24 24" width="14" height="14">
                    <path fill="currentColor"
                          d="M21 12.79A9 9 0 0 1 11.21 3 7 7 0 1 0 21 12.79Z" />
                </svg>

                <div class="theme-thumb"></div>
            </div>

            <div class="user-panel-wrapper" id="user-panel-wrapper">
                <div class="user-panel-trigger" onclick="DEPOSIT_APP.toggleUserPanel(this)">
                    <div class="user-panel-avatar">
                        <?= $sessionUsername ? strtoupper(substr($sessionUsername, 0, 1)) : '?' ?>
                    </div>
                    <span class="user-panel-username">
                        <?= htmlspecialchars($sessionUsername) ?>
                    </span>
                    <span class="user-panel-arrow">&#9660;</span>
                </div>
                
                <div class="user-panel-dropdown" id="user-panel-dropdown">
                    <div class="user-panel-item info">
                        <span class="user-panel-info-name">
                            <?= htmlspecialchars($sessionUsername) ?>
                        </span>
                        <?php if (!empty($sessionUserId)): ?>
                            <span class="user-panel-info-id">ID #<?= (int)$sessionUserId ?></span>
                        <?php endif; ?>
                    </div>

                    <button type="button"
                            class="user-panel-item"
                            data-user-modal="account">
                        Profil
                    </button>

                    <button type="button"
                            class="user-panel-item"
                            data-user-modal="security">
                        Güvenlik
                    </button>

                    <button type="button"
                            class="user-panel-item"
                            onclick="openModal('support-modal')">
                        Destek
                    </button>

                    <form method="post">
                        <?= csrf_field(); ?>
                        <input type="hidden" name="logout" value="1">
                        <button type="submit" class="user-panel-item logout-btn bw-block">
                            Çıkış Yap
                        </button>
                    </form>
                </div>
            </div>
        </header> 
        
        <div class="bw-center-page"> 

            <div class="bw-wallet-balance">
                <div class="bw-wallet-balance-label">TOPLAM VARLIK</div>
                <div class="bw-wallet-balance-amount">
                    <span class="currency-sign">₺</span><?= htmlspecialchars($totalBalanceText) ?>
                </div>
                <?php if (!$activeDeposit): ?>
                    <div class="bw-wallet-actions" style="margin-top:20px; margin-bottom:0;">
                        <button type="button"
                                class="bw-btn bw-btn-primary"
                                style="border-radius: 6px;"
                                onclick="openModal('deposit-modal')">
                            Yatır
                        </button>

                        <button type="button"
                                class="bw-btn bw-btn-outline"
                                style="border-radius: 6px;"
                                onclick="openModal('withdraw-modal')">
                            Çek
                        </button>
                    </div>
                <?php else: ?>
                    <div style="margin-top:20px;"></div>
                <?php endif; ?>
            </div>
            
            <!-- Aktif yatırım kartı: TAB BLOĞUNUN ÜSTÜNDE -->
            <?php if (!empty($activeDeposit)): ?>
                <div class="bw-active-deposit-wrap">
                    <div class="bw-active-deposit-bar" id="active-deposit-card">
                        <button type="button"
                                class="bw-active-deposit-toggle"
                                onclick="toggleActiveDepositDetails()">

                            <div class="bw-active-deposit-left">
                                <span class="bw-pulse-dot"></span>
                                <span class="bw-active-label">Bekleyen talebiniz var.</span>
                                <span class="bw-active-amount">
                                    ₺<?= number_format($activeDeposit['amount_try'], 2, ',', '.') ?>
                                </span>
                            </div>

                            <div class="bw-active-deposit-right">
                                <span class="bw-active-status-badge">Bekliyor</span>
                                <span class="bw-active-chevron" id="active-deposit-chevron">▼</span>
                            </div>
                        </button>

                        <div class="bw-active-deposit-details" id="active-deposit-details">
                           <div class="bw-active-detail-row bw-iban-row">
    <div class="bw-iban-label-block">
        <span class="bw-iban-label-main">Gönderilecek IBAN</span>
        <?php if (!empty($ibanHolder)): ?>
            <span class="bw-iban-label-sub">
                <?= htmlspecialchars($ibanHolder) ?>
            </span>
        <?php endif; ?>
    </div>

    <div class="bw-iban-copy-wrap">
        <span class="bw-iban-text" id="active-iban-text">
            <?= htmlspecialchars($ibanValue) ?>
        </span>

        <button type="button"
                class="bw-iban-copy-btn"
                data-copy-text="<?= htmlspecialchars($ibanValue) ?>"
                onclick="DEPOSIT_APP.copyToClipboard(this, 'active-iban')">
            Kopyala
        </button>
    </div>
</div>
                            <div class="bw-active-detail-row">
                                <span>Yatırım Tutarı</span>
                                <strong>₺<?= number_format($activeDeposit['amount_try'], 2, ',', '.') ?></strong>
                            </div>

                            <div class="bw-active-detail-row">
                                <span>Durum</span>
                                <strong>Onay bekleniyor</strong>
                            </div>

                            <form method="post" id="cancel-deposit-form">
                                <?= csrf_field(); ?>
                                <input type="hidden" name="cancel_deposit" value="1">
                                <input type="hidden" name="cancel_deposit_id" value="<?= $activeDeposit['id'] ?>">
                                <button type="submit" class="bw-btn-cancel-deposit">
                                    Talebi İptal Et
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- TABS CONTAINER -->
            <div class="bw-tabs">

                <div class="bw-tab-header">
                    <button class="bw-tab-link is-active" onclick="switchTab(event, 'assets')">Varlıklar</button>
                    <button class="bw-tab-link" onclick="switchTab(event, 'mysites')">Sitelerim</button>
                    <button class="bw-tab-link" onclick="switchTab(event, 'history')">Geçmiş</button>
                </div>

                <div id="assets" class="bw-tab-content is-active">
                    <div class="bw-asset-list">

                        <div class="bw-asset-item" data-coin="USDT">
                            <div class="icon">₮</div>
                            <div class="info">
                                <div class="name">Tether</div>
                                <div class="code">USDT</div>
                            </div>
                            <div class="balance">
                                <div class="crypto">
                                    <?= rtrim(rtrim(number_format($usdtBalance, 6, '.', ''), '0'), '.') ?>
                                </div>
                                <div class="fiat">
                                    ₺<?= number_format($usdtBalance * $rateUsdt, 2, ',', '.') ?>
                                </div>
                            </div>
                        </div>

                        <div class="bw-asset-item" data-coin="TRX" data-disabled="1">
                            <div class="icon">T</div>
                            <div class="info">
                                <div class="name">Tron</div>
                                <div class="code">TRX</div>
                            </div>
                            <div class="balance">
                                <div class="crypto">0,000000</div>
                                <div class="fiat">$0.00</div>
                            </div>
                        </div>

                        <div class="bw-asset-item" data-coin="BTC" data-disabled="1">
                            <div class="icon">₿</div>
                            <div class="info">
                                <div class="name">Bitcoin</div>
                                <div class="code">BTC</div>
                            </div>
                            <div class="balance">
                                <div class="crypto">0,000000</div>
                                <div class="fiat">$0.00</div>
                            </div>
                        </div>

                        <div class="bw-asset-item" data-coin="XRP" data-disabled="1">
                            <div class="icon">✕</div>
                            <div class="info">
                                <div class="name">XRP</div>
                                <div class="code">XRP</div>
                            </div>
                            <div class="balance">
                                <div class="crypto">0,000000</div>
                                <div class="fiat">$0.00</div>
                            </div>
                        </div>

                        <div class="bw-asset-item" data-coin="DOGE" data-disabled="1">
                            <div class="icon">Ð</div>
                            <div class="info">
                                <div class="name">Dogecoin</div>
                                <div class="code">DOGE</div>
                            </div>
                            <div class="balance">
                                <div class="crypto">0,000000</div>
                                <div class="fiat">$0.00</div>
                            </div>
                        </div>

                        <div class="bw-asset-item" data-coin="LTC" data-disabled="1">
                            <div class="icon">Ł</div>
                            <div class="info">
                                <div class="name">Litecoin</div>
                                <div class="code">LTC</div>
                            </div>
                            <div class="balance">
                                <div class="crypto">0,000000</div>
                                <div class="fiat">$0.00</div>
                            </div>
                        </div>

                        <div class="bw-asset-item" data-coin="ETH" data-disabled="1">
                            <div class="icon">Ξ</div>
                            <div class="info">
                                <div class="name">Ethereum</div>
                                <div class="code">ETH</div>
                            </div>
                            <div class="balance">
                                <div class="crypto">0,000000</div>
                                <div class="fiat">$0.00</div>
                            </div>
                        </div>

                    </div>

                    <button type="button"
                            class="bw-btn bw-btn-outline bw-block bw-support-btn"
                            style="margin-top: 16px; border-radius: 8px;"
                            onclick="openModal('support-modal')">
                        Destek
                    </button>
                </div>

                <div id="mysites" class="bw-tab-content">
                    <h3 style="font-size: 16px; margin-top: 0; margin-bottom: 20px;">Bağlı Sitelerim</h3>
                    
                    <div class="bw-site-list">
                        <?php if (empty($userLinkedSites)): ?>
                            <p style="text-align: center; padding: 15px 0; color: var(--text-muted);">Henüz bağlı siteniz bulunmamaktadır.</p>
                        <?php else: ?>
                            <?php foreach ($userLinkedSites as $site): ?>
                                <div class="bw-site-list-item">
                                    <div class="bw-site-info">
                                        <div class="bw-site-logo"><?= strtoupper(substr($site['site_name'], 0, 1)) ?></div>
                                        <div>
                                            <div style="font-weight: 600;"><?= htmlspecialchars($site['site_name']) ?></div>
                                            <div class="bw-site-username">Kullanıcı Adı: <?= htmlspecialchars($site['site_username']) ?></div>
                                        </div>
                                    </div>
                                    <div class="bw-site-actions">
                                        <div class="bw-site-balance">
                                            ₺<?= number_format($site['site_balance_try'], 2, ',', '.') ?>
                                        </div>
                                        <button type="button" class="bw-btn bw-btn-primary" style="font-size: 11px; padding: 5px 10px;" 
                                                onclick="DEPOSIT_APP.startTransfer(<?= $site['site_id'] ?>, '<?= htmlspecialchars($site['site_name']) ?>')">
                                            Para Yatır
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    
                    <div class="bw-connect-box" onclick="openModal('site-connect-modal')">
                        <div class="icon">+</div>
                        <div style="font-weight: 700;">Yeni Site Bağla</div>
                        <p style="font-size: 13px; color: #64748b; margin: 5px 0 0;">Cüzdanınızdaki bakiyeyi transfer etmek için gereklidir.</p>
                    </div>
                </div>
            
                <div id="history" class="bw-tab-content">
                    <?php if (empty($recentOperations)): ?>
                        <div class="bw-history-empty">
                            Henüz herhangi bir işlem bulunmuyor.
                        </div>
                    <?php else: ?>
                        <?php foreach ($recentOperations as $op): ?>
                            <?php
                            $amt = (float)$op['amt'];

                            $isTransfer = in_array($op['type'], ['site_transfer_out','site_transfer_in'], true);

                          switch ($op['type']) {
    case 'deposit':
        $label       = 'Yatırım';
        $sign        = '+';
        $amountClass = 'positive';
        $chipClass   = 'bw-history-chip bw-history-chip--deposit';
        break;

    case 'withdraw':
        $label       = 'Çekim';
        $sign        = '-';
        $amountClass = 'negative';
        // $chipClass default kalsın
        break;

    case 'site_transfer_out':
        $label       = 'Transfer';
        $sign        = '-';
        $amountClass = 'negative';
        // $chipClass default kalsın
        break;

    case 'site_transfer_in':
        $label       = 'Transfer';
        $sign        = '+';
        $amountClass = 'positive';
        // $chipClass default kalsın
        break;

    default:
        $label       = ucfirst($op['type']);
        $sign        = '';
        $amountClass = '';
        // $chipClass default kalsın
}


                            $siteName = $op['site_name'] ?? '';

                            $statusRaw = strtolower(trim(
                                $op['status']
                                    ?? $op['deposit_status']
                                    ?? $op['withdraw_status']
                                    ?? $op['wr_status']
                                    ?? ''
                            ));

                            if ($statusRaw === 'pending') {
                                $status_text  = 'Bekliyor';
                                $status_class = 'pending';

                            } elseif (in_array($statusRaw, ['approved','confirmed','success','paid'], true)) {
                                $status_text  = 'Tamamlandı';
                                $status_class = 'success';

                            } elseif (in_array($statusRaw, ['user_cancelled','user_canceled'], true)) {
                                $status_text  = 'Kullanıcı İptal Etti';
                                $status_class = 'failed';

                            } elseif (in_array($statusRaw, ['rejected','cancelled','canceled','expired','failed'], true)) {
                                $status_text  = 'İptal / Red';
                                $status_class = 'failed';

                            } else {
                                $status_text  = ucfirst($statusRaw ?: 'Bilinmiyor');
                                $status_class = 'pending';
                            }
                            ?>

                            <div class="bw-history-item">
    <div class="info">
        <div class="type">
            <?php if ($isTransfer): ?>
                <span class="bw-history-chip bw-history-chip--transfer">Transfer</span>
                <?php if (!empty($siteName)): ?>
                    <span class="bw-history-site">
                        <?= htmlspecialchars($siteName) ?>
                    </span>
                <?php endif; ?>
            <?php else: ?>
                <span class="<?= htmlspecialchars($chipClass) ?>">
                    <?= htmlspecialchars($label) ?>
                </span>
            <?php endif; ?>
        </div>
        <div class="date">
            <?= date('d/m/Y H:i', strtotime($op['created_at'])) ?>
        </div>
    </div>

    <div class="amount-status">
        <div class="amount <?= htmlspecialchars($amountClass) ?>">
            <?= $sign . number_format($amt, 2, ',', '.') ?> TL
        </div>
        <div class="status <?= htmlspecialchars($status_class) ?>">
            <?= htmlspecialchars($status_text) ?>
        </div>
    </div>
</div>


                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

            </div> <!-- /.bw-tabs -->

        </div> <!-- /.bw-center-page -->
    </div> <!-- /#view-wallet -->
    
    <?php include __DIR__ . '/partials/deposit_modal.php'; ?>
    <?php include __DIR__ . '/partials/transfer_modal.php'; ?>
    <?php include __DIR__ . '/partials/site_connect_modal.php'; ?>
    <?php include __DIR__ . '/partials/bank_account_modal.php'; ?>
    <?php include __DIR__ . '/partials/withdraw_modal.php'; ?>
    <?php include __DIR__ . '/partials/support_modal.php'; ?>

    <?php include __DIR__ . '/partials/user_panel.php'; ?>

</div> <!-- /.app-frame -->

<?php if ($error): ?>
    <div class="bw-feedback-card danger" onclick="this.remove()">
        <span><?= htmlspecialchars($error) ?></span>
    </div>
<?php endif; ?>
<?php if ($success): ?>
    <div class="bw-feedback-card success" onclick="this.remove()">
        <span><?= htmlspecialchars($success) ?></span>
    </div>
<?php endif; ?>

<script>
window.BW_CONFIG = window.BW_CONFIG || {};
window.BW_CONFIG.rates   = window.BW_CONFIG.rates   || {};
window.BW_CONFIG.wallets = window.BW_CONFIG.wallets || {};
window.BW_CONFIG.ibans   = window.BW_CONFIG.ibans   || [];

// Admin/settings.php'den gelen kur
window.BW_CONFIG.rates.USDT = <?= json_encode((float)($rateUsdt ?? 0)); ?>;

// Kullanıcının USDT bakiyesi
window.BW_CONFIG.user_balance_usdt = <?= json_encode((float)($usdtBalance ?? 0)); ?>;

// Eski kodlarla uyum için global kopya
window.USER_BALANCE_USDT = window.BW_CONFIG.user_balance_usdt;

// Polling endpoint ve CSRF
window.STATUS_API_URL = '<?= htmlspecialchars($statusApiUrl); ?>';
window.CSRF_TOKEN     = '<?= htmlspecialchars($csrfToken); ?>';
</script>

<!-- 2) UYGULAMA JS DOSYALARI -->
<script src="<?php echo $baseUrl; ?>/public/assets/js/wallet/config.js"></script>
<script src="<?php echo $baseUrl; ?>/public/assets/js/wallet/utils.js"></script>
<script src="<?php echo $baseUrl; ?>/public/assets/js/wallet/theme.js"></script>
<script src="<?php echo $baseUrl; ?>/public/assets/js/wallet/modals.js"></script>
<script src="<?php echo $baseUrl; ?>/public/assets/js/wallet/deposit_app.js"></script>
<script src="<?php echo $baseUrl; ?>/public/assets/js/wallet/user_panel.js"></script>
<script src="<?php echo $baseUrl; ?>/public/assets/js/wallet/init.js"></script>

<script>
// ==============================
// Aktif Yatırım Detay Toggle
// ==============================
function toggleActiveDepositDetails() {
    var details  = document.getElementById('active-deposit-details');
    var chevron  = document.getElementById('active-deposit-chevron');

    if (!details) return;

    var isOpen = details.classList.contains('is-open');

    if (isOpen) {
        details.style.maxHeight = '0';
        details.classList.remove('is-open');
        if (chevron) chevron.textContent = '▼';
    } else {
        details.classList.add('is-open');
        details.style.maxHeight = details.scrollHeight + 'px';
        if (chevron) chevron.textContent = '▲';
    }
}
</script>

<?php
$viewParam      = $_GET['v']     ?? null;
$activeTicketId = isset($_GET['ticket']) ? (int)$_GET['ticket'] : 0;
?>

<?php if ($viewParam === 'support'): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    if (typeof openModal === 'function') {
        openModal('support-modal');
    }
});
</script>
<?php endif; ?>

<?php if (!empty($_SESSION['auto_open_deposit_modal'])): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    if (typeof openModal !== 'function') return;

    openModal('deposit-modal');

    var step1   = document.getElementById('deposit-step-1');
    var havale1 = document.getElementById('deposit-step-havale-1');
    var havale2 = document.getElementById('deposit-step-havale-2');
    var backBtn = document.getElementById('deposit-back-btn');

    if (step1) {
        step1.classList.remove('is-active');
        step1.style.display = 'none';
    }
    if (havale1) havale1.classList.remove('is-active');
    if (havale2) {
        havale2.classList.add('is-active');
        havale2.style.display = '';
    }
    if (backBtn) backBtn.style.display = 'none';
});
</script>
<?php unset($_SESSION['auto_open_deposit_modal']); ?>
<?php endif; ?>

</body>
</html>