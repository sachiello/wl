<div class="bw-modal-backdrop" id="withdraw-modal">
        <div class="bw-modal center-modal">
            <div class="bw-modal-title">Para Çek</div>

            <?php if (empty($userBankAccounts)): ?>
                <p class="bw-text-muted" style="text-align:center; margin-bottom:20px;">
                    Henüz kayıtlı banka hesabınız (IBAN) bulunmamaktadır.
                </p>

                <button type="button"
                        class="bw-btn bw-btn-primary bw-block"
                        onclick="openModal('bank-account-modal')">
                    IBAN Ekle
                </button>

                <button type="button"
                        class="bw-btn bw-btn-outline bw-block"
                        onclick="closeModal('withdraw-modal')"
                        style="margin-top:10px;">
                    Kapat
                </button>

            <?php else: ?>

                <form method="post" id="withdraw-form">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="create_withdraw" value="1">
                    <input type="hidden" name="withdraw_method" value="bank">
                    <input type="hidden" name="withdraw_bank_account_id" id="withdraw-bank-account-id" value="0">

                    <p class="bw-text-muted" style="text-align:center; margin-bottom:16px;">
                        Çekim yapılacak banka hesabını seçin ve tutarı girin.
                    </p>

                    <div id="bank-account-list">
                        <button type="button"
                                class="bw-btn bw-btn-outline bw-block"
                                style="margin-top:10px;"
                                onclick="openModal('bank-account-modal')">
                            Yeni IBAN Ekle
                        </button>
                        <?php foreach ($userBankAccounts as $acc): ?>
                            <?php
                                $maskedIban = $acc['iban'];
                                if (strlen($maskedIban) > 10) {
                                    $maskedIban = substr($maskedIban, 0, 6) . ' **** **** ' . substr($maskedIban, -4);
                                }
                            ?>
                            
                            <div class="site-select-item bank-account-item"
                                 onclick="DEPOSIT_APP.selectBankAccount(this, <?= (int)$acc['id']; ?>)">
                                <div class="site-initial-logo">
                                    <?= strtoupper(substr($acc['bank_name'], 0, 1)); ?>
                                </div>
                                <div style="flex-grow:1;">
                                    <div style="font-weight:600;"><?= htmlspecialchars($acc['bank_name']); ?></div>
                                    <div style="font-size:12px; color:#64748b;">
                                        <?= htmlspecialchars($acc['account_holder']); ?>
                                    </div>
                                    <div style="font-size:12px; color:#94a3b8;">
                                        <?= htmlspecialchars($maskedIban); ?>
                                    </div>
                                </div>
                                <span class="bank-account-check" style="font-size:12px; color:#64748b;">
                                    Seç
                                </span>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="bw-form-group" style="margin-top:15px;">
                        <label class="bw-label">Çekilecek Tutar (TL)</label>
                        <div class="bw-input-amount-wrapper">
                            <input type="number"
                                   name="withdraw_amount_try"
                                   class="bw-input bw-input-amount"
                                   placeholder="0.00"
                                   min="0"
                                   step="0.01"
                                   required>
                            <span class="bw-input-suffix">TRY</span>
                        </div>
                        <div class="bw-help-text">
                            Mevcut yaklaşık bakiyeniz:
                            ₺<?= number_format($usdtBalance * $rateUsdt, 2, ',', '.') ?>
                            (<?= rtrim(rtrim(number_format($usdtBalance, 6, '.', ''), '0'), '.') ?> USDT)
                        </div>
                    </div>

                    <div id="withdraw-error-display"
                         class="bw-feedback-card danger"
                         style="display:none; font-size:13px; margin-bottom:10px;"></div>

                    <button type="submit" class="bw-btn bw-btn-primary bw-block" style="margin-top:10px;">
                        Çekim Talebi Gönder
                    </button>
                    <button type="button" class="bw-btn bw-btn-outline bw-block"
                            onclick="closeModal('withdraw-modal')" style="margin-top:10px;">
                        Vazgeç
                    </button>
                </form>

            <?php endif; ?>
        </div>
    </div>