<!-- DESTEK / TICKET MODAL -->
<div class="bw-modal-backdrop" id="support-modal">
    <div class="bw-modal center-modal support-modal">

        <div class="support-modal-header">
            <div class="bw-modal-title">Destek Merkezi</div>
            <button type="button"
                    class="support-close-btn"
                    onclick="closeModal('support-modal')">
                &times;
            </button>
        </div>

        <!-- 3 view için radio kontrolleri -->
        <input type="radio" name="support_view" id="sv-new" class="support-view-radio" checked>
        <input type="radio" name="support_view" id="sv-list" class="support-view-radio">
        <input type="radio" name="support_view" id="sv-thread" class="support-view-radio">

        <div class="support-modal-body">

            <!-- ============== VIEW 1: YENİ DESTEK TALEBİ ============== -->
            <div class="support-view support-view-new">
                
                    

                    <form method="post" class="support-new-ticket-form">
                        <?= csrf_field(); ?>
                        <input type="hidden" name="create_ticket" value="1">

                        <div class="bw-form-group">
                            <label class="bw-label">Konu</label>
                            <input type="text"
                                   name="ticket_subject"
                                   class="bw-input"
                                   placeholder="Örn: Yatırımım henüz yansımadı"
                                   required>
                        </div>

                        <div class="bw-form-group">
                            <label class="bw-label">Mesajınız</label>
                            <textarea name="ticket_message"
                                      class="bw-input"
                                      rows="3"
                                      placeholder="Yaşadığınız sorunu detaylıca yazın..."
                                      required></textarea>
                        </div>

                        <button type="submit"
                                class="bw-btn bw-btn-primary bw-block"
                                style="margin-top:8px;">
                            Talebi Gönder
                        </button>
                    </form>

                    <!-- Taleplerim sekmesine geçiş -->
                    <label for="sv-list" class="support-link-btn">
                        Taleplerim
                    </label>
                
            </div>

            <!-- ============== VIEW 2: TALEPLERİM (LİSTE) ============== -->
            <div class="support-view support-view-list">
                
                    <div class="support-step-title"></div>
                    

                    <?php if (!empty($myTickets)): ?>
                        <div class="support-ticket-list">
                            <?php foreach ($myTickets as $t): ?>
                                <?php
                                    $tid         = (int)$t['id'];
                                    $statusRaw   = strtolower($t['status'] ?? 'open');
                                    $createdAt   = $t['created_at'] ?? $t['last_message_at'] ?? null;
                                    $createdText = $createdAt ? date('d.m.Y H:i', strtotime($createdAt)) : '';

                                    if ($statusRaw === 'open') {
                                        $statusLabel = 'Açık';
                                        $statusClass = 'open';
                                    } elseif ($statusRaw === 'closed') {
                                        $statusLabel = 'Kapalı';
                                        $statusClass = 'closed';
                                    } else {
                                        $statusLabel = ucfirst($statusRaw);
                                        $statusClass = 'open';
                                    }
                                ?>
                                <!-- Label: hem JS için data-ticket-id, hem de THREAD view'ini açmak için for="sv-thread" -->
                                <label class="support-ticket-item"
                                       data-ticket-id="<?= $tid ?>"
                                       for="sv-thread">
                                    <div class="support-ticket-main">
                                        <div class="support-ticket-subject">
                                            <?= htmlspecialchars($t['subject']) ?>
                                        </div>
                                        <div class="support-ticket-meta">
                                            <span class="support-ticket-date">
                                                <?= htmlspecialchars($createdText) ?>
                                            </span>
                                            <span class="support-ticket-status support-ticket-status--<?= $statusClass ?>">
                                                <?= htmlspecialchars($statusLabel) ?>
                                            </span>
                                        </div>
                                    </div>
                                    <span class="support-ticket-arrow">›</span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="bw-text-muted" style="font-size:13px; margin-top:6px;">
                            Henüz oluşturduğunuz bir destek talebi bulunmamaktadır.
                        </p>
                    <?php endif; ?>

                    <!-- Geri: Yeni Talep Aç sekmesine dön -->
                    <label for="sv-new" class="support-link-btn" style="margin-top:12px;">
                        Yeni Destek Talebi Aç
                    </label>
                
            </div>

            <!-- ============== VIEW 3: TALEP KONUŞMASI ============== -->
            <div class="support-view support-view-thread">
                
                    <div class="support-thread-header">
                        <div>
                            <div class="support-thread-title"></div>
                            
                        </div>

                        <!-- Geri: Taleplerim listesine dön -->
                        <label for="sv-list" class="support-back-link">
                            ← Taleplerim
                        </label>
                    </div>

                    <?php if (!empty($myTickets)): ?>
                        <?php foreach ($myTickets as $t): ?>
                            <?php $tid = (int)$t['id']; ?>
                            <div class="support-thread"
                                 data-ticket-id="<?= $tid ?>"
                                 style="display:none;">

                                <?php if (!empty($ticketThreads[$tid])): ?>
                                    <div class="support-ticket-thread">
                                        <?php foreach ($ticketThreads[$tid] as $msg): ?>
                                            <?php
                                                $isAdmin   = (int)$msg['is_admin'] === 1;
                                                $msgDate   = date('d.m.Y H:i', strtotime($msg['created_at']));
                                                $msgClass  = $isAdmin ? 'from-admin' : 'from-user';
                                                $senderLbl = $isAdmin ? 'Destek Ekibi' : 'Siz';
                                            ?>
                                            <div class="support-message <?= $msgClass ?>">
                                                <div class="support-message-meta">
                                                    <span class="support-message-sender"><?= $senderLbl ?></span>
                                                    <span class="support-message-date"><?= htmlspecialchars($msgDate) ?></span>
                                                </div>
                                                <div class="support-message-body">
                                                    <?= nl2br(htmlspecialchars($msg['message'])) ?>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <p class="bw-text-muted" style="font-size:13px;">
                                        Bu destek talebi için henüz mesaj bulunmamaktadır.
                                    </p>
                                <?php endif; ?>

                                <!-- CEVAP FORMU -->
                                <form method="post" class="support-reply-form">
                                    <?= csrf_field(); ?>
                                    <input type="hidden" name="reply_ticket" value="1">
                                    <input type="hidden" name="ticket_id" value="<?= $tid ?>">

                                    <div class="bw-form-group" style="margin-top:8px;">
                                        <label class="bw-label">Cevabınız</label>
                                        <textarea name="reply_message"
                                                  class="bw-input"
                                                  rows="3"
                                                  placeholder="Yeni mesajınızı yazın..."
                                                  required></textarea>
                                    </div>

                                    <button type="submit"
                                            class="bw-btn bw-btn-primary bw-block"
                                            style="margin-top:8px;">
                                        Mesaj Gönder
                                    </button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="bw-text-muted" style="font-size:13px;">
                            Henüz bir destek talebiniz bulunmuyor. Önce yeni bir talep oluşturun.
                        </p>
                    <?php endif; ?>
               
            </div>

        </div>
    </div>
</div>
<style>
/* =========================================
   DESTEK MODALI – GENEL STİL (LIGHT + DARK)
   ========================================= */

/* Modal container */
#support-modal .support-modal {
    max-width: 840px;
    width: 100%;
    background: #ffffff;
    border-radius: 18px;
    border: 1px solid #e5e7eb;
    box-shadow: 0 24px 60px rgba(15, 23, 42, 0.85);
    overflow: hidden;
}

/* DARK MODE – Modal */
body.dark-mode #support-modal .support-modal,
body[data-theme="dark"] #support-modal .support-modal {
    background: #020617 !important;
    border-color: #1f2937 !important;
}

/* =========================================
   HEADER – DESTEK MERKEZİ
   ========================================= */
#support-modal .support-modal-header {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center; /* Başlık ortada */
    padding: 10px 40px;
    border-bottom: 1px solid #e5e7eb;
    background: #ffffff !important; /* Gradient kaldırıldı */
}

/* Header title */
#support-modal .support-modal-header .bw-modal-title {
    margin: 0;
    flex: 0 0 auto;
    font-size: 14px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    text-align: center;
    color: #991b1b;
}

/* Close butonu sağ üstte */
#support-modal .support-close-btn {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    width: 28px;
    height: 28px;
    border-radius: 999px;
    border: none;
    background: #f1f5f9;
    color: #64748b;
    font-size: 18px;
    line-height: 1;
    padding: 0;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    transition: background 0.15s ease, color 0.15s ease, box-shadow 0.15s ease;
}

#support-modal .support-close-btn:hover {
    background: #dc2626;
    color: #ffffff;
    box-shadow: 0 0 0 1px rgba(220, 38, 38, 0.3);
}

/* DARK – Header + close */
body.dark-mode #support-modal .support-modal-header,
body[data-theme="dark"] #support-modal .support-modal-header {
    background: #0f172a !important;
    border-color: #1f2937 !important;
}

body.dark-mode #support-modal .support-modal-header .bw-modal-title,
body[data-theme="dark"] #support-modal .support-modal-header .bw-modal-title {
    color: white !important;
}

body.dark-mode #support-modal .support-close-btn,
body[data-theme="dark"] #support-modal .support-close-btn {
    background: transparent;
    color: #e5e7eb;
}

body.dark-mode #support-modal .support-close-btn:hover,
body[data-theme="dark"] #support-modal .support-close-btn:hover {
    background: rgba(248, 113, 113, 0.15);
    color: #fecaca;
}

/* =========================================
   BODY & VIEW YAPISI
   ========================================= */
#support-modal .support-modal-body {
    margin-top: 8px;
    padding: 0 16px 16px 16px;
}

/* View container’lar */
#support-modal .support-view {
    display: none;
}

/* Radio tab kontrolcülerini gizle */
#support-modal .support-view-radio {
    display: none;
}

/* NEW sekmesi */
#sv-new:checked ~ .support-modal-body .support-view-new {
    display: block;
}

/* LIST sekmesi */
#sv-list:checked ~ .support-modal-body .support-view-list {
    display: block;
}

/* THREAD sekmesi */
#sv-thread:checked ~ .support-modal-body .support-view-thread {
    display: block;
}

/* Kart genel */
#support-modal .support-card {
    background: #ffffff;
    border-radius: 14px;
    border: 1px solid #e5e7eb;
    padding: 10px 12px 12px 12px;
}

/* DARK – kart, body */
body.dark-mode #support-modal .support-modal-body,
body[data-theme="dark"] #support-modal .support-modal-body {
    color: #e5e7eb;
}

body.dark-mode #support-modal .support-card,
body[data-theme="dark"] #support-modal .support-card {
    background: #020617;
    border-color: #1f2937;
}

/* Başlık / alt başlık */
#support-modal .support-step-title {
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 4px;
    color: #0f172a;
}

#support-modal .support-step-subtitle {
    font-size: 12px;
    color: #6b7280;
    margin-bottom: 10px;
}

body.dark-mode #support-modal .support-step-title,
body[data-theme="dark"] #support-modal .support-step-title {
    color: #f9fafb;
}

body.dark-mode #support-modal .support-step-subtitle,
body[data-theme="dark"] #support-modal .support-step-subtitle {
    color: #9ca3af;
}

/* =========================================
   “TALEPLERİM” / “YENİ TALEP” BUTONLARI
   – ORTALANMIŞ & KIRMIZI TON
   ========================================= */
#support-modal .support-link-btn {
    display: flex;                 /* Ortalamak için */
    align-items: center;
    justify-content: center;
    margin: 10px auto 0 auto;      /* Ortaya al */
    font-size: 12px;
    font-weight: 500;
    padding: 6px 16px;
    border-radius: 9px;
    border: 1px solid #dc2626;
    color: #fef2f2;
    background: linear-gradient(135deg, #ef4444, #b91c1c);           /* Açık pembe yerine kırmızı */
    cursor: pointer;
    text-decoration: none;
    transition: all 0.15s ease;
}



/* DARK – link butonları */
body.dark-mode #support-modal .support-link-btn,
body[data-theme="dark"] #support-modal .support-link-btn {
    color: white;
    border-color: red;
    background: transparent;
}

/* =========================================
   TICKET LİSTESİ
   ========================================= */
#support-modal .support-ticket-list {
    margin-top: 4px;
    max-height: 230px;
    overflow-y: auto;
}

#support-modal .support-ticket-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8px 10px;
    margin-bottom: 4px;
    border-radius: 8px;
    text-decoration: none;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    transition: background 0.15s ease, border-color 0.15s ease, transform 0.1s ease;
    cursor: pointer;
}

#support-modal .support-ticket-item:hover {
    background: #eff6ff;
    border-color: #bfdbfe;
    transform: translateY(-1px);
}

body.dark-mode #support-modal .support-ticket-item,
body[data-theme="dark"] #support-modal .support-ticket-item {
    background: rgba(15, 23, 42, 0.9);
    border-color: #1f2937;
}

body.dark-mode #support-modal .support-ticket-item:hover,
body[data-theme="dark"] #support-modal .support-ticket-item:hover {
    background: rgba(30, 64, 175, 0.35);
    border-color: #3b82f6;
}

#support-modal .support-ticket-main {
    display: flex;
    flex-direction: column;
    gap: 3px;
    flex: 1;
    min-width: 0;
}

#support-modal .support-ticket-subject {
    font-size: 13px;
    font-weight: 600;
    color: #0f172a;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

body.dark-mode #support-modal .support-ticket-subject,
body[data-theme="dark"] #support-modal .support-ticket-subject {
    color: #e5e7eb;
}

#support-modal .support-ticket-meta {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 11px;
}

#support-modal .support-ticket-date {
    color: #94a3b8;
}

/* Status badge */
#support-modal .support-ticket-status {
    padding: 2px 8px;
    border-radius: 999px;
    font-size: 10px;
    font-weight: 600;
}

#support-modal .support-ticket-status--open {
    background: #dcfce7;
    color: #15803d;
}

/* Closed için de pembe yerine kırmızımsı ton */
#support-modal .support-ticket-status--closed {
    background: rgba(220, 38, 38, 0.12);
    color: #b91c1c;
}

body.dark-mode #support-modal .support-ticket-status--open,
body[data-theme="dark"] #support-modal .support-ticket-status--open {
    background: rgba(22, 163, 74, 0.14);
    color: #4ade80;
}

body.dark-mode #support-modal .support-ticket-status--closed,
body[data-theme="dark"] #support-modal .support-ticket-status--closed {
    background: rgba(220, 38, 38, 0.16);
    color: #fca5a5;
}

#support-modal .support-ticket-arrow {
    font-size: 16px;
    color: #cbd5e1;
    margin-left: 8px;
}

body.dark-mode #support-modal .support-ticket-arrow,
body[data-theme="dark"] #support-modal .support-ticket-arrow {
    color: #9ca3af;
}

/* =========================================
   THREAD HEADER & BACK LINK
   ========================================= */
#support-modal .support-thread-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 8px;
    margin-bottom: 8px;
    border-bottom: 1px solid #e5e7eb;
    padding-bottom: 6px;
}

#support-modal .support-thread-title {
    font-size: 13px;
    font-weight: 600;
    color: #0f172a;
}

#support-modal .support-thread-subject {
    font-size: 12px;
    color: #6b7280;
}

#support-modal .support-back-link {
    font-size: 12px;
    font-weight: 500;
    color: #b91c1c !important;
    cursor: pointer;
    text-decoration: none;
}

#support-modal .support-back-link:hover {
    opacity: 0.8 !important;
}

/* DARK – thread header & back link */
body.dark-mode #support-modal .support-thread-header,
body[data-theme="dark"] #support-modal .support-thread-header {
    border-bottom-color: #1f2937;
}

body.dark-mode #support-modal .support-thread-title,
body[data-theme="dark"] #support-modal .support-thread-title {
    color: #f9fafb;
}

body.dark-mode #support-modal .support-thread-subject,
body[data-theme="dark"] #support-modal .support-thread-subject {
    color: #9ca3af;
}

body.dark-mode #support-modal .support-back-link,
body[data-theme="dark"] #support-modal .support-back-link {
    color: white !important;
}

/* =========================================
   THREAD MESAJ ALANI & MESAJ BALONLARI
   ========================================= */
#support-modal .support-ticket-thread {
    background: #f9fafb;
    border-radius: 10px;
    padding: 8px;
}

body.dark-mode #support-modal .support-ticket-thread,
body[data-theme="dark"] #support-modal .support-ticket-thread {
    background: radial-gradient(circle at top, rgba(15, 23, 42, 0.9), #020617);
}

/* Mesaj wrapper */
#support-modal .support-message {
    margin-bottom: 8px;
    color: #111827;
}

body.dark-mode #support-modal .support-message,
body[data-theme="dark"] #support-modal .support-message {
    color: #e5e7eb;
}

/* Meta */
#support-modal .support-message-meta {
    font-size: 11px;
    margin-bottom: 3px;
    color: #6b7280;
    display: flex;
    justify-content: space-between;
    gap: 6px;
}

body.dark-mode #support-modal .support-message-meta,
body[data-theme="dark"] #support-modal .support-message-meta {
    color: #9ca3af;
}

/* Varsayılan mesaj gövdesi (light) */
#support-modal .support-message-body {
    background: #f3f4f6 !important;
    border-radius: 12px !important;
    padding: 8px 10px !important;
    border: none !important;
    color: #111827 !important;
}

/* DARK – genel mesaj gövdesi */
body.dark-mode #support-modal .support-message-body,
body[data-theme="dark"] #support-modal .support-message-body {
    background: rgba(15, 23, 42, 0.95) !important;
    color: #e5e7eb !important;
}

/* Kullanıcı mesajı (from-user) – açık pembe yerine kırmızı */
#support-modal .support-message.from-user .support-message-body {
    background: #dc2626 !important;
    color: #fee2e2 !important;
}

/* Admin mesajı (from-admin) – light */
#support-modal .support-message.from-admin .support-message-body {
    background: #eff6ff !important;
    color: #1e3a8a !important;
}

/* DARK – kullanıcı mesajı */
body.dark-mode #support-modal .support-message.from-user .support-message-body,
body[data-theme="dark"] #support-modal .support-message.from-user .support-message-body {
    background: linear-gradient(135deg, rgba(220,38,38,0.45), rgba(127,29,29,0.75)) !important;
    border: 1px solid rgba(220,38,38,0.6) !important;
    color: #fee2e2 !important;
}

/* DARK – admin mesajı */
body.dark-mode #support-modal .support-message.from-admin .support-message-body,
body[data-theme="dark"] #support-modal .support-message.from-admin .support-message-body {
    background: rgba(15, 23, 42, 0.9) !important;
    border: 1px solid #1f2937 !important;
    color: #e5e7eb !important;
}

/* =========================================
   MUTED TEXT (Henüz talebiniz yok vs.)
   ========================================= */
body.dark-mode #support-modal .bw-text-muted,
body[data-theme="dark"] #support-modal .bw-text-muted {
    color: #9ca3af !important;
}
</style>
