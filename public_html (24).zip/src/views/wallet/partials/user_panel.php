<?php
// Bu örnekte PHP tarafında kullanıcı / banka / site verilerini kullanıyorum.
// Bunları zaten bir yerde çekiyor olmalısın. Örnek değişkenler:
$username      = $currentUser['username']
    ?? ($currentUser['name'] ?? ($sessionUsername ?? ''));
$userId        = $currentUser['id'] ?? ($sessionUserId ?? null);
$email         = $currentUser['email'] ?? '';
$createdAt     = $currentUser['created_at'] ?? '';
$totalBalanceTry = $currentUser['total_balance_try'] ?? null;

$bankAccounts = $userBankAccounts ?? [];
$linkedSites  = $userLinkedSites ?? [];

$twofaEnabled = !empty($currentUser['twofa_enabled']); 
$csrfToken    = $_SESSION['csrf_token'] ?? '';
?>
<div id="user-modal-overlay" class="bwup-user-modal-overlay">

    <div class="user-modal bwup-user-modal">

        <div class="user-modal-header">
            <h3 id="user-modal-title"></h3>
            <button type="button" class="user-modal-close" onclick="USER_PANEL.closeModal()">&times;</button>
        </div>

        <div id="user-modal-body" class="user-modal-body">
            <!-- HESAP ÖZETİ İÇERİĞİ -->
            <div class="user-modal-content" data-modal-type="account">
                <div class="user-modal-section">
                    <h4>Genel Bilgiler</h4>
                    <div class="user-summary-grid">
                        <div class="user-summary-card">
                            <span class="label">Kullanıcı Adı</span>
                            <span class="value"><?= htmlspecialchars($username) ?></span>
                        </div>

                        <?php if ($userId): ?>
                            <div class="user-summary-card">
                                <span class="label">Kullanıcı ID</span>
                                <span class="value">#<?= (int)$userId ?></span>
                            </div>
                        <?php endif; ?>

                        <?php if ($email): ?>
                            <div class="user-summary-card">
                                <span class="label">E-posta</span>
                                <span class="value"><?= htmlspecialchars($email) ?></span>
                            </div>
                        <?php endif; ?>

                        <?php if ($createdAt): ?>
                            <div class="user-summary-card">
                                <span class="label">Üyelik Tarihi</span>
                                <span class="value"><?= htmlspecialchars(substr($createdAt, 0, 10)) ?></span>
                            </div>
                        <?php endif; ?>

                        <?php if ($totalBalanceTry !== null): ?>
                            <div class="user-summary-card">
                                <span class="label">Toplam Bakiye (≈ TL)</span>
                                <span class="value">
                                    ₺<?= number_format((float)$totalBalanceTry, 2, ',', '.') ?>
                                </span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="user-modal-section">
                    <h4>Banka Hesaplarım</h4>
                    <ul class="user-list">
                        <?php if (!empty($bankAccounts)): ?>
                            <?php foreach (array_slice($bankAccounts, 0, 3) as $acc): ?>
                                <?php
                                    $bankName = $acc['bank_name'] ?? $acc['bank'] ?? 'Banka';
                                    $holder   = $acc['account_holder'] ?? $acc['full_name'] ?? '';
                                    $iban     = $acc['iban'] ?? '';
                                    // JS’deki bw_mask_iban fonksiyonunun PHP versiyonunu da yazabilirsin
                                    $masked   = $iban ? substr($iban, 0, 8) . '****' . substr($iban, -4) : '';
                                ?>
                                <li class="user-list-item">
                                    <div class="user-list-main">
                                        <div class="user-list-title"><?= htmlspecialchars($bankName) ?></div>
                                        <div class="user-list-sub"><?= htmlspecialchars($holder) ?></div>
                                        <div class="user-list-sub mute"><?= htmlspecialchars($masked) ?></div>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <li class="user-list-item empty">
                                <div class="user-list-main">
                                    <div class="user-list-title">Kayıtlı banka hesabınız yok.</div>
                                    <div class="user-list-sub mute">Çekim için IBAN eklemeniz gerekir.</div>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                    <div class="user-list-footer">
                        <button type="button"
                                class="user-quick-btn outline"
                                onclick="USER_PANEL.closeModal(); openModal('bank-account-modal');">
                            Yeni IBAN Ekle
                        </button>
                    </div>
                </div>

                
                <div class="user-modal-section">
    <h4>Hızlı Aksiyonlar</h4>
    <div class="user-quick-actions">
        <!-- 2FA Aç / Yönet -->
        <button type="button"
                class="user-quick-btn"
                onclick="
                    USER_PANEL.openModal('security');
                    (function () {
                        var btn = document.querySelector('.user-modal-tab[data-security-tab=&quot;2fa&quot;]');
                        if (btn) btn.click();
                    })();
                ">
            2FA'yı Aç
        </button>

        <!-- Şifre Değiştir -->
        <button type="button"
                class="user-quick-btn outline"
                onclick="
                    USER_PANEL.openModal('security');
                    (function () {
                        var btn = document.querySelector('.user-modal-tab[data-security-tab=&quot;password&quot;]');
                        if (btn) btn.click();
                    })();
                ">
            Şifre Değiştir
        </button>
    </div>
</div>

            </div>

            <!-- GÜVENLİK İÇERİĞİ -->
            <div class="user-modal-content" data-modal-type="security">
                <div class="user-modal-section user-security-root">
                    <div class="user-modal-tabs">
                        <button type="button"
                                class="user-modal-tab is-active"
                                data-security-tab="2fa">
                            2FA Güvenlik
                        </button>
                        <button type="button"
                                class="user-modal-tab"
                                data-security-tab="password">
                            Şifre Ayarları
                        </button>
                    </div>

                    <!-- TAB: 2FA -->
                    <div class="user-modal-tab-panel is-active"
                         data-security-panel="2fa">

                        <div id="twofa-alert-box"
                             class="user-security-alert user-security-alert--hidden"></div>

                        <div class="twofa-header">
                            <div class="twofa-icon-circle">
                                <span class="twofa-icon-check">✓</span>
                            </div>
                            <h4 class="twofa-title">
                                <?= $twofaEnabled ? '2FA Zaten Aktif' : '2FA Aktivasyonu' ?>
                            </h4>
                            <p class="twofa-desc">
                                <?php if ($twofaEnabled): ?>
                                    Hesabınız şu anda iki aşamalı doğrulama ile korunuyor.
                                    Aşağıdan 2FA kodu ve şifrenizle devre dışı bırakabilirsiniz.
                                <?php else: ?>
                                    2FA’yı etkinleştirmek için kimlik doğrulama uygulamasında
                                    BetWallet hesabınızı ekleyin ve üretilen 6 haneli kodu aşağıya girin.
                                <?php endif; ?>
                            </p>
                        </div>

                        <div id="twofa-setup-area"
                             class="twofa-setup-area <?= $twofaEnabled ? 'is-hidden' : '' ?>">
                            <div class="twofa-qr-wrap">
                                <img src="" alt="2FA QR Kodu"
                                     class="twofa-qr-img"
                                     id="twofa-qr-image">
                            </div>

                            <form id="twofa-secret-form" class="twofa-secret-form">
                                <div class="bw-form-group">
                                    <label class="bw-label">Secret Key</label>
                                    <input type="text"
                                           id="twofa-secret-key"
                                           name="secret_key"
                                           class="bw-input"
                                           readonly>
                                </div>
                            </form>

                            <div class="twofa-code-field">
                                <label class="bw-label">Uygulamanın Ürettiği 6 Haneli Kod:</label>
                                <div class="twofa-code-input-wrap">
                                    <input type="password"
                                           id="twofa-otp-input"
                                           name="otp_code"
                                           maxlength="6"
                                           inputmode="numeric"
                                           pattern="\d*"
                                           class="bw-input twofa-code-input">
                                    <button type="button"
                                            class="twofa-toggle-visibility"
                                            onclick="toggleTwofaCodeVisibility(this)">
                                        <i class="fa-regular fa-eye"></i>
                                    </button>
                                </div>
                            </div>

                            <!-- 2FA AKTİVASYON FORMU -->
                            <form id="twofa-verify-form" class="user-security-form">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                <input type="hidden" name="action" value="verify_enable_2fa">
                            </form>
                        </div>

                        <div class="user-modal-footer user-modal-footer--between">
                            <span class="user-security-note">
                                <?= $twofaEnabled
                                    ? "2FA’yı kapatırsanız, bir sonraki girişinizde yalnızca şifrenizle giriş yapabilirsiniz."
                                    : "2FA güvenliğinizi artırır, şiddetle önerilir."
                                ?>
                            </span>

                            <?php if ($twofaEnabled): ?>
                                <button type="button"
                                        class="bw-btn-secondary"
                                        id="btn-disable-2fa">
                                    2FA'yı Kapat
                                </button>
                            <?php endif; ?>
                        </div>

                        <div id="twofa-disable-area"
                             class="twofa-disable-area <?= $twofaEnabled ? '' : 'is-hidden' ?>">
                            <h5 class="twofa-disable-title">2FA'yı Kapat</h5>
                            <p class="twofa-disable-desc">
                                Güvenlik için 2FA’yı kapatmadan önce mevcut şifrenizi ve güncel 2FA kodunuzu girmeniz gerekir.
                            </p>

                            <form id="twofa-disable-form" class="user-security-form">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                <input type="hidden" name="action" value="disable_2fa">

                                <div class="bw-form-group">
                                    <label class="bw-label">Mevcut Şifre</label>
                                    <input type="password"
                                           name="current_password"
                                           class="bw-input"
                                           autocomplete="current-password"
                                           required>
                                </div>

                                <div class="bw-form-group">
                                    <label class="bw-label">2FA Kodu</label>
                                    <input type="text"
                                           name="otp_code"
                                           class="bw-input"
                                           inputmode="numeric"
                                           maxlength="6"
                                           pattern="\d*"
                                           required>
                                </div>

                                <div class="user-modal-footer user-modal-footer--right">
                                    <button type="submit"
                                            class="bw-btn-secondary">
                                        Onayla ve 2FA'yı Kapat
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- TAB: ŞİFRE -->
                    <div class="user-modal-tab-panel"
                         data-security-panel="password">
                        <h4>Şifre Değiştir</h4>
                        <div id="password-alert-box"
                             class="user-security-alert user-security-alert--hidden"></div>

                        <form id="user-password-form" class="user-security-form">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                            <input type="hidden" name="action" value="change_password">

                            <div class="bw-form-group">
                                <label class="bw-label">Mevcut Şifre</label>
                                <input type="password" name="current_password" class="bw-input" required>
                            </div>
                            <div class="bw-form-group">
                                <label class="bw-label">Yeni Şifre</label>
                                <input type="password" name="new_password" class="bw-input" required>
                            </div>
                            <div class="bw-form-group">
                                <label class="bw-label">Yeni Şifre (Tekrar)</label>
                                <input type="password" name="new_password_confirmation" class="bw-input" required>
                            </div>

                            <div class="user-modal-footer user-modal-footer--right">
                                <button type="submit" class="bw-btn-primary">Şifreyi Güncelle</button>
                            </div>
                        </form>
                    </div>
                </div> <!-- .user-security-root -->
            </div> <!-- .user-modal-content[data-modal-type="security"] -->

        </div> <!-- #user-modal-body -->
    </div> <!-- .user-modal -->
</div> <!-- #user-modal-overlay -->

<script>
window.BW_CONFIG = window.BW_CONFIG || {};
window.BW_CONFIG.CSRF_TOKEN    = '<?= htmlspecialchars($csrfToken ?? '', ENT_QUOTES, 'UTF-8') ?>';
window.BW_CONFIG.TWOFA_ENABLED = <?= $twofaEnabled ? 'true' : 'false' ?>;
</script>

<style>/* =========================================
   USER PANEL MODAL – BetWallet Neon Theme
   ========================================= */

/* =======================================================
   USER PANEL MODAL (WHITE–RED THEME) - NAMESPACE: bwup-
   ======================================================= */

:root {
    --bwup-modal-bg: #ffffff;
    --bwup-modal-border: #e5e7eb;
    --bwup-modal-radius: 16px;
    --bwup-modal-shadow: 0 18px 40px rgba(15, 23, 42, 0.35);

    --bwup-accent: #dc2626;
    --bwup-accent-soft: rgba(220, 38, 38, 0.08);

    --bwup-text-main: #111827;
    --bwup-text-muted: #6b7280;

    --bwup-card-bg: #f9fafb;
    --bwup-card-border: #e5e7eb;

    --bwup-alert-success-bg: #ecfdf3;
    --bwup-alert-success-border: #22c55e;

    --bwup-alert-error-bg: #fef2f2;
    --bwup-alert-error-border: #ef4444;

    --bwup-alert-info-bg: #eff6ff;
    --bwup-alert-info-border: #3b82f6;
}

/* Dark mode’da arka planı biraz koyulaştır ama modal yine white kalsın istersen */
body.dark-mode {
    --bwup-modal-bg: #f9fafb;
    --bwup-modal-border: #e5e7eb;
    --bwup-card-bg: #f3f4f6;
    --bwup-card-border: #e5e7eb;
}

/* OVERLAY */

.bwup-user-modal-overlay {
    position: fixed;
    inset: 0;
    z-index: 1300;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 16px;
    background: radial-gradient(circle at top, rgba(15, 23, 42, 0.35), transparent 55%),
                rgba(15, 23, 42, 0.68);
    backdrop-filter: blur(8px);
}

.bwup-user-modal-overlay.is-active {
    display: flex;
}

/* MODAL CONTAINER (max 480px) */

.bwup-user-modal-overlay .bwup-user-modal {
    position: relative;
    width: 100%;
    max-width: 480px;          /* İstediğin limit */
    max-height: 90vh;
    background: var(--bwup-modal-bg);
    border-radius: var(--bwup-modal-radius);
    border: 1px solid var(--bwup-modal-border);
    box-shadow: var(--bwup-modal-shadow);
    display: flex;
    flex-direction: column;
    overflow: hidden;
}

/* HEADER */

.bwup-user-modal-overlay .user-modal-header {
    padding: 12px 16px 10px 16px;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: linear-gradient(90deg, #ffffff, #fee2e2);
}

.bwup-user-modal-overlay .user-modal-header h3 {
    margin: 0;
    font-size: 14px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: #991b1b;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 6px;
}

.bwup-user-modal-overlay .user-modal-header h3::before {
    content: '';
    width: 6px;
    height: 6px;
    border-radius: 999px;
    background: var(--bwup-accent);
    box-shadow: 0 0 6px rgba(220, 38, 38, 0.8);
}

/* Close butonu */

.bwup-user-modal-overlay .user-modal-close {
    border: none;
    background: transparent;
    color: #6b7280;
    font-size: 18px;
    width: 28px;
    height: 28px;
    border-radius: 999px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.15s ease;
}

.bwup-user-modal-overlay .user-modal-close:hover {
    background: #fee2e2;
    color: #b91c1c;
}

/* BODY */

.bwup-user-modal-overlay .user-modal-body {
    padding: 14px 16px 16px 16px;
    overflow-y: auto;
    color: var(--bwup-text-main);
    font-size: 13px;
}

/* İç content switching */

.bwup-user-modal-overlay .user-modal-content {
    display: none;
}

.bwup-user-modal-overlay .user-modal-content.is-active {
    display: block;
}

/* SECTIONS */

.bwup-user-modal-overlay .user-modal-section {
    margin-bottom: 16px;
}

.bwup-user-modal-overlay .user-modal-section:last-child {
    margin-bottom: 0;
}

.bwup-user-modal-overlay .user-modal-section > h4 {
    margin: 0 0 8px 0;
    font-size: 13px;
    font-weight: 600;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    color: #b91c1c;
}

/* SUMMARY GRID */

.bwup-user-modal-overlay .user-summary-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 8px;
}

@media (max-width: 520px) {
    .bwup-user-modal-overlay .user-summary-grid {
        grid-template-columns: 1fr;
    }
}

.bwup-user-modal-overlay .user-summary-card {
    background: var(--bwup-card-bg);
    border-radius: 12px;
    padding: 8px 10px;
    border: 1px solid var(--bwup-card-border);
}

.bwup-user-modal-overlay .user-summary-card .label {
    display: block;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    color: var(--bwup-text-muted);
    margin-bottom: 2px;
}

.bwup-user-modal-overlay .user-summary-card .value {
    display: block;
    font-size: 13px;
    font-weight: 500;
    color: var(--bwup-text-main);
}

/* LIST (BANK / SITES) */

.bwup-user-modal-overlay .user-list {
    list-style: none;
    margin: 0;
    padding: 0;
    border-radius: 12px;
    border: 1px solid #e5e7eb;
    background: #ffffff;
}

.bwup-user-modal-overlay .user-list-item {
    padding: 8px 10px;
    border-bottom: 1px solid #f3f4f6;
}

.bwup-user-modal-overlay .user-list-item:last-child {
    border-bottom: none;
}

.bwup-user-modal-overlay .user-list-item.empty {
    background: #f9fafb;
}

.bwup-user-modal-overlay .user-list-main {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.bwup-user-modal-overlay .user-list-title {
    font-size: 13px;
    font-weight: 500;
    color: #111827;
}

.bwup-user-modal-overlay .user-list-sub {
    font-size: 12px;
    color: var(--bwup-text-main);
}

.bwup-user-modal-overlay .user-list-sub.mute {
    color: var(--bwup-text-muted);
}

.bwup-user-modal-overlay .user-list-footer {
    display: flex;
    justify-content: flex-end;
    margin-top: 8px;
}

/* QUICK ACTION BUTTONS */

.bwup-user-modal-overlay .user-quick-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.bwup-user-modal-overlay .user-quick-btn {
    font-size: 12px;
    padding: 6px 12px;
    border-radius: 6px;
    border: 1px solid transparent;
    background: #dc2626;
    color: white;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    transition: all 0.16s ease;
    white-space: nowrap;
}

.bwup-user-modal-overlay .user-quick-btn:hover {
    background: #b91c1c;
    box-shadow: 0 0 0 1px rgba(248, 113, 113, 0.5);
}

.bwup-user-modal-overlay .user-quick-btn.outline {
    background: #dc2626; !important
    color:white;!important

}



/* TABS (SECURITY) */

.bwup-user-modal-overlay .user-modal-tabs {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px;
    border-radius: 999px;
    background: #f3f4f6;
    border: 1px solid #e5e7eb;
    margin-bottom: 12px;
}

.bwup-user-modal-overlay .user-modal-tab {
    border: none;
    background: transparent;
    color: var(--bwup-text-muted);
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    padding: 5px 10px;
    border-radius: 999px;
    cursor: pointer;
    transition: all 0.15s ease;
}

.bwup-user-modal-overlay .user-modal-tab.is-active {
    background: #dc2626;
    color: #fef2f2;
}

/* TAB PANELS */

.bwup-user-modal-overlay .user-modal-tab-panel {
    display: none;
}

.bwup-user-modal-overlay .user-modal-tab-panel.is-active {
    display: block;
}

/* ALERTS */

.bwup-user-modal-overlay .user-security-alert {
    font-size: 12px;
    border-radius: 10px;
    padding: 7px 9px;
    margin-bottom: 8px;
    border: 1px solid transparent;
    color: var(--bwup-text-main);
}

.bwup-user-modal-overlay .user-security-alert--hidden {
    display: none;
}

.bwup-user-modal-overlay .user-security-alert--success {
    display: block;
    background: var(--bwup-alert-success-bg);
    border-color: var(--bwup-alert-success-border);
}

.bwup-user-modal-overlay .user-security-alert--error {
    display: block;
    background: var(--bwup-alert-error-bg);
    border-color: var(--bwup-alert-error-border);
}

.bwup-user-modal-overlay .user-security-alert--info {
    display: block;
    background: var(--bwup-alert-info-bg);
    border-color: var(--bwup-alert-info-border);
}

/* 2FA HEADER */

.bwup-user-modal-overlay .twofa-header {
    display: flex;
    flex-direction: column;
    gap: 6px;
    margin-bottom: 12px;
}

.bwup-user-modal-overlay .twofa-icon-circle {
    width: 30px;
    height: 30px;
    border-radius: 999px;
    background: #dc2626;
    color: #fef2f2;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
}

.bwup-user-modal-overlay .twofa-title {
    margin: 0;
    font-size: 14px;
    font-weight: 600;
    color: #111827;
}

.bwup-user-modal-overlay .twofa-desc {
    margin: 0;
    font-size: 12px;
    color: var(--bwup-text-muted);
}

/* 2FA SETUP */

.bwup-user-modal-overlay .twofa-setup-area {
    margin-bottom: 10px;
}

.bwup-user-modal-overlay .twofa-setup-area.is-hidden {
    display: none;
}

.bwup-user-modal-overlay .twofa-qr-wrap {
    display: flex;
    justify-content: center;
    margin-bottom: 8px;
}

.bwup-user-modal-overlay .twofa-qr-img {
    max-width: 180px;
    height: auto;
    border-radius: 10px;
    background: #f9fafb;
    padding: 6px;
    border: 1px solid #e5e7eb;
}

/* 2FA code input */

.bwup-user-modal-overlay .twofa-code-field {
    margin-top: 4px;
}

.bwup-user-modal-overlay .twofa-code-input-wrap {
    display: flex;
    align-items: center;
    gap: 6px;
    margin-top: 3px;
}

.bwup-user-modal-overlay .twofa-code-input {
    text-align: center;
    letter-spacing: 0.25em;
    font-weight: 600;
}

.bwup-user-modal-overlay .twofa-toggle-visibility {
    border: none;
    background: #f3f4f6;
    border-radius: 8px;
    width: 34px;
    height: 34px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6b7280;
    cursor: pointer;
    transition: all 0.15s ease;
}

.bwup-user-modal-overlay .twofa-toggle-visibility:hover {
    background: #e5e7eb;
    color: #374151;
}

/* 2FA DISABLE AREA */

.bwup-user-modal-overlay .twofa-disable-area {
    margin-top: 10px;
    padding-top: 8px;
    border-top: 1px dashed #e5e7eb;
}

.bwup-user-modal-overlay .twofa-disable-area.is-hidden {
    display: none;
}

.bwup-user-modal-overlay .twofa-disable-title {
    margin: 0 0 4px 0;
    font-size: 13px;
    font-weight: 500;
}

.bwup-user-modal-overlay .twofa-disable-desc {
    margin: 0 0 8px 0;
    font-size: 12px;
    color: var(--bwup-text-muted);
}

/* FOOTER */

.bwup-user-modal-overlay .user-modal-footer {
    margin-top: 8px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.bwup-user-modal-overlay .user-modal-footer--between {
    justify-content: space-between;
}

.bwup-user-modal-overlay .user-modal-footer--right {
    justify-content: flex-end;
}

.bwup-user-modal-overlay .user-security-note {
    font-size: 11px;
    color: var(--bwup-text-muted);
    max-width: 65%;
}

/* SCROLLBAR SADECE MODAL İÇİN */

.bwup-user-modal-overlay .user-modal-body::-webkit-scrollbar {
    width: 6px;
}

.bwup-user-modal-overlay .user-modal-body::-webkit-scrollbar-track {
    background: transparent;
}

.bwup-user-modal-overlay .user-modal-body::-webkit-scrollbar-thumb {
    background: #d1d5db;
    border-radius: 999px;
}
/* Zorunlu override: overlay aktifken mutlaka gözüksün */
#user-modal-overlay.is-active {
    display: flex !important;
    opacity: 1;
    pointer-events: auto;
}

/* ----------------------------------------------------
   HISTORY STATUS – LIGHT MODE (varsayılan)
---------------------------------------------------- */
.bw-history-item .status.success {
    background: rgba(16, 185, 129, 0.15);
    color: #065f46;
}

.bw-history-item .status.pending {
    background: rgba(234, 179, 8, 0.15);
    color: #854d0e;
}

.bw-history-item .status.failed,
.bw-history-item .status.cancelled {
    background: rgba(248, 113, 113, 0.20);
    color: #b91c1c;
}

.bw-history-item .status.expired {
    background: rgba(148, 163, 184, 0.18);
    color: #475569;
}

/* =========================================
   USER PANEL & DESTEK MERKEZİ – DARK MODE
   ========================================= */

/* Dark mode'da değişkenler koyulaşsın */
body.dark-mode,
body[data-theme="dark"] {
    --bwup-modal-bg: #020617;        /* neredeyse siyah */
    --bwup-modal-border: #1f2937;
    --bwup-card-bg: #020617;
    --bwup-card-border: #111827;

    --bwup-text-main: #e5e7eb;
    --bwup-text-muted: #9ca3af;
}

/* Modal container koyu kart */
body.dark-mode .bwup-user-modal,
body[data-theme="dark"] .bwup-user-modal {
    background: var(--bwup-modal-bg) !important;
    border-color: var(--bwup-modal-border) !important;
    box-shadow: 0 18px 40px rgba(0, 0, 0, 0.75) !important;
}

/* Header’ı da koyu yapalım */
body.dark-mode .bwup-user-modal .user-modal-header,
body[data-theme="dark"] .bwup-user-modal .user-modal-header {
    background: radial-gradient(circle at top left, #7f1d1d, #111827);
    border-bottom-color: #1f2937;
}

body.dark-mode .bwup-user-modal .user-modal-header h3,
body[data-theme="dark"] .bwup-user-modal .user-modal-header h3 {
    color: #fecaca;
}

body.dark-mode .bwup-user-modal .user-modal-header h3::before,
body[data-theme="dark"] .bwup-user-modal .user-modal-header h3::before {
    background: #f97373;
    box-shadow: 0 0 10px rgba(248, 113, 113, 0.9);
}

/* Body yazıları */
body.dark-mode .bwup-user-modal .user-modal-body,
body[data-theme="dark"] .bwup-user-modal .user-modal-body {
    color: var(--bwup-text-main);
    background: radial-gradient(circle at top, rgba(15, 23, 42, 0.9), #020617);
}

/* Summary kartları */
body.dark-mode .bwup-user-modal .user-summary-card,
body[data-theme="dark"] .bwup-user-modal .user-summary-card {
    background: rgba(15, 23, 42, 0.9);
    border-color: #1f2937;
}

body.dark-mode .bwup-user-modal .user-summary-card .label,
body[data-theme="dark"] .bwup-user-modal .user-summary-card .label {
    color: var(--bwup-text-muted);
}

body.dark-mode .bwup-user-modal .user-summary-card .value,
body[data-theme="dark"] .bwup-user-modal .user-summary-card .value {
    color: #e5e7eb;
}

/* Banka / Site listeleri */
body.dark-mode .bwup-user-modal .user-list,
body[data-theme="dark"] .bwup-user-modal .user-list {
    background: #020617;
    border-color: #1f2937;
}

body.dark-mode .bwup-user-modal .user-list-item,
body[data-theme="dark"] .bwup-user-modal .user-list-item {
    border-bottom-color: #111827;
}

body.dark-mode .bwup-user-modal .user-list-item.empty,
body[data-theme="dark"] .bwup-user-modal .user-list-item.empty {
    background: #020617;
}

body.dark-mode .bwup-user-modal .user-list-title,
body[data-theme="dark"] .bwup-user-modal .user-list-title {
    color: #e5e7eb;
}

body.dark-mode .bwup-user-modal .user-list-sub,
body[data-theme="dark"] .bwup-user-modal .user-list-sub {
    color: var(--bwup-text-main);
}

body.dark-mode .bwup-user-modal .user-list-sub.mute,
body[data-theme="dark"] .bwup-user-modal .user-list-sub.mute {
    color: var(--bwup-text-muted);
}

/* Hızlı aksiyon butonları */
body.dark-mode .bwup-user-modal .user-quick-btn,
body[data-theme="dark"] .bwup-user-modal .user-quick-btn {
    background: #b91c1c;
    color: #fee2e2;
    border-color: transparent;
}

body.dark-mode .bwup-user-modal .user-quick-btn:hover,
body[data-theme="dark"] .bwup-user-modal .user-quick-btn:hover {
    background: #ef4444;
    box-shadow: 0 0 0 1px rgba(248, 113, 113, 0.7);
}




/* Security tabs */
body.dark-mode .bwup-user-modal .user-modal-tabs,
body[data-theme="dark"] .bwup-user-modal .user-modal-tabs {
    background: rgba(15, 23, 42, 0.95);
    border-color: #1f2937;
}

body.dark-mode .bwup-user-modal .user-modal-tab,
body[data-theme="dark"] .bwup-user-modal .user-modal-tab {
    color: #9ca3af;
}

body.dark-mode .bwup-user-modal .user-modal-tab.is-active,
body[data-theme="dark"] .bwup-user-modal .user-modal-tab.is-active {
    background: #dc2626;
    color: #fee2e2;
}

/* Alertler */
body.dark-mode .bwup-user-modal .user-security-alert--success,
body[data-theme="dark"] .bwup-user-modal .user-security-alert--success {
    background: rgba(22, 163, 74, 0.18);
    border-color: #22c55e;
    color: #bbf7d0;
}

body.dark-mode .bwup-user-modal .user-security-alert--error,
body[data-theme="dark"] .bwup-user-modal .user-security-alert--error {
    background: rgba(248, 113, 113, 0.18);
    border-color: #f87171;
    color: #fecaca;
}

body.dark-mode .bwup-user-modal .user-security-alert--info,
body[data-theme="dark"] .bwup-user-modal .user-security-alert--info {
    background: rgba(59, 130, 246, 0.18);
    border-color: #60a5fa;
    color: #bfdbfe;
}

/* 2FA header kısmı */
body.dark-mode .bwup-user-modal .twofa-icon-circle,
body[data-theme="dark"] .bwup-user-modal .twofa-icon-circle {
    background: #dc2626;
}

body.dark-mode .bwup-user-modal .twofa-title,
body[data-theme="dark"] .bwup-user-modal .twofa-title {
    color: #e5e7eb;
}

body.dark-mode .bwup-user-modal .twofa-desc,
body[data-theme="dark"] .bwup-user-modal .twofa-desc {
    color: #9ca3af;
}

/* 2FA QR kartı */
body.dark-mode .bwup-user-modal .twofa-qr-img,
body[data-theme="dark"] .bwup-user-modal .twofa-qr-img {
    background: #020617;
    border-color: #1f2937;
}

/* Footer not yazısı */
body.dark-mode .bwup-user-modal .user-security-note,
body[data-theme="dark"] .bwup-user-modal .user-security-note {
    color: #9ca3af;
}


</style>