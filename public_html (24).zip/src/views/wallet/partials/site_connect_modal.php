<div class="bw-modal-backdrop" id="site-connect-modal">
        <div class="bw-modal center-modal">
            <button type="button"
                    id="sc-back-btn"
                    class="sc-back-btn"
                    onclick="DEPOSIT_APP.goBackToSiteList()">
                ←
            </button>

            <div class="bw-modal-title">Siteye Bağlan</div>

            <p class="bw-text-muted" style="text-align: center; margin-bottom: 20px;">Bağlanmak istediğiniz siteyi seçin ve bilgilerinizi girin.</p>
            
            <input type="text" id="site-search-input" placeholder="Site adı ile ara..." oninput="DEPOSIT_APP.filterSites(this.value)">

            <div id="site-list-container">
                <?php foreach ($allSitesQ as $site): ?>
                    <?php 
                        $initial = strtoupper(substr($site['name'], 0, 1));
                        $isLinked = in_array($site['id'], array_column($userLinkedSites, 'site_id'));
                    ?>
                    <div class="site-select-item" 
                         data-site-id="<?= $site['id'] ?>" 
                         data-site-name="<?= htmlspecialchars($site['name']) ?>"
                         data-site-logo="<?= htmlspecialchars($site['logo_url'] ?? '') ?>"
                         onclick="DEPOSIT_APP.selectSite(this, <?= $site['id'] ?>, '<?= htmlspecialchars($site['name']) ?>')"
                         style="<?= $isLinked ? 'opacity: 0.5; pointer-events: none;' : '' ?>"
                         id="site-item-<?= $site['id'] ?>">

                        <!-- Sol: logo -->
                        <div class="site-initial-logo"><?= $initial ?></div>

                        <!-- Orta: site adı -->
                        <div class="sc-site-main">
                            <div class="sc-site-name"><?= htmlspecialchars($site['name']) ?></div>
                        </div>

                        <!-- Sağ taraf: bağlıysa badge, değilse butonlar -->
                        <?php if ($isLinked): ?>
                            <div class="sc-linked-badge">Bağlı</div>
                        <?php else: ?>
                            <div class="sc-actions">
                                <button type="button"
                                        class="sc-register-link"
                                        onclick="event.stopPropagation(); DEPOSIT_APP.submitConnectForm('register', <?= $site['id'] ?>)">
                                    Kayıt Ol
                                </button>

                                <button type="button"
                                        class="sc-connect-btn"
                                        onclick="event.stopPropagation(); DEPOSIT_APP.selectSite(this.closest('.site-select-item'), <?= $site['id'] ?>, '<?= htmlspecialchars($site['name']) ?>')">
                                    Bağla
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <div id="site-connect-box" style="padding-top: 20px; border-top: 1px solid #f1f5f9; margin-top: 15px; display: none;">

                <div style="display: flex; align-items: center; justify-content: center; gap: 10px; margin-bottom: 15px;">
                    <div class="site-initial-logo" id="connect-site-logo-initial"></div>
                    <h4 id="connect-site-name" style="margin: 0; font-size: 16px;"></h4>
                </div>

                <form method="post" id="site-connect-form">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="connect_site_demo" value="1">
                    <input type="hidden" name="demo_site_id" id="demo-site-id">
                    <input type="hidden" name="demo_action" id="demo-action">

                    <div class="bw-form-group">
                        <label class="bw-label">Kullanıcı Adı</label>
                        <input type="text" name="demo_username" id="demo-username" class="bw-input" placeholder="Demo için 'test1'" required>
                    </div>
                    <div class="bw-form-group">
                        <label class="bw-label">Şifre</label>
                        <input type="password" name="demo_password" id="demo-password" class="bw-input" placeholder="Demo için herhangi bir şey" required>
                    </div>
                    
                    <div style="display: flex; gap: 10px; margin-top: 20px;">
                        <button type="button" class="bw-btn bw-btn-primary bw-block" onclick="DEPOSIT_APP.submitConnectForm('login')">Giriş Yap & Bağla</button>
                    </div>
                </form>
            </div>

            <button type="button" class="bw-btn bw-btn-outline bw-block" onclick="closeModal('site-connect-modal')" style="margin-top: 20px;">Kapat</button>
        </div>
    </div>
