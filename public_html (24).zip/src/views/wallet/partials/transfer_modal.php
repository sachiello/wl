<div class="bw-modal-backdrop" id="transfer-modal">
        <div class="bw-modal center-modal">
            <div class="bw-modal-title" id="transfer-modal-title"></div>
            
            <form method="post" id="transfer-form">
                <?= csrf_field(); ?>
                <input type="hidden" name="site_transfer" value="1">
                <input type="hidden" name="transfer_site_id" id="transfer-site-id">
                <input type="hidden" name="transfer_coin" id="transfer-coin">

                <div id="transfer-step-1" class="deposit-step is-active">
                    <div class="bw-form-group">
                        <label class="bw-label">Transfer Edilecek Coin</label>
                        <div class="transfer-coin-options">
                            <button type="button" data-coin="USDT" class="selected" onclick="DEPOSIT_APP.selectTransferCoin(this, 'USDT')">USDT</button>
                        </div>
                    </div>
                    
                    <div class="bw-form-group">
                        <label class="bw-label">Yüklenecek Tutar (TL)</label>
                        <div class="bw-input-amount-wrapper">
                            <input type="number" name="transfer_amount_try" id="transfer-amount-try" class="bw-input bw-input-amount" placeholder="0.00" required>
                            <span class="bw-input-suffix">TRY</span>
                        </div>
                    </div>

                    <div class="bw-feedback-card danger" id="transfer-error" style="display: none; margin-top: 15px; font-size: 13px; position: relative;"></div>

                    <button type="submit" class="bw-btn bw-btn-primary bw-block" style="margin-top: 20px;">Bakiyeyi Siteye Yükle</button>
                    <button type="button" class="bw-btn bw-btn-outline bw-block" onclick="closeModal('transfer-modal')" style="margin-top: 10px;">Vazgeç</button>
                </div>
            </form>
            
            <div id="transfer-step-success" class="deposit-step">
                <div id="transfer-success-box">
                    <div class="success-icon">&#10003;</div>
                    <div class="success-title">YÜKLEME BAŞARILI!</div>
                    <div id="transfer-success-message" style="font-size: 14px; color: var(--text-muted);"></div>
                </div>
                
                <a href="#" id="go-to-site-button" target="_blank" class="bw-btn bw-btn-primary bw-block" 
                   style="margin-top: 30px; text-align: center; display: none; text-decoration: none;">
                    Siteye Git
                </a>
                
                <button type="button" class="bw-btn bw-btn-outline bw-block" onclick="window.location.reload();" 
                        style="margin-top: 10px;">
                    Kapat
                </button>
            </div>
        </div>
    </div>
