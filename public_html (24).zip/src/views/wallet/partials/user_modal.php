    <!-- USER PANEL MODAL -->
    <!-- USER MODAL OVERLAY -->
    <div id="user-modal-overlay">
        <div class="user-modal">
            <div class="bw-modal-header">
                <div class="bw-modal-title" id="user-modal-title"></div>
                <button type="button"
                        class="bw-modal-close"
                        onclick="USER_PANEL.closeModal()">
                    &times;
                </button>
            </div>

            <div class="bw-modal-body" id="user-modal-body">
                <!-- JS burayı dolduruyor -->
            </div>
        </div>
    </div>
