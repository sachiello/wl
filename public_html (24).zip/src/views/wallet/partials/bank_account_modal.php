<div class="bw-modal-backdrop" id="bank-account-modal">
        <div class="bw-modal center-modal">
            <div class="bw-modal-title">IBAN Ekle</div>

            <p class="bw-text-muted" style="text-align:center; margin-bottom:20px;">
                Çekim yapabilmek için önce banka hesabınızı kaydedin.
            </p>

            <form method="post" id="bank-account-form">
                <?= csrf_field(); ?>
                <input type="hidden" name="add_bank_account" value="1">

                <div class="bw-form-group">
                    <label class="bw-label">Hesap Sahibi Ad Soyad</label>
                    <input type="text"
                           name="bank_account_full_name"
                           class="bw-input"
                           placeholder="Ad Soyad"
                           required>
                </div>

                <div class="bw-form-group">
                    <label class="bw-label">Banka Adı</label>
                    <input type="text"
                           name="bank_account_bank_name"
                           class="bw-input"
                           placeholder="Örn: Ziraat Bankası"
                           required>
                </div>

                <div class="bw-form-group">
                    <label class="bw-label">IBAN</label>
                    <input type="text"
                           name="bank_account_iban"
                           class="bw-input"
                           placeholder="TR00 0000 0000 0000 0000 0000 00"
                           required>
                </div>

                <button type="submit" class="bw-btn bw-btn-primary bw-block" style="margin-top:10px;">
                    Kaydet
                </button>
                <button type="button" class="bw-btn bw-btn-outline bw-block"
                        onclick="closeModal('bank-account-modal')" style="margin-top:10px;">
                    Vazgeç
                </button>
            </form>
        </div>
    </div>
