<div class="bw-modal-backdrop" id="deposit-modal">
        <div class="bw-modal center-modal">
            <div class="bw-modal-title" id="deposit-modal-title">Para Yatır</div>
            <div id="deposit-back-btn" class="bw-modal-back-btn" style="display:none;" onclick="DEPOSIT_APP.goBack()">&#8592;</div>

            <form method="post" id="deposit-form">
                <?= csrf_field(); ?>
                <input type="hidden" name="create_deposit" value="1">
                <input type="hidden" name="payment_method" id="payment_method_input">
                <input type="hidden" name="amount_try" id="amount_try_input">

<div id="deposit-step-1" class="deposit-step is-active">
    <p class="bw-text-muted" style="text-align: center; margin-bottom: 16px;">
        Lütfen bir ödeme yöntemi seçin.
    </p>

    <div class="deposit-method-grid">

        <!-- HAVALE / EFT -->
        <div class="deposit-method-card" data-method="havale">
            <div class="deposit-method-icon">
                <i class="ri-bank-card-fill"></i>
            </div>
            <div class="title">Havale/EFT</div>
        </div>

        <!-- KRİPTO -->
        <div class="deposit-method-card is-disabled" data-method="crypto">
            <div class="deposit-method-icon">
                <i class="ri-bit-coin-fill"></i>
            </div>
            <div class="title">Kripto Para</div>
        </div>

        <!-- KREDİ KARTI -->
        <div class="deposit-method-card is-disabled" data-method="cc">
            <div class="deposit-method-icon">
                <i class="ri-credit-card-2-fill"></i>
            </div>
            <div class="title">Kredi Kartı</div>
        </div>
    </div>

    <button type="button"
            class="bw-btn bw-btn-outline bw-block"
            onclick="closeModal('deposit-modal')">
        Vazgeç
    </button>
</div>




                <div id="deposit-step-havale-1" class="deposit-step">
                    <div class="bw-form-group">
                        <label class="bw-label">Yatırım Tutarı (TL)</label>
                        <div class="bw-input-amount-wrapper">
                            <input type="number" name="amount_try_havale" id="havale-amount-try" 
                                   class="bw-input bw-input-amount" 
                                   placeholder="1000.00" required>
                            <span class="bw-input-suffix">TRY</span>
                        </div>
                    </div>

                    <div class="bw-form-group">
                        <label class="bw-label">Yansıyacağı Cüzdan</label>
                        <div class="wallet-target-options">
                            <div class="wallet-target-item active">
                                <div class="left">
                                    <div class="icon usdt-icon">₮</div>
                                    <div class="texts">
                                        <div class="name">Tether</div>
                                        <div class="code">USDT Cüzdanı</div>
                                    </div>
                                </div>
                                <div class="right">
                                    <span class="badge-active">AKTİF</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="bw-btn bw-btn-primary bw-block">
                        Devam Et ve IBAN Al
                    </button>
                </div>
                
                <div id="deposit-step-crypto" class="deposit-step">
                </div>

            </form> 

            <div id="deposit-step-havale-2" class="deposit-step">
                <?php
                // Varsa backend’den gelen label / USDT tutarı, yoksa bozulmadan placeholder çalışır
                $walletLabel = $activeDepositDetails['wallet_label'] ?? ($activeDeposit['wallet_label'] ?? 'Tether');
                $walletUsdt  = $activeDepositDetails['wallet_amount_usdt'] ?? ($activeDeposit['wallet_amount_usdt'] ?? null);
                ?>

                <div class="bw-bank-step-wrapper">
                    <!-- IBAN & HESAP ADI KARTI -->
                    <div class="bw-bank-step-section">
                        <!-- FAST Tavsiye Info Box -->
                        <div class="bw-fast-info-box">
                            <div class="bw-fast-info-icon">⚡</div>
                            <div class="bw-fast-info-text">
                                Yatırımlarınızı yaparken <strong>FAST</strong> seçeneğiyle yapmanız tavsiye edilir, 
                                kısa süre içerisinde onaylanacaktır.
                            </div>
                        </div>

                        <!-- KUTU 1: GÖNDERİLECEK IBAN -->
                        <div class="bw-iban-box bw-iban-box--compact">
                            <div class="bw-iban-row bw-iban-row--single">
                                <div class="bw-iban-field">
                                    <span class="bw-iban-label-small">Gönderilecek IBAN</span>
                                    <div class="bw-iban-code bw-iban-code--inline">
                                        <?= htmlspecialchars($activeDepositDetails['iban'] ?? '---') ?>
                                    </div>
                                </div>

                                <button type="button"
                                        class="bw-copy-button"
                                        data-copy-text="<?= htmlspecialchars($activeDepositDetails['iban'] ?? '') ?>"
                                        onclick="DEPOSIT_APP.copyToClipboard(this)">
                                    Kopyala
                                </button>
                            </div>
                        </div>

                        <!-- KUTU 2: HESAP ADI (ALICI) -->
                        <div class="bw-iban-box bw-iban-box--compact">
                            <div class="bw-iban-row bw-iban-row--single">
                                <div class="bw-iban-field">
                                    <span class="bw-iban-label-small">Hesap Adı (Alıcı)</span>
                                    <div class="bw-iban-code bw-iban-code--inline">
                                        <?= htmlspecialchars($activeDepositDetails['holder'] ?? '---') ?>
                                    </div>
                                </div>

                                <button type="button"
                                        class="bw-copy-button"
                                        data-copy-text="<?= htmlspecialchars($activeDepositDetails['holder'] ?? '') ?>"
                                        onclick="DEPOSIT_APP.copyToClipboard(this)">
                                    Kopyala
                                </button>
                            </div>
                        </div>

                        <div class="bw-bank-step-section">
                            <div class="bw-wallet-target bw-wallet-target--inline">
                                <div class="icon usdt-icon">₮</div>

                                <div class="texts">
                                    <div class="name">
                                        <?= htmlspecialchars($walletLabel) ?>
                                    </div>
                                    <div class="code">USDT Cüzdanı</div>
                                </div>

                                <!-- Sağ taraf: Bakiyeye yansıyacak USDT tutarı -->
                                <div class="bw-wallet-net">
                                    <div class="bw-wallet-net-label">Bakiyeye yansıyacak</div>

                                    <div class="bw-wallet-net-value">
                                        <?= number_format($netUsdt, 2, '.', ',') ?>
                                        <span class="usdt-suffix">USDT</span>
                                    </div>

                                    <!-- Alt satır: TL karşılığı (istersen silebilirsin) -->
                                    <div class="bw-wallet-net-sub">
                                        ≈ ₺<?= number_format($netTry, 2, ',', '.') ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- BUTONLAR -->
                    <div class="bw-bank-step-section bw-bank-step-actions">
                        <p class="bw-bank-note">
                            Lütfen <strong><?= number_format($activeDeposit['amount_try'] ?? 0, 2, ',', '.') ?> TL</strong>
                            tutarındaki gönderimi tamamladıktan sonra onay ver.
                        </p>

                        <form method="post" class="bw-crypto-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="confirm_payment" value="1">
                            <input type="hidden" name="confirm_payment_id" value="<?= $activeDeposit['id'] ?? 0 ?>">

                            <button type="submit" class="bw-btn bw-btn-primary bw-block">
                                Ödemeyi Yaptım, Bildir
                            </button>
                        </form>

                        <form method="post" class="bw-crypto-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="cancel_deposit" value="1">
                            <input type="hidden" name="cancel_deposit_id" value="<?= $activeDeposit['id'] ?? 0 ?>">

                            <button type="submit"
                                    class="bw-btn bw-crypto-btn-outline bw-block"
                                    onclick="return confirm('İşlemi iptal etmek istediğinize emin misiniz?');">
                                İptal Et
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>.fa, .fas, .far, .fab {
    font-family: "Font Awesome 6 Free" !important;
    font-weight: 900 !important;
}
.deposit-method-grid {
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 10px;
    margin-bottom: 14px;
}

.deposit-method-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    text-align: center;
    padding: 14px 10px;
    border-radius: 14px;
    border: 1px solid rgba(0,0,0,0.08);
    background: #ffffff;
    cursor: pointer;
    transition: 0.2s;
    user-select: none;
}

.deposit-method-icon i {
    font-size: 38px;
    color: #dc2626;
}

/* title */
.deposit-method-card .title {
    font-size: 13px;
    font-weight: 600;
    color: #991b1b;
    margin-top: 3px;
}

/* hover */
.deposit-method-card:hover {
    transform: translateY(-2px);
    border-color: #dc2626;
    background: #fff5f5;
}

/* disabled */
.deposit-method-card.is-disabled {
    opacity: .35;
    pointer-events: none;
}

/* DARK MODE */
body.dark-mode .deposit-method-card {
    background: #0f172a;
    border-color: #1e293b;
}

body.dark-mode .deposit-method-card:hover {
    background: rgba(220,38,38,0.1);
    border-color: #dc2626;
}

body.dark-mode .deposit-method-icon i {
    color: #fca5a5;
}

body.dark-mode .deposit-method-card .title {
    color: #fca5a5;
}


</style>
    