<?php
// src/views/login.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// CONFIG / DB bağla (path'i projene göre düzelt)
if (!isset($pdo) && isset($db)) {
    $pdo = $db;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    // Bu dosya sadece POST için çalışır, GET ile gelindiyse form sayfasını gösterme.
    // Ama redirect etme!
    exit('Access Denied.');
}


$isAjax   = (($_POST['ajax'] ?? '') === '1');
$errorMsg = null;

// CSRF kontrolü
if (function_exists('csrf_validate_request') && !csrf_validate_request()) {
    $errorMsg = 'Oturum doğrulaması başarısız. Lütfen sayfayı yenileyip tekrar deneyin.';
}

// Form verileri
$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($errorMsg === null) {
    if ($username === '' || $password === '') {
        $errorMsg = 'Lütfen kullanıcı adı ve şifre giriniz.';
    }
}

if ($errorMsg === null) {
    try {
        // 1. ADIM: SQL Sorgusuna 'is_banned' eklendi
        $stmt = $pdo->prepare("
            SELECT id, username, password_hash, trc20_address,
                   two_factor_secret, two_factor_enabled, is_2fa_enabled, is_banned
            FROM users
            WHERE username = ?
            LIMIT 1
        ");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user || !password_verify($password, $user['password_hash'])) {
            $errorMsg = 'Geçersiz kullanıcı adı veya şifre.';
        } else {

            // 2. ADIM: BAN KONTROLÜ (KRİTİK NOKTA)
            if ((int)$user['is_banned'] === 1) {
                // Eğer kullanıcı banlıysa hata mesajını set et ve işlemi durdur.
                $errorMsg = 'Hesabınız inceleniyor, lütfen destek ile iletişime geçiniz.';
            } else {
                // KULLANICI BANLI DEĞİLSE GİRİŞ İŞLEMLERİNE DEVAM ET

                // ----------------------------
                //   ** 2FA DURUMU ANALİZİ **
                // ----------------------------
                $hasSecret   = !empty($user['two_factor_secret']);
                $isEnabledDb = ((int)$user['is_2fa_enabled'] === 1);

                // 2FA aktif sayılması için: secret dolu + is_2fa_enabled = 1
                $twofaActive = $hasSecret && $isEnabledDb;

                // Önce tüm eski session'ları temizle
                session_regenerate_id(true);

                if ($twofaActive) {

                    // Tam login YOK → pending 2FA başlasın
                    $_SESSION['pending_2fa_user_id']  = (int)$user['id'];
                    $_SESSION['pending_2fa_username'] = $user['username'];

                    if ($isAjax) {
                        header('Content-Type: application/json; charset=utf-8');
                        echo json_encode([
                            'ok'       => true,
                            'redirect' => '/src/views/verify_2fa.php'
                        ]);
                        exit;
                    }

                    header('Location: /src/views/verify_2fa.php');
                    exit;

                } else {

                    // 2FA yok (veya devre dışı) → direkt tam login
                    $_SESSION['user_id']       = (int)$user['id'];
                    $_SESSION['username']      = $user['username'];
                    $_SESSION['trc20_address'] = $user['trc20_address'];
                    $_SESSION['2fa_verified']  = true;

                    if ($isAjax) {
                        header('Content-Type: application/json; charset=utf-8');
                        echo json_encode([
                            'ok'       => true,
                            'redirect' => '/wallet'
                        ]);
                        exit;
                    }

                    header('Location: /wallet');
                    exit;
                }
            } // Ban kontrolü else bitişi
        }

    } catch (PDOException $e) {
        // Güvenlik için gerçek hatayı loglayıp kullanıcıya genel mesaj dönüyoruz
        // error_log($e->getMessage()); 
        $errorMsg = 'Şu anda giriş yapılamıyor. Lütfen daha sonra tekrar deneyin.';
    }
}

// ERROR DURUMU (Banlıysa veya şifre yanlışsa buraya düşer)
if ($isAjax) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'ok'    => false,
        'error' => $errorMsg ?? 'Bilinmeyen bir hata oluştu.'
    ]);
    exit;
}

$redirectError = urlencode($errorMsg ?? 'Bilinmeyen bir hata oluştu.');
header("Location: /?v=login&error={$redirectError}");
exit;
?>