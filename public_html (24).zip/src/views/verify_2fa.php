<?php
// src/views/verify_2fa.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require __DIR__ . '/../../config/config.php';
require __DIR__ . '/../../lib/GoogleAuthenticator.php';

// Pending 2FA session yoksa login'e at
if (empty($_SESSION['pending_2fa_user_id'])) {
    header('Location: /?v=login');
    exit;
}

$pendingUserId   = (int)($_SESSION['pending_2fa_user_id']);
$pendingUsername = $_SESSION['pending_2fa_username'] ?? '';
$errorMsg = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF Koruması
    if (function_exists('csrf_validate_request') && !csrf_validate_request()) {
        $errorMsg = 'Oturum doğrulaması başarısız (CSRF hatası).';
    } else {
        $otpCode = trim($_POST['otp_code'] ?? '');

        // Basit validasyon
        if (!ctype_digit($otpCode) || strlen($otpCode) !== 6) {
            $errorMsg = 'Lütfen 6 haneli doğrulama kodunu girin.';
        } else {
            $stmt = $pdo->prepare("
                SELECT id, username, trc20_address, two_factor_secret
                FROM users
                WHERE id = ?
                LIMIT 1
            ");
            $stmt->execute([$pendingUserId]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user || empty($user['two_factor_secret'])) {
                $errorMsg = 'Kullanıcı veya 2FA bilgisi bulunamadı.';
            } else {
                $ga = new GoogleAuthenticator();
                // Saat farkı toleransı (window)
                $window = 2;

                if ($ga->verifyCode($user['two_factor_secret'], $otpCode, $window)) {
                    // Session Fixation önleme
                    session_regenerate_id(true);

                    // Geçici sessionları temizle
                    unset($_SESSION['pending_2fa_user_id'], $_SESSION['pending_2fa_username']);

                    // Asıl oturumu başlat
                    $_SESSION['user_id']        = (int)$user['id'];
                    $_SESSION['username']       = $user['username'];
                    $_SESSION['trc20_address']  = $user['trc20_address'] ?? null;
                    $_SESSION['2fa_verified']   = true;

                    header('Location: /wallet');
                    exit;
                } else {
                    $errorMsg = 'Girdiğiniz kod hatalı veya süresi dolmuş.';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>BetWallet | 2FA Doğrulama</title>
    
    <link rel="stylesheet" href="public/assets/betwallet.css">
    
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        :root {
            --premium-primary: red;
            --premium-accent: red;
            --premium-background: #F0F2F5;
            --premium-card-bg: #FFFFFF;
            --premium-text: #343A40;

            --font-heading: 'Montserrat', sans-serif;
            --font-body: 'Montserrat', sans-serif;
        }

        * { box-sizing: border-box; }

        body {
            background: var(--premium-background);
            margin: 0;
            font-family: var(--font-body);
        }

        /* FRAME & ANIMASYON */
        .app-frame {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            opacity: 0;
            transform: scale(0.99);
            transition:
                opacity 0.45s cubic-bezier(0.4, 0, 0.2, 1),
                transform 0.45s cubic-bezier(0.4, 0, 0.2, 1);
        }

        /* KART YAPISI */
        .bw-auth-shell {
            width: 100%;
            max-width: 420px;
            background: var(--premium-card-bg);
            border-radius: 20px;
            padding: 28px 22px 30px;
            box-shadow:
                0 18px 45px rgba(15, 23, 42, 0.15),
                0 0 0 1px rgba(148, 163, 184, 0.08);
            position: relative;
            overflow: hidden;
            text-align: center; /* İçeriği ortala */
        }

        /* LOGO */
        .bw-logo-container {
            text-align: center;
            margin-bottom: 24px;
        }

        .bw-logo {
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0 auto;
            font-size: 28px;
            font-weight: 800;
            font-family: var(--font-heading);
            color: red;
            text-transform: uppercase;
            letter-spacing: -0.5px;
        }

        .bw-logo i { margin-right: 8px; }
        
        .bw-logo-container p {
            margin-top: 8px;
            font-size: 14px;
            color: var(--premium-text);
            opacity: 0.85;
        }

        /* ALERT KUTULARI */
        .bw-alert {
            border-radius: 10px;
            padding: 10px 12px;
            font-size: 13px;
            margin-bottom: 16px;
            text-align: left;
        }
        .bw-alert-error {
            background: #FDECEC;
            color: #B91C1C;
            border: 1px solid #FCA5A5;
        }

        /* FORM ELEMANLARI */
        .bw-form-group {
            margin-bottom: 16px;
            text-align: left;
        }
        .bw-label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 6px;
            color: var(--premium-text);
        }
        .bw-input {
            width: 100%;
            padding: 12px 11px;
            border-radius: 10px;
            border: 1px solid #D1D5DB;
            font-size: 14px;
            outline: none;
            transition: border 0.2s ease, box-shadow 0.2s ease;
        }
        .bw-input:focus {
            border-color: #dc2626;
            box-shadow: 0 0 0 1px rgba(220, 38, 38, 0.35);
        }

        /* 2FA ÖZEL INPUT STİLİ */
        .bw-input-code {
            font-size: 20px;
            letter-spacing: 8px;
            text-align: center;
            font-weight: 700;
            color: #333;
        }

        /* BUTTON */
        .bw-btn {
            padding: 14px 22px;
            border-radius: 12px;
            font-size: 15px;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: all 0.25s ease;
            width: 100%;
        }
        .bw-btn-primary {
            background: linear-gradient(135deg, #dc2626, #ef4444);
            color: white;
            box-shadow: 0 8px 16px rgba(220, 38, 38, 0.35);
        }
        .bw-btn-primary:hover {
            background: linear-gradient(135deg, #b91c1c, #dc2626);
            box-shadow: 0 10px 20px rgba(220, 38, 38, 0.45);
        }

        /* LINKLER */
        .bw-link-muted {
            display: inline-block;
            margin-top: 16px;
            font-size: 13px;
            color: #6B7280;
            text-decoration: none;
            transition: color 0.2s;
        }
        .bw-link-muted:hover {
            color: #dc2626;
        }

        .betwallet-text { color: red; }
    </style>
</head>
<body>

<div class="app-frame">
    <div class="bw-auth-shell">

        <div class="bw-logo-container">
            <div class="bw-logo">
                <i class="fas fa-shield-alt"></i> <span class="betwallet-text">BetWallet</span>
            </div>
            <p>
                Hoş geldin, <strong><?= htmlspecialchars($pendingUsername) ?></strong><br>
                Lütfen kimliğini doğrula.
            </p>
        </div>

        <?php if ($errorMsg): ?>
            <div class="bw-alert bw-alert-error">
                <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($errorMsg) ?>
            </div>
        <?php endif; ?>

        <form method="post" action="">
            <?= function_exists('csrf_field') ? csrf_field() : '' ?>

            <div class="bw-form-group">
                <label class="bw-label" style="text-align:center;">Authenticator Kodu</label>
                <input type="text" 
                       name="otp_code" 
                       class="bw-input bw-input-code" 
                       maxlength="6" 
                       pattern="[0-9]*" 
                       inputmode="numeric" 
                       placeholder="000000"
                       required 
                       autofocus
                       autocomplete="one-time-code">
            </div>

            <button type="submit" class="bw-btn bw-btn-primary">
                Doğrula ve Giriş Yap
            </button>
        </form>

        <a href="/?v=login" class="bw-link-muted">
            <i class="fas fa-arrow-left"></i> Giriş ekranına dön
        </a>

    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const frame = document.querySelector('.app-frame');
    
    // Landing page ile aynı giriş animasyonu
    setTimeout(() => {
        if (!frame) return;
        frame.style.opacity = '1';
        frame.style.transform = 'scale(1)';
    }, 50);
});
</script>

</body>
</html>