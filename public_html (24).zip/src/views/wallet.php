<?php
// src/views/wallet.php
// Bu dosya, wallet sayfasını controller + view + service katmanlarıyla ayağa kaldıran ince bir yönlendiricidir.

if (!isset($pdo)) {
    require_once __DIR__ . '/../../config/config.php';
}

require_once __DIR__ . '/../controllers/WalletController.php';

$controller = new WalletController($pdo);
$controller->handle();
