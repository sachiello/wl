<?php
// src/views/landing.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


// URL'den başlangıç view'i (isteğe bağlı: /?v=login gibi)
$initialView = $_GET['v'] ?? 'landing';
$allowedViews = ['landing', 'login', 'register'];
if (!in_array($initialView, $allowedViews, true)) {
    $initialView = 'landing';
}

// Hata / başarı mesajları (login/register controller'ların redirect'inde query ile gelebilir)
$error   = $_GET['error']   ?? null;
$success = $_GET['success'] ?? null;
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>BetWallet | Güvenli Giriş</title>
    <link rel="stylesheet" href="public/assets/betwallet.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        :root {
            --premium-primary: red;
            --premium-accent: red;
            --premium-background: #F0F2F5;
            --premium-card-bg: #FFFFFF;
            --premium-text: #343A40;

            --font-heading: 'Montserrat', sans-serif;
            --font-body: 'Montserrat', sans-serif;
        }

        * {
            box-sizing: border-box;
        }

        body {
            background: var(--premium-background);
            margin: 0;
            font-family: var(--font-body);
        }

        /* TÜM SAYFAYI ORTALAYAN FRAME */
        .app-frame {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            opacity: 0;
            transform: scale(0.99);
            transition:
                opacity 0.45s cubic-bezier(0.4, 0, 0.2, 1),
                transform 0.45s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;   /* intro tüm app-frame'i kaplasın */
            overflow: hidden;     /* kırmızı intro taşmasın */
        }

        .app-frame.animate-out {
            opacity: 0;
            transform: scale(0.97);
            pointer-events: none;
        }

        /* ARKADAKİ BOX (KART) */
        .bw-auth-shell {
            width: 100%;
            max-width: 420px;
            background: var(--premium-card-bg);
            border-radius: 20px;
            padding: 28px 22px 30px;
            box-shadow:
                0 18px 45px rgba(15, 23, 42, 0.15),
                0 0 0 1px rgba(148, 163, 184, 0.08);
            position: relative;
            overflow: hidden;
        }

        @media (max-width: 480px) {
            .bw-auth-shell {
                border-radius: 18px;
                padding: 24px 18px 26px;
            }
        }

        /* LOGO */
        .bw-logo-container {
            text-align: center;
            margin-bottom: 16px;
        }

        .bw-logo {
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0 auto;
            font-size: 28px;
            font-weight: 800;
            font-family: var(--font-heading);
            color: red;
            text-transform: uppercase;
            letter-spacing: -0.5px;
            background: transparent !important;
            box-shadow: none !important;
            padding: 0;
        }

        .bw-logo i {
            margin-right: 8px;
        }
        .bw-logo-container p {
            margin-top: 8px;
            font-size: 14px;
            color: var(--premium-text);
            opacity: 0.85;
        }

        /* MESAJ ALANI (TÜM EKRANLAR İÇİN) */
        .bw-alert {
            border-radius: 10px;
            padding: 10px 12px;
            font-size: 13px;
            margin-bottom: 10px;
        }
        .bw-alert-error {
            background: #FDECEC;
            color: #B91C1C;
            border: 1px solid #FCA5A5;
        }
        .bw-alert-success {
            background: #ECFDF3;
            color: #166534;
            border: 1px solid #86EFAC;
        }

        /* VIEW WRAPPER & ANİMASYONLU GEÇİŞ */
        .bw-views-wrapper {
            position: relative;
        }

        .bw-view {
            position: absolute;
            inset: 0;
            opacity: 0;
            transform: translateY(12px);
            pointer-events: none;
            transition: opacity 0.28s ease, transform 0.28s ease;
        }
        .bw-view.is-active {
            position: relative;
            opacity: 1;
            transform: translateY(0);
            pointer-events: auto;
        }
        .bw-view.is-leaving {
            opacity: 0;
            transform: translateY(-10px);
        }

        .bw-landing-actions {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-top: 10px;
        }

        .bw-btn {
            padding: 14px 22px;
            border-radius: 12px;
            font-size: 15px;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: all 0.25s ease;
            width: 100%;
        }

        .bw-btn-primary {
            background: linear-gradient(135deg, #dc2626, #ef4444);
            color: white;
            box-shadow: 0 8px 16px rgba(220, 38, 38, 0.35);
        }
        .bw-btn-primary:hover {
            background: linear-gradient(135deg, #b91c1c, #dc2626);
            box-shadow: 0 10px 20px rgba(220, 38, 38, 0.45);
        }

        .bw-btn-outline {
            background: linear-gradient(135deg, #dc2626, #ef4444);
            color: white;
            border: none;
        }
        .bw-btn-outline:hover {
            opacity: .9;
        }

        .bw-form-group {
            margin-bottom: 12px;
        }
        .bw-label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 4px;
            color: var(--premium-text);
        }
        .bw-input {
            width: 100%;
            padding: 10px 11px;
            border-radius: 10px;
            border: 1px solid #D1D5DB;
            font-size: 14px;
            outline: none;
            transition: border 0.2s ease, box-shadow 0.2s ease;
        }
        .bw-input:focus {
            border-color: #dc2626;
            box-shadow: 0 0 0 1px rgba(220, 38, 38, 0.35);
        }

        .bw-form-footer {
            margin-top: 12px;
            font-size: 13px;
            color: #6B7280;
        }

        .betwallet-text {
            color:red;
        }

        /* USDT CÜZDAN BLOĞU */
        .bw-wallet-select {
            margin-top: 6px;
        }
        .bw-wallet-option {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 12px;
            border-radius: 10px;
            border: 1px dashed #dc2626;
            background: #F9FAFB;
            pointer-events: none; /* tıklanamaz/seçilemez */
            user-select: none;
        }
        .bw-wallet-option .left {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .bw-wallet-option .coin-text {
            display: flex;
            flex-direction: column;
        }
        .bw-wallet-option .coin-name {
            font-size: 14px;
            font-weight: 600;
            color: var(--premium-text);
        }
        .bw-wallet-option .coin-sub {
            font-size: 12px;
            color: #6B7280;
        }
        .bw-wallet-option .right i {
            font-size: 14px;
            color: #dc2626;
        }

        .usdt-icon {
            width: 34px;
            height: 34px;
            border-radius: 8px;
            background: #26A17B;
            color: #ffffff;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: 700;
            font-size: 16px;
            font-family: 'Montserrat', sans-serif;
            box-shadow: 0 0 12px rgba(38, 161, 123, 0.25);
        }

        /* SMS blok ufak layout */
        .bw-sms-row {
            display: flex;
            gap: 8px;
            align-items: center;
        }
        .bw-sms-row input {
            flex: 1;
        }
        .bw-sms-btn {
            white-space: nowrap;
            padding: 9px 12px;
            border-radius: 10px;
            border: none;
            background: #ef4444;
            color: #fff;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
        }
        .bw-sms-btn:hover {
            background: #dc2626;
        }
        .bw-sms-hint {
            font-size: 11px;
            color: #6B7280;
            margin-top: 4px;
        }

        /* ============================================
           AÇILIŞ INTRO – TÜM APP-FRAME KIRMIZI
           ============================================ */
        .bw-intro-cover {
            position: absolute;
            inset: 0;                 /* tüm app-frame alanını kapla */
            background: #dc2626;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10;
            animation: bwIntroFadeOut 0.7s ease-out 1.4s forwards;
        }

        .bw-intro-wallet {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 10px;
            color: #fff;
            transform: scale(0.6);
            opacity: 0;
            animation: bwWalletZoom 1.2s cubic-bezier(0.22, 0.61, 0.36, 1) forwards;
        }

       .bw-intro-wallet-icon {
    width: 92px;
    height: 92px;
    border-radius: 24px;
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;

    background: rgba(255, 255, 255, 0.06);
    backdrop-filter: blur(6px);

    box-shadow:
        0 0 40px rgba(255, 255, 255, 0.35),
        0 0 90px rgba(0, 0, 0, 0.35),
        inset 0 0 25px rgba(255, 255, 255, 0.12);
}

.bw-intro-wallet-icon i {
    font-size: 38px;
    color: #fff;
    text-shadow:
        0 0 15px rgba(255,255,255,0.9),
        0 0 25px rgba(255,255,255,0.4);
}

.bw-intro-wallet-text {
    font-family: var(--font-heading);
    font-size: 24px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.18em;
    color: #ffffff;

    text-shadow:
        0 0 15px rgba(255,255,255,0.8),
        0 0 40px rgba(255,255,255,0.35);

    transform: translateY(8px);
    opacity: 0;
    animation: bwWalletZoom 1.2s cubic-bezier(0.22, 0.61, 0.36, 1) forwards;
}


        @keyframes bwWalletZoom {
            0% {
                transform: scale(0.6);
                opacity: 0;
            }
            40% {
                transform: scale(1);
                opacity: 1;
            }
            100% {
                transform: scale(1.25);
                opacity: 1;
            }
        }

        @keyframes bwIntroFadeOut {
            0% {
                opacity: 1;
            }
            100% {
                opacity: 0;
                visibility: hidden;
            }
        }
    </style>
</head>
<body>

<div class="app-frame">

    <!-- APP-FRAME'İ KAPLAYAN KIRMIZI INTRO -->
    <div class="bw-intro-cover" id="bw-intro-cover">
        <div class="bw-intro-wallet">
            <div class="bw-intro-wallet-icon">
                <i class="fas fa-wallet"></i>
            </div>
            <div class="bw-intro-wallet-text">BETWALLET</div>
        </div>
    </div>
    <!-- /INTRO -->

    <div class="bw-auth-shell">

        <div class="bw-logo-container">
            <div class="bw-logo">
                <i class="fas fa-shield-alt"></i> <span class="betwallet-text">BetWallet</span>
            </div>
            <p>Güvenli ve Hızlı Dijital Cüzdanınız</p>
        </div>

        <?php if ($error): ?>
            <div class="bw-alert bw-alert-error">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="bw-alert bw-alert-success">
                <?= htmlspecialchars($success) ?>
            </div>
        <?php endif; ?>

        <div class="bw-views-wrapper">

            <!-- LANDING VIEW -->
            <div class="bw-view <?php echo $initialView === 'landing' ? 'is-active' : ''; ?>" data-view="landing" id="landing-section">
                <div class="bw-landing-actions">
                    <button type="button" class="bw-btn bw-btn-primary js-open-login">
                        Giriş Yap
                    </button>
                    <button type="button" class="bw-btn bw-btn-outline js-open-register">
                        Kayıt Ol
                    </button>
                </div>
            </div>

            <!-- LOGIN VIEW -->
            <div class="bw-view <?php echo $initialView === 'login' ? 'is-active' : ''; ?>" data-view="login" id="login-section">

                <form method="post" action="/login">
                    <?= csrf_field(); ?>
                    <div class="bw-form-group">
                        <label class="bw-label">Kullanıcı Adı</label>
                        <input type="text" name="username" class="bw-input" required>
                    </div>

                    <div class="bw-form-group">
                        <label class="bw-label">Şifre</label>
                        <input type="password" name="password" class="bw-input" required>
                    </div>

                    <!-- GİRİŞ YAPILACAK CÜZDAN -->
                    <div class="bw-form-group">
                        <label class="bw-label">Giriş Yapılacak Cüzdan</label>

                        <div class="bw-wallet-select">
                            <div class="bw-wallet-option">
                                <div class="left">
                                    <span class="usdt-icon">₮</span>
                                    <div class="coin-text">
                                        <div class="coin-name">USDT Cüzdanı</div>
                                        <div class="coin-sub">TRC20 · Varsayılan</div>
                                    </div>
                                </div>
                                <div class="right">
                                    <i class="fas fa-lock"></i>
                                </div>
                            </div>
                        </div>

                        <input type="hidden" name="wallet_coin" value="USDT">
                    </div>

                    <button type="submit" class="bw-btn bw-btn-primary" style="margin-top:10px;">
                        Giriş Yap
                    </button>

                    <div class="bw-form-footer">
                        Hesabın yok mu?
                        <span class="js-switch-register" style="color:red; cursor:pointer;">Hemen kayıt ol</span>
                    </div>
                </form>
            </div>

            <!-- REGISTER VIEW -->
            <div class="bw-view <?php echo $initialView === 'register' ? 'is-active' : ''; ?>" data-view="register" id="register-section">

                <form method="post" action="/register">
                    <?= csrf_field(); ?>

                    <div class="bw-form-group">
                        <label class="bw-label">Kullanıcı Adı</label>
                        <input type="text" name="username" class="bw-input" required>
                    </div>

                    <div class="bw-form-group">
                        <label class="bw-label">Ad Soyad</label>
                        <input type="text" name="full_name" class="bw-input" required>
                    </div>

                    <div class="bw-form-group">
                        <label class="bw-label">Telefon Numarası</label>
                        <input type="tel" name="phone" class="bw-input" placeholder="+90 5XX XXX XX XX" required>
                    </div>

                    <div class="bw-form-group">
                        <label class="bw-label">E-posta (Opsiyonel)</label>
                        <input type="email" name="email" class="bw-input" placeholder="ornek@mail.com">
                    </div>

                    <div class="bw-form-group">
                        <label class="bw-label">Şifre</label>
                        <input type="password" name="password" class="bw-input" required>
                    </div>

                    <div class="bw-form-group">
                        <label class="bw-label">Şifre (Tekrar)</label>
                        <input type="password" name="password2" class="bw-input" required>
                    </div>

                    <!-- SMS DOĞRULAMA BLOĞU (Şimdilik sadece gösteriş) -->
                    <div class="bw-form-group">
                        <label class="bw-label">SMS Doğrulama</label>
                        <div class="bw-sms-row">
                            <input type="text" name="sms_code" class="bw-input" placeholder="SMS kodu (şimdilik zorunlu değil)">
                            <button type="button" class="bw-sms-btn">Kodu Gönder</button>
                        </div>
                        <div class="bw-sms-hint">
                            SMS doğrulama özelliği yakında aktif olacaktır.
                        </div>
                    </div>

                    <!-- OLUŞTURULACAK CÜZDAN (Sabit USDT) -->
                    <div class="bw-form-group">
                        <label class="bw-label">Oluşturulacak Cüzdan</label>
                        <div class="bw-wallet-select">
                            <div class="bw-wallet-option">
                                <div class="left">
                                    <span class="usdt-icon">₮</span>
                                    <div class="coin-text">
                                        <div class="coin-name">USDT Cüzdanı</div>
                                        <div class="coin-sub">TRC20 · Varsayılan</div>
                                    </div>
                                </div>
                                <div class="right">
                                    <i class="fas fa-lock"></i>
                                </div>
                            </div>
                            <!-- Backend'e sabit olarak USDT gitsin -->
                            <input type="hidden" name="wallet_coin" value="USDT">
                        </div>
                    </div>

                    <button type="submit" class="bw-btn bw-btn-primary" style="margin-top:10px;">
                        Kayıt Ol
                    </button>

                    <div class="bw-form-footer">
                        Zaten hesabın var mı?
                        <span class="js-switch-login" style="color:red; cursor:pointer;">Giriş yap</span>
                    </div>
                </form>
            </div>

        </div>

    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const frame      = document.querySelector('.app-frame');
    const introCover = document.getElementById('bw-intro-cover');

    const btnLandingToLogin    = document.querySelector('.js-open-login');
    const btnLandingToRegister = document.querySelector('.js-open-register');
    const switchToLogin        = document.querySelectorAll('.js-switch-login');
    const switchToRegister     = document.querySelectorAll('.js-switch-register');

    const initialView = "<?php echo $initialView; ?>";

    // Sayfa açılış animasyonu
    setTimeout(() => {
        if (!frame) return;
        frame.style.opacity = '1';
        frame.style.transform = 'scale(1)';
    }, 50);

    // Intro overlay animasyonu bittikten sonra DOM'dan kaldır
    if (introCover) {
        introCover.addEventListener('animationend', function (e) {
            if (e.animationName === 'bwIntroFadeOut') {
                if (introCover && introCover.parentNode) {
                    introCover.parentNode.removeChild(introCover);
                }
            }
        });
    }

    function getView(name) {
        return document.querySelector('.bw-view[data-view="' + name + '"]');
    }

    function setView(target) {
        const next = getView(target);
        if (!next) return;

        const current = document.querySelector('.bw-view.is-active');
        if (current === next) return;

        if (current) {
            current.classList.add('is-leaving');
            current.classList.remove('is-active');
            setTimeout(() => {
                current.classList.remove('is-leaving');
            }, 280);
        }

        next.classList.add('is-active');

        // URL param güncelle (opsiyonel)
        if (history.replaceState) {
            const url = new URL(window.location.href);
            if (target === 'landing') {
                url.searchParams.delete('v');
            } else {
                url.searchParams.set('v', target);
            }
            history.replaceState(null, '', url.toString());
        }
    }

    // Başlangıç view'i JS tarafında da sabitle
    if (initialView !== 'landing') {
        setView(initialView);
    }

    if (btnLandingToLogin) {
        btnLandingToLogin.addEventListener('click', function () {
            setView('login');
        });
    }

    if (btnLandingToRegister) {
        btnLandingToRegister.addEventListener('click', function () {
            setView('register');
        });
    }

    switchToLogin.forEach(el => {
        el.addEventListener('click', () => setView('login'));
    });

    switchToRegister.forEach(el => {
        el.addEventListener('click', () => setView('register'));
    });
});
</script>

</body>
</html>
