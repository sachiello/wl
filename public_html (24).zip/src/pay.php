<?php
// pay.php
require __DIR__ . '/../config/config.php';

$error   = null;
$site    = null;
$orderId = null;
$amount  = null;
$step    = 'params';

// 1) URL parametrelerini oku
$merchantId = $_GET['merchant_id'] ?? null;
$orderId    = $_GET['order_id']    ?? null;
$amount     = $_GET['amount']      ?? null;
$currency   = $_GET['currency']    ?? 'TRY';
$ts         = $_GET['ts']          ?? null;
$sig        = $_GET['sig']         ?? null;

// Hiç parametre yoksa (doğrudan /pay.php açılmışsa) demo ekranı göster
if (!$merchantId && !$orderId && !$amount && !$ts && !$sig) {
    $step = 'no_params';
} else {
    // Bazıları var ama hepsi yoksa gerçekten eksik parametre
    if (!$merchantId || !$orderId || !$amount || !$ts || !$sig) {
        $error = 'Eksik parametre.';
    } else {
        // 2) Merchant'ı bul
        $stmt = $pdo->prepare("SELECT * FROM sites WHERE id = ? AND is_active = 1 LIMIT 1");
        $stmt->execute([(int)$merchantId]);
        $site = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$site) {
            $error = 'Geçersiz merchant.';
        } else {
            // 3) İmzayı doğrula
            $params = [
                'merchant_id' => (int)$merchantId,
                'order_id'    => $orderId,
                'amount'      => $amount,
                'currency'    => $currency,
                'ts'          => $ts,
            ];
            $expectedSig = make_signature($site['api_secret'], $params);

            if (!hash_equals($expectedSig, $sig)) {
                $error = 'İmza doğrulanamadı (sig hatalı).';
            } else {
                $step = 'login';
            }
        }
    }
}

// Login & ödeme simülasyonu:
$loggedUser           = null;
$betwalletBalanceTry  = 1000.00; // DEMO: sabit bakiye (ileride wallets tablosuna bağlanacak)

if ($step === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_validate_request()) {
        $error = 'Oturum doğrulaması başarısız. Lütfen sayfayı yenileyip tekrar deneyin.';
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');

        if ($username === '' || $password === '') {
            $error = 'Kullanıcı adı ve şifre zorunludur.';
        } else {
            $u = $pdo->prepare("SELECT * FROM users WHERE username = ? OR trc20_address = ? LIMIT 1");
            $u->execute([$username, $username]);
            $user = $u->fetch(PDO::FETCH_ASSOC);

            if (!$user || !password_verify($password, $user['password_hash'])) {
                $error = 'Geçersiz kullanıcı veya şifre.';
            } else {
                $loggedUser = $user;
                $step       = 'confirm';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="utf-8">
  <title>Betwallet Ödeme</title>
  <link rel="stylesheet" href="assets/betwallet.css">
</head>
<body>
<div class="bw-center-page">
  <header class="bw-header">
    <div class="bw-logo">
      <div class="bw-logo-icon">BW</div>
      <div class="bw-logo-text">
        <span>BETWALLET</span>
        <span>Ödeme Sayfası</span>
      </div>
    </div>
  </header>

  <section class="bw-card">
    <div class="bw-card-header">
      <div>
        <div class="bw-card-title">Betwallet ile Yatırım</div>
        <div class="bw-card-subtitle">
          Anlaşmalı siteden Betwallet ödeme yöntemini seçtin, şimdi işlemi tamamlayabilirsin.
        </div>
      </div>
      <div class="bw-pill">Ödeme</div>
    </div>

    <?php if ($error): ?>
      <div class="bw-alert-danger">
        <?= htmlspecialchars($error) ?>
      </div>
    <?php endif; ?>

    <?php if ($step === 'no_params'): ?>

      <p class="bw-text-muted">
        Bu sayfa doğrudan açılmış görünüyor. Normalde buraya, anlaşmalı sitenin
        <strong>“Betwallet ile yatır”</strong> seçeneğinden yönlendirilmen gerekiyor.
      </p>
      <p class="bw-text-muted">
        Demo için aşağıdan Sekabet entegrasyonunu test edebilirsin:
      </p>
      <a href="merchant_demo.php" class="bw-btn bw-btn-primary" style="margin-top:8px;">
        Sekabet demo başlat
      </a>
      <a href="index.php" class="bw-btn bw-btn-outline" style="margin-top:8px; margin-left:6px;">
        Ana sayfaya dön
      </a>

    <?php elseif (!$error && $site): ?>

      <!-- Üstte işlem özeti -->
      <div style="margin-bottom:14px;">
        <div class="bw-badge" style="margin-bottom:6px;">
          <span>Site:</span>
          <strong><?= htmlspecialchars($site['name']) ?></strong>
        </div>
        <div class="bw-text-muted">
          İşlem ID: <strong><?= htmlspecialchars($orderId) ?></strong><br>
          Tutar: <strong><?= htmlspecialchars($amount) . ' ' . htmlspecialchars($currency) ?></strong>
        </div>
      </div>

      <?php if ($step === 'login'): ?>

        <h2 style="font-size:15px; margin:10px 0 8px;">Betwallet Giriş</h2>
        <p class="bw-text-muted" style="margin-bottom:10px;">
          Betwallet hesabınla giriş yap, bakiyeni gör ve <strong><?= htmlspecialchars($site['name']) ?></strong>
          hesabına aktarım yap.
        </p>

        <form method="post">
          <?= csrf_field(); ?>
          <div class="bw-form-group">
            <label class="bw-label">Betwallet kullanıcı adı veya TRC20 adresi</label>
            <input type="text" name="username" class="bw-input" required>
          </div>
          <div class="bw-form-group">
            <label class="bw-label">Şifre</label>
            <input type="password" name="password" class="bw-input" required>
          </div>
          <button type="submit" class="bw-btn bw-btn-primary" style="margin-top:6px;">
            Giriş yap ve devam et
          </button>
        </form>
        <p class="bw-text-muted" style="margin-top:10px; font-size:12px;">
          Henüz Betwallet hesabın yoksa önce ana sayfadan <strong>“Tek tıkla cüzdan oluştur”</strong> adımını tamamlaman gerekir.
        </p>

      <?php elseif ($step === 'confirm' && $loggedUser): ?>

        <h2 style="font-size:15px; margin:10px 0 8px;">Yatırımı Onayla</h2>
        <p class="bw-text-muted">
          Merhaba, <strong><?= htmlspecialchars($loggedUser['username']) ?></strong>
        </p>
        <p class="bw-text-muted">
          Demo bakiyen: <strong><?= number_format($betwalletBalanceTry, 2) ?> ₺</strong><br>
          <?= htmlspecialchars($site['name']) ?> için yatırılacak tutar:
          <strong><?= htmlspecialchars($amount) . ' ' . htmlspecialchars($currency) ?></strong>
        </p>

        <p class="bw-text-muted" style="margin-top:8px;">
          Bu demoda sadece işlem akışını gösteriyoruz. Gerçekte bu ekranda:
        </p>
        <ul class="bw-list">
          <li>• Betwallet cüzdanından ilgili coin (TRX/USDT) düşülecek</li>
          <li>• <code>site_deposit_requests</code> tablosuna kayıt oluşturulacak</li>
          <li>• Sitenin <code>callback_url</code> adresine onay isteği gönderilecek</li>
        </ul>

        <div class="bw-alert-success" style="margin-top:10px;">
          Demo: <strong><?= htmlspecialchars($site['name']) ?></strong> hesabına
          <strong><?= htmlspecialchars($amount) . ' ' . htmlspecialchars($currency) ?></strong>
          gönderimi simüle edildi ✅
        </div>

        <a href="index.php" class="bw-btn bw-btn-outline" style="margin-top:10px;">
          Ana sayfaya dön
        </a>

      <?php endif; ?>

    <?php else: ?>

      <p class="bw-text-muted">
        Geçersiz istek. Lütfen işlemi tekrar başlatın veya demo için ana sayfaya dönün.
      </p>
      <a href="index.php" class="bw-btn bw-btn-outline" style="margin-top:8px;">
        Ana sayfaya dön
      </a>

    <?php endif; ?>
  </section>
</div>
</body>
</html>
