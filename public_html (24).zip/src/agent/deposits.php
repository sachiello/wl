<?php
// agent/deposits.php - FINAL SÜRÜM (DB KURU ENTEGRELİ)
require 'init.php'; 

// Yetki Kontrolü
if ($isPersonnel && !hasPerm('approve_deposit')) {
    die("<div style='padding:50px; text-align:center; color:red; font-weight:bold;'>Bu sayfayı görüntüleme yetkiniz yok.</div>");
}

// --------------------------------------------------------
// İşlemi Gerçekleştiren Kişinin ID'si
// --------------------------------------------------------
$processorId    = $_SESSION['agent_id']; 

// İşlem hedef Agent ID'si (Emirlerin ait olduğu Ana Agent)
$targetAgentId = $masterAgentId;

// Onaylayan alanları ayarla:
$processedAgentId      = $targetAgentId;
$processedPersonnelId  = $isPersonnel ? $processorId : null;
// --------------------------------------------------------

$csrfFailed = false;

// CSRF (GÜVENLİK KONTROLÜ)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !csrf_validate_request()) {
    $csrfFailed = true;
    redirect_after_post('error', 'Oturum doğrulaması başarısız. Lütfen sayfayı yenileyip tekrar deneyin.');
}

// --------------------------
// LOGIC: DEPOSIT CONFIRM
// --------------------------
if (!$csrfFailed && $_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['confirm_id'])) {

    $orderId = (int)$_POST['confirm_id'];

    try {

        $pdo->beginTransaction();

        // 1) Emri kilitleyerek al (FOR UPDATE)
        $stmt = $pdo->prepare("
            SELECT 
                d.user_id,
                d.amount_try,
                d.coin_type,
                d.payment_method,
                d.coin_amount,
                d.rate_try_per_unit,
                da.commission_rate
            FROM deposit_orders d
            JOIN deposit_agents da ON da.id = d.agent_id
            WHERE d.id = ?
              AND d.agent_id = ?
              AND d.status = 'pending'
            FOR UPDATE
        ");
        $stmt->execute([$orderId, $targetAgentId]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$order) {
            throw new Exception("Yatırım emri bulunamadı veya daha önce işlenmiş.");
        }

        $userId        = (int)$order['user_id'];
        $amountTRY     = (float)$order['amount_try'];
        $paymentMethod = $order['payment_method'] ?? 'havale';

        // Coin tipi her zaman USDT olarak kabul edilecek
        $coinType      = 'USDT'; 

        $storedCoinAmount = isset($order['coin_amount']) ? (float)$order['coin_amount'] : 0;
        $storedRate       = isset($order['rate_try_per_unit']) ? (float)$order['rate_try_per_unit'] : 0.0;

        // --------------------------------
        // TRY → USDT VERİTABANI KURU İLE ÇEVİR (HAVALE)
        // --------------------------------
        if ($paymentMethod === 'havale') {

            // 1. API YERİNE VERİTABANINDAN KURU ÇEKİYORUZ
            // Bu sayede wallet.php ile burası %100 aynı kuru kullanır.
            $rateStmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'usdt_try_rate' LIMIT 1");
            $rateStmt->execute();
            $dbRate = $rateStmt->fetchColumn();

            // 2. Kur Güvenlik Kontrolü
            // Eğer veritabanında kur 0 veya boşsa sistemin kilitlenmemesi için mantıklı bir fallback (örn: 34) kullanır.
            $rate = ($dbRate && (float)$dbRate > 0) ? (float)$dbRate : 34.00;

            // 3. Hesaplama: (Tutar / Kur)
            $coinAmount = round($amountTRY / $rate, 4); 

        } else {
            // --------------------------------
            // KRİPTO YATIRIM: Sadece USDT kabul edildiği varsayılır. coin_amount ÖNCELİKLİ
            // --------------------------------
            if ($storedCoinAmount > 0) {
                $coinAmount = $storedCoinAmount;
            } elseif ($storedRate > 0) {
                // Eski kayıtlar için fallback: TRY / kayıtlı kur
                $coinAmount = round($amountTRY / $storedRate, 6);
            } else {
                // En kötü durumda fallback: TRY miktarını doğrudan USDT gibi kabul et
                $coinAmount = $amountTRY;
            }
        }

// --------------------------------
// 2) Agent bakiyeleri güncelle (rezerv CREATE aşamasında düşüldü)
//    Burada sadece kasaya al + hacme ekle
// --------------------------------
$updAgent = $pdo->prepare("
    UPDATE deposit_agents
    SET 
        current_cash = current_cash + :amt,
        total_deposit_volume = total_deposit_volume + :amt
    WHERE id = :id
");
$updAgent->execute([
    ':amt' => $amountTRY,
    ':id'  => $targetAgentId, 
]);

// --------------------------------
        // 2) Agent Bakiyelerini ve Karı Güncelle
        // --------------------------------
        
        // Komisyon oranını çek (Zaten yukarıdaki SELECT sorgusunda 'commission_rate' var)
        $commissionRate = isset($order['commission_rate']) ? (float)$order['commission_rate'] : 0;
        $profitAmount = 0;

        // Kar hesapla: (Miktar * Oran) / 100
        if ($commissionRate > 0) {
            $profitAmount = ($amountTRY * $commissionRate) / 100;
        }

        // Tek sorguda KASA, HACİM ve KAR bakiyelerini güncelle
        $updAgent = $pdo->prepare("
            UPDATE deposit_agents
            SET 
                current_cash = current_cash + :amt,
                total_deposit_volume = total_deposit_volume + :amt,
                agent_profit_balance = agent_profit_balance + :profit,  /* Çekilebilir Kar */
                total_profit_earned = total_profit_earned + :profit     /* İstatistiksel Toplam Kar */
            WHERE id = :id
        ");
        
        $updAgent->execute([
            ':amt'    => $amountTRY,
            ':profit' => $profitAmount,
            ':id'     => $targetAgentId, 
        ]);

        // --------------------------------
        // 3) Wallet oluştur veya güncelle (coin_type: USDT olarak sabitlendi)
        // --------------------------------
        $chk = $pdo->prepare("
            SELECT id 
            FROM wallets 
            WHERE user_id = ? AND coin_type = 'USDT'
            LIMIT 1
        ");
        $chk->execute([$userId]);
        $walletId = $chk->fetchColumn();

        // Yoksa cüzdan oluştur
        if (!$walletId) {
            $ins = $pdo->prepare("
                INSERT INTO wallets (user_id, coin_type, balance, created_at)
                VALUES (?, 'USDT', 0, NOW())
            ");
            $ins->execute([$userId]);
        }

        // Bakiyeyi ekle (Sadece USDT'ye ekle)
        $updWallet = $pdo->prepare("
            UPDATE wallets
            SET balance = balance + :amt
            WHERE user_id = :uid AND coin_type = 'USDT'
        ");
        $updWallet->execute([
            ':amt'    => $coinAmount,
            ':uid'    => $userId,
        ]);

        if ($updWallet->rowCount() === 0) {
            throw new Exception("Cüzdan güncellenemedi.");
        }

        // --------------------------------
        // 4) Emri confirmed yap + ONAYLAYAN KİŞİ
        // --------------------------------
        $updOrder = $pdo->prepare("
            UPDATE deposit_orders
            SET 
                status = 'approved',
                confirmed_at = NOW(),
                processed_by_agent_id       = :processed_agent_id,
                processed_by_personnel_id = :processed_personnel_id,
                coin_amount               = :coin_amt,
                coin_type                 = 'USDT' -- Emin olmak için güncellenir
            WHERE id = :id
        ");
        $updOrder->execute([
            ':processed_agent_id'      => $processedAgentId,
            ':processed_personnel_id' => $processedPersonnelId,
            ':coin_amt'               => $coinAmount,
            ':id'                     => $orderId,
        ]);

        // --------------------------------
        // 5) LOG
        // --------------------------------
        agent_log($pdo, 'deposit_confirmed', [
            'order_id'    => $orderId,
            'amount_try'  => $amountTRY,
            'coin_type'   => 'USDT', // Loga sabit USDT gönder
            'coin_amount' => $coinAmount
        ]);

        $pdo->commit();

        $message = number_format($amountTRY, 2) . " TL yatırımı onaylandı. Hesaba geçen: " . number_format($coinAmount, 2) . " USDT";
        redirect_after_post('success', $message);

    } catch (Exception $e) {

        if ($pdo->inTransaction()) $pdo->rollBack();
        redirect_after_post('error', "İşlem Hatası: " . $e->getMessage());
    }
}

// --------------------------
// LOGIC: DEPOSIT REJECT
// --------------------------
// --------------------------
// LOGIC: DEPOSIT REJECT
// --------------------------
if (!$csrfFailed && $_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reject_id'])) {
    
    $orderId = (int)$_POST['reject_id'];
    $reason  = trim($_POST['reject_reason'] ?? 'Reddedildi.');

    try {
        $pdo->beginTransaction();

        // 1) İlgili emri kilitle ve bilgileri çek
        $stmt = $pdo->prepare("
            SELECT 
                id,
                amount_try,
                agent_id,
                payment_method,
                status
            FROM deposit_orders
            WHERE id = ?
              AND agent_id = ?
              AND status = 'pending'
            FOR UPDATE
        ");
        $stmt->execute([$orderId, $targetAgentId]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$order) {
            throw new Exception("Talep zaten işlenmiş veya bulunamadı.");
        }

        $amountTRY      = (float)$order['amount_try'];
        $orderAgentId   = (int)$order['agent_id'];
        $paymentMethod  = $order['payment_method'];

        // 2) Emri reddet
        $stmtUpd = $pdo->prepare("
            UPDATE deposit_orders
            SET status = 'rejected',
                fail_reason = ?,
                confirmed_at = NOW(),
                processed_by_agent_id      = ?,
                processed_by_personnel_id  = ?
            WHERE id = ?
        ");
        $stmtUpd->execute([
            $reason,
            $processedAgentId,
            $processedPersonnelId,
            $orderId
        ]);

        if ($stmtUpd->rowCount() === 0) {
            throw new Exception("Talep güncellenemedi.");
        }

        // 3) Sadece HAVALE işlemlerinde rezervi iade et
        //    (crypto tarafında agent teminatından rezerv düşmedik)
        if ($paymentMethod === 'havale') {
            $refund = $pdo->prepare("
                UPDATE deposit_agents
                SET system_balance = system_balance + :amt
                WHERE id = :id
            ");
            $refund->execute([
                ':amt' => $amountTRY,
                ':id'  => $orderAgentId
            ]);
        }

        // 4) LOG
        agent_log($pdo,'deposit_rejected',[
            'order_id'     => $orderId,
            'reason'       => $reason,
            'amount_try'   => $amountTRY,
            'payment_type' => $paymentMethod
        ]);

        $pdo->commit();
        redirect_after_post('success', "Yatırım talebi reddedildi, rezerv edilen tutar iade edildi.");

    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        redirect_after_post('error', "Talep reddedilirken hata: " . $e->getMessage());
    }
}

?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yatırım Onayı</title>
    
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        /* BASE & LAYOUT (Sidebar'dan bağımsız içerik stilleri) */
        :root { --primary: #c2273f; --bg-body: #f1f5f9; --bg-card: #ffffff; --text-main: #0f172a; --text-muted: #64748b; --border-color: #e2e8f0; --shadow-soft: 0 4px 6px -1px rgba(0,0,0,0.05); --radius-md: 8px; }
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; }
        
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        .main-content { flex: 1; padding: 30px; overflow-y: auto; }
        
        /* TOPBAR & TOOLBAR */
        .topbar h1 { font-size: 24px; font-weight: 800; margin: 0 0 20px 0; color: var(--text-main); }
        
        .toolbar-container { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; gap: 15px; flex-wrap: wrap; }
        .modern-tabs { display: inline-flex; background: #fff; padding: 4px; border-radius: var(--radius-md); border: 1px solid var(--border-color); gap: 4px; }
        .tab-btn { padding: 8px 16px; border-radius: 6px; color: var(--text-muted); font-size: 13px; font-weight: 600; display: flex; align-items: center; gap: 6px; cursor: pointer; border: none; background: transparent; transition: all 0.2s; }
        .tab-btn:hover { background: #f8fafc; color: var(--primary); }
        .tab-btn.is-active { background: var(--primary); color: #fff; }
        
        .toolbar-actions { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
        .filter-select { padding: 8px 12px; border-radius: var(--radius-md); border: 1px solid var(--border-color); background: #fff; font-size: 13px; outline: none; }
        .search-wrapper { position: relative; }
        .search-wrapper i { position: absolute; left: 10px; top: 50%; transform: translateY(-50%); color: var(--text-muted); font-size: 14px; }
        .search-input { padding: 8px 8px 8px 32px; border-radius: var(--radius-md); border: 1px solid var(--border-color); background: #fff; font-size: 13px; width: 200px; outline: none; }
        
        .update-badge { font-size: 12px; color: var(--text-muted); display: flex; align-items: center; gap: 6px; background: #fff; padding: 8px 12px; border-radius: 20px; border: 1px solid var(--border-color); }
        
        /* CARD & TABLE */
        .card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); box-shadow: var(--shadow-soft); padding: 0; overflow: hidden; margin-bottom: 20px; }
        .card.bg-green { background: #ecfdf5; border-color: #10b981; color: #065f46; padding: 15px; }
        .card.bg-red { background: #fef2f2; border-color: #ef4444; color: #991b1b; padding: 15px; }
        
        .table-container { overflow-x: auto; }
        .admin-table { width: 100%; border-collapse: collapse; font-size: 14px; }
        .admin-table th { text-align: left; padding: 14px 20px; color: var(--text-muted); font-weight: 600; border-bottom: 1px solid var(--border-color); font-size: 12px; text-transform: uppercase; background: #f8fafc; }
        .admin-table td { padding: 14px 20px; border-bottom: 1px solid var(--border-color); vertical-align: middle; color: var(--text-main); }
        .admin-table tr:last-child td { border-bottom: none; }
        
        /* BADGES & BUTTONS */
        .badge { padding: 4px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
        .badge.pending { background: #fffbeb; color: #b45309; border: 1px solid #fcd34d; }
        .badge.success { background: #ecfdf5; color: #047857; border: 1px solid #6ee7b7; }
        .badge.danger { background: #fef2f2; color: #b91c1c; border: 1px solid #fca5a5; }
        
        .badge-method { padding: 4px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; text-transform: uppercase; display: inline-flex; align-items: center; gap: 4px; }
        .badge-havale { background: #eff6ff; color: #1d4ed8; border: 1px solid #dbeafe; }
        .badge-crypto { background: #fefce8; color: #a16207; border: 1px solid #fef08a; }

        .action-group { display: flex; gap: 8px; justify-content: flex-end; }
        .btn-icon { width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; border-radius: 8px; border: none; cursor: pointer; transition: all 0.2s; font-size: 16px; }
        .btn-approve { background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; }
        .btn-approve:hover { background: #16a34a; color: #fff; }
        .btn-reject { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
        .btn-reject:hover { background: #dc2626; color: #fff; }
        
        /* MODAL */
        .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 999; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(2px); }
        .modal-content { background: #fff; width: 100%; max-width: 400px; border-radius: 16px; padding: 24px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .modal-header h3 { margin: 0; font-size: 18px; font-weight: 700; }
        .close-btn { font-size: 24px; cursor: pointer; color: var(--text-muted); }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 8px; font-size: 13px; font-weight: 600; }
        .form-control { width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 8px; font-family: inherit; font-size: 14px; outline: none; box-sizing: border-box; }
        .form-control:focus { border-color: var(--primary); }

        /* ANIMATIONS */
        @keyframes spin { 100% { transform: rotate(360deg); } }
        .spinning-icon { animation: spin 1s linear infinite; color: var(--primary); display: inline-block; }
        .spinning-icon.paused { animation-play-state: paused; opacity: 0.5; }
        @keyframes softFlash { 0% { background-color: #dcfce7; } 100% { background-color: transparent; } }
        .new-item-flash { animation: softFlash 3s ease-out; }

        @media (max-width: 768px) {
            .toolbar-container {
                flex-direction: column;
                align-items: stretch;
            }
            .modern-tabs, .toolbar-actions {
                width: 100%;
                justify-content: center;
            }
            .search-input {
                width: 100%;
            }
            .modal-content {
                max-width: 90%;
            }
            .admin-table {
                min-width: 800px; /* Force table to be wide, letting container scroll */
            }
        }
    </style>
</head>
<body>

<div class="app-wrapper">

    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        <div class="topbar">
            <h1>Yatırım Onayı</h1>
        </div>

        <?php $flash = get_flash(); if ($flash): ?>
            <div class="card <?= $flash['type'] == 'success' ? 'bg-green' : 'bg-red' ?>">
                <div style="display:flex; align-items:center; gap:10px;">
                    <i class="ri-<?= $flash['type'] == 'success' ? 'checkbox-circle-fill' : 'error-warning-fill' ?>" style="font-size:20px;"></i>
                    <?= htmlspecialchars($flash['text']) ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="toolbar-container">
            <div class="modern-tabs">
                <button onclick="filterTable('all')" class="tab-btn is-active" id="tab-all"><i class="ri-apps-line"></i> Tümü</button>
                <button onclick="filterTable('havale')" class="tab-btn" id="tab-havale"><i class="ri-bank-card-line"></i> Havale</button>
                <button onclick="filterTable('crypto')" class="tab-btn" id="tab-crypto"><i class="ri-currency-line"></i> Kripto</button>
            </div>

            <div class="toolbar-actions">
                <select id="filterStatus" class="filter-select" onchange="masterFilter()">
                    <option value="all" selected>Tüm Durumlar</option>
                    <option value="pending">⏳ Bekleyenler</option>
                    <option value="approved">✅ Onaylananlar</option>
                    <option value="rejected">❌ Reddedilenler</option>
                </select>

                <div class="search-wrapper">
                    <i class="ri-search-line"></i>
                    <input type="text" id="searchInput" class="search-input" placeholder="Ref No veya Kullanıcı..." onkeyup="masterFilter()">
                </div>

                <div class="update-badge">
                    <i class="ri-refresh-line spinning-icon paused" id="refreshIcon"></i>
                    <span style="font-family: monospace; font-size: 13px;" id="lastUpdateTime">--:--:--</span>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="table-container">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Kullanıcı</th>
                            <th>Tutar</th>
                            <th>Yöntem</th>
                            <th>Detay (IBAN/Coin)</th>
                            <th>Tarih</th>
                            <th>Durum</th>
                            <th style="text-align: right;">İşlem</th>
                        </tr>
                    </thead>
                    <tbody id="depositTableBody">
                        </tbody>
                </table>
                <div id="no-data-row" style="display:none; text-align:center; padding: 40px; color: var(--text-muted);">
                    <i class="ri-inbox-line" style="font-size: 48px; display: block; margin-bottom: 10px; opacity: 0.3;"></i>
                    Filtrelere uygun talep bulunamadı.
                </div>
            </div>
        </div>
    </div>
</div>

<div id="rejectModal" class="modal-overlay" style="display:none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Yatırım Reddetme</h3>
            <span class="close-btn" onclick="closeModal('rejectModal')">&times;</span>
        </div>
        <form method="post">
            <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
            <input type="hidden" name="reject_id" id="rejectOrderId">
            <div class="form-group">
                <label>Reddetme Nedeni</label>
                <textarea name="reject_reason" class="form-control" rows="3" required placeholder="Örn: Hesap sahibi uyuşmuyor, Dekont sahte vb."></textarea>
            </div>
            <div style="text-align:right;">
                <button type="button" class="btn-icon" style="background:#f1f5f9; color:var(--text-muted); width:auto; padding:0 15px; margin-right:5px;" onclick="closeModal('rejectModal')">İptal</button>
                <button type="submit" class="btn-icon btn-reject" style="width:auto; padding:0 15px;">Reddet</button>
            </div>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>

<script>
    let currentCategory = 'all';
    let lastMaxId = 0; 
    let firstLoad = true;
    let targetAgentId = <?= $targetAgentId ?>;
    
    function openRejectModal(id) {
        document.getElementById('rejectOrderId').value = id;
        document.getElementById('rejectModal').style.display = 'flex';
    }
    
    function closeModal(id) { 
        document.getElementById(id).style.display = 'none'; 
    }
    
    // --- SEKME FİLTRESİ ---
    function filterTable(category) {
        currentCategory = category;
        const buttons = document.querySelectorAll('.tab-btn');
        buttons.forEach(btn => btn.classList.remove('is-active'));
        
        const activeBtn = document.getElementById('tab-' + category);
        if(activeBtn) activeBtn.classList.add('is-active');

        masterFilter(); 
    }

    // --- ANA FİLTRE MANTIĞI ---
    function masterFilter() {
        const statusFilter = document.getElementById('filterStatus').value; 
        const searchTerm = document.getElementById('searchInput').value.toLowerCase().trim();

        const rows = document.querySelectorAll('.deposit-row');
        let visibleCount = 0;

        rows.forEach(row => {
            const method = row.getAttribute('data-method'); 
            const status = row.getAttribute('data-status'); 
            const rowText = row.innerText.toLowerCase();

            const categoryMatch = (currentCategory === 'all' || method === currentCategory);
            // DB'den gelen 'confirmed' status'u approved olarak kabul et
            const statusMatch = (statusFilter === 'all' || status === statusFilter || (statusFilter === 'approved' && status === 'confirmed'));
            const searchMatch = (searchTerm === '' || rowText.includes(searchTerm));

            if (categoryMatch && statusMatch && searchMatch) {
                row.style.display = ''; 
                visibleCount++;
            } else {
                row.style.display = 'none';
            }
        });

        const noData = document.getElementById('no-data-row');
        if(noData) noData.style.display = (visibleCount === 0) ? 'block' : 'none';
    }

    // --- AJAX GÜNCELLEME ---
    function fetchNewData() {
        const refreshIcon = document.getElementById('refreshIcon');
        if(refreshIcon) refreshIcon.classList.remove('paused');

        fetch('api/table_deposits.php?t=' + new Date().getTime())
            .then(response => response.text())
            .then(html => {
                const tbody = document.getElementById('depositTableBody');
                document.getElementById('lastUpdateTime').innerText = new Date().toLocaleTimeString('tr-TR');

                if (tbody.innerHTML.trim() !== html.trim()) {
                    tbody.innerHTML = html;
                    masterFilter();
                    
                    const rows = document.querySelectorAll('.deposit-row');
                    let currentMaxId = 0;

                    rows.forEach(row => {
                        const id = parseInt(row.getAttribute('data-id'));
                        if(id > currentMaxId) currentMaxId = id;
                        if (!firstLoad && id > lastMaxId) {
                            row.classList.add('new-item-flash');
                        }
                    });

                    lastMaxId = currentMaxId;
                    firstLoad = false;
                }
            })
            .catch(error => console.error('Hata:', error))
            .finally(() => {
                if(refreshIcon) refreshIcon.classList.add('paused');
            });
    }

    document.addEventListener('DOMContentLoaded', () => {
        fetchNewData(); 
        setInterval(fetchNewData, 5000); 
        
        // Modal dışına tıklayınca kapat
        const overlay = document.querySelector('.modal-overlay');
        if (overlay) {
            overlay.addEventListener('click', function(e) {
                if (e.target === this) closeModal('rejectModal');
            });
        }
    });
</script>
</body>
</html>