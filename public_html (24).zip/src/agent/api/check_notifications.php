<?php
// agent/api/check_notifications.php
session_start();
require_once __DIR__ . '/../../../config/config.php';

if (!isset($_SESSION['agent_id'])) { http_response_code(403); exit; }

// Kimin bildirimleri? (Personelse Patronun ID'si)
$myId = $_SESSION['agent_id'];
$stmt = $pdo->prepare("SELECT role, parent_id FROM deposit_agents WHERE id = ?");
$stmt->execute([$myId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$targetId = ($user['role'] === 'personnel') ? $user['parent_id'] : $myId;

// Bekleyen sayıları çek
$pendingDeps = $pdo->prepare("SELECT COUNT(*) FROM deposit_orders WHERE agent_id = ? AND status = 'pending'");
$pendingDeps->execute([$targetId]);
$dCount = $pendingDeps->fetchColumn();

$pendingWds = $pdo->prepare("SELECT COUNT(*) FROM agent_withdraw_orders WHERE agent_id = ? AND status = 'pending'");
$pendingWds->execute([$targetId]);
$wCount = $pendingWds->fetchColumn();

header('Content-Type: application/json');
echo json_encode([
    'deposits' => $dCount,
    'withdrawals' => $wCount,
    'total' => $dCount + $wCount
]);
?>