<?php
// agent/api/profit_actions.php - FINAL (ADRES KAYDI EKLENDİ + BAKİYE DÜŞMEZ)
ob_start();
require_once __DIR__ . '/../init.php';
error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['agent_id'])) {
    ob_clean();
    echo json_encode(['status' => 'error', 'message' => 'Oturum süreniz dolmuş.']);
    exit;
}

$agentId = $masterAgentId ?? $_SESSION['agent_id'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    ob_clean();
    echo json_encode(['status' => 'error', 'message' => 'Geçersiz istek yöntemi.']);
    exit;
}

$action = $_POST['action'] ?? '';

try {
    // =================================================
    // SENARYO 1: KÂRI TEMİNATA AKTAR (ANLIK İŞLEM)
    // =================================================
    if ($action === 'profit_to_collateral') {
        $amount = floatval($_POST['amount']);
        if ($amount <= 0) throw new Exception("Geçersiz miktar.");

        $pdo->beginTransaction();

        $stmt = $pdo->prepare("SELECT agent_profit_balance FROM deposit_agents WHERE id = ? FOR UPDATE");
        $stmt->execute([$agentId]);
        $currentProfit = (float)$stmt->fetchColumn();

        if ($currentProfit < $amount) {
            throw new Exception("Yetersiz kâr bakiyesi.");
        }

        // Bakiyeyi ANINDA güncelle (Çünkü bu bir transfer, onay beklemez)
        $upd = $pdo->prepare("UPDATE deposit_agents SET agent_profit_balance = agent_profit_balance - :amt, system_balance = system_balance + :amt WHERE id = :id");
        $upd->execute([':amt' => $amount, ':id' => $agentId]);

        $pdo->prepare("INSERT INTO agent_profit_logs (agent_id, type, amount, fee_amount, description, created_at) VALUES (?, 'profit_to_collateral', ?, 0, ?, NOW())")
            ->execute([$agentId, $amount, "Kâr cüzdanından teminata aktarım."]);

        $pdo->commit();
        ob_clean();
        echo json_encode(['status' => 'success', 'message' => number_format($amount, 2) . ' TL teminata aktarıldı.']);
        exit;
    }

    // =================================================
    // SENARYO 2: KÂR ÇEKİM TALEBİ (ONAY BEKLER)
    // =================================================
    if ($action === 'withdraw_profit') {
        
        $amount  = floatval($_POST['amount']);
        $address = trim($_POST['trc20']); 

        if ($amount < 100) throw new Exception("Minimum çekim tutarı 100 TL'dir.");
        if (empty($address)) throw new Exception("Lütfen bir cüzdan adresi belirtin.");

        $pdo->beginTransaction();

        // 1. Mevcut Bakiyeyi Çek
        $stmt = $pdo->prepare("SELECT agent_profit_balance FROM deposit_agents WHERE id = ? FOR UPDATE");
        $stmt->execute([$agentId]);
        $currentBalance = (float)$stmt->fetchColumn();

        // 2. Bekleyen Taleplerin Toplamını Çek
        $stmtPending = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM agent_profit_withdraw_requests WHERE agent_id = ? AND status = 'pending'");
        $stmtPending->execute([$agentId]);
        $pendingTotal = (float)$stmtPending->fetchColumn();

        // 3. Kontrol: (Mevcut - Bekleyen) yetiyor mu?
        $availableBalance = $currentBalance - $pendingTotal;

        if ($availableBalance < $amount) {
            throw new Exception("Yetersiz bakiye. (Bekleyen işlemler düşüldüğünde kalan: " . number_format($availableBalance, 2) . " TL)");
        }

        // Kesinti Hesapla (%1)
        $feeRate = 1.00; 
        $feeAmount = round($amount * ($feeRate / 100), 2);
        $netAmount = $amount - $feeAmount;

        // 4. Talebi Kaydet (ADRESİ DE KAYDEDİYORUZ ARTIK)
        // Bakiye DÜŞMÜYOR, sadece talep oluşuyor.
        $ins = $pdo->prepare("
            INSERT INTO agent_profit_withdraw_requests 
            (agent_id, amount, fee_rate, fee_amount, amount_after_fee, wallet_address, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW())
        ");
        $ins->execute([$agentId, $amount, $feeRate, $feeAmount, $netAmount, $address]);

        // 5. Log Tut
        $descr = "Kâr çekim talebi (Cüzdan: " . $address . ")";
        $pdo->prepare("INSERT INTO agent_profit_logs (agent_id, type, amount, fee_amount, description, created_at) VALUES (?, 'profit_withdraw', ?, ?, ?, NOW())")
            ->execute([$agentId, $amount, $feeAmount, $descr]);

        $pdo->commit();

        ob_clean();
        echo json_encode(['status' => 'success', 'message' => 'Çekim talebi oluşturuldu. Yönetici onayı bekleniyor.']);
        exit;
    }

    throw new Exception("Geçersiz işlem türü.");

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    ob_clean();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    exit;
}
?>