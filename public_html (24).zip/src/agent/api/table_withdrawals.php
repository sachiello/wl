<?php
// agent/api/table_withdrawals.php - YOL DÜZELTİLDİ
// Dosya konumu: agent/api/ klasörü içinde varsayılıyor.
// init.php konumu: agent/ klasörü içinde varsayılıyor.
require_once __DIR__ . '/../init.php';

// Hata raporlamayı açalım (Geliştirme aşamasında hataları görmek için)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Oturum kontrolü
if (!isset($_SESSION['agent_id'])) { exit; }

// Personel yetki kontrolü
if (isset($isPersonnel) && $isPersonnel && function_exists('hasPerm') && !hasPerm('approve_withdraw')) {
    exit;
}

// Hedef Agent (Master)
$targetAgentId = $masterAgentId ?? $_SESSION['agent_id'];

try {
    // Çekim görevlerini çek
    // NOT: Eğer veritabanında 'processed_by_agent_id' sütunları yoksa bu sorgu hata verir.
    // Hata alırsanız SQL komutlarını çalıştırdığınızdan emin olun.
    $sql = "
        SELECT 
            awo.*, 
            u.username,
            pa.name as agent_name,
            pp.name as personnel_name
        FROM agent_withdraw_orders awo
        LEFT JOIN users u ON awo.user_id = u.id
        LEFT JOIN deposit_agents pa ON awo.processed_by_agent_id = pa.id
        LEFT JOIN deposit_agents pp ON awo.processed_by_personnel_id = pp.id
        WHERE awo.agent_id = ?
        ORDER BY awo.id DESC
        LIMIT 50
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$targetAgentId]);
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$tasks) {
        echo '<tr><td colspan="7" style="text-align:center; padding:30px; color:#94a3b8; font-size:13px;">
                <i class="ri-inbox-line" style="font-size:32px; display:block; margin-bottom:5px; opacity:0.5;"></i>
                Şu anda işlem bekleyen veya geçmiş kayıt bulunmuyor.
              </td></tr>';
        exit;
    }

    foreach ($tasks as $t):

        $dbStatus = strtolower(trim($t['status']));

        // CSS Sınıfları
        $statusClass = 'status-pending';
        $statusLabel = 'Bekliyor';
        $statusIcon  = 'ri-loader-4-line spinning-icon';

        if ($dbStatus === 'paid') {
            $statusClass = 'status-paid';
            $statusLabel = 'Ödendi';
            $statusIcon  = 'ri-check-double-line';
        } elseif ($dbStatus === 'rejected' || $dbStatus === 'failed') {
            $statusClass = 'status-rejected';
            $statusLabel = 'Reddedildi';
            $statusIcon  = 'ri-close-circle-line';
        } elseif ($dbStatus === 'assigned') {
            $statusLabel = 'İşleniyor';
        }

        $amountTry = number_format((float)$t['amount'], 2, ',', '.');
        $createdAt = $t['created_at'] ? date('d.m H:i', strtotime($t['created_at'])) : '-';

        // İşlem Yapan Bilgisi
        $processorInfo = '';
        if ($dbStatus !== 'pending' && $dbStatus !== 'assigned') {
            if (!empty($t['personnel_name'])) {
                $processorInfo = '<div style="font-size:10px; color:var(--text-muted); margin-top:4px;"><i class="ri-user-settings-line"></i> ' . htmlspecialchars($t['personnel_name']) . '</div>';
            } elseif (!empty($t['agent_name'])) {
                $processorInfo = '<div style="font-size:10px; color:var(--text-muted); margin-top:4px;"><i class="ri-shield-user-line"></i> ' . htmlspecialchars($t['agent_name']) . '</div>';
            }
        }

        // Banka bilgileri
        $bankName = $t['to_bank_name'] ?? '-';
        $iban     = $t['to_iban'] ?? '-';
        $fullName = $t['to_full_name'] ?? '-';
        $username = $t['username'] ?? 'Misafir';

    ?>
    <tr class="withdraw-row" data-id="<?= (int)$t['id'] ?>" data-status="<?= htmlspecialchars($dbStatus) ?>">

        <td style="padding:12px 20px; border-bottom:1px solid var(--border-color);">
            <span style="font-family:monospace; color:var(--text-muted); background:#f1f5f9; padding:2px 6px; border-radius:4px;">
                #<?= (int)$t['id'] ?>
            </span>
        </td>

        <td style="padding:12px 20px; border-bottom:1px solid var(--border-color); font-weight:700; color:#dc2626;">
            -<?= $amountTry ?> ₺
        </td>

        <td style="padding:12px 20px; border-bottom:1px solid var(--border-color);">
            <div style="font-weight:600; color:var(--text-main);"><?= htmlspecialchars($username) ?></div>
            <div style="font-size:11px; color:var(--text-muted);">ID: <?= (int)$t['user_id'] ?></div>
        </td>

        <td style="padding:12px 20px; border-bottom:1px solid var(--border-color);">
            <div style="font-weight:600; color:var(--text-main); font-size:13px;">
                <?= htmlspecialchars($bankName) ?>
            </div>
            <div style="font-family:monospace; font-size:11px; color:var(--text-muted); letter-spacing:0.5px;">
                <?= htmlspecialchars($iban) ?>
            </div>
            <div style="font-size:11px; color:var(--primary); font-weight:500;">
                <?= htmlspecialchars($fullName) ?>
            </div>
        </td>

        <td style="padding:12px 20px; border-bottom:1px solid var(--border-color); color:var(--text-muted); font-size:13px;">
            <?= $createdAt ?>
        </td>

        <td style="padding:12px 20px; border-bottom:1px solid var(--border-color);">
            <span class="badge-status <?= $statusClass ?>">
                <i class="<?= $statusIcon ?>"></i> <?= $statusLabel ?>
            </span>
            <?= $processorInfo ?>
            <?php if(($dbStatus === 'rejected' || $dbStatus === 'failed') && !empty($t['fail_reason'])): ?>
                <div style="font-size:10px; color:#ef4444; margin-top:2px; max-width:150px; line-height:1.2;">
                    <?= htmlspecialchars($t['fail_reason']) ?>
                </div>
            <?php endif; ?>
        </td>

        <td style="padding:12px 20px; border-bottom:1px solid var(--border-color); text-align:right;">
            <?php if ($dbStatus === 'pending' || $dbStatus === 'assigned'): ?>
                <div style="display:flex; gap:8px; justify-content:flex-end;">
                    
                    <form method="post" class="inline-form" onsubmit="return confirm('Bu çekim talebini ödediğinizi onaylıyor musunuz? \n\nTutar: <?= $amountTry ?> TL');">
                        <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
                        <input type="hidden" name="complete_task_id" value="<?= (int)$t['id'] ?>">
                        <button type="submit" class="btn-icon btn-pay" title="Ödemeyi Tamamla" style="background:#dcfce7; color:#166534; border:1px solid #bbf7d0;">
                            <i class="ri-check-line"></i>
                        </button>
                    </form>

                    <button type="button"
                            onclick="openRejectModal(<?= (int)$t['id'] ?>)"
                            class="btn-icon btn-reject"
                            title="Reddet / İptal Et">
                        <i class="ri-close-line"></i>
                    </button>

                </div>
            <?php else: ?>
                <div style="display:flex; justify-content:flex-end;">
                    <i class="ri-checkbox-circle-fill" style="color:#cbd5e1; font-size:24px;"></i>
                </div>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach;

} catch (PDOException $e) {
    // HATA YAKALAMA: Veritabanı hatası olursa tablo içinde göster
    echo '<tr><td colspan="7" style="padding:20px; color:red; background:#fee2e2; font-weight:bold; text-align:center;">
            <i class="ri-alarm-warning-fill" style="font-size:32px; display:block;"></i>
            SQL HATASI: ' . htmlspecialchars($e->getMessage()) . '<br><br>
            <span style="color:#333; font-weight:normal; font-size:12px;">
            Muhtemelen veritabanı sütunları eksik. Lütfen "processed_by_agent_id" vb. sütunları ekleyen SQL komutlarını çalıştırın.
            </span>
          </td></tr>';
}
?>