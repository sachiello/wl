<?php
// agent/api/live_counts.php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/config.php';

session_start();
if (!isset($_SESSION['agent_id'])) { echo json_encode(['status'=>'error']); exit; }

try {
    // Kimin verisi? (Personelse Patronun ID'si)
    $myId = $_SESSION['agent_id'];
    $stmt = $pdo->prepare("SELECT id, role, parent_id FROM deposit_agents WHERE id = ?");
    $stmt->execute([$myId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) { echo json_encode(['status'=>'error']); exit; }
    $targetId = ($user['role'] === 'personnel') ? $user['parent_id'] : $user['id'];

    // Sayımları Yap
    $counts = [];
    
    // Bekleyen Yatırımlar
    $stmtDep = $pdo->prepare("SELECT COUNT(*) FROM deposit_orders WHERE agent_id = ? AND status = 'pending'");
    $stmtDep->execute([$targetId]);
    $counts['deposits'] = (int)$stmtDep->fetchColumn();

    // Bekleyen Çekimler
    $stmtWd = $pdo->prepare("SELECT COUNT(*) FROM agent_withdraw_orders WHERE agent_id = ? AND status = 'pending'");
    $stmtWd->execute([$targetId]);
    $counts['withdrawals'] = (int)$stmtWd->fetchColumn();

    $total = $counts['deposits'] + $counts['withdrawals'];
    
    echo json_encode(['status' => 'success', 'counts' => $counts, 'total' => $total]);

} catch (Exception $e) {
    echo json_encode(['status' => 'error']);
}
?>