<?php
// agent/api/table_deposits.php - GÜNCELLENMİŞ HTML ÇIKTISI
require_once __DIR__ . '/../init.php'; 

// Yetki ve Kimlik Kontrolü
if (!isset($_SESSION['agent_id'])) exit;
if ($isPersonnel && !hasPerm('approve_deposit')) exit;

$targetId = $masterAgentId; // init.php'den gelir.

$sql = "
    SELECT 
        d.*,
        u.username, 
        di.iban, 
        di.bank_name,
        pa.name AS processed_agent_name,
        pe.name AS processed_personnel_name
    FROM deposit_orders d 
    LEFT JOIN users u ON d.user_id = u.id 
    LEFT JOIN deposit_ibans di ON d.iban_id = di.id
    LEFT JOIN deposit_agents pa ON pa.id = d.processed_by_agent_id
    LEFT JOIN deposit_agents pe ON pe.id = d.processed_by_personnel_id
    WHERE d.agent_id = ? 
    ORDER BY d.id DESC 
    LIMIT 50
";
$stmt = $pdo->prepare($sql);
$stmt->execute([$targetId]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$orders) {
    echo '<tr><td colspan="8" style="text-align:center; padding:30px; color:var(--text-muted);">Bekleyen yatırım talebi yok.</td></tr>';
    exit;
}

foreach ($orders as $o): 
    $method   = $o['payment_method'] ?? 'havale';
    $dbStatus = strtolower(trim($o['status'])); 

    $statusClass = 'pending';
    $statusLabel = 'Bekliyor';
    $statusIcon  = 'ri-time-line';

    if (in_array($dbStatus, ['approved', 'confirmed', 'success'])) { 
        $statusClass = 'success'; 
        $statusLabel = 'Onaylandı'; 
        $statusIcon  = 'ri-check-double-line'; 
    } 
    elseif ($dbStatus == 'rejected') { 
        $statusClass = 'danger'; 
        $statusLabel = 'Reddedildi'; 
        $statusIcon  = 'ri-close-circle-line'; 
    }

    // Onaylayan bilgisini hazırla
    $approverText = '';
    if ($dbStatus !== 'pending') {
        if (!empty($o['processed_personnel_name'])) {
            // Personel onayladı
            $approverText = 'Personel: ' . $o['processed_personnel_name'];
        } elseif (!empty($o['processed_agent_name'])) {
            // Ana agent onayladı
            $approverText = 'Agent: ' . $o['processed_agent_name'];
        }
    }
?>
<tr class="deposit-row" 
    data-method="<?= $method ?>" 
    data-id="<?= $o['id'] ?>"
    data-status="<?= $dbStatus ?>">
    
    <td><span style="font-family: monospace; color: var(--text-muted);">#<?= $o['id'] ?></span></td>
    
    <td>
        <div style="font-weight: 600; color: var(--text-main);">
            <?= htmlspecialchars($o['username']) ?>
        </div>
    </td>
    
    <td>
        <div style="font-weight: 700; color: var(--text-main); font-size: 15px;">
            <?= number_format($o['amount_try'], 2) ?> 
            <span style="font-size: 11px; color: var(--text-muted);">TL</span>
        </div>
    </td>
    
    <td>
        <?php if ($method === 'havale'): ?>
            <span class="badge-method badge-havale">
                <i class="ri-bank-line"></i> Havale
            </span>
        <?php elseif ($method === 'crypto'): ?>
            <span class="badge-method badge-crypto">
                <i class="ri-bit-coin-line"></i> Kripto
            </span>
        <?php endif; ?>
    </td>
    
    <td style="font-size: 13px; color: var(--text-muted);">
        <?php if ($method === 'havale'): ?>
            <i class="ri-arrow-right-s-line" style="vertical-align:middle"></i>
            <?= htmlspecialchars($o['iban'] ?? '-') ?> 
            (<?= htmlspecialchars($o['bank_name'] ?? '-') ?>)
        <?php elseif ($method === 'crypto'): ?>
            <strong style="color:var(--text-main)">
                <?= htmlspecialchars($o['coin_type'] ?? '') ?>
            </strong>
        <?php else: ?>
            -
        <?php endif; ?>
    </td>
    
    <td style="font-size: 12px; color: var(--text-muted);">
        <?= date('d.m.Y H:i', strtotime($o['created_at'])) ?>
    </td>
    
    <td>
        <span class="badge <?= $statusClass ?>">
            <i class="<?= $statusIcon ?>"></i> <?= $statusLabel ?>
        </span>
        <?php if ($approverText): ?>
            <div style="font-size: 11px; color: var(--text-muted); margin-top: 3px;">
                Onaylayan: <?= htmlspecialchars($approverText) ?>
            </div>
        <?php endif; ?>
    </td>
    
    <td style="text-align: right;">
        <?php if ($dbStatus === 'pending'): ?>
            <div class="action-group">
                <form method="post" onsubmit="return confirm('Yatırımı onaylıyor musunuz?')" style="display:inline;">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="confirm_id" value="<?= $o['id'] ?>">
                    <button type="submit" class="btn-icon btn-approve" title="Onayla">
                        <i class="ri-check-line"></i>
                    </button>
                </form>
                <button type="button" onclick="openRejectModal(<?= $o['id'] ?>)" class="btn-icon btn-reject" title="Reddet">
                    <i class="ri-close-line"></i>
                </button>
            </div>
        <?php else: ?>
            <i class="ri-checkbox-circle-fill" style="color: #cbd5e1; font-size: 20px;"></i>
        <?php endif; ?>
    </td>
</tr>
<?php endforeach; ?>
