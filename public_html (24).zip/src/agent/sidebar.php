<?php
// agent/sidebar.php
$cur = basename($_SERVER['PHP_SELF']);
$displayName = isset($me['name']) ? $me['name'] : ($_SESSION['agent_name'] ?? 'Agent');
$displayRole = (isset($isPersonnel) && $isPersonnel) ? 'Personel' : 'Yönetici';
$currentCash = $me['current_cash'] ?? 0.00;

function isActive($pageName, $currentPage) {
    return ($currentPage == $pageName) ? 'active' : '';
}
?>
<style>
    /* =========================================
       GLOBAL RESET & LAYOUT (BOŞLUK SORUNU ÇÖZÜMÜ)
       ========================================= */
    * { box-sizing: border-box; }
    



    /* =========================================
       SIDEBAR TASARIMI
       ========================================= */
    :root {
        --sidebar-width: 280px;
        --sidebar-bg: #ffffff;
        --primary-color: #c2273f;
        --text-primary: #1f2937;
        --text-secondary: #6b7280;
        --border-color: #e5e7eb;
    }

/* DARK MODE: sadece body'ye uygulanan temel tema */
body.dark-mode {
    background-color: #0f172a; /* Genel arka plan */
    color: #f1f5f9;
}



/* SIDEBAR – dark mode görünümü */
body.dark-mode .sidebar {
    background-color: #111827;    /* Önceki --sidebar-bg karşılığı */
    border-right-color: #374151;  /* Önceki --border-color karşılığı */
}

/* Sidebar içi text renkleri için istersen: */
body.dark-mode .sidebar .brand-logo span,
body.dark-mode .sidebar .menu-category,
body.dark-mode .sidebar .nav-link,
body.dark-mode .sidebar .user-name,
body.dark-mode .sidebar .user-role {
    color: #e5e7eb;
}

body.dark-mode .sidebar .nav-link {
    color: #9ca3af;
}

body.dark-mode .sidebar .nav-link.active {
    color: #f97373; /* primary'nin dark varyantı gibi düşünebilirsin */
}


    .sidebar-header {
        padding: 24px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .brand-logo {
        font-size: 20px;
        font-weight: 800;
        color: var(--primary-color);
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .brand-logo span { color: var(--text-primary); }

    /* Cüzdan Kartı */
    .balance-card {
        margin: 0 20px 20px;
        padding: 20px;
        background: linear-gradient(135deg, #c2273f 0%, #be123c 100%);
        border-radius: 16px;
        color: white;
        box-shadow: 0 4px 6px -1px rgba(194, 39, 63, 0.3);
        position: relative;
        overflow: hidden;
    }
    .balance-card::after {
        content: '';
        position: absolute;
        top: -20px; right: -20px;
        width: 80px; height: 80px;
        background: rgba(255,255,255,0.1);
        border-radius: 50%;
    }
    .balance-label { font-size: 11px; font-weight: 600; opacity: 0.9; text-transform: uppercase; }
    .balance-amount { font-size: 22px; font-weight: 800; margin-top: 5px; }

    /* Menü Linkleri */
    .sidebar-menu { flex: 1; overflow-y: auto; padding: 0 16px; }
    .sidebar-menu::-webkit-scrollbar { width: 4px; }
    .sidebar-menu::-webkit-scrollbar-thumb { background: var(--border-color); border-radius: 4px; }

    .menu-category {
        font-size: 11px;
        font-weight: 700;
        color: var(--text-secondary);
        margin: 20px 10px 10px;
        letter-spacing: 0.5px;
    }

    .nav-link {
        display: flex; align-items: center; gap: 12px;
        padding: 12px 16px;
        color: var(--text-secondary);
        font-size: 14px; font-weight: 500;
        border-radius: 12px;
        text-decoration: none;
        margin-bottom: 4px;
        transition: 0.2s;
    }
    .nav-link:hover { background: rgba(0,0,0,0.03); color: var(--text-primary); }
    .nav-link.active { background: rgba(194, 39, 63, 0.08); color: var(--primary-color); font-weight: 600; }
    .nav-link i { font-size: 18px; }

    /* Footer */
    .sidebar-footer { padding: 20px; border-top: 1px solid var(--border-color); }
    
    .user-profile { display: flex; align-items: center; gap: 12px; }
    .user-avatar { 
        width: 40px; height: 40px; 
        background: var(--primary-color); color: white; 
        border-radius: 10px; display: flex; align-items: center; justify-content: center; 
        font-weight: 700; 
    }
    .user-info { flex: 1; overflow: hidden; }
    .user-name { font-size: 14px; font-weight: 600; color: var(--text-primary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .user-role { font-size: 12px; color: var(--text-secondary); }

    /* =========================================
       MOBILE RESPONSIVE (TELEFON UYUMU)
       ========================================= */
    .mobile-menu-btn { 
        display: none; /* Masaüstünde gizli */
    }
    .sidebar-overlay { display: none; }

    @media (max-width: 1024px) {
        .sidebar {
            position: fixed;
            left: -100%; /* Ekran dışına it */
            height: 100vh;
            width: 280px;
            box-shadow: 0 0 20px rgba(0,0,0,0.2);
        }
        
        .sidebar.active {
            left: 0; /* Aktif olunca içeri kay */
        }

        /* Hamburger Butonu */
        .mobile-menu-btn {
            display: flex;
            align-items: center; justify-content: center;
            position: fixed;
            top: 15px; left: 15px;
            z-index: 40;
            width: 40px; height: 40px;
            background: var(--sidebar-bg);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            color: var(--text-primary);
            font-size: 20px;
            cursor: pointer;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        .sidebar-overlay {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 45;
            backdrop-filter: blur(2px);
            display: none;
        }
        
        .sidebar-overlay.active { display: block; }
        
        /* Mobilde ana içerik padding ayarı */
        .main-content {
            padding: 70px 20px 20px 20px !important; /* Üstten boşluk bırak ki butonun altında kalmasın */
        }
    }
</style>

<button class="mobile-menu-btn" onclick="toggleSidebar()">
    <i class="ri-menu-2-line"></i>
</button>
<div class="sidebar-overlay" onclick="toggleSidebar()"></div>

<aside class="sidebar" id="appSidebar">
    
    <div class="sidebar-header">
        <div class="brand-logo">
            <i class="ri-wallet-3-fill"></i>
            <span>BetWallet</span>
        </div>
        <i class="ri-close-line" onclick="toggleSidebar()" style="font-size:24px; cursor:pointer; color:var(--text-secondary); display:none;" id="mobileCloseBtn"></i>
    </div>

    <div class="balance-card">
        <div class="balance-label">Kasa Bakiyesi</div>
        <div class="balance-amount"><?= number_format($currentCash, 2) ?> ₺</div>
        <i class="ri-shield-check-fill" style="position:absolute; bottom:-10px; right:10px; font-size:50px; opacity:0.2;"></i>
    </div>

    <nav class="sidebar-menu">
        <div class="menu-category">GENEL</div>
        <a href="index.php" class="nav-link <?= isActive('index.php', $cur) ?>">
            <i class="ri-dashboard-line"></i> <span>Genel Bakış</span>
        </a>
        
        <?php if(function_exists('hasPerm') && hasPerm('view_reports')): ?>
        <a href="reports.php" class="nav-link <?= isActive('reports.php', $cur) ?>">
            <i class="ri-file-chart-line"></i> <span>Raporlar</span>
        </a>
        <?php endif; ?>

        <div class="menu-category">İŞLEMLER</div>
        
        <?php if(function_exists('hasPerm') && hasPerm('approve_deposit')): ?>
        <a href="deposits.php" class="nav-link <?= isActive('deposits.php', $cur) ?>">
            <i class="ri-arrow-down-circle-line"></i> <span>Yatırım Talepleri</span>
        </a>
        <?php endif; ?>

        <?php if(function_exists('hasPerm') && hasPerm('approve_withdraw')): ?>
        <a href="withdrawals.php" class="nav-link <?= isActive('withdrawals.php', $cur) ?>">
            <i class="ri-arrow-up-circle-line"></i> <span>Çekim Görevleri</span>
        </a>
        <?php endif; ?>

        <?php if(function_exists('hasPerm') && hasPerm('manage_ibans')): ?>
        <a href="ibans.php" class="nav-link <?= isActive('ibans.php', $cur) ?>">
            <i class="ri-bank-card-line"></i> <span>IBAN Yönetimi</span>
        </a>
        <?php endif; ?>

        <?php if(function_exists('hasPerm') && hasPerm('request_balance')): ?>
        <a href="balance.php" class="nav-link <?= isActive('balance.php', $cur) ?>">
            <i class="ri-wallet-3-line"></i> <span>Bakiye Yükle</span>
        </a>
        <?php endif; ?>

        <?php if(!isset($isPersonnel) || !$isPersonnel): ?>
        <a href="cash_adjustment.php" class="nav-link <?= isActive('cash_adjustment.php', $cur) ?>">
            <i class="ri-safe-2-line"></i> <span>Kasa Yönetimi</span>
        </a>
        <?php endif; ?>

        <div class="menu-category">YÖNETİM</div>

        <?php if(function_exists('hasPerm') && hasPerm('view_profit_wallet')): ?>
        <a href="profit.php" class="nav-link <?= isActive('profit.php', $cur) ?>">
            <i class="ri-coins-line"></i> <span>Kâr Cüzdanı</span>
        </a>
        <?php endif; ?>

        <?php if(function_exists('hasPerm') && hasPerm('manage_personnel')): ?>
        <a href="personnel.php" class="nav-link <?= isActive('personnel.php', $cur) ?>">
            <i class="ri-team-line"></i> <span>Personel</span>
        </a>
        <?php endif; ?>

        <?php if(!isset($isPersonnel) || !$isPersonnel): ?>
        <a href="settings.php" class="nav-link <?= isActive('settings.php', $cur) ?>">
            <i class="ri-settings-4-line"></i> <span>Ayarlar</span>
        </a>
        <?php endif; ?>
    </nav>

    <div class="sidebar-footer">
        <div class="user-profile">
            <div class="user-avatar"><?= strtoupper(substr($displayName, 0, 1)) ?></div>
            <div class="user-info">
                <div class="user-name"><?= htmlspecialchars($displayName) ?></div>
                <div class="user-role"><?= htmlspecialchars($displayRole) ?></div>
            </div>
            <a href="login.php?logout=1" style="color:var(--text-secondary);"><i class="ri-logout-box-r-line"></i></a>
        </div>
    </div>
</aside>

<script>
    function toggleSidebar() {
        const sidebar = document.getElementById('appSidebar');
        const overlay = document.querySelector('.sidebar-overlay');
        const closeBtn = document.getElementById('mobileCloseBtn');

        sidebar.classList.toggle('active');
        overlay.classList.toggle('active');

        // Mobilde çarpı işaretini göster/gizle
        if (window.innerWidth <= 1024) {
            closeBtn.style.display = sidebar.classList.contains('active') ? 'block' : 'none';
        }
    }
</script>