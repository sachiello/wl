<?php
// agent/withdrawals.php - FINAL SÜRÜM (withdraw_requests + wallets refund entegre)
require 'init.php';

// Yetki Kontrolü
if ($isPersonnel && !hasPerm('approve_withdraw')) {
    die("<div style='padding:50px; text-align:center; color:red; font-weight:bold;'>Bu sayfayı görüntüleme yetkiniz yok.</div>");
}

// --------------------------------------------------------
// İşlem Yapan Bilgileri (Session'dan)
// --------------------------------------------------------
$processorId          = $_SESSION['agent_id'];
$targetAgentId        = $masterAgentId; // İşlem her zaman ana agent kasasından
$processedAgentId     = $targetAgentId;
$processedPersonnelId = $isPersonnel ? $processorId : null;
// --------------------------------------------------------

// CSRF Güvenlik Kontrolü
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !csrf_validate_request()) {
    redirect_after_post('error', 'Oturum doğrulaması başarısız. Lütfen sayfayı yenileyip tekrar deneyin.');
}

// --- LOGIC: ÇEKİM GÖREVİ TAMAMLAMA (PAID) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['complete_task_id'])) {

    $taskId = (int)$_POST['complete_task_id'];

    try {
        $pdo->beginTransaction();

        // 1) Görevi kilitleyerek çek
        $stmt = $pdo->prepare("
            SELECT *
            FROM agent_withdraw_orders
            WHERE id = ?
              AND agent_id = ?
              AND status = 'pending'
            FOR UPDATE
        ");
        $stmt->execute([$taskId, $targetAgentId]);
        $task = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$task) {
            throw new Exception("Görev bulunamadı veya daha önce işlenmiş.");
        }

        $amount            = (float)$task['amount'];
        $withdrawRequestId = isset($task['withdraw_request_id']) ? (int)$task['withdraw_request_id'] : 0;

        // 2) Agent'ın güncel bakiyesini çek (lock)
        $ag = $pdo->prepare("
            SELECT current_cash, system_balance, total_withdraw_volume
            FROM deposit_agents
            WHERE id = ?
            FOR UPDATE
        ");
        $ag->execute([$targetAgentId]);
        $agentRow = $ag->fetch(PDO::FETCH_ASSOC);

        if (!$agentRow) {
            throw new Exception("Agent kaydı bulunamadı.");
        }

        $currentCash = (float)$agentRow['current_cash'];

        if ($currentCash < $amount) {
            throw new Exception(
                "Kasa yetersiz. (Mevcut: " . number_format($currentCash, 2) . " TL). Ödeme yapamazsınız."
            );
        }

        // 2-b) Kasadan tekrar düşmüyoruz, sadece sistem bakiyesi + hacim
        $upd = $pdo->prepare("
            UPDATE deposit_agents
            SET 
                system_balance        = system_balance + :amt,
                total_withdraw_volume = total_withdraw_volume + :amt
            WHERE id = :agent_id
        ");
        $upd->execute([
            ':amt'      => $amount,
            ':agent_id' => $targetAgentId,
        ]);

        // 3) Agent görevini tamamla
        $updTask = $pdo->prepare("
            UPDATE agent_withdraw_orders
            SET status = 'paid',
                completed_at = NOW(),
                processed_by_agent_id = ?,
                processed_by_personnel_id = ?
            WHERE id = ?
        ");
        $updTask->execute([$processedAgentId, $processedPersonnelId, $taskId]);

        // 4) Aynı işlemi withdraw_requests tablosuna da yansıt (ayna)
        if ($withdrawRequestId > 0) {
            $wrUpdate = $pdo->prepare("
                UPDATE withdraw_requests
                SET status = 'approved'
                WHERE id = ?
            ");
            $wrUpdate->execute([$withdrawRequestId]);
        }

        // 5) Genel log
        agent_log($pdo, 'withdraw_paid', [
            'task_id' => $taskId,
            'amount'  => $amount
        ]);

        $pdo->commit();
        redirect_after_post('success', "Ödeme kaydedildi.");

    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        redirect_after_post('error', $e->getMessage());
    }
}

// --- LOGIC: ÇEKİM GÖREVİNİ REDDETME (REJECT/FAILED) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reject_task_id'])) {
    $taskId = (int)$_POST['reject_task_id'];
    $reason = trim($_POST['reject_reason'] ?? 'Agent tarafından reddedildi.');

    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare("
            SELECT id, amount, user_id, withdraw_request_id
            FROM agent_withdraw_orders
            WHERE id = ?
              AND agent_id = ?
              AND status = 'pending'
            FOR UPDATE
        ");
        $stmt->execute([$taskId, $targetAgentId]);
        $task = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$task) { 
            throw new Exception("Görev bulunamadı veya zaten işlenmiş."); 
        }

        $amount            = (float)$task['amount'];
        $withdrawRequestId = isset($task['withdraw_request_id']) ? (int)$task['withdraw_request_id'] : 0;

        // 1) Daha önce kasadan düşülen tutarı geri iade et (agent kasa)
        $refund = $pdo->prepare("
            UPDATE deposit_agents
            SET current_cash = current_cash + :amt
            WHERE id = :agent_id
        ");
        $refund->execute([
            ':amt'      => $amount,
            ':agent_id' => $targetAgentId,
        ]);

        // 2) Görevi 'rejected' yap
        $upd = $pdo->prepare("
            UPDATE agent_withdraw_orders
            SET status = 'rejected',
                completed_at = NOW(),
                fail_reason = ?,
                processed_by_agent_id = ?,
                processed_by_personnel_id = ?
            WHERE id = ?
        ");
        $upd->execute([$reason, $processedAgentId, $processedPersonnelId, $taskId]);

        // 3) withdraw_requests + wallets tarafını düzelt (kullanıcıya coin iadesi)
        if ($withdrawRequestId > 0) {

            // 3-a) İlgili withdraw_request kaydını kilitle
            $wrSel = $pdo->prepare("
                SELECT id, user_id, coin_type, amount
                FROM withdraw_requests
                WHERE id = ?
                FOR UPDATE
            ");
            $wrSel->execute([$withdrawRequestId]);
            $wr = $wrSel->fetch(PDO::FETCH_ASSOC);

            if ($wr) {
                $wrUserId   = (int)$wr['user_id'];
                $wrCoinType = $wr['coin_type'];         // Örn: 'USDT'
                $wrAmount   = (float)$wr['amount'];     // Coin miktarı (USDT)

                // 3-b) Kullanıcının ilgili coin cüzdanını kilitle
                $wSel = $pdo->prepare("
                    SELECT id, balance
                    FROM wallets
                    WHERE user_id = ?
                      AND coin_type = ?
                    FOR UPDATE
                ");
                $wSel->execute([$wrUserId, $wrCoinType]);
                $walletRow = $wSel->fetch(PDO::FETCH_ASSOC);

                if ($walletRow) {
                    // Var olan cüzdana coin iadesi
                    $wUpd = $pdo->prepare("
                        UPDATE wallets
                        SET balance = balance + :amt
                        WHERE id = :id
                    ");
                    $wUpd->execute([
                        ':amt' => $wrAmount,
                        ':id'  => $walletRow['id'],
                    ]);
                } else {
                    // Her ihtimale karşı, cüzdan yoksa yeni satır aç
                    $wIns = $pdo->prepare("
                        INSERT INTO wallets (user_id, coin_type, balance, created_at)
                        VALUES (:uid, :coin, :amt, NOW())
                    ");
                    $wIns->execute([
                        ':uid'  => $wrUserId,
                        ':coin' => $wrCoinType,
                        ':amt'  => $wrAmount,
                    ]);
                }

                // 3-c) withdraw_requests statüsünü ve notunu güncelle
                $wrReject = $pdo->prepare("
                    UPDATE withdraw_requests
                    SET status = 'rejected',
                        note   = :note
                    WHERE id = :id
                ");
                $wrReject->execute([
                    ':note' => $reason,
                    ':id'   => $withdrawRequestId,
                ]);
            }
        }

        // 4) Log
        agent_log($pdo, 'withdraw_rejected', [
            'task_id' => $taskId, 
            'amount'  => $amount, 
            'reason'  => $reason
        ]);

        $pdo->commit();
        redirect_after_post('success', "Çekim görevi reddedildi.");

    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        redirect_after_post('error', $e->getMessage());
    }
}

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Çekim Görevleri</title>
    
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        /* BASE STYLES */
        :root {
            --primary: #4f46e5;
            --bg-body: #f1f5f9;
            --bg-card: #ffffff;
            --text-main: #1f2937;
            --text-muted: #6b7280;
            --border-color: #e5e7eb;
            --shadow-soft: 0 1px 3px rgba(0,0,0,0.05);
            --radius-md: 8px;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-body);
            color: var(--text-main);
            margin: 0;
        }
        
        .app-wrapper {
            display: flex;
            width: 100%;
            min-height: 100vh;
        }
        .main-content {
            flex: 1;
            padding: 30px;
            overflow-y: auto;
        }
        
        .topbar h1 {
            font-size: 24px;
            font-weight: 800;
            margin: 0 0 20px 0;
            color: var(--text-main);
        }
        
        .card {
            background: var(--bg-card);
            border-radius: 16px;
            border: 1px solid var(--border-color);
            box-shadow: var(--shadow-soft);
            padding: 0;
            overflow: hidden;
            margin-bottom: 20px;
        }
        .card.bg-green {
            background: #ecfdf5;
            border-color: #10b981;
            color: #065f46;
            padding: 15px;
        }
        .card.bg-red {
            background: #fef2f2;
            border-color: #ef4444;
            color: #991b1b;
            padding: 15px;
        }

        /* TOOLBAR */
        .toolbar-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            gap: 15px;
            flex-wrap: wrap;
        }
        .modern-tabs {
            display: inline-flex;
            background: #fff;
            padding: 4px;
            border-radius: var(--radius-md);
            border: 1px solid var(--border-color);
            gap: 4px;
        }
        .tab-btn {
            padding: 8px 16px;
            border-radius: 6px;
            color: var(--text-muted);
            font-size: 13px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 6px;
            cursor: pointer;
            border: none;
            background: transparent;
            transition: all 0.2s;
        }
        .tab-btn:hover {
            background: #f8fafc;
            color: var(--primary);
        }
        .tab-btn.is-active {
            background: var(--primary);
            color: #fff;
        }
        
        .toolbar-actions {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }
        .filter-select {
            padding: 8px 12px;
            border-radius: var(--radius-md);
            border: 1px solid var(--border-color);
            background: #fff;
            font-size: 13px;
            outline: none;
        }
        .search-wrapper {
            position: relative;
        }
        .search-wrapper i {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            font-size: 14px;
        }
        .search-input {
            padding: 8px 8px 8px 32px;
            border-radius: var(--radius-md);
            border: 1px solid var(--border-color);
            background: #fff;
            font-size: 13px;
            width: 200px;
            outline: none;
        }
        .update-badge {
            font-size: 12px;
            color: var(--text-muted);
            display: flex;
            align-items: center;
            gap: 6px;
            background: #fff;
            padding: 8px 12px;
            border-radius: 20px;
            border: 1px solid var(--border-color);
        }

        /* TABLE */
        .table-container { overflow-x: auto; }
        .admin-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }
        .admin-table th {
            text-align: left;
            padding: 14px 20px;
            color: var(--text-muted);
            font-weight: 600;
            border-bottom: 1px solid var(--border-color);
            font-size: 12px;
            text-transform: uppercase;
            background: #f8fafc;
        }
        .admin-table td {
            padding: 14px 20px;
            border-bottom: 1px solid var(--border-color);
            vertical-align: middle;
            color: var(--text-main);
        }
        .admin-table tr:last-child td {
            border-bottom: none;
        }

        /* STATUS BADGES */
        .badge-status {
            padding: 5px 10px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            letter-spacing: 0.5px;
        }
        .status-pending {
            background: #fff7ed;
            color: #c2410c;
            border: 1px solid #ffedd5;
        }
        .status-paid {
            background: #ecfdf5;
            color: #047857;
            border: 1px solid #a7f3d0;
        }
        .status-rejected {
            background: #fef2f2;
            color: #b91c1c;
            border: 1px solid #fecaca;
        }

        /* BUTTONS */
        .btn-icon {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            transition: all 0.2s;
            font-size: 16px;
        }
        .btn-pay {
            background: #fef2f2;
            color: #dc2626;
            border: 1px solid #fecaca;
        }
        .btn-pay:hover {
            background: #dc2626;
            color: #fff;
        }
        .btn-reject {
            background: #f0fdf4;
            color: #16a34a;
            border: 1px solid #bbf7d0;
        }
        .btn-reject:hover {
            background: #16a34a;
            color: #fff;
        }

        /* MODAL */
        .modal-overlay {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 999;
            display: flex;
            align-items: center;
            justify-content: center;
            backdrop-filter: blur(2px);
        }
        .modal-content {
            background: #fff;
            width: 100%;
            max-width: 400px;
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .modal-header h3 {
            margin: 0;
            font-size: 18px;
            font-weight: 700;
        }
        .close-btn {
            font-size: 24px;
            cursor: pointer;
            color: var(--text-muted);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-size: 13px;
            font-weight: 600;
        }
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-family: inherit;
            font-size: 14px;
            outline: none;
            box-sizing: border-box;
        }
        .form-control:focus {
            border-color: var(--primary);
        }

        @keyframes spin { 100% { transform: rotate(360deg); } }
        .spinning-icon { animation: spin 1s linear infinite; color: var(--primary); display: inline-block; }
        .spinning-icon.paused { animation-play-state: paused; opacity: 0.5; }

        @keyframes softFlash {
            0% { background-color: #fef2f2; }
            100% { background-color: transparent; }
        }
        .new-item-flash { animation: softFlash 3s ease-out; }
        .withdraw-row { transition: background-color 0.3s; }

        @media (max-width: 768px) {
            .toolbar-container {
                flex-direction: column;
                align-items: stretch;
            }
            .modern-tabs, .toolbar-actions {
                width: 100%;
                justify-content: center;
            }
            .search-input {
                width: 100%;
            }
            .modal-content {
                max-width: 90%;
            }
            .admin-table {
                min-width: 800px;
            }
        }
    </style>
</head>
<body>

<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    <div class="main-content">
        <div class="topbar"><h1>Çekim Görevleri</h1></div>

        <?php $flash = get_flash(); if ($flash): ?>
            <div class="card <?= $flash['type'] == 'success' ? 'bg-green' : 'bg-red' ?>">
                <div style="display:flex; align-items:center; gap:10px;">
                    <i class="ri-<?= $flash['type'] == 'success' ? 'checkbox-circle-fill' : 'error-warning-fill' ?>" style="font-size:20px;"></i>
                    <?= htmlspecialchars($flash['text']) ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="toolbar-container">
            <div class="modern-tabs">
                <button onclick="filterTable('all')" class="tab-btn is-active" id="tab-all">
                    <i class="ri-apps-line"></i> Tümü
                </button>
            </div>
            <div class="toolbar-actions">
                <select id="filterStatus" class="filter-select" onchange="masterFilter()">
                    <option value="all">Tüm Durumlar</option>
                    <option value="pending">⏳ Bekleyenler</option>
                    <option value="paid">✅ Ödenenler</option>
                    <option value="rejected">❌ Reddedilenler</option>
                </select>
                <div class="search-wrapper">
                    <i class="ri-search-line"></i>
                    <input type="text" id="searchInput" class="search-input" placeholder="Ara..." onkeyup="masterFilter()">
                </div>
                <div class="update-badge">
                    <i class="ri-refresh-line spinning-icon paused" id="refreshIcon"></i>
                    <span style="font-family: monospace; font-size: 13px;" id="lastUpdateTime">--:--:--</span>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="table-container">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tutar</th>
                            <th>Kullanıcı</th>
                            <th>Banka / IBAN</th>
                            <th>Tarih</th>
                            <th>Durum</th>
                            <th style="text-align: right;">İşlem</th>
                        </tr>
                    </thead>
                    <tbody id="withdrawTableBody"></tbody>
                </table>
                <div id="no-data-row" style="display:none; text-align:center; padding: 40px; color: var(--text-muted);">
                    <i class="ri-inbox-line" style="font-size: 48px; display: block; margin-bottom: 10px; opacity: 0.3;"></i>
                    Filtrelere uygun görev bulunamadı.
                </div>
            </div>
        </div>
    </div>
</div>

<div id="rejectModal" class="modal-overlay" style="display:none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Çekim Reddetme</h3>
            <span class="close-btn" onclick="closeModal('rejectModal')">&times;</span>
        </div>
        <form method="post">
            <?php if (function_exists('csrf_field')) echo csrf_field(); ?>
            <input type="hidden" name="reject_task_id" id="rejectTaskId">
            <div class="form-group">
                <label>Reddetme Nedeni</label>
                <textarea name="reject_reason" class="form-control" rows="3" required placeholder="Örn: IBAN yanlış, Hesap adı eşleşmiyor vb."></textarea>
            </div>
            <div style="text-align:right;">
                <button type="button" class="btn-icon" style="background:#f1f5f9; color:var(--text-muted); width:auto; padding:0 15px; margin-right:5px;" onclick="closeModal('rejectModal')">İptal</button>
                <button type="submit" class="btn-icon btn-pay" style="width:auto; padding:0 15px; background:#dc2626; color:white;">Reddet</button>
            </div>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>

<script>
    let lastMaxIdWd = 0; 
    let firstLoadWd = true;
    
    function openRejectModal(id) {
        document.getElementById('rejectTaskId').value = id;
        document.getElementById('rejectModal').style.display = 'flex';
    }
    
    function closeModal(id) { document.getElementById(id).style.display = 'none'; }
    function filterTable(category) { masterFilter(); }

    // --- ANA FİLTRE MANTIĞI ---
    function masterFilter() {
        const statusFilter = document.getElementById('filterStatus').value; 
        const searchTerm = document.getElementById('searchInput').value.toLowerCase().trim();
        const rows = document.querySelectorAll('.withdraw-row');
        let visibleCount = 0;

        rows.forEach(row => {
            const status = row.getAttribute('data-status'); 
            const rowText = row.innerText.toLowerCase();
            const statusMatch = (statusFilter === 'all' || status === statusFilter);
            const searchMatch = (searchTerm === '' || rowText.includes(searchTerm));

            if (statusMatch && searchMatch) {
                row.style.display = ''; 
                visibleCount++;
            } else {
                row.style.display = 'none';
            }
        });

        const noData = document.getElementById('no-data-row');
        if(noData) noData.style.display = (visibleCount === 0) ? 'block' : 'none';
    }

    // --- AJAX GÜNCELLEME ---
    function fetchNewData() {
        const refreshIcon = document.getElementById('refreshIcon');
        if(refreshIcon) refreshIcon.classList.remove('paused');

        fetch('api/table_withdrawals.php?t=' + new Date().getTime())
            .then(response => response.text())
            .then(html => {
                const tbody = document.getElementById('withdrawTableBody');
                document.getElementById('lastUpdateTime').innerText = new Date().toLocaleTimeString('tr-TR');

                if (tbody.innerHTML.trim() !== html.trim()) {
                    tbody.innerHTML = html;
                    masterFilter();
                    
                    const rows = document.querySelectorAll('.withdraw-row');
                    let currentMaxId = 0;
                    rows.forEach(row => {
                        const id = parseInt(row.getAttribute('data-id'));
                        if(id > currentMaxId) currentMaxId = id;
                        if (!firstLoadWd && id > lastMaxIdWd) {
                            row.classList.add('new-item-flash');
                        }
                    });
                    lastMaxIdWd = currentMaxId;
                    firstLoadWd = false;
                }
            })
            .catch(error => console.error('Hata:', error))
            .finally(() => {
                if(refreshIcon) refreshIcon.classList.add('paused');
            });
    }

    document.addEventListener('DOMContentLoaded', () => {
        fetchNewData(); 
        setInterval(fetchNewData, 5000); 
        
        const overlay = document.querySelector('.modal-overlay');
        if (overlay) {
            overlay.addEventListener('click', function(e) {
                if (e.target === this) closeModal('rejectModal');
            });
        }
    });
</script>
</body>
</html>
