<?php 
// agent/balance.php - FINAL SÜRÜM
require 'init.php'; 

// Yetki Kontrolü
if ($isPersonnel && !hasPerm('request_balance')) {
    die("<div style='padding:50px; text-align:center; color:red; font-weight:bold;'>Bakiye talep yetkiniz yok.</div>");
}

// İşlemler Patron Adına ($masterAgentId)
$targetAgentId = $masterAgentId;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !csrf_validate_request()) {
    redirect_after_post('error', "Oturum doğrulaması başarısız. Lütfen formu yenileyip tekrar deneyin.");
}

// --- LOGIC: TALEP GÖNDERME ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['amount'])) {
    $amount = floatval($_POST['amount']);
    
    if ($amount < 100) {
        redirect_after_post('error', "Minimum 100 TL talep edebilirsiniz.");
    } else {
        try {
            // 1. Bonus Hesapla (Örn: %2.5) - Admin tarafındaki mantıkla aynı
            $bonusRate = 2.50;
            $credited  = $amount * (1 + ($bonusRate / 100));

            // 2. Talebi Kaydet (Patron ID ile)
            $stmt = $pdo->prepare("
                INSERT INTO agent_balance_requests 
                (agent_id, amount, bonus_rate, amount_credited, status, created_at) 
                VALUES (?, ?, ?, ?, 'pending', NOW())
            ");
            
            if ($stmt->execute([$targetAgentId, $amount, $bonusRate, $credited])) {
                redirect_after_post('success', "Bakiye talebi başarıyla iletildi. Yönetici onayı bekleniyor.");
            } else {
                redirect_after_post('error', "Veritabanı hatası.");
            }
        } catch (Exception $e) {
            redirect_after_post('error', "Hata: " . $e->getMessage());
        }
    }
}

// --- VERİLERİ ÇEK ---

// 1. Admin Cüzdan Adresi (TRC20 - USDT)
$stmtWallet = $pdo->prepare("SELECT address FROM admin_crypto_wallets WHERE coin_symbol = 'USDT' AND network = 'TRC20' AND is_active = 1 LIMIT 1");
$stmtWallet->execute();
$walletAddress = $stmtWallet->fetchColumn();
if (!$walletAddress) $walletAddress = "Admin cüzdan adresi tanımlanmamış.";

// 2. Geçmiş Talepler (Patronun talepleri)
$stmtHist = $pdo->prepare("SELECT * FROM agent_balance_requests WHERE agent_id = ? ORDER BY created_at DESC LIMIT 20");
$stmtHist->execute([$targetAgentId]);
$history = $stmtHist->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bakiye Yükle</title>
    
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        /* BASE & LAYOUT */
        :root { --primary: #c2273f; --bg-body: #f1f5f9; --bg-card: #ffffff; --text-main: #1f2937; --text-muted: #6b7280; --border-color: #e5e7eb; --radius-md: 8px; }
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; }
        
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        .main-content { flex: 1; padding: 30px; overflow-y: auto; }
        
        .topbar h1 { font-size: 24px; font-weight: 800; margin: 0 0 20px 0; color: var(--text-main); }
        
        .card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); padding: 24px; margin-bottom: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .card.bg-green { background: #ecfdf5; border-color: #10b981; color: #065f46; padding: 15px; }
        .card.bg-red { background: #fef2f2; border-color: #ef4444; color: #991b1b; padding: 15px; }

        /* WALLET SECTION */
        .wallet-box { background: #f9fafb; padding: 15px; border-radius: var(--radius-md); border: 1px dashed #d1d5db; position: relative; display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; }
        .wallet-text { font-family: monospace; color: var(--text-main); font-size: 14px; word-break: break-all; font-weight: 600; }
        
        .btn-copy { border: 1px solid var(--border-color); background: #fff; padding: 6px 12px; border-radius: 6px; cursor: pointer; color: var(--primary); font-weight: 600; font-size: 12px; transition: all 0.2s; display: flex; align-items: center; gap: 5px; }
        .btn-copy:hover { background: #f3f4f6; border-color: var(--primary); }
        
        /* FORM */
        .form-group { margin-bottom: 15px; }
        .form-label { display: block; font-weight: 600; font-size: 13px; margin-bottom: 5px; color: var(--text-main); }
        .form-control { width: 100%; padding: 12px; border: 1px solid var(--border-color); border-radius: var(--radius-md); font-size: 14px; outline: none; box-sizing: border-box; transition: border-color 0.2s; }
        .form-control:focus { border-color: var(--primary); }
        
        .btn-primary { width: 100%; padding: 12px; background: var(--primary); color: white; border: none; border-radius: var(--radius-md); font-weight: 600; cursor: pointer; transition: opacity 0.2s; display: flex; justify-content: center; align-items: center; gap: 8px; }
        .btn-primary:hover { opacity: 0.9; }

        /* TABLE */
        .table-responsive { overflow-x: auto; }
        .history-table { width: 100%; border-collapse: collapse; font-size: 14px; }
        .history-table th { text-align: left; padding: 12px 15px; color: var(--text-muted); font-weight: 600; font-size: 11px; text-transform: uppercase; border-bottom: 1px solid var(--border-color); }
        .history-table td { padding: 15px; border-bottom: 1px solid #f3f4f6; color: var(--text-main); }
        .history-table tr:last-child td { border-bottom: none; }
        
        .status-badge { padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: 700; display: inline-flex; align-items: center; gap: 4px; }
        .status-approved { background: #dcfce7; color: #166534; }
        .status-rejected { background: #fee2e2; color: #991b1b; }
        .status-pending { background: #fef3c7; color: #b45309; }
        
        /* RESPONSIVE GRID */
        .balance-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; }
        @media (max-width: 768px) { 
            .balance-grid { grid-template-columns: 1fr; } 
            .history-table { min-width: 600px; }
        }
    </style>
</head>
<body>

<div class="app-wrapper">
    
    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        
        <div class="topbar">
            <h1>Bakiye Yükle</h1>
        </div>

        <?php $flash = get_flash(); if ($flash): ?>
            <div class="card <?= $flash['type'] == 'success' ? 'bg-green' : 'bg-red' ?>">
                <div style="display:flex; align-items:center; gap:10px;">
                    <i class="ri-<?= $flash['type'] == 'success' ? 'checkbox-circle-fill' : 'error-warning-fill' ?>" style="font-size:20px;"></i>
                    <?= htmlspecialchars($flash['text']) ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="balance-grid">
                
                <div>
                    <h3 style="font-size:16px; margin:0 0 15px 0; color:var(--text-main);">Betwallet USDT (TRC20) Adresi</h3>
                    
                    <div class="wallet-box">
                        <span id="walletAddr" class="wallet-text"><?= htmlspecialchars($walletAddress) ?></span>
                        <button onclick="copyToClipboard()" class="btn-copy" title="Kopyala">
                            <i class="ri-file-copy-line"></i> Kopyala
                        </button>
                    </div>
                    
                    <p style="font-size: 13px; color: var(--text-muted); line-height: 1.5;">
                        <i class="ri-information-line"></i> Lütfen sadece <b>TRC20</b> ağını kullanın. Farklı ağlardan yapılan gönderimler kaybolabilir. Gönderim sonrası yan taraftaki formu doldurunuz.
                    </p>
                </div>

                <div>
                    <h3 style="font-size:16px; margin:0 0 15px 0; color:var(--text-main);">Ödeme Bildirimi</h3>
                    <form method="post">
                        <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="form-label">Gönderilen Tutar (TL Karşılığı)</label>
                            <div style="position: relative;">
                                <input type="number" step="0.01" name="amount" class="form-control" placeholder="Örn: 10000" required>
                                <span style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); color: var(--text-muted); font-weight: 600; font-size: 13px;">₺</span>
                            </div>
                        </div>
                        <button type="submit" class="btn-primary">
                            <i class="ri-send-plane-fill"></i> Bildirimi Gönder
                        </button>
                    </form>
                </div>

            </div>
        </div>

        <div class="card" style="margin-top: 20px;">
            <h3 style="font-size:16px; margin:0 0 20px 0; font-weight:700; color:var(--text-main);">Talep Geçmişi</h3>
            <div class="table-responsive">
                <table class="history-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Gönderilen</th>
                            <th>Tutar:</th>
                            <th>Durum</th>
                            <th>Tarih</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($history as $h): 
                             $bonusAmount = $h['amount_credited'];
                        ?>
                        <tr>
                            <td style="font-family: monospace; color: var(--text-muted);">#<?= $h['id'] ?></td>
                            <td style="font-weight:600;"><?= number_format($h['amount'], 2) ?> ₺</td>
                            <td style="font-weight:700; color:#10b981;"><?= number_format($bonusAmount, 2) ?> ₺</td>
                            <td>
                                <?php if($h['status'] == 'approved'): ?>
                                    <span class="status-badge status-approved"><i class="ri-check-line"></i> Onaylandı</span>
                                <?php elseif($h['status'] == 'rejected'): ?>
                                    <span class="status-badge status-rejected"><i class="ri-close-line"></i> Reddedildi</span>
                                <?php else: ?>
                                    <span class="status-badge status-pending"><i class="ri-loader-4-line"></i> Bekliyor</span>
                                <?php endif; ?>
                            </td>
                            <td style="color: var(--text-muted); font-size: 13px;">
                                <?= date('d.m.Y H:i', strtotime($h['created_at'])) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        
                        <?php if(!$history): ?>
                            <tr><td colspan="5" style="text-align: center; color: var(--text-muted); padding: 40px;">Henüz talep bulunmuyor.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<?php include 'footer.php'; ?>

<script>
    function copyToClipboard() {
        const copyText = document.getElementById("walletAddr").innerText;
        navigator.clipboard.writeText(copyText).then(() => {
            alert("Cüzdan adresi kopyalandı!");
        }).catch(err => {
            console.error('Kopyalama hatası:', err);
        });
    }
</script>

</body>
</html>