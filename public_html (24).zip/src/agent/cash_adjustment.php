<?php
// agent/cash_adjustment.php - FINAL SÜRÜM (KOYU INFO BOX)
require 'init.php'; 

// Yetki Kontrolü
if (isset($isPersonnel) && $isPersonnel) {
    die("<div style='padding:50px; text-align:center; color:red; font-weight:bold;'>Personelin bu sayfaya erişim yetkisi yoktur.</div>");
}

$targetAgentId = $masterAgentId;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !csrf_validate_request()) {
    redirect_after_post('error', 'Oturum doğrulaması başarısız. Lütfen formu yenileyip tekrar deneyin.');
}

// --- LOGIC: KASA GİRİŞİ ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['amount'])) {
    $amount = (float)$_POST['amount'];
    $reason = trim($_POST['reason'] ?? '');

    if (empty($reason)) {
        redirect_after_post('error', "Açıklama alanı zorunludur.");
    } elseif ($amount <= 0) {
        redirect_after_post('error', "Geçerli bir tutar girin.");
    } else {
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("SELECT current_cash FROM deposit_agents WHERE id = ? FOR UPDATE");
            $stmt->execute([$targetAgentId]);
            $currentCashBefore = (float)$stmt->fetchColumn();

            $newCash = $currentCashBefore + $amount;

            // 1. Güncelle
            $upd = $pdo->prepare("UPDATE deposit_agents SET current_cash = current_cash + :amount WHERE id = :agent_id");
            $upd->execute([':amount' => $amount, ':agent_id' => $targetAgentId]);

            // 2. Logla
            $meta = json_encode([
                'amount' => $amount, 
                'type' => 'in',
                'reason' => $reason,
                'balance_before' => number_format($currentCashBefore, 2),
                'balance_after' => number_format($newCash, 2)
            ], JSON_UNESCAPED_UNICODE);

            $logStmt = $pdo->prepare("INSERT INTO activity_logs (actor_type, actor_id, scope, action, meta_json, created_at) VALUES ('agent', ?, 'cash', 'cash_in_manual', ?, NOW())");
            $logStmt->execute([$targetAgentId, $meta]);
            
            $pdo->commit();
            $message = "Kasa bakiyesi başarıyla güncellendi. Yeni Bakiye: " . number_format($newCash, 2) . " TL";
            redirect_after_post('success', $message);

        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            redirect_after_post('error', "İşlem Hatası: " . $e->getMessage());
        }
    }
}

// Verileri Çek
$stmtCurrent = $pdo->prepare("SELECT current_cash, system_balance FROM deposit_agents WHERE id = ?");
$stmtCurrent->execute([$targetAgentId]);
$meData = $stmtCurrent->fetch(PDO::FETCH_ASSOC);
$currentCash = (float)$meData['current_cash'];
$systemBalance = (float)$meData['system_balance'];

$stmtLogs = $pdo->prepare("SELECT * FROM activity_logs WHERE actor_type = 'agent' AND actor_id = ? AND scope = 'cash' ORDER BY created_at DESC LIMIT 15");
$stmtLogs->execute([$targetAgentId]);
$logs = $stmtLogs->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kasa Yönetimi</title>
    
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        /* GLOBAL COLORS & RESET */
        :root { 
            --primary: #c2273f; 
            --primary-hover: #be123c;
            --bg-body: #f1f5f9; 
            --bg-card: #ffffff; 
            --text-main: #1f2937; 
            --text-muted: #6b7280; 
            --border-color: #e5e7eb; 
            --radius-md: 8px; 
        }
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; }
        
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        .main-content { flex: 1; padding: 30px; overflow-y: auto; }
        
        .topbar h1 { font-size: 24px; font-weight: 800; margin: 0 0 20px 0; color: var(--text-main); }
        
        .card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); padding: 24px; margin-bottom: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .card.bg-green { background: #ecfdf5; border-color: #10b981; color: #065f46; padding: 15px; }
        .card.bg-red { background: #fef2f2; border-color: #ef4444; color: #991b1b; padding: 15px; }

        /* BALANCE CARDS */
        .balance-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; }
        .bal-card { background: #fff; padding: 20px; border-radius: 12px; border: 1px solid var(--border-color); transition: transform 0.2s; }
        .bal-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
        
        .bal-label { font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }
        .bal-val { font-size: 28px; font-weight: 800; margin: 5px 0; color: var(--text-main); }
        .bal-desc { font-size: 12px; color: var(--text-muted); }
        .val-primary { color: var(--primary); }

        /* LAYOUT */
        .content-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 30px; }
        @media(max-width: 900px) { .content-grid { grid-template-columns: 1fr; } }

        /* FORM */
        .form-container { border-left: 4px solid var(--primary); padding-left: 20px; }
        .form-header { color: var(--primary); margin: 0 0 20px 0; font-size: 18px; display: flex; align-items: center; gap: 8px; font-weight: 700; }
        .form-group { margin-bottom: 15px; }
        .form-label { display: block; font-weight: 600; font-size: 13px; margin-bottom: 5px; color: var(--text-main); }
        .form-control { width: 100%; padding: 12px; border: 1px solid var(--border-color); border-radius: var(--radius-md); font-size: 14px; outline: none; box-sizing: border-box; transition: border-color 0.2s; }
        .form-control:focus { border-color: var(--primary); }
        
        .btn-red { width: 100%; padding: 12px; background: var(--primary); color: white; border: none; border-radius: var(--radius-md); font-weight: 600; cursor: pointer; transition: opacity 0.2s; display: flex; justify-content: center; align-items: center; gap: 8px; }
        .btn-red:hover { background: var(--primary-hover); }

        /* INFO BOX - DARK STYLE (GÜNCELLENDİ) */
        .info-box { 
            background: #1e293b; /* Koyu Slate */
            border: 1px solid #334155; 
            border-radius: var(--radius-md); 
            padding: 20px; 
            color: #fff;
        }
        .info-title { 
            color: #f1f5f9; 
            margin: 0 0 15px 0; 
            font-size: 15px; 
            font-weight: 700; 
            display: flex; 
            align-items: center; 
            gap: 8px; 
        }
        .info-title i { color: #fb7185; /* Açık Kırmızı İkon */ font-size: 18px; }
        .info-list { padding-left: 20px; margin: 0; list-style-type: disc; }
        .info-list li { 
            font-size: 13px; 
            color: #cbd5e1; /* Açık Gri */ 
            margin-bottom: 8px; 
            line-height: 1.5; 
        }

        /* TABLE */
        .table-responsive { overflow-x: auto; }
        .log-table { width: 100%; border-collapse: collapse; font-size: 14px; }
        .log-table th { text-align: left; padding: 12px 15px; color: var(--text-muted); font-weight: 600; font-size: 11px; text-transform: uppercase; border-bottom: 1px solid var(--border-color); }
        .log-table td { padding: 15px; border-bottom: 1px solid #f3f4f6; color: var(--text-main); }
        .log-table tr:last-child td { border-bottom: none; }
        
        .badge { padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: 700; display: inline-flex; align-items: center; gap: 4px; }
        .badge-red { background: #fff1f2; color: #be123c; border: 1px solid #fecdd3; }
    </style>
</head>
<body>

<div class="app-wrapper">
    
    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        
        <div class="topbar">
            <h1>Kasa Yönetimi (Manuel)</h1>
        </div>

        <?php $flash = get_flash(); if ($flash): ?>
            <div class="card <?= $flash['type'] == 'success' ? 'bg-green' : 'bg-red' ?>">
                <div style="display:flex; align-items:center; gap:10px;">
                    <i class="ri-<?= $flash['type'] == 'success' ? 'checkbox-circle-fill' : 'error-warning-fill' ?>" style="font-size:20px;"></i>
                    <?= htmlspecialchars($flash['text']) ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="balance-grid">
                <div class="bal-card">
                    <div class="bal-label">GÜNCEL NAKİT KASA</div>
                    <div class="bal-val val-primary"><?= number_format($currentCash, 2) ?> TL</div>
                    <div class="bal-desc">Bankadaki fiili paranızı temsil eder. Çekim limitiniz budur.</div>
                </div>
                <div class="bal-card">
                    <div class="bal-label">TEMİNAT LİMİTİ</div>
                    <div class="bal-val val-dark"><?= number_format($systemBalance, 2) ?> TL</div>
                    <div class="bal-desc">Sistem üzerinden alabileceğiniz maksimum yatırım hacmidir.</div>
                </div>
            </div>
            
            <div class="content-grid">
                <div class="form-container">
                    <h3 class="form-header"><i class="ri-add-circle-line"></i> Kasaya Ekle (Nakit Girişi)</h3>

                    <form method="post">
                        <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
                        
                        <div class="form-group">
                            <label class="form-label">Tutar (TL)</label>
                            <input type="number" step="0.01" name="amount" class="form-control" required placeholder="Örn: 5000">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Açıklama (Zorunlu)</label>
                            <input type="text" name="reason" class="form-control" required placeholder="Örn: Bankaya manuel nakit yatırma">
                        </div>
                        
                        <button type="submit" class="btn-red">
                            <i class="ri-wallet-3-fill"></i> Bakiyeyi Güncelle
                        </button>
                    </form>
                </div>

                <div class="info-box">
                    <div class="info-title"><i class="ri-information-fill"></i> Kasa Yönetimi İpuçları</div>
                    <ul class="info-list">
                        <li>Eğer kasanızda olandan daha fazla çekim gönderebilecekseniz, kasaya ekleme yaparak çekim kapasitenizi arttırabilirsiniz.</li>
                        <li>Güncel kasada bakiyeniz olmazsa, sistemden size çekim işlemi atanamaz.</li>
                        <li>Çekim gönderdikçe kazanç kasanıza %3'ü eklenir ve gönderdiğiniz miktar kadar teminatınız tekrar artar.</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="card">
            <h3 style="margin:0 0 20px 0; font-size:16px; font-weight:700; color:var(--text-main);">Son Kasa Hareketleri</h3>
            <div class="table-responsive">
                <table class="log-table">
                    <thead>
                        <tr>
                            <th>Tarih</th>
                            <th>İşlem Türü</th>
                            <th>Miktar</th>
                            <th>Açıklama</th>
                            <th>Bakiye Öncesi</th>
                            <th>Bakiye Sonrası</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($logs as $log): 
                            $meta = json_decode($log['meta_json'], true);
                            $is_in = ($log['action'] === 'cash_in_manual');
                            if (!$is_in) continue;
                        ?>
                        <tr>
                            <td style="color:var(--text-muted);"><?= date('d.m H:i', strtotime($log['created_at'])) ?></td>
                            <td>
                                <span class="badge badge-red"><i class="ri-add-line"></i> MANUEL GİRİŞ</span>
                            </td>
                            <td style="font-weight:700; color:var(--primary);">
                                +<?= number_format($meta['amount'] ?? 0, 2) ?> TL
                            </td>
                            <td><?= htmlspecialchars($meta['reason'] ?? '-') ?></td>
                            <td style="font-family:monospace;"><?= $meta['balance_before'] ?? 0 ?> TL</td>
                            <td style="font-family:monospace; font-weight:700;"><?= $meta['balance_after'] ?? 0 ?> TL</td>
                        </tr>
                        <?php endforeach; ?>
                        
                        <?php if(!$logs): ?>
                            <tr><td colspan="6" style="text-align:center; padding:30px; color:var(--text-muted);">Henüz manuel işlem kaydı bulunmuyor.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<?php include 'footer.php'; ?>
</body>
</html>