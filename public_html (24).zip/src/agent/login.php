<?php
// agent/login.php
session_start();
require __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../lib/GoogleAuthenticator.php'; // Kütüphane

// --- F5 Koruması için Yardımcı Fonksiyonlar ---
if (!function_exists('set_flash')) {
    function set_flash($type, $message) {
        $_SESSION['flash_message'] = ['type' => $type, 'text' => $message];
    }
}
if (!function_exists('get_flash')) {
    function get_flash() {
        if (isset($_SESSION['flash_message'])) {
            $msg = $_SESSION['flash_message'];
            unset($_SESSION['flash_message']);
            return $msg;
        }
        return null;
    }
}
if (!function_exists('redirect_after_post')) {
    function redirect_after_post($type, $message) {
        set_flash($type, $message);
        header("Location: " . basename($_SERVER['PHP_SELF']));
        exit();
    }
}
// -------------------------------------------

// Çıkış
if (isset($_GET['logout'])) {
    $_SESSION = []; session_destroy(); header('Location: login.php'); exit;
}

// Giriş yapılmışsa at
if (isset($_SESSION['agent_id'])) { header('Location: index.php'); exit; }

$show2fa = false; // 2FA ekranını gösterelim mi?

// --- 2FA KOD KONTROLÜ (2. AŞAMA) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['2fa_code'])) {
    $userId = $_SESSION['2fa_pending_user_id'] ?? null;
    $code = $_POST['2fa_code'];
    
    if ($userId) {
        $stmt = $pdo->prepare("SELECT * FROM deposit_agents WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $ga = new GoogleAuthenticator();
        if ($user && $ga->verifyCode($user['two_factor_secret'], $code, 2)) {
            // BAŞARILI GİRİŞ
            $_SESSION['agent_id'] = $user['id'];
            $_SESSION['agent_name'] = $user['name'];
            $_SESSION['is_personnel'] = ($user['role'] === 'personnel');
            unset($_SESSION['2fa_pending_user_id']); // Temp veriyi sil
            
            // Log
            try { $pdo->prepare("UPDATE deposit_agents SET last_login = NOW() WHERE id = ?")->execute([$user['id']]); } catch(Exception $e){}
            
            header('Location: index.php'); exit;
        } else {
            // Hatalı 2FA kodu durumunda, 2FA formunu tekrar göstermek için yönlendirme YAPMIYORUZ.
            // Sayfanın state'ini koruması gerekiyor. Ama bir hata mesajı gösterebiliriz.
            // Bu senaryoda eski yapı daha mantıklı, bu yüzden PRG'yi sadece basit hatalar için kullanıyoruz.
            // Ancak tutarlılık için, 2FA sayfasını tekrar yüklemesi için yönlendirme yapabiliriz.
            set_flash('error', 'Girdiğiniz kod YANLIŞ.');
            // 2FA ekranını tekrar göstermek için session'da hangi kullanıcı olduğunu tutmamız lazım.
            // Bu zaten `$_SESSION['2fa_pending_user_id']` ile yapılıyor, bu yüzden sadece yönlendirme yeterli.
            header('Location: login.php?show_2fa=1');
            exit;
        }
    } else {
        redirect_after_post('error', "Oturum zaman aşımı. Tekrar giriş yapın.");
    }
}

// --- KULLANICI ADI/ŞİFRE KONTROLÜ (1. AŞAMA) ---
elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['name'])) {
    $name = trim($_POST['name']);
    $password = trim($_POST['password']);

    $stmt = $pdo->prepare("SELECT * FROM deposit_agents WHERE name = ? LIMIT 1");
    $stmt->execute([$name]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password_hash'])) {
        if (!$user['is_active']) {
            redirect_after_post('error', 'Hesabınız pasif.');
        } else {
            // 2FA KONTROLÜ
            if ($user['two_factor_enabled']) {
                // 2FA AÇIK: Session'a geçici ID at, 2FA ekranını göster. Yönlendirme yok.
                $_SESSION['2fa_pending_user_id'] = $user['id'];
                $show2fa = true;
            } else {
                // 2FA KAPALI: Direkt içeri al
                $_SESSION['agent_id'] = $user['id'];
                $_SESSION['agent_name'] = $user['name'];
                $_SESSION['is_personnel'] = ($user['role'] === 'personnel');
                try { $pdo->prepare("UPDATE deposit_agents SET last_login = NOW() WHERE id = ?")->execute([$user['id']]); } catch(Exception $e){}
                header('Location: index.php'); exit;
            }
        }
    } else {
        redirect_after_post('error', 'Kullanıcı adı veya şifre hatalı.');
    }
}

// GET parametresi ile 2FA ekranını tetikleme
if (isset($_GET['show_2fa']) && isset($_SESSION['2fa_pending_user_id'])) {
    $show2fa = true;
}

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Agent Giriş - BetWallet</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Fontlar ve İkonlar -->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Orbitron:wght@600;800&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary: #c2273f;
            --primary-hover: #9f1239;
            --bg-body: #f8fafc;
            --text-main: #0f172a;
            --text-muted: #64748b;
            --border-color: #e2e8f0;
        }

        body {
            background: var(--bg-body);
            font-family: 'Inter', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            color: var(--text-main);
        }

        .login-card {
            background: #fff;
            padding: 40px;
            border-radius: 16px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.08);
            border: 1px solid var(--border-color);
        }

        /* Marka Alanı */
        .logo-area {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .brand-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 26px;
            font-weight: 800;
            color: var(--primary);
            letter-spacing: -1px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .brand-subtitle {
            font-size: 13px;
            color: var(--text-muted);
            margin-top: 5px;
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        /* Form Elemanları */
        .form-group { margin-bottom: 20px; }

        .form-label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: var(--text-main);
            margin-bottom: 8px;
        }

        .input-wrapper { position: relative; }
        
        .input-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            font-size: 18px;
        }

        .form-input {
            width: 100%;
            padding: 14px 14px 14px 44px; /* İkon boşluğu */
            border: 1px solid var(--border-color);
            border-radius: 10px;
            font-size: 14px;
            outline: none;
            box-sizing: border-box;
            transition: all 0.2s;
            background: #fcfcfc;
            color: var(--text-main);
        }

        .form-input:focus {
            border-color: var(--primary);
            background: #fff;
            box-shadow: 0 0 0 3px rgba(194, 39, 63, 0.1);
        }

        .btn-login {
            width: 100%;
            padding: 14px;
            background: var(--primary);
            color: #fff;
            border: none;
            border-radius: 10px;
            font-weight: 700;
            font-size: 15px;
            cursor: pointer;
            transition: background 0.2s;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
        }

        .btn-login:hover { background: var(--primary-hover); }

        .error-box {
            background: #fee2e2;
            color: #991b1b;
            padding: 12px;
            border-radius: 8px;
            font-size: 13px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
            border: 1px solid #fecaca;
        }

        .footer-text {
            text-align: center;
            margin-top: 25px;
            font-size: 12px;
            color: var(--text-muted);
        }
        
        /* 2FA Özel Stil */
        .otp-input {
            text-align: center;
            letter-spacing: 8px;
            font-size: 20px;
            font-weight: 700;
            font-family: monospace;
            padding-left: 14px !important; /* Ortalamak için soldaki boşluğu iptal et */
        }
    </style>
</head>
<body>

    <div class="login-card">
        
        <div class="logo-area">
            <div class="brand-title">
                <i class="ri-shield-keyhole-fill"></i> BETWALLET
            </div>
            <div class="brand-subtitle">Agent Operasyon Paneli</div>
        </div>

        <?php $flash = get_flash(); if ($flash): ?>
            <div class="error-box">
                <i class="ri-error-warning-fill"></i>
                <?= htmlspecialchars($flash['text']) ?>
            </div>
        <?php endif; ?>

        <?php if ($show2fa): ?>
            <!-- 2FA EKRANI -->
            <form method="post">
                <div style="text-align:center; margin-bottom:20px;">
                    <div style="width:60px; height:60px; background:#fee2e2; color:var(--primary); border-radius:50%; display:inline-flex; align-items:center; justify-content:center; font-size:28px; margin-bottom:10px;">
                        <i class="ri-smartphone-line"></i>
                    </div>
                    <h3 style="margin:0; font-size:16px; color:var(--text-main);">Güvenlik Doğrulaması</h3>
                    <p style="color:var(--text-muted); font-size:13px; margin:5px 0 0 0;">Lütfen Authenticator kodunu girin.</p>
                </div>

                <div class="form-group">
                    <div class="input-wrapper">
                        <input type="text" name="2fa_code" class="form-input otp-input" required autofocus placeholder="000 000" maxlength="6" autocomplete="off">
                    </div>
                </div>

                <button type="submit" class="btn-login">
                    Doğrula ve Gir <i class="ri-arrow-right-line"></i>
                </button>
                
                <div style="text-align:center; margin-top:15px;">
                    <a href="login.php" style="font-size:13px; text-decoration:none; color:var(--text-muted); display:inline-flex; align-items:center; gap:5px;">
                        <i class="ri-arrow-left-line"></i> Girişe Dön
                    </a>
                </div>
            </form>

        <?php else: ?>
            <!-- GİRİŞ EKRANI -->
            <form method="post">
                <div class="form-group">
                    <label class="form-label">Kullanıcı Adı</label>
                    <div class="input-wrapper">
                        <i class="ri-user-3-line input-icon"></i>
                        <input type="text" name="name" class="form-input" placeholder="Agent hesabınız" required autofocus>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Şifre</label>
                    <div class="input-wrapper">
                        <i class="ri-lock-2-line input-icon"></i>
                        <input type="password" name="password" class="form-input" placeholder="••••••" required>
                    </div>
                </div>

                <button type="submit" class="btn-login">
                    Giriş Yap <i class="ri-login-circle-line"></i>
                </button>
            </form>
        <?php endif; ?>

        <div class="footer-text">
            &copy; <?= date('Y') ?> BetWallet Finans Sistemleri<br>
            Yetkili personel harici giriş yasaktır.
        </div>

    </div>

</body>
</html>