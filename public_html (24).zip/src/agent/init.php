<?php
// agent/init.php
// Hataları göster (Geliştirme aşamasında)
ini_set('display_errors', 1); 
error_reporting(E_ALL);

// Güvenlik Başlıkları
header("X-Frame-Options: DENY");
header("X-XSS-Protection: 1; mode=block");
header("X-Content-Type-Options: nosniff");

// Config Dosyası
$configPath = __DIR__ . '/../../config/config.php';
if (!file_exists($configPath)) die("Kritik Hata: Config dosyası bulunamadı!");
require_once $configPath;

if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($pdo)) $pdo = $db;
// 30 Dakika işlem yapılmazsa oturumu kapat
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 1800)) {
    session_unset();     
    session_destroy();   
    header("Location: login.php?timeout=1");
    exit;
}
$_SESSION['last_activity'] = time();

// Login Kontrolü
$curPage = basename($_SERVER['PHP_SELF']);
if ($curPage != 'login.php' && !isset($_SESSION['agent_id'])) {
    header("Location: login.php"); exit;
}

// --- KİMLİK VE ROL AYRIŞTIRMA ---
// $myId: Giriş yapan kişinin ID'si (Personel veya Patron)
// $masterAgentId: İşlem yapılacak kasa (Daima Patronun ID'si)

$myId = $_SESSION['agent_id']; 

// Giriş yapan kişinin güncel bilgilerini çek
$stmt = $pdo->prepare("SELECT id, name, role, parent_id, system_balance, current_cash, permissions, is_active FROM deposit_agents WHERE id = ?");
$stmt->execute([$myId]);
$me = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$me) {
    // Kullanıcı silinmişse at
    session_destroy();
    header("Location: login.php"); exit;
}

// Session'ı güncelle (Hız ve tutarlılık için)
$_SESSION['agent_name']  = $me['name']; 
$_SESSION['permissions'] = json_decode($me['permissions'] ?? '[]', true);

// ROL BELİRLEME
if ($me['role'] === 'personnel') {
    $isPersonnel   = true;
    $_SESSION['is_personnel'] = true;
    $masterAgentId = $me['parent_id']; // Personelse kasası patronunkidir
    
    // Arka planda patronun bakiyelerini çek (Logic kontrolleri için)
    $stmtBoss = $pdo->prepare("SELECT system_balance, current_cash FROM deposit_agents WHERE id = ?");
    $stmtBoss->execute([$masterAgentId]);
    $boss = $stmtBoss->fetch(PDO::FETCH_ASSOC);
    
    $sysBalance = $boss['system_balance'] ?? 0;
    $curCash    = $boss['current_cash'] ?? 0;
} else {
    $isPersonnel   = false;
    $_SESSION['is_personnel'] = false;
    $masterAgentId = $me['id']; // Patronsa kasa kendisinindir
    
    $sysBalance = $me['system_balance'];
    $curCash    = $me['current_cash'];
}
if (!empty($me['allowed_ips'])) {
    $currentIp = $_SERVER['REMOTE_ADDR'];
    // Virgülle ayrılan IP'leri diziye çevir ve boşlukları temizle
    $allowedList = array_map('trim', explode(',', $me['allowed_ips']));
    
    // Eğer mevcut IP listede yoksa DURDUR
    if (!in_array($currentIp, $allowedList)) {
        // Güvenlik ihlali logla (Opsiyonel)
        // Oturumu kapat
        session_destroy();
        die("<div style='font-family:sans-serif; text-align:center; padding:50px; color:red;'>
                <h1>Erişim Engellendi!</h1>
                <p>IP Adresiniz ($currentIp) bu panele erişim yetkisine sahip değil.</p>
                <p>Yöneticinizle iletişime geçin.</p>
                <a href='login.php'>Geri Dön</a>
             </div>");
    }
}
// --- YARDIMCI FONKSİYONLAR ---

// 1. CSRF Güvenlik
if (!function_exists('csrf_token')) {
    function csrf_token() {
        if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        return $_SESSION['csrf_token'];
    }
}
if (!function_exists('csrf_field')) {
    function csrf_field() { return '<input type="hidden" name="csrf_token" value="' . csrf_token() . '">'; }
}
if (!function_exists('csrf_validate')) {
    function csrf_validate() {
        if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            die("Güvenlik Uyarısı: Geçersiz İstek (CSRF Hatası). Sayfayı yenileyin.");
        }
    }
}

// 2. Yetki Kontrolü (Çakışmayı önlemek için function_exists ekledik)
if (!function_exists('hasPerm')) {
    function hasPerm($perm) {
        global $isPersonnel;
        // Patronun her yetkisi vardır
        if (!$isPersonnel) return true;
        
        if (!isset($_SESSION['permissions']) || empty($_SESSION['permissions'])) return false;
        // 'ALL' yetkisi varsa veya istenen yetki varsa
        if (in_array('ALL', $_SESSION['permissions'])) return true;
        return in_array($perm, $_SESSION['permissions']);
    }
}

// 3. Loglama (Personel Adına)
if (!function_exists('agent_log')) {
    function agent_log($pdo, $action, $details = []) {
        global $myId, $masterAgentId;
        $jsonDetails = json_encode($details, JSON_UNESCAPED_UNICODE);
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        
        // Log tablosuna: agent_id (Patron), personnel_id (İşlemi Yapan)
        $stmt = $pdo->prepare("INSERT INTO agent_personnel_logs (agent_id, personnel_id, action, details, ip_address, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$masterAgentId, $myId, $action, $jsonDetails, $ip]);
    }
}

// 4. POST sonrası Yönlendirme ve Mesaj Gösterme
if (!function_exists('redirect_after_post')) {
    function redirect_after_post($type, $message) {
        set_flash($type, $message);
        // Form verilerinin tekrar gönderilmesini önlemek için yönlendir
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit();
    }
}

function set_flash($type, $message) {
    $_SESSION['flash_message'] = [
        'type' => $type, // 'success' veya 'error'
        'text' => $message
    ];
}

function get_flash() {
    if (isset($_SESSION['flash_message'])) {
        $msg = $_SESSION['flash_message'];
        unset($_SESSION['flash_message']); // Mesajı gösterdikten sonra sil (F5 yapınca tekrar çıkmasın)
        return $msg;
    }
    return null;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel - <?= htmlspecialchars($me['name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
<link rel="stylesheet" href="agent.css?v=1.1">
</head>
<audio id="notifSound" src="https://cdn.freesound.org/previews/536/536108_11930272-lq.mp3" preload="auto"></audio>

<script>
    let lastTotal = 0;
    const sound = document.getElementById('notifSound');

    function checkNotifications() {
        fetch('api/check_notifications.php')
            .then(response => response.json())
            .then(data => {
                const currentTotal = parseInt(data.total);
                
                // Eğer yeni bir iş varsa (sayı arttıysa)
                if (currentTotal > lastTotal) {
                    // Sesi Çal
                    sound.play().catch(error => console.log("Otomatik oynatma engellendi, kullanıcı etkileşimi lazım."));
                    
                    // Tarayıcı Bildirimi (Opsiyonel)
                    if (Notification.permission === "granted") {
                        new Notification("🔔 Yeni İşlem Var!", { body: data.deposits + " Yatırım, " + data.withdrawals + " Çekim bekliyor." });
                    } else if (Notification.permission !== "denied") {
                        Notification.requestPermission();
                    }
                    
                    // Sayfada Görsel Uyarı (Toast)
                    showToast(data.deposits, data.withdrawals);
                }
                
                lastTotal = currentTotal;
                
                // Menüdeki sayıları güncelle (Eğer varsa)
                updateBadges(data);
            })
            .catch(err => console.error(err));
    }

    function showToast(d, w) {
        // Basit bir alert kutusu oluşturup sağ üstte gösterelim
        let div = document.createElement('div');
        div.style.cssText = "position:fixed; top:20px; right:20px; background:#333; color:#fff; padding:15px; border-radius:8px; z-index:9999; box-shadow:0 5px 15px rgba(0,0,0,0.3); animation: slideIn 0.5s;";
        div.innerHTML = `<div style='font-weight:bold; margin-bottom:5px;'>⚠️ Yeni İşlem!</div>
                         <div>Yatırım: ${d} | Çekim: ${w}</div>`;
        document.body.appendChild(div);
        setTimeout(() => div.remove(), 5000);
    }

    function updateBadges(data) {
        // Sidebar'daki badge'leri ID ile bulup güncelleyebilirsin
        // Örn: <span id="depBadge">...</span>
    }

    // İlk yüklemede izin iste
    if (Notification.permission !== "denied") { Notification.requestPermission(); }

    // Her 5 saniyede bir kontrol et
    setInterval(checkNotifications, 5000);
    // init.php dosyasının en altına ekle:

</script>

<style>
@keyframes slideIn { from { transform: translateX(100%); } to { transform: translateX(0); } }
</style>
<body>