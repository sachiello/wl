<?php
// agent/profit.php - KÂR CÜZDANI (BLOKE MANTIĞI EKLENDİ)
require 'init.php';

$agentId = $masterAgentId;

// ====== 2FA KONTROLÜ ======
$stmt = $pdo->prepare("SELECT two_factor_enabled FROM deposit_agents WHERE id=?");
$stmt->execute([$agentId]);
$need2FA = ($stmt->fetchColumn() == 0);

// ====== PROFIT BİLGİLERİ ======
$stmt = $pdo->prepare("
    SELECT agent_profit_balance, total_profit_earned, total_profit_withdrawn, system_balance
    FROM deposit_agents WHERE id = ?
");
$stmt->execute([$agentId]);
$w = $stmt->fetch(PDO::FETCH_ASSOC);

$profit     = (float)$w['agent_profit_balance'];  // TOPLAM kâr bakiyesi
$totalEarn  = (float)$w['total_profit_earned'];
$totalWdr   = (float)$w['total_profit_withdrawn'];
$collateral = (float)$w['system_balance'];

// ====== TALEPLER (BEKLEYEN) ======
$stmt = $pdo->prepare("
    SELECT * FROM agent_profit_withdraw_requests 
    WHERE agent_id=? AND status='pending'
    ORDER BY created_at DESC
");
$stmt->execute([$agentId]);
$activeReq = $stmt->fetchAll(PDO::FETCH_ASSOC);

// BLOKE MİKTAR: Bekleyen taleplerin brüt TUTAR toplamı
$blockedProfit = 0.0;
foreach ($activeReq as $r) {
    $blockedProfit += (float)$r['amount']; // tablo kolonun ismi: amount (brüt TL)
}

// KULLANILABİLİR KÂR = TOPLAM − BLOKE
$availableProfit = $profit - $blockedProfit;
if ($availableProfit < 0) {
    $availableProfit = 0.0;
}

// ====== TALEPLER (GEÇMİŞ) ======
$stmt = $pdo->prepare("
    SELECT * FROM agent_profit_withdraw_requests 
    WHERE agent_id=? AND status!='pending'
    ORDER BY created_at DESC LIMIT 20
");
$stmt->execute([$agentId]);
$pastReq = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kâr Cüzdanı</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        /* BASE STYLES */
        :root { 
            --primary: #c2273f; 
            --primary-hover: #be123c;
            --bg-body: #f1f5f9; 
            --bg-card: #ffffff; 
            --text-main: #1f2937; 
            --text-muted: #6b7280; 
            --border-color: #e5e7eb; 
            --radius-md: 8px; 
        }
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; }
        
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        .main-content { flex: 1; padding: 30px; overflow-y: auto; position: relative; }
        
        .topbar h1 { font-size: 24px; font-weight: 800; margin: 0 0 20px 0; color: var(--text-main); }

        /* CARDS */
        .card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); padding: 24px; margin-bottom: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .card-title { font-size: 16px; font-weight: 700; margin: 0 0 20px 0; display: flex; align-items: center; gap: 8px; }

        /* STATS GRID */
        .stats-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
        .stat-box { background: #f8fafc; padding: 20px; border-radius: 12px; border: 1px solid var(--border-color); }
        .stat-label { font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; }
        .stat-val { font-size: 24px; font-weight: 800; color: var(--text-main); margin-top: 5px; }
        .val-primary { color: var(--primary); }
        .stat-sub { margin-top: 6px; font-size: 12px; color: var(--text-muted); }

        /* FORMS */
        .form-group { margin-bottom: 15px; }
        .form-label { display: block; font-weight: 600; font-size: 13px; margin-bottom: 6px; color: var(--text-main); }
        .form-control { width: 100%; padding: 12px; border: 1px solid var(--border-color); border-radius: var(--radius-md); font-size: 14px; outline: none; box-sizing: border-box; transition: border-color 0.2s; }
        .form-control:focus { border-color: var(--primary); }

        .btn-primary { width: 100%; padding: 12px; background: var(--primary); color: white; border: none; border-radius: var(--radius-md); font-weight: 600; cursor: pointer; transition: opacity 0.2s; }
        .btn-primary:hover { background: var(--primary-hover); }
        .btn-primary:disabled { background: #e5e7eb; color: #9ca3af; cursor: not-allowed; }

        .btn-dark { width: 100%; padding: 12px; background: #1e293b; color: white; border: none; border-radius: var(--radius-md); font-weight: 600; cursor: pointer; }
        .btn-dark:hover { background: #334155; }
        .btn-dark:disabled { background: #e5e7eb; color: #9ca3af; cursor: not-allowed; }

        /* ALERTS & INFO */
        .alert-box { padding: 12px; border-radius: var(--radius-md); font-size: 13px; margin-top: 10px; display: none; }
        .alert-red { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
        .alert-green { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        
        .global-warning { background: #fff7ed; color: #9a3412; border: 1px solid #ffedd5; padding: 15px; border-radius: var(--radius-md); margin-bottom: 20px; display: flex; align-items: center; gap: 10px; font-weight: 500; font-size: 14px; }

        /* TABLES */
        .table-responsive { overflow-x: auto; }
        .table { width: 100%; border-collapse: collapse; font-size: 14px; }
        .table th { text-align: left; padding: 12px; color: var(--text-muted); font-weight: 600; font-size: 11px; text-transform: uppercase; border-bottom: 1px solid var(--border-color); }
        .table td { padding: 12px; border-bottom: 1px solid #f3f4f6; color: var(--text-main); vertical-align: middle; }
        .table tr:last-child td { border-bottom: none; }

        .badge { padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: 700; }
        .bg-green { background: #dcfce7; color: #166534; }
        .bg-red { background: #fee2e2; color: #991b1b; }

        /* 2FA LOCK SCREEN */
        .blur-locked { filter: blur(8px); opacity: 0.4; pointer-events: none; user-select: none; }
        .lock-overlay {
            position: absolute; top: 0; left: 0; width: 100%; height: 100%;
            display: flex; justify-content: center; align-items: center;
            z-index: 50;
        }
        .lock-box {
            background: white; padding: 40px; width: 350px;
            border-radius: 20px; text-align: center;
            box-shadow: 0 20px 50px rgba(0,0,0,0.2);
            border: 1px solid var(--border-color);
        }
        .lock-icon { font-size: 40px; color: var(--primary); margin-bottom: 15px; }

        /* SPLIT LAYOUT */
        .split-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        @media (max-width: 900px) { .split-grid { grid-template-columns: 1fr; } }
        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
            .table-responsive .table {
                min-width: 600px;
            }
        }
    </style>
</head>
<body>

<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    
    <div class="main-content">
        
        <?php if($need2FA): ?>
        <div class="lock-overlay">
            <div class="lock-box">
                <i class="ri-lock-2-fill lock-icon"></i>
                <h2 style="margin:0 0 10px 0; font-size:20px;">Güvenlik Kilidi</h2>
                <p style="color:#64748b; font-size:14px; margin-bottom:20px;">Kâr cüzdanına erişmek için 2FA (İki Adımlı Doğrulama) özelliğini aktif etmelisiniz.</p>
                <a href="settings.php" class="btn-primary" style="display:inline-block; text-decoration:none; line-height:40px;">Ayarlara Git</a>
            </div>
        </div>
        <?php endif; ?>

        <div id="pageContent" class="<?= $need2FA ? 'blur-locked' : '' ?>">
            
            <div class="topbar">
                <h1>Kâr Cüzdanı</h1>
            </div>

            <div class="global-warning">
                <i class="ri-alert-fill"></i>
                <span>Kripto çekim işlemlerinizde ağ ücreti nedeniyle %1 işlem kesintisi uygulanır. Bekleyen çekim talepleriniz kâr bakiyenizden blokeye alınır; teminata aktarılamaz.</span>
            </div>

            <div class="stats-grid">
                <div class="stat-box" style="border-left: 4px solid #10b981;">
                    <div class="stat-label">KULLANILABİLİR KÂR BAKİYESİ</div>
                    <div class="stat-val" style="color:#10b981;"><?= number_format($availableProfit, 2) ?> TL</div>
                    <div class="stat-sub">
                        Toplam: <strong><?= number_format($profit, 2) ?> TL</strong> &nbsp;•&nbsp;
                        Blokede: <strong><?= number_format($blockedProfit, 2) ?> TL</strong>
                    </div>
                </div>
                <div class="stat-box" style="border-left: 4px solid var(--primary);">
                    <div class="stat-label">MEVCUT TEMİNAT</div>
                    <div class="stat-val val-primary"><?= number_format($collateral, 2) ?> TL</div>
                </div>
            </div>

            <div class="split-grid">
                
                <div class="card">
                    <h3 class="card-title"><i class="ri-bank-card-line"></i> Kâr Çekimi (TRC20)</h3>
                    
                    <form id="withdrawForm">
                        <?= csrf_field() ?>
                        <div class="form-group">
                            <label class="form-label">TRC20 USDT Adresi</label>
                            <input type="text" name="trc20" id="trc20" class="form-control" placeholder="Cüzdan adresini yapıştırın">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Çekilecek Tutar (TL)</label>
                            <input type="number" step="0.01" id="amountInput" name="amount" class="form-control" placeholder="Örn: 1000">
                        </div>

                        <div id="withdrawError" class="alert-box alert-red"></div>
                        <div id="withdrawNet" class="alert-box alert-green"></div>

                        <button type="submit" id="withdrawBtn" class="btn-primary" disabled>
                            Çekim Talebi Oluştur
                        </button>
                    </form>
                </div>

                <div class="card">
                    <h3 class="card-title"><i class="ri-exchange-funds-line"></i> Kârı Teminata Aktar</h3>
                    <p style="font-size:13px; color:var(--text-muted); margin-bottom:20px;">
                        Kazancınızı çekmek yerine teminata ekleyerek daha fazla yatırım limiti (kota) açabilirsiniz. Kesinti uygulanmaz.
                        Sadece <strong>kullanılabilir</strong> kâr bakiyesi teminata aktarılabilir; bekleyen çekim talepleriniz blokede tutulur.
                    </p>

                    <form id="toCollateralForm">
                        <?= csrf_field() ?>
                        <div class="form-group">
                            <label class="form-label">Aktarılacak Tutar (TL)</label>
                            <input type="number" step="0.01" id="colInput" name="amount" class="form-control" placeholder="Miktar girin">
                        </div>

                        <div id="colError" class="alert-box alert-red"></div>

                        <button type="submit" id="colBtn" class="btn-dark" disabled>
                            Teminata Ekle
                        </button>
                    </form>
                </div>

            </div>

            <div class="card">
                <h3 class="card-title">Bekleyen Çekim Talepleri</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Tutar</th>
                                <th>Adres</th>
                                <th>Kesinti</th>
                                <th>Net Geçen</th>
                                <th>Tarih</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(!$activeReq): ?>
                                <tr><td colspan="5" style="text-align:center; color:#9ca3af; padding:20px;">Bekleyen talep yok.</td></tr>
                            <?php else: foreach($activeReq as $r): ?>
                                <tr>
                                    <td style="font-weight:bold;"><?= number_format($r['amount'],2) ?> TL</td>
                                    <td>
                                        <div style="display:flex; align-items:center; gap:6px;">
                                            <span style="font-family:monospace; color:var(--text-muted); font-size:12px; background:#f1f5f9; padding:2px 6px; border-radius:4px; border:1px solid #e2e8f0; max-width:200px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                                                <?= htmlspecialchars($r['wallet_address'] ?? '-') ?>
                                            </span>
                                            <?php if(!empty($r['wallet_address'])): ?>
                                            <i class="ri-file-copy-line" 
                                               style="cursor:pointer; color:var(--primary); font-size:14px;" 
                                               onclick="navigator.clipboard.writeText('<?= htmlspecialchars($r['wallet_address']) ?>'); showToast('success', 'Adres kopyalandı');"
                                               title="Kopyala"></i>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td style="color:#ef4444;">-<?= number_format($r['fee_amount'],2) ?> TL</td>
                                    <td style="color:#10b981; font-weight:700;"><?= number_format($r['amount_after_fee'],2) ?> TL</td>
                                    <td><?= date('d.m H:i', strtotime($r['created_at'])) ?></td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card">
                <h3 class="card-title">Geçmiş İşlemler</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Tutar</th>
                                <th>Adres</th>
                                <th>Net</th>
                                <th>Durum</th>
                                <th>Tarih</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(!$pastReq): ?>
                                <tr><td colspan="5" style="text-align:center; color:#9ca3af; padding:20px;">Kayıt bulunamadı.</td></tr>
                            <?php else: foreach($pastReq as $r): ?>
                                <tr>
                                    <td><?= number_format($r['amount'],2) ?> TL</td>
                                    <td>
                                        <div style="display:flex; align-items:center; gap:6px;">
                                            <span style="font-family:monospace; color:var(--text-muted); font-size:12px; background:#f1f5f9; padding:2px 6px; border-radius:4px; border:1px solid #e2e8f0; max-width:200px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                                                <?= htmlspecialchars($r['wallet_address'] ?? '-') ?>
                                            </span>
                                            <?php if(!empty($r['wallet_address'])): ?>
                                            <i class="ri-file-copy-line" 
                                               style="cursor:pointer; color:var(--primary); font-size:14px;" 
                                               onclick="navigator.clipboard.writeText('<?= htmlspecialchars($r['wallet_address']) ?>'); showToast('success', 'Adres kopyalandı');"
                                               title="Kopyala"></i>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td style="font-weight:700;"><?= number_format($r['amount_after_fee'],2) ?> TL</td>
                                    <td>
                                        <?php if($r['status']=='paid'): ?>
                                            <span class="badge bg-green">Ödendi</span>
                                        <?php else: ?>
                                            <span class="badge bg-red">Reddedildi</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="color:var(--text-muted);"><?= date('d.m.Y H:i', strtotime($r['created_at'])) ?></td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<script>
const totalProfit      = <?= $profit ?>;            // Toplam kâr
const blockedProfit    = <?= $blockedProfit ?>;     // Blokede (pending)
const profitBalance    = <?= $availableProfit ?>;   // Kullanılabilir kâr

function showToast(type, msg) {
    const color = type === 'success' ? '#10b981' : '#ef4444';
    const div = document.createElement('div');
    div.style.cssText = `position:fixed; top:20px; right:20px; background:${color}; color:white; padding:15px 25px; border-radius:8px; z-index:9999; font-weight:600; box-shadow:0 5px 15px rgba(0,0,0,0.2); animation: fadeIn 0.5s;`;
    div.innerText = msg;
    document.body.appendChild(div);
    setTimeout(() => { div.remove(); }, 3000);
}

function validateWithdraw(){
    const trc = document.getElementById("trc20").value.trim();
    const amt = parseFloat(document.getElementById("amountInput").value);
    const err = document.getElementById("withdrawError");
    const netBox = document.getElementById("withdrawNet");
    const btn = document.getElementById("withdrawBtn");

    err.style.display = "none";
    netBox.style.display = "none";
    btn.disabled = true;

    if (!trc) return; 
    if (isNaN(amt) || amt <= 0) return;

    if (amt < 100){
        err.innerHTML = "Minimum çekim tutarı 100 TL'dir.";
        err.style.display = "block";
        return;
    }

    // ÖNEMLİ: Artık PROFIT değil, KULLANILABİLİR KÂR üzerinden kontrol ediyoruz
    if (amt > profitBalance){
        err.innerHTML = "Yetersiz kullanılabilir bakiye. Kullanılabilir: " + profitBalance.toFixed(2) + " TL (Toplam: " + totalProfit.toFixed(2) + " TL, blokede: " + blockedProfit.toFixed(2) + " TL)";
        err.style.display = "block";
        return;
    }

    let fee = (amt * 0.01).toFixed(2);
    let net = (amt - fee).toFixed(2);

    netBox.innerHTML = `<div style="display:flex; justify-content:space-between;"><span>Kesinti (%1):</span> <b>${fee} TL</b></div>
                        <div style="display:flex; justify-content:space-between; margin-top:5px; font-size:15px;"><span>Net Geçecek:</span> <b>${net} TL</b></div>`;
    netBox.style.display = "block";
    btn.disabled = false;
}

document.getElementById("trc20").addEventListener("input", validateWithdraw);
document.getElementById("amountInput").addEventListener("input", validateWithdraw);

document.getElementById("withdrawForm").addEventListener("submit", function(e){
    e.preventDefault();
    const btn = document.getElementById("withdrawBtn");
    btn.disabled = true;
    btn.innerText = "İşleniyor...";

    let fd = new FormData(this);
    fd.append("action","withdraw_profit");

    fetch("api/profit_actions.php", { method:"POST", body:fd })
    .then(r => r.text())
    .then(text => {
        try {
            const d = JSON.parse(text);
            if(d.status === "success"){
                showToast("success", d.message);
                setTimeout(() => location.reload(), 1000);
            } else {
                showToast("error", d.message);
                btn.disabled = false;
                btn.innerText = "Çekim Talebi Oluştur";
            }
        } catch(err) {
            console.error("JSON Hatası:", text);
            location.reload(); 
        }
    });
});

function validateCol(){
    const val = parseFloat(document.getElementById("colInput").value);
    const err = document.getElementById("colError");
    const btn = document.getElementById("colBtn");

    err.style.display = "none";
    btn.disabled = true;

    if (isNaN(val) || val <= 0) return;

    // Yine sadece kullanılabilir kâr üzerinden kontrol
    if (val > profitBalance){
        err.innerHTML = "Yetersiz kullanılabilir bakiye. Kullanılabilir: " + profitBalance.toFixed(2) + " TL";
        err.style.display = "block";
        return;
    }
    btn.disabled = false;
}

document.getElementById("colInput").addEventListener("input", validateCol);

document.getElementById("toCollateralForm").addEventListener("submit", function(e){
    e.preventDefault();
    const btn = document.getElementById("colBtn");
    btn.disabled = true;
    btn.innerText = "Aktarılıyor...";

    let fd = new FormData(this);
    fd.append("action","profit_to_collateral");

    fetch("api/profit_actions.php", { method:"POST", body:fd })
    .then(r => r.text())
    .then(text => {
        try {
            const d = JSON.parse(text);
            if(d.status === "success"){
                showToast("success", d.message);
                setTimeout(() => location.reload(), 1000);
            } else {
                showToast("error", d.message);
                btn.disabled = false;
                btn.innerText = "Teminata Ekle";
            }
        } catch(err) {
            console.error("JSON Hatası:", text);
            location.reload(); 
        }
    });
});
</script>

</body>
</html>
