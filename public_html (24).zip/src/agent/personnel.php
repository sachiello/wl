<?php
// agent/personnel.php - FINAL SÜRÜM (ROZET RENKLERİ DÜZELTİLDİ)
require 'init.php';

// GÜVENLİK KONTROLÜ
if (isset($isPersonnel) && $isPersonnel && !hasPerm('manage_personnel')) {
    die("<div style='padding:50px; text-align:center; color:red; font-weight:bold;'>Bu sayfayı görüntüleme yetkiniz yok.</div>");
}

// --- İŞLEM: PERSONEL EKLE / DÜZENLE ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (!csrf_validate_request()) {
        redirect_after_post('error', "Güvenlik doğrulaması başarısız.");
    } else {
        // 1. EKLEME
        if (isset($_POST['add_personnel'])) {
            $name = trim($_POST['name']);
            $pass = trim($_POST['password']);
            $perms = isset($_POST['perms']) ? $_POST['perms'] : [];
            
            $parentId = $masterAgentId;

            if (strlen($name) < 3 || strlen($pass) < 4) {
                redirect_after_post('error', "Kullanıcı adı en az 3, şifre en az 4 karakter olmalıdır.");
            } else {
                $check = $pdo->prepare("SELECT id FROM deposit_agents WHERE name = ?");
                $check->execute([$name]);
                if ($check->fetch()) {
                    redirect_after_post('error', "Bu kullanıcı adı zaten kullanılıyor.");
                } else {
                    try {
                        $hash = password_hash($pass, PASSWORD_BCRYPT);
                        $permJson = json_encode($perms);
                        
                        $ins = $pdo->prepare("INSERT INTO deposit_agents (name, password_hash, role, parent_id, permissions, is_active, created_at) VALUES (?, ?, 'personnel', ?, ?, 1, NOW())");
                        $ins->execute([$name, $hash, $parentId, $permJson]);
                        
                        redirect_after_post('success', "Yeni personel başarıyla oluşturuldu.");
                    } catch (Exception $e) { 
                        redirect_after_post('error', "Hata: " . $e->getMessage()); 
                    }
                }
            }
        }

        // 2. SİLME
        if (isset($_POST['delete_id'])) {
            $delId = (int)$_POST['delete_id'];
            $pdo->prepare("DELETE FROM deposit_agents WHERE id = ? AND parent_id = ?")->execute([$delId, $masterAgentId]);
            redirect_after_post('success', "Personel silindi.");
        }

        // 3. DÜZENLEME
        if (isset($_POST['edit_personnel'])) {
            $editId = (int)$_POST['edit_id'];
            $perms = isset($_POST['perms']) ? $_POST['perms'] : [];
            $newPass = trim($_POST['password']);
            $isActive = isset($_POST['is_active']) ? 1 : 0;
            $permJson = json_encode($perms);

            try {
                if (!empty($newPass)) {
                    $hash = password_hash($newPass, PASSWORD_BCRYPT);
                    $pdo->prepare("UPDATE deposit_agents SET password_hash = ?, permissions = ?, is_active = ? WHERE id = ? AND parent_id = ?")->execute([$hash, $permJson, $isActive, $editId, $masterAgentId]);
                } else {
                    $pdo->prepare("UPDATE deposit_agents SET permissions = ?, is_active = ? WHERE id = ? AND parent_id = ?")->execute([$permJson, $isActive, $editId, $masterAgentId]);
                }
                redirect_after_post('success', "Personel bilgileri güncellendi.");
            } catch (Exception $e) { 
                redirect_after_post('error', "Hata: " . $e->getMessage()); 
            }
        }
    }
}

// Listeleme
$stmt = $pdo->prepare("SELECT * FROM deposit_agents WHERE parent_id = ? ORDER BY created_at DESC");
$stmt->execute([$masterAgentId]);
$personnels = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Yönetimi</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        /* BASE STYLES */
        :root { --primary: #c2273f; --bg-body: #f1f5f9; --bg-card: #ffffff; --text-main: #1f2937; --text-muted: #6b7280; --border-color: #e5e7eb; --radius-md: 8px; }
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; }
        
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        .main-content { flex: 1; padding: 30px; overflow-y: auto; }
        
        .topbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .topbar h1 { font-size: 24px; font-weight: 800; margin: 0; color: var(--text-main); }

        /* ALERTS */
        .card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); padding: 24px; margin-bottom: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .card.bg-green { background: #ecfdf5; border-color: #10b981; color: #065f46; padding: 15px; }
        .card.bg-red { background: #fef2f2; border-color: #ef4444; color: #991b1b; padding: 15px; }

        /* TABLE */
        .table-responsive { overflow-x: auto; }
        .admin-table { width: 100%; border-collapse: collapse; font-size: 14px; }
        .admin-table th { text-align: left; padding: 12px 20px; color: var(--text-muted); font-weight: 600; font-size: 11px; text-transform: uppercase; border-bottom: 1px solid var(--border-color); background: #f9fafb; }
        .admin-table td { padding: 16px 20px; border-bottom: 1px solid var(--border-color); vertical-align: middle; color: var(--text-main); }
        .admin-table tr:last-child td { border-bottom: none; }

        /* BUTTONS */
        .btn-primary { background: var(--primary); color: #fff; border: none; padding: 10px 20px; border-radius: var(--radius-md); cursor: pointer; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; text-decoration: none; transition: opacity 0.2s; }
        .btn-primary:hover { opacity: 0.9; }
        
        .btn-icon { width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; border: 1px solid transparent; cursor: pointer; transition: all 0.2s; font-size: 16px; }
        .btn-edit { background: #f3f4f6; color: #4b5563; border-color: #e5e7eb; }
        .btn-edit:hover { background: #e5e7eb; color: #1f2937; }
        .btn-delete { background: #fef2f2; color: #dc2626; border-color: #fecaca; }
        .btn-delete:hover { background: #dc2626; color: #fff; }

        /* BADGES (RENK DÜZELTMELERİ) */
        .badge { padding: 4px 8px; border-radius: 6px; font-size: 11px; font-weight: 600; display: inline-block; margin: 0 4px 4px 0; border: 1px solid transparent; }
        
        /* Durum Rozetleri */
        .badge-active { background: #dcfce7; color: #166534; border-color: #bbf7d0; }
        .badge-passive { background: #f3f4f6; color: #6b7280; border-color: #e5e7eb; }
        
        /* Yetki Rozet Renkleri */
        .badge-blue   { background: #eff6ff; color: #1d4ed8; border-color: #dbeafe; }
        .badge-green  { background: #f0fdf4; color: #15803d; border-color: #bbf7d0; }
        .badge-red    { background: #fef2f2; color: #b91c1c; border-color: #fecaca; }
        .badge-purple { background: #faf5ff; color: #7e22ce; border-color: #e9d5ff; }
        .badge-yellow { background: #fefce8; color: #a16207; border-color: #fef08a; }
        .badge-gray   { background: #f8fafc; color: #475569; border-color: #e2e8f0; }

        /* MODAL */
        .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 999; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(2px); }
        .modal-content { background: #fff; width: 100%; max-width: 500px; border-radius: 16px; padding: 24px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid var(--border-color); padding-bottom: 15px; }
        .modal-header h3 { margin: 0; font-size: 18px; font-weight: 700; }
        .close-btn { font-size: 24px; cursor: pointer; color: var(--text-muted); transition: color 0.2s; }
        .close-btn:hover { color: var(--text-main); }
        
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 6px; font-size: 13px; font-weight: 600; color: var(--text-main); }
        .form-control { width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: var(--radius-md); font-size: 14px; outline: none; box-sizing: border-box; transition: border-color 0.2s; }
        .form-control:focus { border-color: var(--primary); }

        /* Custom Checkbox Grid */
        .perms-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 5px; }
        .perm-item { display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--text-main); background: #f9fafb; padding: 8px; border-radius: 6px; border: 1px solid var(--border-color); cursor: pointer; transition: all 0.2s; }
        .perm-item:hover { background: #f3f4f6; }
        .perm-item input { cursor: pointer; accent-color: var(--primary); width: 16px; height: 16px; }

        @media (max-width: 768px) {
            .topbar {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            .admin-table {
                min-width: 700px;
            }
            .modal-content {
                max-width: 90%;
            }
            .perms-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    <div class="main-content">
        
        <div class="topbar">
            <h1>Personel Yönetimi</h1>
            <button class="btn-primary" onclick="openModal('addModal')">
                <i class="ri-user-add-line"></i> Yeni Personel
            </button>
        </div>

        <?php $flash = get_flash(); if ($flash): ?>
            <div class="card <?= $flash['type'] == 'success' ? 'bg-green' : 'bg-red' ?>">
                <div style="display:flex; align-items:center; gap:10px;">
                    <i class="ri-<?= $flash['type'] == 'success' ? 'checkbox-circle-fill' : 'error-warning-fill' ?>" style="font-size:20px;"></i>
                    <?= htmlspecialchars($flash['text']) ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="card" style="padding:0; overflow:hidden;">
            <div class="table-responsive">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Kullanıcı</th>
                            <th>Atanmış Yetkiler</th>
                            <th>Durum</th>
                            <th style="text-align:right;">İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($personnels as $p): $pPerms = json_decode($p['permissions'], true) ?? []; ?>
                        <tr>
                            <td>
                                <div style="font-weight:600; font-size:15px; color:var(--text-main);">
                                    <?= htmlspecialchars($p['name']) ?>
                                </div>
                                <div style="font-size:12px; color:var(--text-muted);">ID: <?= $p['id'] ?></div>
                            </td>
                            <td>
                                <?php 
                                // Rozet eşleştirmeleri
                                $badges = [
                                    'approve_deposit'    => ['badge-green',  'Yatırım Onayı'],
                                    'approve_withdraw'   => ['badge-red',    'Çekim/Ödeme'],
                                    'manage_ibans'       => ['badge-blue',   'IBAN Yönetimi'],
                                    'request_balance'    => ['badge-green',  'Bakiye Talebi'],
                                    'manage_personnel'   => ['badge-purple', 'Personel Yönetimi'],
                                    'view_profit_wallet' => ['badge-yellow', 'Kâr Cüzdanı'],
                                    'view_profit_logs'   => ['badge-yellow', 'Kâr Logları'],
                                    'view_reports'       => ['badge-gray',   'Raporlar'],
                                ];

                                if(empty($pPerms)) {
                                    echo "<span style='color:#9ca3af; font-style:italic; font-size:12px;'>Yetki yok</span>";
                                } else {
                                    foreach($badges as $key => $val) {
                                        if(in_array($key, $pPerms)) {
                                            echo "<span class='badge {$val[0]}'>{$val[1]}</span>";
                                        }
                                    }
                                }
                                ?>
                            </td>
                            <td>
                                <?= $p['is_active'] 
                                    ? '<span class="badge badge-active"><i class="ri-checkbox-circle-line"></i> Aktif</span>' 
                                    : '<span class="badge badge-passive"><i class="ri-indeterminate-circle-line"></i> Pasif</span>' 
                                ?>
                            </td>
                            <td style="text-align:right;">
                                <div style="display:flex; justify-content:flex-end; gap:5px;">
                                    <button class="btn-icon btn-edit" onclick='openEditModal(<?= json_encode($p) ?>)' title="Düzenle">
                                        <i class="ri-pencil-line"></i>
                                    </button>
                                    <form method="post" onsubmit="return confirm('Bu personeli silmek istediğinize emin misiniz?');" style="margin:0;">
                                        <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
                                        <input type="hidden" name="delete_id" value="<?= $p['id'] ?>">
                                        <button class="btn-icon btn-delete" title="Sil">
                                            <i class="ri-delete-bin-line"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        
                        <?php if(!$personnels): ?>
                            <tr><td colspan="4" style="text-align:center; padding:30px; color:var(--text-muted);">Henüz personel eklenmemiş.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div id="addModal" class="modal-overlay" style="display:none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Yeni Personel Ekle</h3>
            <span class="close-btn" onclick="closeModal('addModal')">&times;</span>
        </div>
        <form method="post">
            <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
            <input type="hidden" name="add_personnel" value="1">
            
            <div class="form-group">
                <label>Kullanıcı Adı</label>
                <input type="text" name="name" required class="form-control" placeholder="Giriş için kullanılacak ad">
            </div>
            <div class="form-group">
                <label>Şifre</label>
                <input type="text" name="password" required class="form-control" placeholder="Giriş şifresi">
            </div>
            
            <div class="form-group">
                <label>Yetkiler</label>
                <div class="perms-grid">
                    <label class="perm-item"><input type="checkbox" name="perms[]" value="approve_deposit" checked> Yatırım Onayı</label>
                    <label class="perm-item"><input type="checkbox" name="perms[]" value="approve_withdraw"> Çekim/Ödeme</label>
                    <label class="perm-item"><input type="checkbox" name="perms[]" value="manage_ibans"> IBAN Yönetimi</label>
                    <label class="perm-item"><input type="checkbox" name="perms[]" value="request_balance"> Bakiye Yükleme</label>
                    <label class="perm-item"><input type="checkbox" name="perms[]" value="view_reports"> Raporlar</label>
                    <label class="perm-item"><input type="checkbox" name="perms[]" value="manage_personnel"> Personel Yönetimi</label>
                    <label class="perm-item"><input type="checkbox" name="perms[]" value="view_profit_wallet"> Kâr Cüzdanı</label>
                    <label class="perm-item"><input type="checkbox" name="perms[]" value="view_profit_logs"> Kâr Geçmişi</label>
                </div>
            </div>
            
            <div style="text-align:right; margin-top:20px;">
                <button type="button" onclick="closeModal('addModal')" style="background:none; border:none; color:var(--text-muted); margin-right:10px; cursor:pointer;">İptal</button>
                <button type="submit" class="btn-primary">Personeli Kaydet</button>
            </div>
        </form>
    </div>
</div>

<div id="editModal" class="modal-overlay" style="display:none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Düzenle: <span id="editNameTitle" style="color:var(--primary);"></span></h3>
            <span class="close-btn" onclick="closeModal('editModal')">&times;</span>
        </div>
        <form method="post">
            <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
            <input type="hidden" name="edit_personnel" value="1">
            <input type="hidden" name="edit_id" id="editId">
            
            <div class="form-group">
                <label>Yeni Şifre <span style="font-weight:400; color:#9ca3af;">(Değiştirmek istemiyorsanız boş bırakın)</span></label>
                <input type="text" name="password" class="form-control" placeholder="Yeni şifre...">
            </div>
            
            <div class="form-group">
                <label class="perm-item" style="display:inline-flex; width:auto;">
                    <input type="checkbox" name="is_active" id="editActive" value="1"> 
                    <span style="font-weight:600;">Hesap Aktif</span>
                </label>
            </div>
            
            <div class="form-group">
                <label>Yetkiler</label>
                <div class="perms-grid">
                    <label class="perm-item"><input type="checkbox" name="perms[]" value="approve_deposit" id="p_dep"> Yatırım Onayı</label>
                    <label class="perm-item"><input type="checkbox" name="perms[]" value="approve_withdraw" id="p_wd"> Çekim/Ödeme</label>
                    <label class="perm-item"><input type="checkbox" name="perms[]" value="manage_ibans" id="p_iban"> IBAN Yönetimi</label>
                    <label class="perm-item"><input type="checkbox" name="perms[]" value="request_balance" id="p_bal"> Bakiye Yükleme</label>
                    <label class="perm-item"><input type="checkbox" name="perms[]" value="view_reports" id="p_rep"> Raporlar</label>
                    <label class="perm-item"><input type="checkbox" name="perms[]" value="manage_personnel" id="p_pers"> Personel Yönetimi</label>
                    <label class="perm-item"><input type="checkbox" name="perms[]" value="view_profit_wallet" id="p_pw"> Kâr Cüzdanı</label>
                    <label class="perm-item"><input type="checkbox" name="perms[]" value="view_profit_logs" id="p_pl"> Kâr Geçmişi</label>
                </div>
            </div>
            
            <div style="text-align:right; margin-top:20px;">
                <button type="button" onclick="closeModal('editModal')" style="background:none; border:none; color:var(--text-muted); margin-right:10px; cursor:pointer;">İptal</button>
                <button type="submit" class="btn-primary">Güncelle</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal(id){
    document.getElementById(id).style.display='flex';
}
function closeModal(id){
    document.getElementById(id).style.display='none';
}

function openEditModal(data){
    document.getElementById('editId').value = data.id;
    document.getElementById('editNameTitle').innerText = data.name;
    document.getElementById('editActive').checked = (data.is_active == 1);
    
    // Yetkileri temizle
    const checkboxes = document.querySelectorAll('#editModal input[name="perms[]"]');
    checkboxes.forEach(cb => cb.checked = false);

    // Gelen yetkileri işaretle
    let perms = []; 
    try { perms = JSON.parse(data.permissions); } catch(e){}
    
    if(perms.includes('approve_deposit')) document.getElementById('p_dep').checked = true;
    if(perms.includes('approve_withdraw')) document.getElementById('p_wd').checked = true;
    if(perms.includes('manage_ibans')) document.getElementById('p_iban').checked = true;
    if(perms.includes('request_balance')) document.getElementById('p_bal').checked = true;
    if(perms.includes('view_reports')) document.getElementById('p_rep').checked = true;
    if(perms.includes('manage_personnel')) document.getElementById('p_pers').checked = true;
    if(perms.includes('view_profit_wallet')) document.getElementById('p_pw').checked = true;
    if(perms.includes('view_profit_logs')) document.getElementById('p_pl').checked = true;

    openModal('editModal');
}

// Modal dışına tıklayınca kapatma
window.onclick = function(event) {
    if (event.target.classList.contains('modal-overlay')) {
        event.target.style.display = "none";
    }
}
</script>

</body>
</html>