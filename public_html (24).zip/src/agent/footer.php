<audio id="agentAlertSound" src="https://cdn.freesound.org/previews/536/536108_11930272-lq.mp3" preload="auto"></audio>

<script>
let lastAgentTotal = 0;
const agentSound = document.getElementById('agentAlertSound');

function updateAgentLiveCounts() {
    // API'ye istek at
    fetch('api/live_counts.php')
        .then(response => response.json())
        .then(data => {
            if(data.status !== 'success') return;

            const counts = data.counts;
            const currentTotal = parseInt(data.total);

            // 1. SIDEBARDAKİ ROZETLERİ GÜNCELLE
            updateAgentBadge('deposits', counts.deposits);
            updateAgentBadge('withdrawals', counts.withdrawals);

            // 2. SESLİ UYARI (Yeni iş geldiyse)
            if (currentTotal > lastAgentTotal && lastAgentTotal !== 0) {
                try {
                    agentSound.play().catch(e => console.log("Ses izni yok."));
                    // Masaüstü bildirimi (Opsiyonel)
                    if (Notification.permission === "granted") new Notification("🔔 Yeni İşlem Var!");
                } catch(e) { console.log("Ses hatası."); }
            }
            
            lastAgentTotal = currentTotal;
        })
        .catch(err => console.error("Live count error:", err));
}

// Rozet Güncelleyici (Görünür/Gizli ayarı yapar)
function updateAgentBadge(key, count) {
    const badge = document.getElementById('badge_' + key);
    if (!badge) return;

    if (count > 0) {
        badge.innerText = count;
        badge.style.display = 'inline-block';
        // Dikkat çekmesi için animasyon class'ı ekle
        badge.classList.add('pulse-animation');
    } else {
        badge.style.display = 'none';
        badge.classList.remove('pulse-animation');
    }
}

// İzin iste ve başlat
if (Notification.permission !== "denied") { Notification.requestPermission(); }

document.addEventListener('DOMContentLoaded', () => {
    updateAgentLiveCounts(); // Açılışta çek
    setInterval(updateAgentLiveCounts, 5000); // 5 saniyede bir yenile
});
</script>

<style>
/* Yanıp Sönme Efekti */
@keyframes pulse-red { 0% { box-shadow: 0 0 0 0 rgba(220, 38, 38, 0.7); } 70% { box-shadow: 0 0 0 6px rgba(220, 38, 38, 0); } 100% { box-shadow: 0 0 0 0 rgba(220, 38, 38, 0); } }
.pulse-animation { animation: pulse-red 2s infinite; }
</style>