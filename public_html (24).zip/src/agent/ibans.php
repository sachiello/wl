<?php 
// agent/ibans.php - F5 KORUMALI FINAL SÜRÜM
require 'init.php'; 

// Yetki Kontrolü
if (isset($isPersonnel) && $isPersonnel && !hasPerm('manage_ibans')) {
    die("<div style='padding:50px; text-align:center; color:red; font-weight:bold;'>Bu sayfayı görüntüleme yetkiniz yok.</div>");
}

$processorId   = $_SESSION['agent_id']; 
$targetAgentId = $masterAgentId;

// --- İŞLEMLER ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!csrf_validate_request()) {
        redirect_after_post('error', 'Oturum doğrulaması başarısız.');
    }

    // 1. EKLEME İŞLEMİ
    if (isset($_POST['add_iban'])) {
        $bank   = trim($_POST['bank_name']);
        $holder = trim($_POST['holder_name']);
        $iban   = trim($_POST['iban']);
        $minLim = (float)$_POST['min_limit'];
        $maxLim = (float)$_POST['max_limit'];
        $quota  = (float)$_POST['quota_limit'];

        if (empty($bank) || empty($iban)) {
            redirect_after_post('error', "Banka adı ve IBAN zorunludur.");
        } else {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO deposit_ibans 
                    (agent_id, bank_name, holder_name, iban, min_deposit_limit, max_deposit_limit, quota_limit, is_active, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, 1, NOW())
                ");
                $stmt->execute([$processorId, $bank, $holder, $iban, $minLim, $maxLim, $quota]);
                
                redirect_after_post('success', "Yeni IBAN başarıyla eklendi.");
            } catch (Exception $e) {
                redirect_after_post('error', "Hata: " . $e->getMessage());
            }
        }
    }

    // 2. DURUM GÜNCELLEME
    if (isset($_POST['toggle_status_id'])) {
        $toggleId = (int)$_POST['toggle_status_id'];
        $pdo->prepare("UPDATE deposit_ibans SET is_active = NOT is_active WHERE id = ? AND agent_id IN (?, (SELECT id FROM deposit_agents WHERE parent_id = ?))")
            ->execute([$toggleId, $targetAgentId, $targetAgentId]); 
        
        redirect_after_post('success', "Hesap durumu güncellendi.");
    }

    // 3. SİLME
    if (isset($_POST['delete_id'])) {
        $delId = (int)$_POST['delete_id'];
        $stmt = $pdo->prepare("DELETE FROM deposit_ibans WHERE id = ? AND agent_id IN (?, (SELECT id FROM deposit_agents WHERE parent_id = ?))");
        $stmt->execute([$delId, $targetAgentId, $targetAgentId]); 
        
        redirect_after_post('success', "Hesap silindi.");
    }
}

// --- SORGULAMA ---
$stmt = $pdo->prepare("
    SELECT 
        di.*,
        da.role AS creator_role,
        da.name AS creator_name,
        (SELECT COALESCE(SUM(amount_try), 0) FROM deposit_orders WHERE iban_id = di.id AND status = 'confirmed') AS live_quota_used,
        (SELECT COUNT(*) FROM deposit_orders WHERE iban_id = di.id AND status = 'confirmed' AND DATE(created_at) = CURDATE()) AS live_daily_txn
    FROM deposit_ibans di
    JOIN deposit_agents da ON da.id = di.agent_id
    WHERE 
        di.agent_id = :masterId
        OR di.agent_id IN (SELECT id FROM deposit_agents WHERE parent_id = :masterId AND role = 'personnel')
    ORDER BY di.id DESC
");
$stmt->execute([':masterId' => $targetAgentId]);
$ibans = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hesap ve Limit Yönetimi</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        /* BASE & LAYOUT */
        :root { --primary: #4f46e5; --bg-body: #f1f5f9; --bg-card: #ffffff; --text-main: #1f2937; --text-muted: #6b7280; --border-color: #e5e7eb; --radius-md: 8px; }
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; }
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        .main-content { flex: 1; padding: 30px; overflow-y: auto; }
        .topbar h1 { font-size: 24px; font-weight: 800; margin: 0 0 20px 0; color: var(--text-main); }
        
        .card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); padding: 24px; margin-bottom: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .card.bg-green { background: #ecfdf5; border-color: #10b981; color: #065f46; padding: 15px; }
        .card.bg-red { background: #fef2f2; border-color: #ef4444; color: #991b1b; padding: 15px; }

        /* FORM ELEMENTS */
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 20px; align-items: end; }
        .form-group label { font-size: 12px; font-weight: 600; margin-bottom: 6px; display: block; color: var(--text-main); }
        .form-control { width: 100%; padding: 10px 12px; border: 1px solid var(--border-color); border-radius: var(--radius-md); font-size: 14px; outline: none; box-sizing: border-box; transition: border-color 0.2s; }
        .form-control:focus { border-color: var(--primary); }
        .btn-primary { background: var(--primary); color: #fff; border: none; padding: 10px 20px; border-radius: var(--radius-md); cursor: pointer; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 5px; transition: opacity 0.2s; height: 42px; }
        .btn-primary:hover { opacity: 0.9; }

        /* TABLE STYLES */
        .iban-table { width: 100%; border-collapse: separate; border-spacing: 0 15px; }
        .iban-row { background: #fff; box-shadow: 0 2px 4px rgba(0,0,0,0.02); transition: transform 0.2s; }
        .iban-row:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
        .iban-row td { padding: 20px; border-top: 1px solid var(--border-color); border-bottom: 1px solid var(--border-color); vertical-align: middle; }
        .iban-row td:first-child { border-left: 1px solid var(--border-color); border-radius: 12px 0 0 12px; }
        .iban-row td:last-child { border-right: 1px solid var(--border-color); border-radius: 0 12px 12px 0; }
        
        .bank-name { font-weight: 700; font-size: 15px; color: var(--text-main); }
        .iban-code { font-family: monospace; background: #f3f4f6; padding: 4px 8px; border-radius: 6px; font-size: 12px; color: var(--text-muted); display: inline-block; margin: 5px 0; }
        .limit-label { font-size: 11px; color: #9ca3af; font-weight: 600; text-transform: uppercase; }
        .limit-val { font-weight: 700; font-size: 13px; color: var(--text-main); }
        
        .progress-track { width: 100%; height: 6px; background: #f3f4f6; border-radius: 10px; overflow: hidden; margin: 8px 0; }
        .progress-fill { height: 100%; border-radius: 10px; transition: width 0.5s ease; }
        
        .btn-status { border: none; padding: 6px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .status-active { background: #dcfce7; color: #166534; }
        .status-passive { background: #f3f4f6; color: #4b5563; }
        .status-full { background: #fee2e2; color: #991b1b; cursor: not-allowed; }
        .btn-delete { background: transparent; border: none; color: #ef4444; font-size: 12px; font-weight: 600; cursor: pointer; text-decoration: underline; margin-top: 5px; }
        .btn-delete:hover { color: #b91c1c; }

        @media (max-width: 900px) {
            .main-content {
                padding: 20px;
            }
            .form-grid {
                grid-template-columns: 1fr;
            }
            .iban-table, .iban-table thead, .iban-table tbody, .iban-table th, .iban-table td, .iban-table tr {
                display: block;
            }
            .iban-table thead tr {
                position: absolute;
                top: -9999px;
                left: -9999px;
            }
            .iban-row {
                margin-bottom: 20px;
                border: 1px solid var(--border-color);
                border-radius: 12px;
                box-shadow: none;
            }
            .iban-table td {
                border: none;
                border-bottom: 1px solid var(--border-color);
                position: relative;
                padding: 15px;
                padding-left: 50%;
                text-align: right;
            }
             .iban-row td:first-child, .iban-row td:last-child {
                border-radius: 0;
            }
            .iban-table td:last-child {
                border-bottom: none;
            }
            .iban-table td:before {
                position: absolute;
                left: 15px;
                width: 45%;
                padding-right: 10px;
                white-space: nowrap;
                text-align: left;
                font-weight: 600;
                color: var(--text-muted);
                font-size: 12px;
                text-transform: uppercase;
            }
            .iban-table td:nth-of-type(1):before { content: "Hesap"; }
            .iban-table td:nth-of-type(2):before { content: "Limitler"; }
            .iban-table td:nth-of-type(3):before { content: "Kota"; }
            .iban-table td:nth-of-type(4):before { content: "Performans"; }
            .iban-table td:nth-of-type(5):before { content: "Yönetim"; }
        }
    </style>
</head>
<body>

<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    <div class="main-content">
        
        <div class="topbar">
            <h1>Hesap ve Limit Yönetimi</h1>
        </div>

        <?php $flash = get_flash(); if ($flash): ?>
            <div class="card <?= $flash['type'] == 'success' ? 'bg-green' : 'bg-red' ?>">
                <div style="display:flex; align-items:center; gap:10px;">
                    <i class="ri-<?= $flash['type'] == 'success' ? 'checkbox-circle-fill' : 'error-warning-fill' ?>" style="font-size:20px;"></i>
                    <?= htmlspecialchars($flash['text']) ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="card">
            <h3 style="margin:0 0 20px 0; font-size:16px; font-weight:700; color:var(--text-main);"><i class="ri-add-circle-line"></i> Yeni Hesap Ekle</h3>
            <form method="post" class="form-grid">
                <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
                <input type="hidden" name="add_iban" value="1">
                
                <div class="form-group">
                    <label>Banka Adı</label>
                    <input type="text" name="bank_name" class="form-control" placeholder="Örn: Ziraat" required>
                </div>
                <div class="form-group">
                    <label>Ad Soyad</label>
                    <input type="text" name="holder_name" class="form-control" placeholder="Hesap Sahibi" required>
                </div>
                <div class="form-group">
                    <label>IBAN</label>
                    <input type="text" name="iban" class="form-control" placeholder="TR..." required>
                </div>
                <div class="form-group">
                    <label>Min. Limit (TL)</label>
                    <input type="number" name="min_limit" class="form-control" value="100">
                </div>
                <div class="form-group">
                    <label>Max. Limit (TL)</label>
                    <input type="number" name="max_limit" class="form-control" value="50000">
                </div>
                <div class="form-group">
                    <label>Toplam Kota (TL)</label>
                    <input type="number" name="quota_limit" class="form-control" value="100000">
                </div>

                <button type="submit" class="btn-primary">
                    <i class="ri-save-line"></i> Kaydet
                </button>
            </form>
        </div>

        <table class="iban-table">
            <thead>
                <tr style="text-align: left; color: var(--text-muted); font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px;">
                    <th style="padding-left: 20px;">Hesap Bilgileri</th>
                    <th>Limitler</th>
                    <th style="width: 30%;">Kota Durumu</th>
                    <th>Performans</th>
                    <th style="text-align: right; padding-right: 20px;">Yönetim</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($ibans as $i): 
                    $quotaLimit = (float)$i['quota_limit'];
                    $quotaUsed  = (float)$i['live_quota_used']; 
                    $dailyTxn   = (int)$i['live_daily_txn'];    
                    $quotaLeft  = $quotaLimit - $quotaUsed;
                    $percent    = ($quotaLimit > 0) ? ($quotaUsed / $quotaLimit * 100) : 0;
                    
                    $progressColor = '#10b981'; 
                    if($percent > 50) $progressColor = '#f59e0b'; 
                    if($percent > 85) $progressColor = '#ef4444'; 

                    $isFull = ($quotaUsed >= $quotaLimit);
                    
                    $creatorBadge = ($i['creator_role'] === 'personnel') 
                        ? '<span style="font-size:10px; background:#f3f4f6; padding:2px 6px; border-radius:4px; color:#6b7280;"><i class="ri-user-settings-line"></i> '.$i['creator_name'].'</span>' 
                        : '<span style="font-size:10px; background:#eff6ff; padding:2px 6px; border-radius:4px; color:#3b82f6;"><i class="ri-shield-user-line"></i> '.$i['creator_name'].'</span>';
                ?>
                <tr class="iban-row">
                    <td>
                        <div class="bank-name"><?= htmlspecialchars($i['bank_name']) ?></div>
                        <div style="font-size:13px; color:var(--text-muted);"><?= htmlspecialchars($i['holder_name']) ?></div>
                        <div class="iban-code"><?= htmlspecialchars($i['iban']) ?></div>
                        <div style="margin-top:4px;"><?= $creatorBadge ?></div>
                    </td>

                    <td>
                        <div style="display:flex; flex-direction:column; gap:4px;">
                            <div><span class="limit-label">MİN:</span> <span class="limit-val"><?= number_format($i['min_deposit_limit']) ?> ₺</span></div>
                            <div><span class="limit-label">MAX:</span> <span class="limit-val"><?= number_format($i['max_deposit_limit']) ?> ₺</span></div>
                        </div>
                    </td>

                    <td>
                        <div style="display: flex; justify-content: space-between; font-size: 11px; margin-bottom: 4px; font-weight:600;">
                            <span style="color: var(--text-main);"><?= number_format($quotaUsed) ?> ₺</span>
                            <span style="color: var(--text-muted);"><?= number_format($quotaLimit) ?> ₺</span>
                        </div>
                        <div class="progress-track">
                            <div class="progress-fill" style="width: <?= min($percent, 100) ?>%; background: <?= $progressColor ?>;"></div>
                        </div>
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="font-size: 10px; color: var(--text-muted);">%<?= number_format($percent, 1) ?> Dolu</span>
                            <?php if($quotaLeft <= 0): ?>
                                <span style="color: #ef4444; font-weight: 800; font-size: 11px;">KOTA DOLDU</span>
                            <?php else: ?>
                                <span style="color: #10b981; font-weight: 700; font-size: 11px;">KALAN: <?= number_format($quotaLeft) ?> ₺</span>
                            <?php endif; ?>
                        </div>
                    </td>

                    <td>
                        <div style="text-align: center; border: 1px solid var(--border-color); padding: 8px; border-radius: 8px; min-width: 80px;">
                            <div style="font-size: 16px; font-weight: 800; color: var(--text-main);">
                                <?= (int)$i['live_daily_txn'] ?>
                            </div>
                            <div style="font-size: 9px; color: var(--text-muted); font-weight:700; text-transform:uppercase;">Bugün</div>
                        </div>
                    </td>

                    <td style="text-align: right;">
                        <div style="display: flex; flex-direction: column; gap: 8px; align-items: flex-end;">
                            <form method="post">
                                <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
                                <input type="hidden" name="toggle_status_id" value="<?= $i['id'] ?>">
                                <?php if($isFull): ?>
                                    <button type="button" class="btn-status status-full" disabled>KOTA DOLU</button>
                                <?php elseif($i['is_active']): ?>
                                    <button type="submit" class="btn-status status-active">AKTİF</button>
                                <?php else: ?>
                                    <button type="submit" class="btn-status status-passive">PASİF</button>
                                <?php endif; ?>
                            </form>

                            <form method="post" onsubmit="return confirm('Bu hesabı silmek istiyor musunuz?');">
                                <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
                                <input type="hidden" name="delete_id" value="<?= $i['id'] ?>">
                                <button type="submit" class="btn-delete">Sil</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                
                <?php if(empty($ibans)): ?>
                    <tr><td colspan="5" style="text-align: center; padding: 40px; color: var(--text-muted);">Henüz eklenmiş bir hesap yok.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

    </div>
</div>

<?php include 'footer.php'; ?>
</body>
</html>