<?php
// agent/topbar.php
// Bu dosya init.php'den ve sidebar.php'den SONRA include edilmelidir.

$currentCash  = $me['current_cash']      ?? 0.00;
$securityFund = $me['security_balance']  ?? 0.00;
$profitWallet = $me['profit_balance']    ?? 0.00;
$dailyCiro    = $me['daily_volume']      ?? 0.00;
$todayOrders  = $me['today_order_count'] ?? 0;
?>

<style>
    /* Sidebar genişliği: sidebar.php'de kullandığın width ile aynı olmalı */
    :root {
        --agent-sidebar-width: 260px;
    }

    .agent-topbar {
        position: sticky;
        top: 0;
        z-index: 998;

        /* Sidebar’ı hesaba kat: içerik alanının üstüne otur */
        margin-left: var(--agent-sidebar-width);
        width: calc(100% - var(--agent-sidebar-width));

        padding: 12px 20px;
        background: #ffffff;
        border-bottom: 1px solid #e5e7eb;
        display: flex;
        gap: 20px;
        align-items: center;
        justify-content: space-between;
        box-sizing: border-box;
    }
    body.dark-mode .agent-topbar {
        background: #1e293b;
        border-color: #334155;
    }
    .agent-topbar .topbar-left {
        display: flex;
        gap: 16px;
        align-items: center;
        flex-wrap: wrap;
    }
    .agent-topbar .top-box {
        background: #f8fafc;
        border-radius: 10px;
        padding: 8px 14px;
        min-width: 140px;
        border-left: 4px solid #4f46e5;
    }
    body.dark-mode .agent-topbar .top-box {
        background: #0f172a;
        border-color: #6366f1;
    }
    .agent-topbar .top-box .label {
        font-size: 11px;
        font-weight: 700;
        color: #6b7280;
        text-transform: uppercase;
    }
    body.dark-mode .agent-topbar .top-box .label {
        color: #94a3b8;
    }
    .agent-topbar .top-box .value {
        font-size: 16px;
        font-weight: 800;
        color: #1f2937;
    }
    body.dark-mode .agent-topbar .top-box .value {
        color: #ffffff;
    }
    .agent-topbar .topbar-right {
        font-size: 12px;
        font-weight: 600;
        color: #6b7280;
        white-space: nowrap;
    }
    body.dark-mode .agent-topbar .topbar-right {
        color: #cbd5e1;
    }

    @media (max-width: 768px) {
        .agent-topbar {
            margin-left: 0;
            width: 100%;
            flex-direction: column;
            align-items: flex-start;
            gap: 10px;
        }
        .agent-topbar .topbar-right {
            align-self: flex-end;
        }
    }
</style>

<div class="agent-topbar">
    <div class="topbar-left">

        <div class="top-box">
            <div class="label">KASA</div>
            <div class="value">₺<?= number_format($currentCash, 2, ',', '.') ?></div>
        </div>

        <div class="top-box">
            <div class="label">TEMİNAT</div>
            <div class="value">₺<?= number_format($securityFund, 2, ',', '.') ?></div>
        </div>

        <div class="top-box">
            <div class="label">KÂR KASASI</div>
            <div class="value">₺<?= number_format($profitWallet, 2, ',', '.') ?></div>
        </div>

        <div class="top-box">
            <div class="label">GÜNLÜK CİRO</div>
            <div class="value">₺<?= number_format($dailyCiro, 2, ',', '.') ?></div>
        </div>

        <div class="top-box">
            <div class="label">BUGÜN EMİR</div>
            <div class="value"><?= number_format($todayOrders) ?></div>
        </div>

    </div>

    <div class="topbar-right">
        Son güncelleme: <span id="topBarUpdateTime"><?= date("H:i:s") ?></span>
    </div>
</div>

<script>
setInterval(() => {
    const el = document.getElementById('topBarUpdateTime');
    if (el) el.innerText = new Date().toLocaleTimeString("tr-TR");
}, 5000);
</script>
