<?php
// agent/settings.php - FINAL SÜRÜM (F5 SORUNU KESİN ÇÖZÜM)
require 'init.php';
require_once __DIR__ . '/../../lib/GoogleAuthenticator.php'; 

// Yetki Kontrolü
if (isset($isPersonnel) && $isPersonnel) {
    die("<div style='padding:50px; text-align:center; color:red; font-weight:bold;'>Bu sayfaya sadece ana yönetici erişebilir.</div>");
}

// --- FLASH MESAJLARI AL ---
// init.php içinde tanımladığın get_flash fonksiyonunu burada kullanıyoruz.
// Bu satırları en tepeye koy ki aşağıdaki değişkenler ezilmesin.
$flash = get_flash();
$msg = ($flash && $flash['type'] == 'success') ? $flash['text'] : "";
$err = ($flash && $flash['type'] == 'error') ? $flash['text'] : "";

$ga = new GoogleAuthenticator();

// Mevcut Ayarları Çek
$stmt = $pdo->prepare("SELECT allowed_ips, two_factor_enabled, two_factor_secret FROM deposit_agents WHERE id = ?");
$stmt->execute([$masterAgentId]);
$settings = $stmt->fetch(PDO::FETCH_ASSOC);

// Eğer secret yoksa geçici bir tane oluştur
$secret = $settings['two_factor_secret'] ?? null;
if (!$secret) {
    if (!isset($_SESSION['temp_secret'])) {
        $_SESSION['temp_secret'] = $ga->createSecret();
    }
    $secret = $_SESSION['temp_secret'];
}

// --- İŞLEMLER (POST GELDİĞİNDE) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (!csrf_validate_request()) {
        set_flash('error', "Güvenlik doğrulaması başarısız.");
        header("Location: settings.php");
        exit;
    }

    // 1. IP AYARLARI
    if (isset($_POST['save_security'])) {
        $ips = trim($_POST['allowed_ips'] ?? '');
        $upd = $pdo->prepare("UPDATE deposit_agents SET allowed_ips = ? WHERE id = ?");
        $upd->execute([$ips, $masterAgentId]);
        
        set_flash('success', "Güvenlik ayarları başarıyla güncellendi.");
        header("Location: settings.php"); // Sayfayı yenile (POST -> GET)
        exit;
    }

    // 2. 2FA AKTİFLEŞTİRME
    if (isset($_POST['enable_2fa'])) {
        $code = trim($_POST['verify_code'] ?? '');
        $tempSecret = $_SESSION['temp_secret'] ?? '';
        
        if (empty($code)) {
            set_flash('error', "Lütfen doğrulama kodunu girin.");
            header("Location: settings.php");
            exit;
        } elseif ($ga->verifyCode((string)$tempSecret, $code, 2)) {
            $upd = $pdo->prepare("UPDATE deposit_agents SET two_factor_enabled = 1, two_factor_secret = ? WHERE id = ?");
            $upd->execute([$tempSecret, $masterAgentId]);
            unset($_SESSION['temp_secret']);
            
            set_flash('success', "İki Adımlı Doğrulama (2FA) aktifleştirildi!");
            header("Location: settings.php");
            exit;
        } else {
            set_flash('error', "Girdiğiniz kod hatalı veya süresi dolmuş.");
            header("Location: settings.php");
            exit;
        }
    }

    // 3. 2FA KAPATMA
    if (isset($_POST['disable_2fa'])) {
        $code = trim($_POST['verify_code'] ?? '');
        $currentSecret = $settings['two_factor_secret'] ?? '';

        if (empty($code)) {
            set_flash('error', "Güvenlik için lütfen kodu girin.");
            header("Location: settings.php");
            exit;
        } elseif ($ga->verifyCode((string)$currentSecret, $code, 2)) {
            $upd = $pdo->prepare("UPDATE deposit_agents SET two_factor_enabled = 0, two_factor_secret = NULL WHERE id = ?");
            $upd->execute([$masterAgentId]);
            
            // Yeni kurulum için secret oluştur
            $_SESSION['temp_secret'] = $ga->createSecret();
            
            set_flash('success', "İki Adımlı Doğrulama başarıyla kaldırıldı.");
            header("Location: settings.php");
            exit;
        } else {
            set_flash('error', "Hatalı kod! Güvenliğiniz için 2FA'yı kaldırmadan önce doğrulama yapmalısınız.");
            header("Location: settings.php");
            exit;
        }
    }
}

$qrUrl = '';
if ($secret) {
    $qrUrl = $ga->getQRCodeGoogleUrl('BetWallet_Agent_' . $_SESSION['agent_name'], $secret);
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ayarlar ve Güvenlik</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        :root { --primary: #c2273f; --bg-body: #f1f5f9; --bg-card: #ffffff; --text-main: #1f2937; --text-muted: #6b7280; --border-color: #e5e7eb; --radius-md: 8px; }
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; }
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        .main-content { flex: 1; padding: 30px; overflow-y: auto; }
        .topbar h1 { font-size: 24px; font-weight: 800; margin: 0 0 20px 0; color: var(--text-main); }
        .card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); padding: 24px; margin-bottom: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .card-title { font-size: 16px; font-weight: 700; margin: 0 0 20px 0; display: flex; align-items: center; gap: 8px; }
        .alert { padding: 15px; border-radius: var(--radius-md); margin-bottom: 20px; display: flex; align-items: center; gap: 10px; font-weight: 500; font-size: 14px; }
        .alert-green { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
        .alert-red { background: #fef2f2; color: #b91c1c; border: 1px solid #fecaca; }
        .form-group { margin-bottom: 15px; }
        .form-label { display: block; font-weight: 600; font-size: 13px; margin-bottom: 6px; color: var(--text-main); }
        .form-control { width: 100%; padding: 12px; border: 1px solid var(--border-color); border-radius: var(--radius-md); font-size: 14px; outline: none; box-sizing: border-box; transition: border-color 0.2s; font-family: inherit; }
        .form-control:focus { border-color: var(--primary); }
        textarea.form-control { resize: vertical; min-height: 100px; }
        .btn-primary { width: 100%; padding: 12px; background: var(--primary); color: #fff; border: none; border-radius: var(--radius-md); font-weight: 600; cursor: pointer; transition: opacity 0.2s; }
        .btn-primary:hover { opacity: 0.9; }
        .btn-danger { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; padding: 12px; border-radius: var(--radius-md); font-weight: 600; cursor: pointer; transition: all 0.2s; width: 100%; }
        .btn-danger:hover { background: #dc2626; color: #fff; }
        .settings-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; }
        @media(max-width: 900px) { .settings-grid { grid-template-columns: 1fr; } }
        @media(max-width: 768px) { }
        .qr-box { text-align: center; padding: 20px; background: #f9fafb; border-radius: var(--radius-md); border: 1px dashed var(--border-color); margin-bottom: 20px; }
        .qr-img { width: 160px; height: 160px; margin-bottom: 15px; border: 1px solid #e5e7eb; padding: 5px; background: #fff; border-radius: 8px; }
        .secret-code { font-family: monospace; background: #eef2ff; color: var(--primary); padding: 6px 12px; border-radius: 6px; font-size: 14px; letter-spacing: 1px; display: inline-block; }
        .code-input { font-size: 24px; text-align: center; letter-spacing: 8px; font-weight: 700; color: var(--text-main); }
        .success-state { text-align: center; padding: 30px; }
        .success-icon { font-size: 64px; color: #10b981; margin-bottom: 15px; display: block; }
    </style>
</head>
<body>

<div class="app-wrapper">
    
    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        
        <div class="topbar">
            <h1>Hesap Ayarları & Güvenlik</h1>
        </div>

        <?php if($msg): ?>
            <div class="alert alert-green">
                <i class="ri-checkbox-circle-fill"></i> <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>
        
        <?php if($err): ?>
            <div class="alert alert-red">
                <i class="ri-error-warning-fill"></i> <?= htmlspecialchars($err) ?>
            </div>
        <?php endif; ?>

        <div class="settings-grid">
            
            <div class="card">
                <h3 class="card-title"><i class="ri-shield-cross-line"></i> IP Erişim Kısıtlaması</h3>
                <p style="color:var(--text-muted); font-size:13px; margin-bottom:20px; line-height:1.5;">
                    Hesabınıza sadece belirlediğiniz IP adreslerinden erişilmesine izin verin. Birden fazla IP için araya virgül koyunuz. Boş bırakırsanız her yerden erişilebilir.
                </p>
                
                <form method="post">
                    <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
                    <input type="hidden" name="save_security" value="1">
                    
                    <div class="form-group">
                        <label class="form-label">İzin Verilen IP Adresleri</label>
                        <textarea name="allowed_ips" class="form-control" placeholder="Örn: 192.168.1.1, 88.244.12.5"><?= htmlspecialchars($settings['allowed_ips'] ?? '') ?></textarea>
                    </div>
                    
                    <div style="margin-bottom:20px; font-size:12px; color:var(--primary); display:flex; align-items:center; gap:5px;">
                        <i class="ri-map-pin-line"></i> Şu anki IP Adresiniz: <b><?= $_SERVER['REMOTE_ADDR'] ?></b>
                    </div>
                    
                    <button type="submit" class="btn-primary">
                        <i class="ri-save-line"></i> Ayarları Kaydet
                    </button>
                </form>
            </div>

            <div class="card">
                <h3 class="card-title"><i class="ri-smartphone-line"></i> Google Authenticator (2FA)</h3>
                
                <?php if($settings['two_factor_enabled']): ?>
                    <div class="success-state">
                        <i class="ri-shield-check-fill success-icon"></i>
                        <h3 style="color:#065f46; margin:0 0 10px 0;">Hesabınız Güvende</h3>
                        <p style="color:var(--text-muted); font-size:14px; margin-bottom:25px;">
                            İki adımlı doğrulama şu anda aktif.
                        </p>
                        
                        <div style="background:#fff1f2; padding:20px; border-radius:12px; border:1px solid #fecdd3; margin-top:20px;">
                            <p style="font-size:13px; color:#be123c; margin-bottom:15px;">
                                <b>Uyarı:</b> 2FA'yı kaldırmak güvenlik riskidir. Kaldırmak için lütfen kodunuzu girin.
                            </p>
                            <form method="post" onsubmit="return confirm('Güvenlik korumasını kaldırmak istediğinize emin misiniz?');">
                                <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
                                <input type="hidden" name="disable_2fa" value="1">
                                
                                <div class="form-group">
                                    <input type="text" name="verify_code" class="form-control code-input" placeholder="000000" required maxlength="6" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9]/g, '')" style="margin-bottom:15px; font-size:20px; padding:10px;">
                                </div>

                                <button type="submit" class="btn-danger">
                                    <i class="ri-lock-unlock-line"></i> Doğrula ve Kaldır
                                </button>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="qr-box">
                        <img src="<?= $qrUrl ?>" class="qr-img" alt="QR Code">
                        <div style="margin-bottom:10px; font-size:13px; color:var(--text-main);">
                            Google Authenticator uygulamasını açıp QR kodu taratın.
                        </div>
                        <div class="secret-code"><?= $secret ?></div>
                        <div style="font-size:11px; color:var(--text-muted); margin-top:5px;">(QR okumazsa bu kodu girin)</div>
                    </div>
                    
                    <form method="post">
                        <?php if(function_exists('csrf_field')) echo csrf_field(); ?>
                        <input type="hidden" name="enable_2fa" value="1">
                        
                        <div class="form-group">
                            <label class="form-label">Doğrulama Kodu</label>
                            <input type="text" name="verify_code" class="form-control code-input" placeholder="000000" required maxlength="6" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9]/g, '')">
                        </div>
                        
                        <button type="submit" class="btn-primary">
                            <i class="ri-lock-2-line"></i> Doğrula ve Aktifleştir
                        </button>
                    </form>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
</body>
</html>