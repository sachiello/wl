<?php require 'init.php'; 

// GÜVENLİK: Personel buraya giremez, sadece Patron (Ana Agent) girer.
if (isset($_SESSION['is_personnel']) && $_SESSION['is_personnel'] === true) {
    die("<div style='padding:50px; text-align:center; color:red;'>Bu sayfaya erişim yetkiniz yok.</div>");
}

$agentId = $_SESSION['agent_id'];

// Logları Çek (Personel ismiyle birleştirerek)
// Not: agent_personnel_logs tablosunu önceki adımda oluşturduğunu varsayıyorum.
$sql = "SELECT l.*, p.name as staff_name 
        FROM agent_personnel_logs l 
        LEFT JOIN deposit_agents p ON l.personnel_id = p.id 
        WHERE l.agent_id = ? 
        ORDER BY l.created_at DESC LIMIT 100";
$stmt = $pdo->prepare($sql);
$stmt->execute([$agentId]);
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<style>
    @media (max-width: 768px) {
        .admin-table {
            min-width: 600px;
        }
    }
</style>
<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    <div class="main-content">
        <div class="topbar">
            <h1>Personel Logları</h1>
        </div>

        <div class="form-card" style="margin-bottom: 20px; padding: 15px;">
            <p style="font-size: 13px; color: var(--text-muted); margin: 0;">
                <i class="ri-error-warning-line"></i> Burada, altınızda çalışan personellerin yaptığı işlemleri (Giriş, Yatırım Onayı, IBAN ekleme vb.) görebilirsiniz.
            </p>
        </div>

        <div class="table-container">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Tarih</th>
                        <th>Personel</th>
                        <th>İşlem Türü</th>
                        <th>Detay</th>
                        <th>IP Adresi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($logs as $log): ?>
                    <tr>
                        <td style="color: var(--text-muted); font-size: 12px;">
                            <?= date('d.m.Y H:i:s', strtotime($log['created_at'])) ?>
                        </td>
                        <td>
                            <div style="font-weight: 700; color: var(--text-main);">
                                <i class="ri-user-line" style="font-size: 12px; margin-right: 4px;"></i>
                                <?= htmlspecialchars($log['staff_name'] ?? 'Silinmiş Personel') ?>
                            </div>
                        </td>
                        <td>
                            <span style="background: #f1f5f9; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; text-transform: uppercase;">
                                <?= htmlspecialchars($log['action']) ?>
                            </span>
                        </td>
                        <td style="font-size: 13px;">
                            <?= htmlspecialchars($log['details']) ?>
                        </td>
                        <td style="font-family: monospace; font-size: 11px; color: var(--text-muted);">
                            <?= htmlspecialchars($log['ip_address']) ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <?php if(!$logs): ?>
                        <tr><td colspan="5" style="text-align: center; color: var(--text-muted); padding: 30px;">Henüz kaydedilmiş bir işlem yok.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>
</div>
</body>
</html>