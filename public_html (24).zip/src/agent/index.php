<?php 
// agent/index.php
require 'init.php'; 

// --- 1. KULLANICI VE VERİ HAZIRLIĞI ---
$myId = $_SESSION['agent_id'] ?? 0;
if ($myId == 0) { header("Location: login.php"); exit; }

// Kendi bilgilerimizi tazeleyelim
$stmtMe = $pdo->prepare("SELECT * FROM deposit_agents WHERE id = ?");
$stmtMe->execute([$myId]);
$me = $stmtMe->fetch(PDO::FETCH_ASSOC);

// Hedef ID Belirleme
$targetId = $me['id'];
if (!empty($me['parent_id'])) {
    $targetId = $me['parent_id'];
}

// Hedef Agent Verileri
$stmtTarget = $pdo->prepare("SELECT * FROM deposit_agents WHERE id = ?");
$stmtTarget->execute([$targetId]);
$targetAgent = $stmtTarget->fetch(PDO::FETCH_ASSOC);

// Bakiyeler
$sysBalance  = $targetAgent['system_balance'] ?? 0;       // Teminat
$curCash     = $targetAgent['current_cash'] ?? 0;         // Kasa
$profit      = $targetAgent['agent_profit_balance'] ?? 0; // Kazanç
$isPersonnel = ($me['role'] === 'personnel');

// --- 2. İSTATİSTİKLER (SAYAÇLAR) ---
$stmtDeps = $pdo->prepare("SELECT COUNT(*) FROM deposit_orders WHERE agent_id = ? AND status = 'pending'");
$stmtDeps->execute([$targetId]);
$pendingDepsCount = $stmtDeps->fetchColumn();

$stmtWds = $pdo->prepare("SELECT COUNT(*) FROM agent_withdraw_orders WHERE agent_id = ? AND status = 'pending'");
$stmtWds->execute([$targetId]);
$pendingWdsCount = $stmtWds->fetchColumn();

// --- 3. BEKLEYEN İŞLEMLER LOGU (Yatırım + Çekim Birleşik) ---
// Son 10 bekleyen yatırımı çek
$sqlPendingDeps = "
    SELECT 
        id, 
        'deposit' as type, 
        amount_try as amount, 
        created_at, 
        user_id 
    FROM deposit_orders 
    WHERE agent_id = ? AND status = 'pending' 
    ORDER BY created_at DESC LIMIT 10";
$stmtPD = $pdo->prepare($sqlPendingDeps);
$stmtPD->execute([$targetId]);
$pDeps = $stmtPD->fetchAll(PDO::FETCH_ASSOC);

// Son 10 bekleyen çekimi çek
$sqlPendingWds = "
    SELECT 
        id, 
        'withdraw' as type, 
        amount, 
        created_at, 
        user_id 
    FROM agent_withdraw_orders 
    WHERE agent_id = ? AND status = 'pending' 
    ORDER BY created_at DESC LIMIT 10";
$stmtPW = $pdo->prepare($sqlPendingWds);
$stmtPW->execute([$targetId]);
$pWds = $stmtPW->fetchAll(PDO::FETCH_ASSOC);

// Birleştir ve Tarihe Göre Sırala
$mergedLog = array_merge($pDeps, $pWds);
usort($mergedLog, function($a, $b) {
    return strtotime($b['created_at']) - strtotime($a['created_at']);
});
// Sadece ilk 15 kaydı göster
$mergedLog = array_slice($mergedLog, 0, 15);

$pageTitle = 'Genel Bakış';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Dashboard - BetWallet</title>
    
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root { 
            --primary: #c2273f; 
            --bg-body: #f1f5f9; 
            --bg-card: #ffffff; 
            --text-main: #0f172a; 
            --text-muted: #64748b; 
            --border-color: #e2e8f0; 
            --success: #10b981; 
            --warning: #f59e0b; 
            --info: #3b82f6; 
            --danger: #ef4444; 
        }
        
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; display: flex; }
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        
        /* DÜZELTME: Sidebar CSS'leri buradan kaldırıldı, sidebar.php içinden geliyor. */
        
        .main-content { flex: 1; padding: 30px; overflow-y: auto; width: 100%; }
        
        /* Header */
        .header-area { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; flex-wrap: wrap; gap: 20px; }
        .welcome-text h1 { margin: 0; font-size: 24px; font-weight: 800; color: var(--text-main); }
        .welcome-text p { margin: 5px 0 0; color: var(--text-muted); font-size: 14px; }
        
        .action-btn { 
            background: var(--bg-card); border: 1px solid var(--border-color); color: var(--text-main); 
            padding: 10px 16px; border-radius: 8px; cursor: pointer; display: flex; align-items: center; gap: 8px; 
            font-size: 13px; font-weight: 600; transition: all 0.2s; text-decoration: none; 
        }
        .action-btn:hover { background: #f8fafc; border-color: var(--primary); color: var(--primary); }
        
        /* Stats Grid */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; margin-bottom: 30px; }
        
        .stat-card { 
            background: var(--bg-card); padding: 24px; border-radius: 16px; 
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05); border: 1px solid var(--border-color); 
            position: relative; overflow: hidden; transition: transform 0.2s; 
        }
        .stat-card:hover { transform: translateY(-3px); }
        
        .stat-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 15px; }
        .stat-icon { width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 20px; }
        .stat-title { font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }
        .stat-value { font-size: 28px; font-weight: 800; color: var(--text-main); letter-spacing: -0.5px; font-family: 'Inter', sans-serif; }
        .stat-desc { font-size: 12px; color: var(--text-muted); margin-top: 5px; }
        
        /* Colors */
        .card-primary .stat-icon { background: rgba(59, 130, 246, 0.1); color: var(--info); }
        .card-success .stat-icon { background: rgba(16, 185, 129, 0.1); color: var(--success); }
        .card-warning .stat-icon { background: rgba(245, 158, 11, 0.1); color: var(--warning); }
        .card-danger .stat-icon { background: rgba(239, 68, 68, 0.1); color: var(--danger); }
        
        /* Content Card (Log Table) */
        .content-card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); padding: 25px; margin-bottom: 20px; height: fit-content; }
        .card-title { font-size: 16px; font-weight: 700; margin: 0 0 20px 0; display: flex; align-items: center; gap: 8px; color: var(--text-main); }
        
        /* Table */
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; font-size: 14px; }
        th { text-align: left; padding: 12px; color: var(--text-muted); font-weight: 600; border-bottom: 1px solid var(--border-color); font-size: 12px; text-transform: uppercase; }
        td { padding: 14px 12px; border-bottom: 1px solid var(--border-color); color: var(--text-main); vertical-align: middle; }
        tr:last-child td { border-bottom: none; }
        
        .badge { padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 700; text-transform: uppercase; display: inline-flex; align-items: center; gap: 5px; }
        .badge-pending { background: #fffbeb; color: #b45309; border: 1px solid #fcd34d; }
        
        /* Icon Box for Type */
        .type-icon { width: 32px; height: 32px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 16px; }
        .type-deposit { background: #ecfccb; color: #3f6212; }
        .type-withdraw { background: #fee2e2; color: #991b1b; }
        
        .user-id { font-family: monospace; color: var(--text-muted); font-size: 12px; }

        /* Dashboard Split */
        .dashboard-split { display: grid; grid-template-columns: 2fr 1fr; gap: 20px; }
        @media(max-width: 900px) { .dashboard-split { grid-template-columns: 1fr; } }

        @media (max-width: 768px) {
            .header-area {
                flex-direction: column;
                align-items: flex-start;
            }
            .stats-grid, .dashboard-split {
                grid-template-columns: 1fr;
            }
            .main-content {
                padding: 15px;
            }
            .table-responsive {
                overflow-x: auto;
            }
        }
    </style>
</head>
<body>

<div class="app-wrapper">
    
    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        
        <div class="header-area">
            <div class="welcome-text">
                <h1>Hoş Geldin, <?= htmlspecialchars($me['name']) ?></h1>
                <p>Operasyonel durum ve bekleyen işlemler özeti.</p>
            </div>
            
            <?php if (!$isPersonnel): ?>
            <a href="balance.php" class="action-btn">
                <i class="ri-add-circle-line"></i> <span>Bakiye Yükle</span>
            </a>
            <?php endif; ?>
        </div>

        <div class="stats-grid">
            
            <?php if (!$isPersonnel): ?>
            <div class="stat-card card-success">
                <div class="stat-header">
                    <div>
                        <div class="stat-title">TOPLAM KASA</div>
                        <div class="stat-value"><?= number_format($curCash, 2) ?> ₺</div>
                    </div>
                    <div class="stat-icon"><i class="ri-bank-card-line"></i></div>
                </div>
                <div class="stat-desc">Dağıtılabilir güncel nakit bakiyesi.</div>
            </div>

            <div class="stat-card card-primary">
                <div class="stat-header">
                    <div>
                        <div class="stat-title">TOPLAM TEMİNAT</div>
                        <div class="stat-value"><?= number_format($sysBalance, 2) ?> ₺</div>
                    </div>
                    <div class="stat-icon"><i class="ri-shield-check-line"></i></div>
                </div>
                <div class="stat-desc">Yatırım kabul etme limiti.</div>
            </div>

            <div class="stat-card card-warning">
                <div class="stat-header">
                    <div>
                        <div class="stat-title">GÜNCEL KAZANÇ</div>
                        <div class="stat-value"><?= number_format($profit, 2) ?> ₺</div>
                    </div>
                    <div class="stat-icon"><i class="ri-coins-line"></i></div>
                </div>
                <div class="stat-desc">Henüz çekilmemiş net komisyon.</div>
            </div>
            <?php endif; ?>

            <div class="stat-card card-danger">
                <div class="stat-header">
                    <div>
                        <div class="stat-title">İŞLEM BEKLEYEN</div>
                        <div class="stat-value"><?= $pendingDepsCount + $pendingWdsCount ?> <small style="font-size:16px; color:var(--text-muted)">Adet</small></div>
                    </div>
                    <div class="stat-icon"><i class="ri-time-line"></i></div>
                </div>
                <div class="stat-desc">
                    <?= $pendingDepsCount ?> Yatırım / <?= $pendingWdsCount ?> Çekim
                </div>
            </div>

        </div>

        <div class="dashboard-split">

            <div class="content-card">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h3 class="card-title" style="margin:0;"><i class="ri-file-list-3-line"></i> Bekleyen İşlemler Akışı</h3>
                    <div style="font-size:12px; color:var(--text-muted);">Son talepler (Yatırım ve Çekim)</div>
                </div>
                
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>İşlem Türü</th>
                                <th>Talep ID</th>
                                <th>Kullanıcı ID</th>
                                <th>Tutar</th>
                                <th>Tarih</th>
                                <th>Durum</th>
                                <th style="text-align:right;">İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($mergedLog) > 0): ?>
                                <?php foreach($mergedLog as $log): ?>
                                    <tr>
                                        <td>
                                            <?php if($log['type'] == 'deposit'): ?>
                                                <div style="display:flex; align-items:center; gap:10px;">
                                                    <div class="type-icon type-deposit"><i class="ri-arrow-left-down-line"></i></div>
                                                    <div>
                                                        <div style="font-weight:600; color:#3f6212;">Yatırım</div>
                                                        <div style="font-size:11px; color:var(--text-muted);">Gelen Para</div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <div style="display:flex; align-items:center; gap:10px;">
                                                    <div class="type-icon type-withdraw"><i class="ri-arrow-right-up-line"></i></div>
                                                    <div>
                                                        <div style="font-weight:600; color:#991b1b;">Çekim</div>
                                                        <div style="font-size:11px; color:var(--text-muted);">Giden Para</div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td><span class="user-ref">#<?= $log['id'] ?></span></td>
                                        <td><span class="user-id">User-<?= $log['user_id'] ?></span></td>
                                        <td style="font-weight:700; font-size:15px;">
                                            <?= number_format($log['amount'], 2) ?> ₺
                                        </td>
                                        <td style="color:var(--text-muted); font-size:13px;">
                                            <?= date('d.m H:i', strtotime($log['created_at'])) ?>
                                            <div style="font-size:10px;"><?= time_elapsed_string($log['created_at']) ?></div>
                                        </td>
                                        <td>
                                            <span class="badge badge-pending">
                                                <i class="ri-loader-4-line"></i> Bekliyor
                                            </span>
                                        </td>
                                        <td style="text-align:right;">
                                            <a href="<?= $log['type'] == 'deposit' ? 'deposits.php' : 'withdrawals.php' ?>" class="action-btn" style="display:inline-flex; padding:6px 12px; font-size:12px;">
                                                İncele <i class="ri-arrow-right-s-line"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" style="text-align:center; padding:40px; color:var(--text-muted);">
                                        <i class="ri-inbox-line" style="font-size:48px; opacity:0.3; display:block; margin-bottom:10px;"></i>
                                        Bekleyen işlem bulunmuyor.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div style="display:flex; flex-direction:column; gap:20px;">
                
                <div class="content-card" style="<?= $targetAgent['two_factor_enabled'] ? 'border-left: 4px solid var(--success);' : 'border-left: 4px solid var(--danger);' ?>">
                    <h3 class="card-title"><i class="ri-shield-keyhole-line"></i> Güvenlik Durumu</h3>
                    <?php if($targetAgent['two_factor_enabled']): ?>
                        <div style="color:var(--success); font-weight:600; display:flex; align-items:center; gap:8px; margin-bottom:10px;">
                            <i class="ri-checkbox-circle-fill"></i> 2FA Aktif
                        </div>
                        <p style="font-size:13px; color:var(--text-muted);">Hesabınız güvende. Girişlerde kod istenecektir.</p>
                    <?php else: ?>
                        <div style="color:var(--danger); font-weight:600; display:flex; align-items:center; gap:8px; margin-bottom:10px;">
                            <i class="ri-error-warning-fill"></i> 2FA Pasif
                        </div>
                        <p style="font-size:13px; color:var(--text-muted); margin-bottom:10px;">Hesap güvenliğiniz risk altında. Hemen 2FA kurun.</p>
                        <a href="settings.php" class="action-btn" style="justify-content:center; background:var(--danger); color:#fff; border:none;">Hemen Aktifleştir</a>
                    <?php endif; ?>
                </div>

                <div class="content-card">
                    <h3 class="card-title"><i class="ri-server-line"></i> API Bağlantısı</h3>
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px;">
                        <div style="width:10px; height:10px; background:var(--success); border-radius:50%; box-shadow:0 0 0 3px rgba(16, 185, 129, 0.2);"></div>
                        <span style="font-size:13px; font-weight:600;">Sistem Aktif</span>
                    </div>
                    <div style="font-size:12px; color:var(--primary); background:#fff1f2; padding:10px; border-radius:6px;">
                        <i class="ri-robot-line"></i> <b>Otomasyon API</b> ve özel entegrasyonlar için bizimle iletişime geçin.
                    </div>
                </div>

                <div class="content-card">
                    <h3 class="card-title"><i class="ri-guide-fill"></i> Finans Özeti</h3>
                    <div style="font-size:13px; color:var(--text-muted); line-height:1.6;">
                        <p style="margin-bottom:10px;"><strong>Komisyon:</strong> %<?= $targetAgent['commission_rate'] ?? 0 ?></p>
                        <p>Bakiyenizi çekmek için mutabakat talebi oluşturabilirsiniz.</p>
                    </div>
                </div>

            </div>

        </div>

    </div>
</div>
<?php include 'footer.php'; ?>

<?php
// Basit zaman farkı fonksiyonu (Örn: 5 dk önce)
function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'yıl',
        'm' => 'ay',
        'w' => 'hafta',
        'd' => 'gün',
        'h' => 'saat',
        'i' => 'dk',
        's' => 'sn',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v;
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' önce' : 'az önce';
}
?>
</body>
</html>