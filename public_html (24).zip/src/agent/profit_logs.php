<?php
require 'init.php';

$agentId = $masterAgentId;

$stmt = $pdo->prepare("
    SELECT *
    FROM agent_profit_logs
    WHERE agent_id = ?
    ORDER BY created_at DESC
    LIMIT 200
");
$stmt->execute([$agentId]);
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<style>
    @media (max-width: 768px) {
        .card {
            overflow-x: auto;
        }
        .table {
            min-width: 600px;
        }
    }
</style>
<div class="app-wrapper">
<?php include 'sidebar.php'; ?>
<div class="main-content">

<div class="topbar"><h1>Kâr Hareketleri</h1></div>

<div class="card">
<table class="table">
    <thead>
        <tr>
            <th>Tarih</th>
            <th>Tür</th>
            <th>Tutar</th>
            <th>Açıklama</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach($logs as $l): ?>
        <tr>
            <td><?= date('d.m.Y H:i', strtotime($l['created_at'])) ?></td>
            <td><?= htmlspecialchars($l['type']) ?></td>
            <td><b><?= number_format($l['amount'],2) ?> TL</b></td>
            <td><?= htmlspecialchars($l['description']) ?></td>
        </tr>
    <?php endforeach; ?>

    <?php if(!$logs): ?>
        <tr><td colspan="4" style="text-align:center; padding:20px;">Kayıt bulunamadı</td></tr>
    <?php endif; ?>
    </tbody>
</table>
</div>

</div>
</div>
<?php include 'footer.php'; ?>
