<?php
// agent/reports.php
require 'init.php';

// --- 1. KİMLİK VE YETKİ KONTROLÜ ---
$myId = $_SESSION['agent_id'] ?? 0;
if ($myId == 0) { header("Location: login.php"); exit; }

// Kendi bilgilerimizi çekelim
$stmtMe = $pdo->prepare("SELECT * FROM deposit_agents WHERE id = ?");
$stmtMe->execute([$myId]);
$me = $stmtMe->fetch(PDO::FETCH_ASSOC);

// Yetki Kontrolü (Personel ise)
if ($me['role'] == 'personnel' && !hasPerm('view_reports')) {
    die("<div style='padding:20px; color:red; font-family:sans-serif;'>Rapor görüntüleme yetkiniz yok.</div>");
}

// Hedef Agent ID (Parent varsa o, yoksa kendisi)
$targetId = (!empty($me['parent_id'])) ? $me['parent_id'] : $me['id'];
$today = date('Y-m-d');

// --- 2. DEĞİŞKENLERİ TANIMLA ---
$totalIn = 0.0; $countIn = 0;
$totalOut = 0.0; $countOut = 0;
$netChange = 0.0;
$estCommission = 0.0;
$commRate = 0.025; // Varsayılan %2.5
$ibanStats = [];

try {
    // Komisyon Oranı
    $stmtRate = $pdo->prepare("SELECT commission_rate FROM deposit_agents WHERE id = ?");
    $stmtRate->execute([$targetId]);
    $val = $stmtRate->fetchColumn();
    if ($val) { $commRate = (float)$val / 100; }

    // Bugün Giren (Yatırımlar)
    $stmtIn = $pdo->prepare("SELECT SUM(amount_try) as total, COUNT(*) as cnt FROM deposit_orders WHERE agent_id = ? AND status = 'confirmed' AND DATE(confirmed_at) = ?");
    $stmtIn->execute([$targetId, $today]);
    $inStats = $stmtIn->fetch(PDO::FETCH_ASSOC);
    if ($inStats) {
        $totalIn = (float)($inStats['total'] ?? 0);
        $countIn = (int)($inStats['cnt'] ?? 0);
    }

    // Bugün Çıkan (Çekimler)
    $stmtOut = $pdo->prepare("SELECT SUM(amount) as total, COUNT(*) as cnt FROM agent_withdraw_orders WHERE agent_id = ? AND status = 'paid' AND DATE(completed_at) = ?");
    $stmtOut->execute([$targetId, $today]);
    $outStats = $stmtOut->fetch(PDO::FETCH_ASSOC);
    if ($outStats) {
        $totalOut = (float)($outStats['total'] ?? 0);
        $countOut = (int)($outStats['cnt'] ?? 0);
    }

    // Hesaplamalar
    $netChange = $totalIn - $totalOut;
    $estCommission = $totalIn * $commRate;

    // IBAN Performansı
    $stmtIban = $pdo->prepare("
        SELECT i.bank_name, i.iban, i.holder_name, 
               COUNT(d.id) as txn_count, 
               SUM(d.amount_try) as volume 
        FROM deposit_ibans i
        LEFT JOIN deposit_orders d ON d.iban_id = i.id AND d.status = 'confirmed' AND DATE(d.confirmed_at) = ?
        WHERE i.agent_id = ?
        GROUP BY i.id
        ORDER BY volume DESC
    ");
    $stmtIban->execute([$today, $targetId]);
    $ibanStats = $stmtIban->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    // Loglama yapılabilir
}

// --- CSV DIŞA AKTARMA ---
if (isset($_GET['export']) && $_GET['export'] == 'today') {
    if (ob_get_level()) ob_end_clean();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="gun_sonu_raporu_'.$today.'.csv"');
    $output = fopen('php://output', 'w');
    fputs($output, "\xEF\xBB\xBF"); // BOM
    fputcsv($output, ['Tip', 'Tutar', 'Zaman', 'Durum']);
    
    $dRows = $pdo->prepare("SELECT 'Yatirim', amount_try, created_at, status FROM deposit_orders WHERE agent_id = ? AND DATE(created_at) = ?");
    $dRows->execute([$targetId, $today]);
    while($row = $dRows->fetch(PDO::FETCH_ASSOC)) fputcsv($output, $row);
    
    $wRows = $pdo->prepare("SELECT 'Cekim', amount, created_at, status FROM agent_withdraw_orders WHERE agent_id = ? AND DATE(created_at) = ?");
    $wRows->execute([$targetId, $today]);
    while($row = $wRows->fetch(PDO::FETCH_ASSOC)) fputcsv($output, $row);
    
    fclose($output);
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raporlar - BetWallet</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        /* Index.php ile uyumlu temel stiller */
        :root { --primary: #c2273f; --bg-body: #f1f5f9; --bg-card: #ffffff; --text-main: #0f172a; --text-muted: #64748b; --border-color: #e2e8f0; }
        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; display: flex; }
        .app-wrapper { display: flex; width: 100%; min-height: 100vh; }
        .main-content { flex: 1; padding: 30px; overflow-y: auto; width: 100%; }

        .header-area { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; flex-wrap: wrap; gap: 20px; }
        .welcome-text h1 { margin: 0; font-size: 24px; font-weight: 800; color: var(--text-main); }
        .welcome-text p { margin: 5px 0 0; color: var(--text-muted); font-size: 14px; }

        .action-btn { 
            background: var(--bg-card); border: 1px solid var(--border-color); color: var(--text-main); 
            padding: 10px 16px; border-radius: 8px; cursor: pointer; display: flex; align-items: center; gap: 8px; 
            font-size: 13px; font-weight: 600; transition: all 0.2s; text-decoration: none; 
        }
        .action-btn:hover { background: #f8fafc; border-color: var(--primary); color: var(--primary); }
        .btn-primary { background: var(--primary); color: #fff; border: 1px solid var(--primary); }
        .btn-primary:hover { opacity: 0.9; color: #fff; }

        /* Kartlar */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: var(--bg-card); padding: 20px; border-radius: 16px; border: 1px solid var(--border-color); box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        
        .stat-label { font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }
        .stat-value { font-size: 24px; font-weight: 800; margin-top: 5px; font-family: 'Inter', sans-serif; }
        .stat-sub { font-size: 12px; color: var(--text-muted); margin-top: 2px; }

        /* Tablo */
        .content-card { background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border-color); padding: 25px; }
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; font-size: 14px; }
        th { text-align: left; padding: 12px; color: var(--text-muted); font-weight: 600; border-bottom: 1px solid var(--border-color); font-size: 12px; text-transform: uppercase; }
        td { padding: 14px 12px; border-bottom: 1px solid var(--border-color); color: var(--text-main); vertical-align: middle; }
        tr:last-child td { border-bottom: none; }

        .badge { padding: 4px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; }
        .bg-red { background: #fee2e2; color: #ef4444; }
        .bg-green { background: #ecfdf5; color: #10b981; }

        @media (max-width: 768px) {
            .header-area {
                flex-direction: column;
                align-items: flex-start;
            }
            .stats-grid {
                grid-template-columns: 1fr;
            }
            .table-responsive table {
                min-width: 600px;
            }
        }
    </style>
</head>
<body>

<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    
    <div class="main-content">
        
        <div class="header-area">
            <div class="welcome-text">
                <h1>Raporlar ve Mutabakat</h1>
                <p>Bugünün (<?= date('d.m.Y') ?>) finansal özeti.</p>
            </div>
            <a href="?export=today" class="action-btn btn-primary">
                <i class="ri-file-excel-2-line"></i> Günlük CSV İndir
            </a>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-label">BUGÜN GİREN (CASH-IN)</div>
                <div class="stat-value" style="color:#10b981;">+<?= number_format($totalIn, 2) ?> ₺</div>
                <div class="stat-sub"><?= $countIn ?> İşlem</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-label">BUGÜN ÇIKAN (CASH-OUT)</div>
                <div class="stat-value" style="color:#ef4444;">-<?= number_format($totalOut, 2) ?> ₺</div>
                <div class="stat-sub"><?= $countOut ?> İşlem</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-label">NET KASA DEĞİŞİMİ</div>
                <div class="stat-value" style="color:<?= $netChange >= 0 ? '#4f46e5' : '#ef4444' ?>;">
                    <?= ($netChange >= 0 ? '+' : '') . number_format($netChange, 2) ?> ₺
                </div>
                <div class="stat-sub">Giren - Çıkan</div>
            </div>
            
            <div class="stat-card" style="background:#f0fdf4; border-color:#bbf7d0;">
                <div class="stat-label" style="color:#166534;">TAHMİNİ KAZANÇ</div>
                <div class="stat-value" style="color:#15803d;"><?= number_format($estCommission, 2) ?> ₺</div>
                <div class="stat-sub" style="color:#166534;">%<?= $commRate*100 ?> Komisyon</div>
            </div>
        </div>

        <div class="content-card">
            <h3 style="margin:0 0 20px 0; font-size:16px; font-weight:700;"><i class="ri-bank-card-line"></i> Günlük IBAN Performansı</h3>
            
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Banka / Hesap</th>
                            <th>İşlem Adedi</th>
                            <th>Toplam Hacim</th>
                            <th>Risk Durumu</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($ibanStats)): ?>
                            <?php foreach($ibanStats as $iban): 
                                $volume = (float)($iban['volume'] ?? 0);
                            ?>
                            <tr>
                                <td>
                                    <div style="font-weight:700;"><?= htmlspecialchars($iban['bank_name']) ?></div>
                                    <div style="font-size:12px; color:var(--text-muted); font-family:monospace;"><?= htmlspecialchars($iban['iban']) ?></div>
                                    <div style="font-size:11px; color:var(--text-muted);"><?= htmlspecialchars($iban['holder_name']) ?></div>
                                </td>
                                <td><?= $iban['txn_count'] ?> Adet</td>
                                <td style="font-weight:700; color:#10b981;"><?= number_format($volume, 2) ?> TL</td>
                                <td>
                                    <?php if($iban['txn_count'] > 50): ?>
                                        <span class="badge bg-red">Yüksek</span>
                                    <?php else: ?>
                                        <span class="badge bg-green">Normal</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="4" style="text-align:center; padding:30px; color:var(--text-muted);">Bugün henüz işlem gerçekleşmedi.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<?php include 'footer.php'; ?>
</body>
</html>