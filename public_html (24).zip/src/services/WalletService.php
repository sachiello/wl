<?php

require_once __DIR__ . '/../helpers/wallet_helpers.php';
require_once __DIR__ . '/wallet/DepositService.php';
require_once __DIR__ . '/wallet/WithdrawService.php';
require_once __DIR__ . '/wallet/BankAccountService.php';
require_once __DIR__ . '/wallet/TransferService.php';
require_once __DIR__ . '/wallet/SiteService.php';
require_once __DIR__ . '/wallet/SupportService.php';
require_once __DIR__ . '/wallet/RateService.php';

class WalletService
{
    private PDO $pdo;
    private array $config;
    private int $userId;
    private string $username;
    private string $redirectBase;
    private DepositService $depositService;
    private WithdrawService $withdrawService;
    private BankAccountService $bankAccountService;
    private TransferService $transferService;
    private SiteService $siteService;
    private SupportService $supportService;
    private RateService $rateService;

    public function __construct(PDO $pdo, array $config, string $redirectBase)
    {
        wallet_require_session();

        $this->pdo          = $pdo;
        $this->config       = $config;
        $this->redirectBase = $redirectBase;
        $this->userId       = (int)($_SESSION['user_id'] ?? 0);
        $this->username     = $_SESSION['username'] ?? '';

        $this->rateService        = new RateService($pdo, $config);
        $this->depositService     = new DepositService($pdo, $this->userId, $this->username, $config);
        $this->withdrawService    = new WithdrawService($pdo, $this->userId);
        $this->bankAccountService = new BankAccountService($pdo, $this->userId);
        $this->transferService    = new TransferService($pdo, $this->userId);
        $this->siteService        = new SiteService($pdo, $this->userId);
        $this->supportService     = new SupportService($pdo, $this->userId);
    }

    /**
     * POST isteklerini tek noktadan yönetir.
     */
    public function handlePost(array $post): string
    {
        if (!csrf_validate_request()) {
            wallet_set_flash('error', 'Oturum doğrulama hatası. Lütfen sayfayı yenileyip tekrar deneyin.');
            return $this->redirectBase;
        }

        if (isset($post['logout'])) {
            session_unset();
            session_destroy();
            return '/';
        }

        if ($this->userId <= 0) {
            wallet_set_flash('error', 'Oturum süresi doldu. Lütfen tekrar giriş yapın.');
            return '/';
        }

        $rateUsdt = $this->rateService->getUsdtRate();

        if (isset($post['create_deposit'])) {
            $this->depositService->createDeposit($post, $rateUsdt);
            return $this->redirectBase;
        }

        if (isset($post['cancel_deposit'])) {
            $this->depositService->cancelDeposit($post);
            return $this->redirectBase;
        }

        if (isset($post['add_bank_account'])) {
            $this->bankAccountService->addBankAccount($post);
            return $this->redirectBase . '#withdraw';
        }

        if (isset($post['create_withdraw'])) {
            $this->withdrawService->createWithdraw($post, $rateUsdt);
            return $this->redirectBase;
        }

        if (isset($post['site_transfer'])) {
            $this->transferService->transferToSite($post, $rateUsdt);
            return $this->redirectBase;
        }

        if (isset($post['connect_site_demo'])) {
            $this->siteService->connectSiteDemo($post);
            return $this->redirectBase;
        }

        if (isset($post['create_ticket'])) {
            $this->supportService->createTicket($post);
            return '/wallet?v=support';
        }

        if (isset($post['reply_ticket'])) {
            $ticketId = (int)($post['ticket_id'] ?? 0);
            $this->supportService->replyTicket($post);
            return '/wallet?v=support&ticket=' . $ticketId;
        }

        return $this->redirectBase;
    }

    /**
     * GET akışı için tüm verileri toplar.
     */
    public function buildViewData(): array
    {
        $flash            = wallet_pop_flash();
        $rateUsdt         = $this->rateService->getUsdtRate();
        $exchangeRates    = ['USDT' => $rateUsdt];
        $statusApiUrl     = $this->config['status_api_path'] ?? '/src/controllers/get_user_status.php';
        $userId           = $this->userId;
        $defaultMinAmount = 100;

        $usdtBalance      = $this->getUsdtBalance($userId);
        $totalBalanceTry  = $usdtBalance * $rateUsdt;
        $totalBalanceText = number_format($totalBalanceTry, 2, ',', '.');

        $this->expireOldDeposits($userId);

        $activeDeposit        = $this->getActiveDeposit($userId);
        $activeDepositDetails = $this->getActiveDepositDetails($activeDeposit);

        $activeIbans      = $this->getActiveIbans();
        $currentIbanInfo  = bw_find_best_iban($this->pdo, $defaultMinAmount);
        $userBankAccounts = $this->getUserBankAccounts($userId);
        $userLinkedSites  = $this->getUserSites($userId);
        $allSitesQ        = $this->getAllSites();

        $supportData    = $this->getSupportData($userId);
        $recentOps      = $this->getRecentOperations($userId, $rateUsdt);

        $netTry  = isset($activeDeposit['amount_try']) ? (float)$activeDeposit['amount_try'] : 0.0;
        $netUsdt = ($rateUsdt > 0 && $netTry > 0) ? $netTry / $rateUsdt : 0.0;

        return [
            'csrfToken'            => csrf_token(),
            'statusApiUrl'         => $statusApiUrl,
            'sessionUserId'        => $userId,
            'sessionUsername'      => $this->username,
            'sessionAddress'       => $_SESSION['trc20_address'] ?? null,
            'rateUsdt'             => $rateUsdt,
            'exchangeRates'        => $exchangeRates,
            'totalBalanceText'     => $totalBalanceText,
            'totalBalanceTry'      => $totalBalanceTry,
            'usdtBalance'          => $usdtBalance,
            'activeDeposit'        => $activeDeposit,
            'activeDepositDetails' => $activeDepositDetails,
            'activeIbans'          => $activeIbans,
            'currentIbanInfo'      => $currentIbanInfo,
            'userBankAccounts'     => $userBankAccounts,
            'userLinkedSites'      => $userLinkedSites,
            'allSitesQ'            => $allSitesQ,
            'myTickets'            => $supportData['tickets'],
            'ticketThreads'        => $supportData['threads'],
            'recentOperations'     => $recentOps,
            'cryptoWallets'        => $this->getCryptoWallets(),
            'error'                => $flash['error'] ?? null,
            'success'              => $flash['success'] ?? null,
            'netTry'               => $netTry,
            'netUsdt'              => $netUsdt,
        ];
    }

    private function getUsdtBalance(int $userId): float
    {
        $stmt = $this->pdo->prepare("
            SELECT balance 
            FROM wallets 
            WHERE user_id = ? AND coin_type = 'USDT' 
            LIMIT 1
        ");
        $stmt->execute([$userId]);
        return (float)($stmt->fetchColumn() ?? 0.0);
    }

    private function expireOldDeposits(int $userId): void
    {
        $this->pdo->prepare("
            UPDATE deposit_orders 
            SET status = 'expired' 
            WHERE user_id = ? AND status = 'pending' AND expire_at < NOW()
        ")->execute([$userId]);
    }

    private function getActiveDeposit(int $userId): ?array
    {
        $stmt = $this->pdo->prepare("
            SELECT d.* 
            FROM deposit_orders d 
            LEFT JOIN deposit_ibans i ON d.iban_id = i.id 
            WHERE d.user_id = ? AND d.status = 'pending' 
            LIMIT 1
        ");
        $stmt->execute([$userId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    private function getActiveDepositDetails(?array $activeDeposit): array
    {
        $details = [
            'iban'        => null,
            'holder'      => null,
            'address'     => null,
            'network'     => null,
            'expiry'      => $activeDeposit ? strtotime($activeDeposit['expire_at']) * 1000 : 0,
            'coin_type'   => $activeDeposit['coin_type']   ?? null,
            'coin_amount' => $activeDeposit['coin_amount'] ?? 0.0
        ];

        if (!$activeDeposit) {
            return $details;
        }

        if ($activeDeposit['payment_method'] === 'havale' && $activeDeposit['iban_id']) {
            $stmt = $this->pdo->prepare("SELECT iban, holder_name FROM deposit_ibans WHERE id = ?");
            $stmt->execute([$activeDeposit['iban_id']]);
            $ibanInfo = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($ibanInfo) {
                $details['iban']   = $ibanInfo['iban'];
                $details['holder'] = $ibanInfo['holder_name'];
            }
        } elseif ($activeDeposit['payment_method'] === 'crypto' && $activeDeposit['crypto_wallet_id']) {
            $stmt = $this->pdo->prepare("SELECT address, network FROM admin_crypto_wallets WHERE id = ? AND coin_type = 'USDT'");
            $stmt->execute([$activeDeposit['crypto_wallet_id']]);
            $cryptoInfo = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($cryptoInfo) {
                $details['address'] = $cryptoInfo['address'];
                $details['network'] = $cryptoInfo['network'];
            }
        }

        return $details;
    }

    private function getActiveIbans(): array
    {
        $sql = "
            SELECT 
                i.*,
                a.name       AS iban_owner_name,
                a.role       AS iban_owner_role,
                parent.name AS parent_agent_name,
                COALESCE(
                    CASE WHEN a.role = 'agent' THEN a.system_balance END,
                    parent.system_balance
                ) AS agent_system_balance,
                COALESCE(
                    CASE WHEN a.role = 'agent' THEN a.current_cash END,
                    parent.current_cash
                ) AS agent_current_cash,
                COALESCE(
                    CASE WHEN a.role = 'agent' THEN a.is_active END,
                    parent.is_active
                ) AS agent_is_active
            FROM deposit_ibans i
            LEFT JOIN deposit_agents a 
                    ON a.id = i.agent_id
            LEFT JOIN deposit_agents parent
                    ON a.parent_id = parent.id
            WHERE 
                i.is_active = 1
                AND i.current_daily_txn < i.max_daily_txn
                AND (
                    i.agent_id IS NULL 
                    OR (
                        COALESCE(
                            CASE WHEN a.role = 'agent' THEN a.is_active END,
                            parent.is_active
                        ) = 1
                    )
                );
        ";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    private function getCryptoWallets(): array
    {
        $wallets = ['USDT' => null];
        if (function_exists('bw_get_available_crypto_wallet')) {
            $wallets['USDT'] = bw_get_available_crypto_wallet($this->pdo, 'USDT');
        }
        return $wallets;
    }

    private function getUserBankAccounts(int $userId): array
    {
        $stmt = $this->pdo->prepare("
            SELECT id, bank_name, iban, account_holder
            FROM user_bank_accounts
            WHERE user_id = ?
            ORDER BY id DESC
        ");
        $stmt->execute([$userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    private function getUserSites(int $userId): array
    {
        $stmt = $this->pdo->prepare("
            SELECT 
                us.site_username, 
                us.site_balance_try, 
                us.site_id, 
                s.name as site_name, 
                s.logo_url
            FROM user_sites us
            JOIN sites s ON us.site_id = s.id
            WHERE us.user_id = ?
        ");
        $stmt->execute([$userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    private function getAllSites(): array
    {
        $stmt = $this->pdo->query("
            SELECT id, name, logo_url 
            FROM sites 
            WHERE is_active = 1
        ");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    private function getSupportData(int $userId): array
    {
        $tickets = [];
        $threads = [];

        $tStmt = $this->pdo->prepare("
            SELECT id, subject, status, created_at, last_message_at
            FROM support_tickets
            WHERE user_id = ?
            ORDER BY last_message_at DESC
        ");
        $tStmt->execute([$userId]);
        $tickets = $tStmt->fetchAll(PDO::FETCH_ASSOC);

        if (!empty($tickets)) {
            $ids = array_column($tickets, 'id');
            $in  = implode(',', array_fill(0, count($ids), '?'));

            $mStmt = $this->pdo->prepare("
                SELECT ticket_id, message, is_admin, created_at
                FROM support_messages
                WHERE ticket_id IN ($in)
                ORDER BY ticket_id ASC, id ASC
            ");
            $mStmt->execute($ids);

            while ($row = $mStmt->fetch(PDO::FETCH_ASSOC)) {
                $ticketId = (int)$row['ticket_id'];
                if (!isset($threads[$ticketId])) {
                    $threads[$ticketId] = [];
                }
                $threads[$ticketId][] = $row;
            }
        }

        return [
            'tickets' => $tickets,
            'threads' => $threads,
        ];
    }

    private function getRecentOperations(int $userId, float $rateUsdt): array
    {
        $depositQ = $this->pdo->prepare("
            SELECT 
                id,
                amount_try AS amt,
                coin_type,
                status,
                created_at,
                'deposit' AS type
            FROM deposit_orders
            WHERE user_id = ?
            ORDER BY created_at DESC
            LIMIT 10
        ");
        $depositQ->execute([$userId]);
        $depositOps = $depositQ->fetchAll(PDO::FETCH_ASSOC);

        $withdrawQ = $this->pdo->prepare("
            SELECT 
                id,
                (amount * :rateUsdt) AS amt,
                coin_type,
                status,
                created_at,
                'withdraw' AS type
            FROM withdraw_requests
            WHERE user_id = :uid
            ORDER BY created_at DESC
            LIMIT 10
        ");
        $withdrawQ->execute([
            ':rateUsdt' => $rateUsdt,
            ':uid'      => $userId,
        ]);
        $withdrawOps = $withdrawQ->fetchAll(PDO::FETCH_ASSOC);

        $merchantOutQ = $this->pdo->prepare("
            SELECT
                mo.id,
                mo.amount_try AS amt,
                'TRY'      AS coin_type,
                mo.status,
                mo.created_at,
                'site_transfer_out' AS type,
                s.name     AS site_name
            FROM merchant_orders mo
            JOIN sites s ON s.id = mo.site_id
            WHERE mo.user_id = ?
            ORDER BY mo.created_at DESC
            LIMIT 10
        ");
        $merchantOutQ->execute([$userId]);
        $merchantOutOps = $merchantOutQ->fetchAll(PDO::FETCH_ASSOC);

        $merchantInQ = $this->pdo->prepare("
            SELECT
                mpw.id,
                mpw.net_amount AS amt,
                'TRY'          AS coin_type,
                mpw.status,
                mpw.created_at,
                'site_transfer_in' AS type,
                s.name         AS site_name
            FROM merchant_player_withdraws mpw
            JOIN sites s ON s.id = mpw.site_id
            WHERE mpw.user_id = ?
            ORDER BY mpw.created_at DESC
            LIMIT 10
        ");
        $merchantInQ->execute([$userId]);
        $merchantInOps = $merchantInQ->fetchAll(PDO::FETCH_ASSOC);

        $recentOperations = array_merge(
            $depositOps,
            $withdrawOps,
            $merchantOutOps,
            $merchantInOps
        );

        usort($recentOperations, function ($a, $b) {
            return strtotime($b['created_at']) <=> strtotime($a['created_at']);
        });

        return array_slice($recentOperations, 0, 10);
    }
}
