<?php

class BankAccountService
{
    private PDO $pdo;
    private int $userId;

    public function __construct(PDO $pdo, int $userId)
    {
        $this->pdo    = $pdo;
        $this->userId = $userId;
    }

    public function addBankAccount(array $post): void
    {
        $fullName = trim($post['bank_account_full_name'] ?? '');
        $bankName = trim($post['bank_account_bank_name'] ?? '');
        $ibanRaw  = trim($post['bank_account_iban'] ?? '');
        $iban     = strtoupper(str_replace(' ', '', $ibanRaw));

        if ($fullName === '' || $bankName === '' || $iban === '') {
            wallet_set_flash('error', "Lütfen banka adı, IBAN ve hesap sahibini doldurun.");
            return;
        }

        if (strlen($iban) < 16) {
            wallet_set_flash('error', "Lütfen geçerli bir IBAN girin.");
            return;
        }

        try {
            $check = $this->pdo->prepare("
                SELECT id 
                FROM user_bank_accounts 
                WHERE user_id = ? AND iban = ?
                LIMIT 1
            ");
            $check->execute([$this->userId, $iban]);
            if ($check->fetch()) {
                throw new Exception("Bu IBAN daha önce eklenmiş.");
            }

            $countStmt = $this->pdo->prepare("SELECT COUNT(*) FROM user_bank_accounts WHERE user_id = ?");
            $countStmt->execute([$this->userId]);
            $hasAny    = (int)$countStmt->fetchColumn() > 0;
            $isDefault = $hasAny ? 0 : 1;

            $this->pdo->beginTransaction();

            if ($isDefault === 1) {
                $this->pdo->prepare("
                    UPDATE user_bank_accounts
                    SET is_default = 0
                    WHERE user_id = ?
                ")->execute([$this->userId]);
            }

            $ins = $this->pdo->prepare("
                INSERT INTO user_bank_accounts
                    (user_id, bank_name, iban, account_holder, is_default, created_at)
                VALUES
                    (?, ?, ?, ?, ?, NOW())
            ");
            $ins->execute([
                $this->userId,
                $bankName,
                $iban,
                $fullName,
                $isDefault
            ]);

            $this->pdo->commit();
            wallet_set_flash('success', "Banka hesabınız başarıyla eklendi.");
        } catch (Exception $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            wallet_set_flash('error', "Banka hesabı eklenirken hata oluştu: " . $e->getMessage());
        }
    }
}
