<?php

class SiteService
{
    private PDO $pdo;
    private int $userId;

    public function __construct(PDO $pdo, int $userId)
    {
        $this->pdo    = $pdo;
        $this->userId = $userId;
    }

    public function connectSiteDemo(array $post): void
    {
        $siteId       = (int)($post['demo_site_id'] ?? 0);
        $siteUsername = trim($post['demo_username'] ?? '');
        $sitePassword = $post['demo_password'] ?? '';
        $action       = $post['demo_action'] ?? 'login';

        if (($action === 'login' || $action === 'register') && $siteUsername === 'test1') {
            try {
                $siteStmt = $this->pdo->prepare("SELECT id FROM sites WHERE id = ? AND is_active = 1");
                $siteStmt->execute([$siteId]);
                if (!$siteStmt->fetch()) {
                    throw new Exception("Seçilen site geçersiz.");
                }

                $checkStmt = $this->pdo->prepare("SELECT id FROM user_sites WHERE user_id = ? AND site_id = ?");
                $checkStmt->execute([$this->userId, $siteId]);
                if ($checkStmt->fetch()) {
                    throw new Exception("Bu site cüzdanınıza zaten bağlı.");
                }

                $insertStmt = $this->pdo->prepare("
                    INSERT INTO user_sites (user_id, site_id, site_username, linked_at) 
                    VALUES (?, ?, ?, NOW())
                ");
                $insertStmt->execute([$this->userId, $siteId, $siteUsername]);

                wallet_set_flash('success', "Site başarıyla cüzdanınıza bağlandı!");
            } catch (Exception $e) {
                wallet_set_flash('error', "Bağlantı Hatası: " . $e->getMessage());
            }
        } else {
            wallet_set_flash('error', "Demo giriş başarısız. Lütfen 'test1' kullanın.");
        }
    }
}
