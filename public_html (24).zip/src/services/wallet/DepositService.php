<?php

class DepositService
{
    private PDO $pdo;
    private int $userId;
    private string $username;
    private array $config;

    public function __construct(PDO $pdo, int $userId, string $username, array $config)
    {
        $this->pdo       = $pdo;
        $this->userId    = $userId;
        $this->username  = $username;
        $this->config    = $config;
    }

    public function createDeposit(array $post, float $rateUsdt): void
    {
        $paymentMethod  = $post['payment_method'] ?? null;
        $siteId         = 0;
        $expiryMinutes  = (int)($this->config['deposit_expiry_minutes'] ?? 15);
        $localSuccess   = null;

        try {
            $amount = (float)($post['amount_try'] ?? 0);
            if ($amount <= 0) {
                if ($paymentMethod === 'havale') {
                    $amount = (float)($post['amount_try_havale'] ?? 0);
                } elseif ($paymentMethod === 'crypto') {
                    $amount = (float)($post['amount_try_crypto'] ?? 0);
                }
            }

            if ($amount <= 0) {
                throw new Exception("Lütfen geçerli bir tutar girin.");
            }

            $checkPending = $this->pdo->prepare("SELECT id FROM deposit_orders WHERE user_id = ? AND status = 'pending' LIMIT 1");
            $checkPending->execute([$this->userId]);
            if ($checkPending->fetch()) {
                throw new Exception("Zaten bekleyen bir yatırım talebiniz var. Lütfen önce onu tamamlayın veya iptal edin.");
            }

            $this->pdo->beginTransaction();

            if ($paymentMethod === 'havale') {
                $sqlFinder = "
                    SELECT 
                        i.id as iban_id, 
                        i.agent_id, 
                        a.id as real_agent_id,
                        a.system_balance
                    FROM deposit_ibans i
                    JOIN deposit_agents a ON i.agent_id = a.id
                    WHERE 
                        i.is_active = 1
                        AND i.min_deposit_limit <= :amount 
                        AND i.max_deposit_limit >= :amount 
                        AND i.current_daily_txn < i.max_daily_txn
                        AND a.is_active = 1
                        AND a.system_balance >= :amount
                    ORDER BY RAND()
                    LIMIT 1
                    FOR UPDATE
                ";

                $stmtFinder = $this->pdo->prepare($sqlFinder);
                $stmtFinder->execute([':amount' => $amount]);
                $assignedData = $stmtFinder->fetch(PDO::FETCH_ASSOC);

                if (!$assignedData) {
                    throw new Exception("Şu an bu tutar için uygun yatırım kanalı bulunamadı. Lütfen farklı bir tutar deneyin.");
                }

                $updAgent = $this->pdo->prepare("UPDATE deposit_agents SET system_balance = system_balance - ? WHERE id = ?");
                $updAgent->execute([$amount, $assignedData['real_agent_id']]);

                $sqlInsert = "
                    INSERT INTO deposit_orders 
                        (user_id, site_id, amount_try, expire_at, status, payment_method, iban_id, agent_id, user_confirmed) 
                    VALUES 
                        (?, ?, ?, DATE_ADD(NOW(), INTERVAL ? MINUTE), 'pending', 'havale', ?, ?, 0)
                ";

                $stmt = $this->pdo->prepare($sqlInsert);
                $stmt->execute([
                    $this->userId,
                    $siteId,
                    $amount,
                    $expiryMinutes,
                    $assignedData['iban_id'],
                    $assignedData['real_agent_id']
                ]);

                $localSuccess = "Yatırım talebiniz oluşturuldu. Şimdi size özel atanan IBAN'a ödemeyi yapabilirsiniz.";
            } elseif ($paymentMethod === 'crypto') {
                $coin = 'USDT';

                if (!function_exists('bw_get_available_crypto_wallet')) {
                    throw new Exception("Sistem hatası: Cüzdan fonksiyonu bulunamadı.");
                }

                $wallet = bw_get_available_crypto_wallet($this->pdo, $coin);
                if (!$wallet) {
                    throw new Exception("USDT için aktif bir cüzdan adresi bulunamadı.");
                }

                if ($rateUsdt <= 0) {
                    throw new Exception("Kur bilgisi alınamadı.");
                }

                $coinAmount = round($amount / $rateUsdt, 6);

                $sql = "
                    INSERT INTO deposit_orders (
                        user_id, site_id, coin_type, amount_try, rate_try_per_unit, coin_amount,
                        expire_at, status, payment_method, crypto_wallet_id, user_confirmed
                    ) 
                    VALUES (
                        ?, ?, ?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL ? MINUTE), 'pending', 'crypto', ?, 0
                    )
                ";
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute([
                    $this->userId,
                    $siteId,
                    $coin, 
                    $amount,
                    $rateUsdt,
                    $coinAmount,
                    $expiryMinutes,
                    $wallet['id']
                ]);

                $localSuccess = "Kripto yatırım talebi oluşturuldu. Lütfen süresi dolmadan transferi yapın.";
            } else {
                throw new Exception("Geçersiz ödeme yöntemi.");
            }

            $this->pdo->commit();

            if (!empty($localSuccess)) {
                $_SESSION['auto_open_deposit_modal'] = true;
                wallet_set_flash('success', $localSuccess);
            }
        } catch (Exception $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }

            $errorMsg   = $e->getMessage();
            $userInfo   = $this->username . " (ID: {$this->userId})";
            $amountInfo = isset($amount) ? number_format($amount, 2) . " TL" : "Bilinmiyor";
            $dateInfo   = date('d.m.Y H:i:s');

            $telegramMessage = "🚨 <b>HATA: Yatırım İşlemi Başarısız!</b>\n\n" .
                               "👤 <b>Kullanıcı:</b> $userInfo\n" .
                               "💰 <b>Tutar:</b> $amountInfo\n" .
                               "⚠️ <b>Hata Mesajı:</b> $errorMsg\n" .
                               "📅 <b>Zaman:</b> $dateInfo";

            bw_send_telegram_alert($telegramMessage);
            wallet_set_flash('error', "Hata: " . $errorMsg);
        }
    }

public function cancelDeposit(array $post): void
{
    $orderId = (int)$post['cancel_deposit_id'];

    $stmtCheck = $this->pdo->prepare("
        SELECT amount_try, agent_id 
        FROM deposit_orders 
        WHERE id = ? AND user_id = ? AND status = 'pending'
    ");
    $stmtCheck->execute([$orderId, $this->userId]);
    $order = $stmtCheck->fetch(PDO::FETCH_ASSOC);

    if ($order) {
        $this->pdo->beginTransaction();
        try {
            // 1) Kullanıcı iptal etti -> user_cancelled
            $updateOrder = $this->pdo->prepare("
                UPDATE deposit_orders 
                SET status = 'user_cancelled'
                WHERE id = ?
            ");
            $updateOrder->execute([$orderId]);

            // 2) Agent limitini/teminatını geri serbest bırak
            if (!empty($order['agent_id'])) {
                $updateAgent = $this->pdo->prepare("
                    UPDATE deposit_agents 
                    SET system_balance = system_balance + ? 
                    WHERE id = ?
                ");
                $updateAgent->execute([
                    $order['amount_try'],
                    $order['agent_id']
                ]);
            }

            $this->pdo->commit();
            wallet_set_flash('success', "İşlem iptal edildi ve limitler serbest bırakıldı.");
        } catch (Exception $e) {
            $this->pdo->rollBack();
            wallet_set_flash('error', "İptal işlemi sırasında hata oluştu.");
        }
    } else {
        wallet_set_flash('error', "İptal edilecek aktif işlem bulunamadı.");
    }
}

}
