<?php

class TransferService
{
    private PDO $pdo;
    private int $userId;

    public function __construct(PDO $pdo, int $userId)
    {
        $this->pdo    = $pdo;
        $this->userId = $userId;
    }

    public function transferToSite(array $post, float $rateUsdt): void
    {
        $siteTransferId = (int)($post['transfer_site_id'] ?? 0);
        $amountTry      = (float)($post['transfer_amount_try'] ?? 0);
        $orderId        = 'ORD-' . time() . '-' . rand(1000, 9999);

        if ($amountTry <= 0 || $siteTransferId <= 0) {
            wallet_set_flash('error', "Geçersiz tutar veya site seçimi.");
            return;
        }

        try {
            if ($rateUsdt <= 0) {
                throw new Exception("Kur alınamadı. Lütfen tekrar deneyin.");
            }

            $coinAmount = round($amountTry / $rateUsdt, 6);

            $this->pdo->beginTransaction();

            $wStmt = $this->pdo->prepare("
                SELECT balance 
                FROM wallets 
                WHERE user_id = ? AND coin_type = 'USDT' 
                FOR UPDATE
            ");
            $wStmt->execute([$this->userId]);
            $wallet = $wStmt->fetch(PDO::FETCH_ASSOC);

            if (!$wallet) {
                throw new Exception("Cüzdan bulunamadı.");
            }

            $walletBalance = (float)$wallet['balance'];
            if ($walletBalance + 0.000001 < $coinAmount) {
                throw new Exception("Yetersiz cüzdan bakiyesi (USDT).");
            }

            $usStmt = $this->pdo->prepare("
                SELECT site_balance_try 
                FROM user_sites 
                WHERE user_id = ? AND site_id = ? 
                FOR UPDATE
            ");
            $usStmt->execute([$this->userId, $siteTransferId]);
            $siteUser = $usStmt->fetch(PDO::FETCH_ASSOC);

            if (!$siteUser) {
                throw new Exception("Bu site cüzdanınıza bağlı değil.");
            }

            $updWallet = $this->pdo->prepare("
                UPDATE wallets 
                SET balance = balance - ? 
                WHERE user_id = ? AND coin_type = 'USDT'
            ");
            $updWallet->execute([$coinAmount, $this->userId]);

            $updUserSite = $this->pdo->prepare("
                UPDATE user_sites
                SET site_balance_try = site_balance_try + ?
                WHERE user_id = ? AND site_id = ?
            ");
            $updUserSite->execute([$amountTry, $this->userId, $siteTransferId]);

            $siteStmt = $this->pdo->prepare("
                SELECT commission_rate
                FROM sites
                WHERE id = ?
                FOR UPDATE
            ");
            $siteStmt->execute([$siteTransferId]);
            $siteRow = $siteStmt->fetch(PDO::FETCH_ASSOC);

            if (!$siteRow) {
                throw new Exception("Site bulunamadı.");
            }

            $commissionRate   = (float)$siteRow['commission_rate'];
            $grossAmount      = $amountTry;
            $commissionAmount = round($grossAmount * $commissionRate / 100, 2);
            $netForSite       = $grossAmount - $commissionAmount;

            $updateSite = $this->pdo->prepare("
                UPDATE sites
                SET 
                    balance              = balance + ?,              
                    net_balance          = net_balance + ?,          
                    total_deposit_volume = total_deposit_volume + ?  
                WHERE id = ?
            ");
            $updateSite->execute([
                $netForSite,
                $netForSite,
                $grossAmount,
                $siteTransferId
            ]);

            $insMerchant = $this->pdo->prepare("
                INSERT INTO merchant_orders 
                    (site_id, user_id, order_id, amount_try, commission_rate, commission_amount, net_amount, coin_amount, coin_type, status, created_at)
                VALUES 
                    (?, ?, ?, ?, ?, ?, ?, ?, 'USDT', 'success', NOW())
            ");
            $insMerchant->execute([
                $siteTransferId,
                $this->userId,
                $orderId,
                $grossAmount,
                $commissionRate,
                $commissionAmount,
                $netForSite,
                $coinAmount
            ]);

            $siteUrlStmt = $this->pdo->prepare("SELECT success_redirect_url FROM sites WHERE id = ?");
            $siteUrlStmt->execute([$siteTransferId]);
            $redirectUrl = $siteUrlStmt->fetchColumn();

            $this->pdo->commit();

            $_SESSION['transfer_success_data'] = [
                'message'      => "₺" . number_format($amountTry, 2, ',', '.') . " başarıyla yüklendi!",
                'redirect_url' => $redirectUrl,
                'site_id'      => $siteTransferId
            ];

            wallet_set_flash('success', "₺" . number_format($amountTry, 2, ',', '.') . " site bakiyenize aktarıldı.");
        } catch (Exception $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            wallet_set_flash('error', "Yükleme Hatası: " . $e->getMessage());
        }
    }
}
