<?php

class SupportService
{
    private PDO $pdo;
    private int $userId;

    public function __construct(PDO $pdo, int $userId)
    {
        $this->pdo    = $pdo;
        $this->userId = $userId;
    }

    public function createTicket(array $post): void
    {
        $subject = trim($post['ticket_subject'] ?? '');
        $message = trim($post['ticket_message'] ?? '');

        if ($subject === '' || $message === '') {
            wallet_set_flash('error', "Lütfen konu ve mesaj alanlarını doldurun.");
            return;
        }

        try {
            $this->pdo->beginTransaction();

            $stmt = $this->pdo->prepare("
                INSERT INTO support_tickets (user_id, subject, status, created_at, updated_at, last_message_at)
                VALUES (:user_id, :subject, 'open', NOW(), NOW(), NOW())
            ");
            $stmt->execute([
                ':user_id' => $this->userId,
                ':subject' => $subject,
            ]);
            $ticketId = (int)$this->pdo->lastInsertId();

            $msgStmt = $this->pdo->prepare("
                INSERT INTO support_messages (ticket_id, user_id, is_admin, message, created_at)
                VALUES (:ticket_id, :user_id, 0, :message, NOW())
            ");
            $msgStmt->execute([
                ':ticket_id' => $ticketId,
                ':user_id'   => $this->userId,
                ':message'   => $message,
            ]);

            $this->pdo->commit();
            wallet_set_flash('success', "Destek talebiniz oluşturuldu. En kısa sürede dönüş yapılacaktır.");
        } catch (Exception $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            wallet_set_flash('error', "Destek talebi oluşturulamadı: " . $e->getMessage());
        }
    }

    public function replyTicket(array $post): void
    {
        $ticketId = (int)($post['ticket_id'] ?? 0);
        $message  = trim($post['reply_message'] ?? '');

        if ($ticketId <= 0 || $message === '') {
            wallet_set_flash('error', "Geçersiz talep veya boş mesaj.");
            return;
        }

        try {
            $this->pdo->beginTransaction();

            $check = $this->pdo->prepare("SELECT id, status FROM support_tickets WHERE id = ? AND user_id = ?");
            $check->execute([$ticketId, $this->userId]);
            $ticket = $check->fetch(PDO::FETCH_ASSOC);

            if (!$ticket) {
                throw new Exception("Destek talebi bulunamadı.");
            }
            if ($ticket['status'] === 'closed') {
                throw new Exception("Bu destek talebi kapatılmış. Yeni mesaj ekleyemezsiniz.");
            }

            $msgStmt = $this->pdo->prepare("
                INSERT INTO support_messages (ticket_id, user_id, is_admin, message, created_at)
                VALUES (:ticket_id, :user_id, 0, :message, NOW())
            ");
            $msgStmt->execute([
                ':ticket_id' => $ticketId,
                ':user_id'   => $this->userId,
                ':message'   => $message,
            ]);

            $upd = $this->pdo->prepare("
                UPDATE support_tickets
                SET status = 'open',
                    last_message_at = NOW(),
                    updated_at = NOW()
                WHERE id = :id
            ");
            $upd->execute([':id' => $ticketId]);

            $this->pdo->commit();
            wallet_set_flash('success', "Mesajınız gönderildi.");
        } catch (Exception $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            wallet_set_flash('error', "Mesaj gönderilemedi: " . $e->getMessage());
        }
    }
}
