<?php

class WithdrawService
{
    private PDO $pdo;
    private int $userId;

    public function __construct(PDO $pdo, int $userId)
    {
        $this->pdo    = $pdo;
        $this->userId = $userId;
    }

    public function createWithdraw(array $post, float $rateUsdt): void
    {
        $amountTry = (float)($post['withdraw_amount_try'] ?? 0);
        $bankAccId = (int)($post['withdraw_bank_account_id'] ?? 0);
        $note      = trim($post['withdraw_note'] ?? '');

        try {
            if ($amountTry <= 0) {
                throw new Exception("Geçerli bir tutar girin.");
            }
            if ($bankAccId <= 0) {
                throw new Exception("Lütfen banka hesabı seçin.");
            }

            $ba = $this->pdo->prepare("
                SELECT bank_name, iban, account_holder
                FROM user_bank_accounts
                WHERE id = ? AND user_id = ?
                LIMIT 1
            ");
            $ba->execute([$bankAccId, $this->userId]);
            $bank = $ba->fetch(PDO::FETCH_ASSOC);

            if (!$bank) {
                throw new Exception("Seçilen banka hesabı bulunamadı.");
            }

            $withdrawCoin = 'USDT';
            $coinRateTry  = $rateUsdt;

            if (!$coinRateTry || $coinRateTry <= 0) {
                throw new Exception("Kur bilgisi alınamadı. Lütfen daha sonra tekrar deneyin.");
            }

            $coinToDeduct = round($amountTry / $coinRateTry, 6);

            $this->pdo->beginTransaction();

            $balStmt = $this->pdo->prepare("
                SELECT id, balance
                FROM wallets
                WHERE user_id = :uid
                  AND coin_type = :coin
                FOR UPDATE
            ");
            $balStmt->execute([
                ':uid'  => $this->userId,
                ':coin' => $withdrawCoin,
            ]);
            $walletRow = $balStmt->fetch(PDO::FETCH_ASSOC);

            if (!$walletRow) {
                throw new Exception("Cüzdan bulunamadı. Lütfen destek ile iletişime geçin.");
            }

            $walletId      = (int)$walletRow['id'];
            $walletBalance = (float)$walletRow['balance'];

            if ($walletBalance + 0.000001 < $coinToDeduct) {
                throw new Exception("Yetersiz cüzdan bakiyesi. Mevcut: {$walletBalance} {$withdrawCoin}");
            }

            $deduct = $this->pdo->prepare("
                UPDATE wallets
                SET balance = balance - :coin_amount
                WHERE id = :wid
                  AND user_id = :uid
                  AND coin_type = :coin
                  AND balance >= :coin_amount
            ");
            $deduct->execute([
                ':coin_amount' => $coinToDeduct,
                ':wid'         => $walletId,
                ':uid'         => $this->userId,
                ':coin'        => $withdrawCoin,
            ]);

            if ($deduct->rowCount() === 0) {
                throw new Exception("İşlem sırasında bakiye değişti veya yetersiz hale geldi. Lütfen tekrar deneyin.");
            }

            $wr = $this->pdo->prepare("
                INSERT INTO withdraw_requests
                (user_id, amount, coin_type, method, user_bank_name, user_iban, user_full_name, status, note, created_at)
                VALUES (?, ?, ?, 'bank', ?, ?, ?, 'pending', ?, NOW())
            ");
            $wr->execute([
                $this->userId,
                $coinToDeduct,
                $withdrawCoin,
                $bank['bank_name'],
                $bank['iban'],
                $bank['account_holder'],
                $note
            ]);
            $withdrawRequestId = (int)$this->pdo->lastInsertId();

            $agentStmt = $this->pdo->prepare("
                SELECT 
                    a.id, a.current_cash
                FROM deposit_agents a
                WHERE a.is_active = 1
                  AND a.current_cash >= :amt
                ORDER BY a.current_cash DESC
                LIMIT 1
            ");
            $agentStmt->execute([':amt' => $amountTry]);
            $agent = $agentStmt->fetch(PDO::FETCH_ASSOC);

            $overflowCreated = false;

            if ($agent) {
                $agentId = (int)$agent['id'];

                $updAgent = $this->pdo->prepare("
                    UPDATE deposit_agents
                    SET current_cash = current_cash - ?
                    WHERE id = ?
                ");
                $updAgent->execute([$amountTry, $agentId]);

                $aw = $this->pdo->prepare("
                    INSERT INTO agent_withdraw_orders
                    (agent_id, user_id, amount, to_bank_name, to_iban, to_full_name, status, created_at, withdraw_request_id)
                    VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW(), ?)
                ");
                $aw->execute([
                    $agentId,
                    $this->userId,
                    $amountTry,
                    $bank['bank_name'],
                    $bank['iban'],
                    $bank['account_holder'],
                    $withdrawRequestId
                ]);
            } else {
                $ov = $this->pdo->prepare("
                    INSERT INTO agent_withdraw_overflow
                    (withdraw_request_id, user_id, amount_try, coin_amount, coin_type, 
                     to_bank_name, to_iban, to_full_name, status, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'waiting', NOW())
                ");
                $ov->execute([
                    $withdrawRequestId,
                    $this->userId,
                    $amountTry,
                    $coinToDeduct,
                    $withdrawCoin,
                    $bank['bank_name'],
                    $bank['iban'],
                    $bank['account_holder']
                ]);

                $overflowCreated = true;
            }

            $this->pdo->commit();

            wallet_set_flash('success', "₺" . number_format($amountTry, 2, ',', '.') . " çekim talebiniz oluşturuldu.");

            if ($overflowCreated) {
                $msg = "AGENT KASALARI YETERSİZ, BEKLEYEN ÇEKİM VAR\n"
                     . "Kullanıcı ID: {$this->userId}\n"
                     . "Tutar: ₺" . number_format($amountTry, 2, ',', '.');

                $this->notifyTelegramOverflow($msg);
            }
        } catch (Exception $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            wallet_set_flash('error', $e->getMessage());
        }
    }

    private function notifyTelegramOverflow(string $message): void
    {
        $botToken = '8578330928:AAHtvldJx_NRnZrE-qrqKa9asts6rplgUDM';
        $chatId   = '7054375811';

        $url  = "https://api.telegram.org/bot{$botToken}/sendMessage";
        $data = [
            'chat_id'    => $chatId,
            'text'       => $message,
            'parse_mode' => 'HTML',
        ];

        if (function_exists('curl_init')) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_exec($ch);
            curl_close($ch);
        } else {
            $query = http_build_query($data);
            @file_get_contents($url . '?' . $query);
        }
    }
}
