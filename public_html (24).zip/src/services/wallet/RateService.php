<?php

class RateService
{
    private PDO $pdo;
    private array $config;

    public function __construct(PDO $pdo, array $config)
    {
        $this->pdo    = $pdo;
        $this->config = $config;
    }

    public function getUsdtRate(): float
    {
        $rate = (float)($this->config['default_usdt_rate'] ?? 42.0);

        $stmt = $this->pdo->prepare("
            SELECT setting_value 
            FROM settings 
            WHERE setting_key = 'usdt_try_rate'
            LIMIT 1
        ");
        $stmt->execute();
        $rateVal = $stmt->fetchColumn();

        if ($rateVal !== false && (float)$rateVal > 0) {
            $rate = (float)$rateVal;
        }

        return $rate;
    }
}
