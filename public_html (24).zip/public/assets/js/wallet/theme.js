// Tema yönetimi
const THEME_STORAGE_KEY = 'betwallet-theme';

function applyTheme(theme) {
    const body = document.body;
    if (theme === 'dark') {
        body.setAttribute('data-theme', 'dark');
    } else {
        body.removeAttribute('data-theme');
        theme = 'light';
    }

    try {
        localStorage.setItem(THEME_STORAGE_KEY, theme);
    } catch (e) {
        // localStorage yoksa sessiz geç
    }
}

function initThemeFromStorage() {
    let theme = 'light';

    try {
        const stored = localStorage.getItem(THEME_STORAGE_KEY);
        if (stored === 'dark' || stored === 'light') {
            theme = stored;
        } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            theme = 'dark';
        }
    } catch (e) {
        // default light
    }

    applyTheme(theme);
}

function toggleTheme() {
    const isDark = document.body.getAttribute('data-theme') === 'dark';
    applyTheme(isDark ? 'light' : 'dark');
}

window.toggleTheme = toggleTheme;
