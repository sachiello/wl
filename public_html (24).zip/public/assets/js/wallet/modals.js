// Genel modal yardımcıları
function openModal(modalId) {
    document.querySelectorAll('.bw-modal-backdrop.is-visible').forEach(m => {
        m.classList.remove('is-visible');
    });

    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('is-visible');
    }

    if (typeof DEPOSIT_APP !== 'undefined') {
        if (modalId === 'transfer-modal') {
            DEPOSIT_APP.updateTransferBalanceDisplay();
        }
        if (typeof ACTIVE_DEPOSIT_ID !== 'undefined' && ACTIVE_DEPOSIT_ID > 0) {
            DEPOSIT_APP.startTimer();
        }
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.remove('is-visible');
}

function switchTab(event, tabId) {
    document
        .querySelectorAll('.bw-tab-header .bw-tab-link')
        .forEach(link => link.classList.remove('is-active'));

    if (event && event.currentTarget) {
        event.currentTarget.classList.add('is-active');
    }

    document
        .querySelectorAll('.bw-tab-content')
        .forEach(content => content.classList.remove('is-active'));

    const target = document.getElementById(tabId);
    if (target) target.classList.add('is-active');
}

window.openModal = openModal;
window.closeModal = closeModal;
window.switchTab = switchTab;
