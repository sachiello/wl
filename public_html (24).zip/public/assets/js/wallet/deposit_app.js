// Çekirdek cüzdan/transfer uygulaması (DEPOSIT_APP)
const BW_CONFIG = window.BW_CONFIG || {};

let ACTIVE_DEPOSIT_EXPIRY_TIME_MS = window.ACTIVE_DEPOSIT_EXPIRY_TIME_MS || 0;
let ACTIVE_DEPOSIT_ID             = window.ACTIVE_DEPOSIT_ID || 0;

// USER_BALANCE_USDT: önce window’dan, yoksa BW_CONFIG’ten oku
let USER_BALANCE_USDT = (function () {
    if (typeof window.USER_BALANCE_USDT !== 'undefined') {
        return parseFloat(window.USER_BALANCE_USDT) || 0;
    }
    if (BW_CONFIG.user_balance_usdt !== undefined) {
        return parseFloat(BW_CONFIG.user_balance_usdt) || 0;
    }
    return 0;
})();

const TRANSFER_SUCCESS_DATA = window.TRANSFER_SUCCESS_DATA || null;
const CSRF_TOKEN            = window.CSRF_TOKEN || null;
const STATUS_API_URL        = window.STATUS_API_URL || null;
const POLLING_INTERVAL_MS   = window.POLLING_INTERVAL_MS || 5000;


const DEPOSIT_APP = {
    // --- VERİLER ---
    rates:   BW_CONFIG.rates   || {},
    wallets: BW_CONFIG.wallets || {},
    ibans:   BW_CONFIG.ibans   || [],

    // --- DOM ELEMENTLERİ ---
    modal: null,
    timerDisplay: null,
    timerCardDisplay: null,
    havaleAmountInput: null,
    havaleIbanIdInput: null,
    havaleErrorDiv: null,
    cryptoAmountInput: null,
    cryptoCoinSelect: null,
    cryptoWalletInfo: null,
    cryptoAddressText: null,
    cryptoCalcResult: null,
    transferSiteIdInput: null,
    transferCoinInput: null,
    transferAmountInput: null,
    transferErrorDiv: null,
    connectBox: null,
    demoSiteIdInput: null,
    demoActionInput: null,
    userPanelDropdown: null,
    userPanelTrigger: null,

    // --- ZAMANLAYICILAR ---
    timerInterval: null,
    pollingInterval: null,

    currentTransferCoin: 'USDT',

    // ---------------------------------------------------
    // INIT
    // ---------------------------------------------------
    init: function () {
        // DOM bağlamaları
        this.modal = document.getElementById('deposit-modal');
        this.timerDisplay = document.getElementById('deposit-timer');
        this.timerCardDisplay = document.getElementById('remaining-time-display-card');

        this.havaleAmountInput = document.getElementById('havale-amount-try');
        this.havaleIbanIdInput = document.getElementById('havale-iban-id');
        this.havaleErrorDiv = document.getElementById('havale-error-display');

        this.cryptoAmountInput = document.getElementById('crypto-amount-try');
        this.cryptoCoinSelect = document.getElementById('crypto-coin-select');
        this.cryptoWalletInfo = document.getElementById('crypto-wallet-info');
        this.cryptoAddressText = document.getElementById('crypto-address-text');
        this.cryptoCalcResult = document.getElementById('crypto-calc-result');

        this.transferSiteIdInput = document.getElementById('transfer-site-id');
        this.transferCoinInput = document.getElementById('transfer-coin');
        this.transferAmountInput = document.getElementById('transfer-amount-try');
        this.transferErrorDiv = document.getElementById('transfer-error');

        this.connectBox = document.getElementById('site-connect-box');
        this.demoSiteIdInput = document.getElementById('demo-site-id');
        this.demoActionInput = document.getElementById('demo-action');

        this.userPanelDropdown = document.getElementById('user-panel-dropdown');
        this.userPanelTrigger = document.querySelector('.user-panel-trigger');

        // Form submit: havale / kripto tutarını tek inputa yaz
        const form = document.getElementById('deposit-form');
        const paymentMethodInput = document.getElementById('payment_method_input');
        const amountTryInput = document.getElementById('amount_try_input');

        if (form && paymentMethodInput && amountTryInput) {
            form.addEventListener('submit', (e) => {
                const method = paymentMethodInput.value;
                if (method === 'havale') {
                    amountTryInput.value = form.elements.amount_try_havale.value;
                } else if (method === 'crypto') {
                    amountTryInput.value = form.elements.amount_try_crypto.value;
                }
            });
        }

        // Aktif deposit varsa timer başlat
        if (typeof ACTIVE_DEPOSIT_ID !== 'undefined' && ACTIVE_DEPOSIT_ID > 0) {
            this.startTimer();
        }

        // Başarılı transfer varsa modal göster
        if (typeof TRANSFER_SUCCESS_DATA !== 'undefined' && TRANSFER_SUCCESS_DATA) {
            this.showTransferSuccess();
        }

        // Transfer Modal: dışa tıklayınca resetle
        const transferModal = document.getElementById('transfer-modal');
        if (transferModal) {
            transferModal.addEventListener('click', (e) => {
                if (e.target.id === 'transfer-modal' || e.target.classList.contains('bw-btn-outline')) {
                    this.resetTransferModal();
                }
            });
        }

        // Deposit Modal: ödeme yöntemi kartları
        document
            .querySelectorAll('#deposit-step-1 .deposit-method-card')
            .forEach(card => {
                const method = card.dataset.method;
                if (method && !card.classList.contains('is-disabled')) {
                    card.addEventListener('click', () => this.selectMethod(method));
                }
            });

        // Transfer formu validasyonu (USDT -> TRY)
// Transfer formu: son kontrol
// Transfer formu: son kontrol
const transferForm = document.getElementById('transfer-form');
const self = this; // event listener içinde DEPOSIT_APP’a erişmek için

if (transferForm) {
    transferForm.addEventListener('submit', function (e) {
        const amountEl = document.getElementById('transfer-amount-try');
        const amount   = parseFloat(amountEl?.value) || 0;

        // Kur ve bakiye kaynağı: DEPOSIT_APP.rates + global USER_BALANCE_USDT
        const rates    = self.rates || {};
        const rateUsdt = rates.USDT ? parseFloat(rates.USDT) : 0;
        const userUsdt = parseFloat(USER_BALANCE_USDT) || 0;

        if (amount <= 0) {
            if (self.transferErrorDiv) {
                self.transferErrorDiv.innerText = "Lütfen yüklenecek tutarı girin.";
                self.transferErrorDiv.style.display = 'block';
            }
            e.preventDefault();
            return;
        }

        if (!rateUsdt || rateUsdt <= 0) {
            if (self.transferErrorDiv) {
                self.transferErrorDiv.innerText =
                    "Kur bilgisi alınamadı. Lütfen sayfayı yenileyin.";
                self.transferErrorDiv.style.display = 'block';
            }
            e.preventDefault();
            return;
        }

        const requiredCoin = amount / rateUsdt; // TRY / (TRY/USDT) = USDT

        if (requiredCoin > userUsdt + 0.000001) {
            if (self.transferErrorDiv) {
                self.transferErrorDiv.innerText =
                    `Yetersiz cüzdan bakiyesi. USDT bakiyeniz, ` +
                    `${number_format(requiredCoin, 6, ',', '.')} USDT gereksinimini karşılamıyor.`;
                self.transferErrorDiv.style.display = 'block';
            }
            e.preventDefault();
            return;
        }

        if (self.transferErrorDiv) {
            self.transferErrorDiv.style.display = 'none';
        }
    });
}



        // Site bağlama select
        const connectSelect = document.getElementById('site-connect-select');
        if (connectSelect && typeof this.showConnectForm === 'function') {
            connectSelect.addEventListener('change', this.showConnectForm.bind(this));
        }

        // Kullanıcı paneli: dışarı tıklayınca kapat (DEPOSIT_APP tarafı)
        document.addEventListener('click', (e) => {
            const wrapper = document.getElementById('user-panel-wrapper');
            if (wrapper && !wrapper.contains(e.target)) {
                this.closeUserPanel();
            }
        });
    },

    // ---------------------------------------------------
    // Kullanıcı Paneli (Deposit tarafı)
    // ---------------------------------------------------
    toggleUserPanel: function (triggerElement) {
        if (!this.userPanelDropdown) return;

        if (this.userPanelDropdown.classList.contains('is-active')) {
            this.closeUserPanel();
        } else {
            this.userPanelDropdown.classList.add('is-active');
            if (triggerElement) {
                triggerElement.classList.add('is-active');
            }
        }
    },

    closeUserPanel: function () {
        if (this.userPanelDropdown) this.userPanelDropdown.classList.remove('is-active');
        if (this.userPanelTrigger) this.userPanelTrigger.classList.remove('is-active');
    },

    // ---------------------------------------------------
    // Transfer Başarı Modalı
    // ---------------------------------------------------
    showTransferSuccess: function () {
        openModal('transfer-modal');

        const titleEl = document.getElementById('transfer-modal-title');
        const msgEl = document.getElementById('transfer-success-message');
        const goToSiteBtn = document.getElementById('go-to-site-button');

        if (titleEl) titleEl.innerText = "Transfer Sonucu";
        if (msgEl) msgEl.innerText = TRANSFER_SUCCESS_DATA.message || '';

        if (goToSiteBtn) {
            if (TRANSFER_SUCCESS_DATA.redirect_url) {
                goToSiteBtn.href = TRANSFER_SUCCESS_DATA.redirect_url;
                goToSiteBtn.style.display = 'block';
            } else {
                goToSiteBtn.style.display = 'none';
            }
        }

        this.switchTransferStep('success');
    },

    switchTransferStep: function (step) {
        document
            .querySelectorAll('#transfer-modal .deposit-step')
            .forEach(el => el.classList.remove('is-active'));

        const target = document.getElementById(`transfer-step-${step}`);
        if (target) target.classList.add('is-active');
    },

    // ---------------------------------------------------
    // Ödeme Yöntemi Seçimi
    // ---------------------------------------------------
    selectMethod: function (method) {
        const paymentMethodInput = document.getElementById('payment_method_input');
        if (!paymentMethodInput) return;

        paymentMethodInput.value = method;
        if (method === 'havale') {
            this.switchStep('havale-1', 'Havale/EFT ile Yatır');
        } else if (method === 'crypto') {
            this.updateCryptoCalculation();
            this.switchStep('crypto', 'Kripto ile Yatır');
        } else if (method === 'cc') {
            alert('Kredi Kartı yöntemi şu anda bakımda.');
        }
    },

    // Site Bağlan Modalında Geri Dönüş
    backToSiteSelect: function () {
        const selectStage = document.getElementById('site-select-stage');
        const connectStage = document.getElementById('site-connect-stage');
        const namePlaceholder = document.querySelector('.app-site-name-placeholder');

        if (selectStage) selectStage.style.display = 'block';
        if (connectStage) connectStage.style.display = 'none';
        if (namePlaceholder) namePlaceholder.innerText = '';

        document
            .querySelectorAll('.site-select-item.selected')
            .forEach(el => el.classList.remove('selected'));

        if (this.connectBox) this.connectBox.style.display = 'none';
    },

    // Kullanıcı Panelinden Yatırım Modalını Açma
    openDepositModal: function () {
        openModal('deposit-modal');
        this.switchStep('1', 'Para Yatır');
    },

    // Kullanıcı Panelinden Çekim Modalını Açma
    openWithdrawModal: function () {
        openModal('withdraw-modal');
    },

    // ---------------------------------------------------
    // Transfer Coin Seçimi / Modal
    // ---------------------------------------------------
    selectTransferCoin: function (buttonElement, coin) {
        this.currentTransferCoin = coin;
        const transferCoinInput = document.getElementById('transfer-coin');
        if (transferCoinInput) transferCoinInput.value = coin;

        document
            .querySelectorAll('.transfer-coin-options button')
            .forEach(btn => btn.classList.remove('selected'));

        if (buttonElement) buttonElement.classList.add('selected');

        this.updateTransferBalanceDisplay();
    },

    startTransfer: function (siteId, siteName) {
        if (this.transferSiteIdInput) this.transferSiteIdInput.value = siteId;

        const titleEl = document.getElementById('transfer-modal-title');
        if (titleEl) titleEl.innerText = siteName + " Para Yatır";

        this.resetTransferModal();
        this.switchTransferStep('1');
        openModal('transfer-modal');
    },

    resetTransferModal: function () {
        const form = document.getElementById('transfer-form');
        if (form) form.reset();
        if (this.transferErrorDiv) this.transferErrorDiv.style.display = 'none';

        const defaultButton = document.querySelector('.transfer-coin-options button[data-coin="USDT"]');
        if (defaultButton) {
            this.selectTransferCoin(defaultButton, 'USDT');
        } else {
            this.currentTransferCoin = '';
            const transferCoinInput = document.getElementById('transfer-coin');
            if (transferCoinInput) transferCoinInput.value = '';
        }

        this.updateTransferBalanceDisplay();
    },

    // Cüzdan bakiyesi gösterimi (Transfer modalı)
    updateTransferBalanceDisplay: function () {
        let balance = 0;
        if (this.currentTransferCoin === 'USDT') {
            balance = USER_BALANCE_USDT;
        }

        const rate = this.rates[this.currentTransferCoin] || 1;
        const tryValue = number_format(balance * rate, 2, ',', '.');

        const el = document.getElementById('current-wallet-balance');
        if (el) {
            el.innerText =
                `${number_format(balance, 6, ',', '.')} ${this.currentTransferCoin} (≈ ₺${tryValue})`;
        }
    },

    // TÜM EKRANDAKİ BAKİYELERİ GÜNCELLE
// TÜM EKRANDAKİ BAKİYELERİ GÜNCELLE
updateAllBalances: function () {
    // 1) Varlıklar sekmesindeki USDT kartı
    const usdtCryptoEl = document.querySelector('.bw-asset-item[data-coin="USDT"] .balance .crypto');
    const usdtFiatEl   = document.querySelector('.bw-asset-item[data-coin="USDT"] .balance .fiat');

    if (usdtCryptoEl && usdtFiatEl) {
        const rates   = this.rates || {};
        const rateUsdtLocal = rates.USDT ? parseFloat(rates.USDT) : 0;
        const usdtAmount    = parseFloat(USER_BALANCE_USDT) || 0;

        usdtCryptoEl.innerText = number_format(usdtAmount, 6, ',', '.');
        usdtFiatEl.innerText   = '₺' + number_format(usdtAmount * rateUsdtLocal, 2, ',', '.');
    }

    // 3) Transfer modalındaki bakiye
    this.updateTransferBalanceDisplay();
},



    // ---------------------------------------------------
    // Sitelerim (Site seçimi / bağlama)
    // ---------------------------------------------------
    selectSite: function (element, siteId, siteName) {

        document
            .querySelectorAll('.site-select-item')
            .forEach(el => el.classList.remove('selected'));

        if (element) element.classList.add('selected');

        const listContainer = document.getElementById('site-list-container');
        if (listContainer) listContainer.style.display = 'none';

        const searchInput = document.getElementById('site-search-input');
        if (searchInput) searchInput.style.display = 'none';

        if (this.connectBox) this.connectBox.style.display = 'block';

        const backBtn = document.getElementById('sc-back-btn');
        if (backBtn) backBtn.style.display = 'flex';

        const nameEl = document.getElementById('connect-site-name');
        if (nameEl) nameEl.innerText = siteName;

        if (this.demoSiteIdInput) this.demoSiteIdInput.value = siteId;

        const initial = siteName.charAt(0).toUpperCase();
        const logoInitial = document.getElementById('connect-site-logo-initial');
        if (logoInitial) logoInitial.innerText = initial;

        const connectForm = document.getElementById('site-connect-form');
        if (connectForm) connectForm.reset();
    },

    goBackToSiteList: function () {

        const listContainer = document.getElementById('site-list-container');
        if (listContainer) listContainer.style.display = 'block';

        const searchInput = document.getElementById('site-search-input');
        if (searchInput) searchInput.style.display = 'block';

        if (this.connectBox) this.connectBox.style.display = 'none';

        const backBtn = document.getElementById('sc-back-btn');
        if (backBtn) backBtn.style.display = 'none';

        document
            .querySelectorAll('.site-select-item')
            .forEach(el => el.classList.remove('selected'));
    },

    filterSites: function (searchTerm) {
        const term = (searchTerm || '').toLowerCase();
        document
            .querySelectorAll('.site-select-item')
            .forEach(item => {
                const name = (item.dataset.siteName || '').toLowerCase();
                item.style.display = name.includes(term) ? 'flex' : 'none';
            });

        if (this.connectBox) this.connectBox.style.display = 'none';
    },

    submitConnectForm: function (action) {
        if (this.demoActionInput) this.demoActionInput.value = action;
        const form = document.getElementById('site-connect-form');

        const userEl = document.getElementById('demo-username');
        const passEl = document.getElementById('demo-password');

        if (!userEl?.value || !passEl?.value) {
            alert('Lütfen kullanıcı adı ve şifre girin.');
            return;
        }

        if (form) form.submit();
    },

    selectBankAccount(elem, id) {
        document.querySelectorAll('.bank-account-item').forEach(item => {
            item.classList.remove('selected');
        });

        elem.classList.add('selected');

        const hidden = document.getElementById('withdraw-bank-account-id');
        if (hidden) {
            hidden.value = id;
        }
    },

    // ---------------------------------------------------
    // Deposit Step / Geri Butonu
    // ---------------------------------------------------
    switchStep: function (step, title) {
        document
            .querySelectorAll('.deposit-step')
            .forEach(el => el.classList.remove('is-active'));

        const target = document.getElementById(`deposit-step-${step}`);
        if (target) target.classList.add('is-active');

        const modalTitle = document.getElementById('deposit-modal-title');
        if (modalTitle) modalTitle.innerText = title || 'Para Yatır';

        const backBtn = document.getElementById('deposit-back-btn');
        if (backBtn) backBtn.style.display = (step !== '1') ? 'block' : 'none';
    },

    goBack: function () {
        const current = document.querySelector('.deposit-step.is-active');
        if (!current) {
            this.switchStep('1', 'Para Yatır');
            return;
        }

        const id = current.id;
        if (id === 'deposit-step-havale-1') {
            this.switchStep('1', 'Para Yatır');
        } else if (id === 'deposit-step-havale-2') {
            this.switchStep('havale-1', 'Havale/EFT ile Yatır');
        } else if (id === 'deposit-step-crypto') {
            this.switchStep('1', 'Para Yatır');
        } else {
            this.switchStep('1', 'Para Yatır');
        }
    },

    // ---------------------------------------------------
    // HAVALE KONTROL (IBAN seçimi)
    // ---------------------------------------------------
    checkHavaleAmount: function () {
        console.log("--- HAVALE KONTROL BAŞLADI ---");

        const amountTRY = parseFloat(this.havaleAmountInput?.value) || 0;
        console.log("Girilen Tutar (TRY):", amountTRY);

        if (this.havaleErrorDiv) {
            this.havaleErrorDiv.style.display = 'none';
            this.havaleErrorDiv.innerText = '';
        }

        if (amountTRY <= 0) {
            if (this.havaleErrorDiv) {
                this.havaleErrorDiv.innerText = 'Lütfen geçerli bir tutar girin.';
                this.havaleErrorDiv.style.display = 'block';
            }
            return;
        }

        if (!this.ibans || !Array.isArray(this.ibans) || this.ibans.length === 0) {
            console.error("HATA: JS tarafına IBAN listesi gelmemiş (BW_CONFIG.ibans boş).");
            if (this.havaleErrorDiv) {
                this.havaleErrorDiv.innerText = 'Şu anda aktif banka hesabı bulunamadı.';
                this.havaleErrorDiv.style.display = 'block';
            }
            return;
        }

        console.log("Toplam IBAN Sayısı:", this.ibans.length);

        let candidates = this.ibans.filter((iban) => {
            const active = parseInt(iban.is_active, 10) || 0;
            const minLimit = parseFloat(iban.min_deposit_limit) || 0;
            const maxLimit = parseFloat(iban.max_deposit_limit) || 0;
            const currentDailyTxn = parseInt(iban.current_daily_txn, 10) || 0;
            const maxDailyTxn = parseInt(iban.max_daily_txn, 10) || 0;

            const agentId = (iban.agent_id === null || iban.agent_id === undefined)
                ? null
                : parseInt(iban.agent_id, 10);

            let agentBalance = 0;
            if (iban.agent_system_balance !== undefined && iban.agent_system_balance !== null) {
                agentBalance = parseFloat(iban.agent_system_balance) || 0;
            } else if (iban.agent_balance !== undefined && iban.agent_balance !== null) {
                agentBalance = parseFloat(iban.agent_balance) || 0;
            }

            let agentIsActive = 1;
            if (iban.agent_is_active !== undefined && iban.agent_is_active !== null) {
                agentIsActive = parseInt(iban.agent_is_active, 10) || 0;
            }

            console.group(`IBAN ID ${iban.id} kontrolü`);
            console.log("active:", active);
            console.log("limit aralığı:", minLimit, "-", maxLimit);
            console.log("current_daily_txn / max_daily_txn:", currentDailyTxn, "/", maxDailyTxn);
            console.log("agent_id:", agentId, "agent_is_active:", agentIsActive, "agentBalance(system):", agentBalance);

            if (active !== 1) {
                console.log("→ RED: Pasif IBAN");
                console.groupEnd();
                return false;
            }

            if (amountTRY < minLimit || amountTRY > maxLimit) {
                console.log("→ RED: Tutar min/max aralığında değil");
                console.groupEnd();
                return false;
            }

            if (currentDailyTxn >= maxDailyTxn) {
                console.log("→ RED: Günlük işlem limiti dolmuş");
                console.groupEnd();
                return false;
            }

            if (agentId !== null) {
                if (agentIsActive !== 1) {
                    console.log("→ RED: Agent aktif değil");
                    console.groupEnd();
                    return false;
                }
                if (agentBalance < amountTRY) {
                    console.log("→ RED: Agent teminatı tutarı karşılamıyor");
                    console.groupEnd();
                    return false;
                }
            }

            console.log("→ KABUL: Bu IBAN aday listesine eklendi");
            console.groupEnd();
            return true;
        });

        console.log("Uygun IBAN aday sayısı:", candidates.length);

        if (candidates.length === 0) {
            if (this.havaleErrorDiv) {
                this.havaleErrorDiv.innerText =
                    'Şu anda bu tutar (' + number_format(amountTRY, 2, ',', '.') +
                    ' TL) için uygun bir havale kanalı bulunmamaktadır. Lütfen tutarı değiştirin.';
                this.havaleErrorDiv.style.display = 'block';
            }
            return;
        }

        candidates.sort((a, b) => {
            const remA = (parseFloat(a.quota_limit) || 0) - (parseFloat(a.quota_used) || 0);
            const remB = (parseFloat(b.quota_limit) || 0) - (parseFloat(b.quota_used) || 0);

            if (remA === remB) {
                const idA = parseInt(a.id, 10) || 0;
                const idB = parseInt(b.id, 10) || 0;
                return idA - idB;
            }
            return remB - remA;
        });

        const selectedIban = candidates[0];
        console.log("Seçilen IBAN (JS):", selectedIban);

        if (this.havaleIbanIdInput) {
            this.havaleIbanIdInput.value = selectedIban.id;
        }

        const ibanDisplay = document.getElementById('havale-iban-display');
        const holderDisplay = document.getElementById('havale-holder-display');
        const bankDisplay = document.getElementById('havale-bank-display');

        if (ibanDisplay) ibanDisplay.innerText = selectedIban.iban || '';
        if (holderDisplay) holderDisplay.innerText = selectedIban.holder_name || '';
        if (bankDisplay) bankDisplay.innerText = selectedIban.bank_name || '';

        this.switchStep('havale-2', 'Havale Bilgileri');
    },

    // ---------------------------------------------------
    // Polling: Anlık Durum Çekme
    // ---------------------------------------------------
   // ---------------------------------------------------
// Polling: Anlık Durum Çekme
// ---------------------------------------------------
startPolling: function () {
    if (this.pollingInterval) clearInterval(this.pollingInterval);

    const STATUS_URL  = window.STATUS_API_URL || '';
    const CSRF        = window.CSRF_TOKEN || '';
    const INTERVAL_MS = window.POLLING_INTERVAL_MS || 5000;

    const fetchData = async () => {
        if (!STATUS_URL || !CSRF) {
            console.error("Polling başlatılamadı: STATUS_API_URL veya CSRF_TOKEN eksik.", {
                STATUS_URL,
                CSRF
            });
            return;
        }

        try {
            const response = await fetch(
                `${STATUS_URL}?csrf_token=${encodeURIComponent(CSRF)}`,
                {
                    method: 'GET',
                    headers: { 'Accept': 'application/json' }
                }
            );

            if (response.status === 403 || response.status === 401) {
                console.error("Polling Hata: Oturum veya CSRF doğrulama başarısız. Sayfa yenileniyor...");
                clearInterval(this.pollingInterval);
                window.location.reload();
                return;
            }

            if (!response.ok) {
                throw new Error(`HTTP Hata! Durum: ${response.status}`);
            }

            const jsonResponse = await response.json();

            if (!jsonResponse || jsonResponse.status !== 'success' || !jsonResponse.data) {
                console.error("API Hata: Geçersiz veya hatalı API cevap formatı:", jsonResponse);
                return;
            }

            const data = jsonResponse.data;

            // DEBUG istersen geçici olarak açıp bakabilirsin
            // console.log('[STATUS RAW]', jsonResponse);
            // console.log('[STATUS DATA balance]', data.user_balance_usdt);

            const newActiveDepositId = parseInt(data.active_deposit_id, 10) || 0;
            const newExpiryTime      = parseInt(
                data.active_deposit_expiry_time_ms,
                10
            ) || 0;

            USER_BALANCE_USDT = parseFloat(data.user_balance_usdt) || 0;

            // Tüm ekrandaki bakiyeleri güncelle
            this.updateAllBalances();

            const depositCard = document.getElementById('active-deposit-card');

            if (newActiveDepositId > 0) {
                const depositChanged =
                    (newActiveDepositId !== ACTIVE_DEPOSIT_ID) ||
                    (newExpiryTime !== ACTIVE_DEPOSIT_EXPIRY_TIME_MS);

                if (depositChanged) {
                    ACTIVE_DEPOSIT_ID             = newActiveDepositId;
                    ACTIVE_DEPOSIT_EXPIRY_TIME_MS = newExpiryTime;

                    if (!depositCard) {
                        window.location.reload();
                        return;
                    }

                    this.startTimer();
                }
            } else if (ACTIVE_DEPOSIT_ID > 0) {
                ACTIVE_DEPOSIT_ID             = 0;
                ACTIVE_DEPOSIT_EXPIRY_TIME_MS = 0;

                if (this.timerInterval) {
                    clearInterval(this.timerInterval);
                }

                if (depositCard) {
                    window.location.reload();
                }
            }

        } catch (error) {
            console.error("Anlık durum çekilirken genel hata/network hatası:", error);
        }
    };

    fetchData();
    this.pollingInterval = setInterval(fetchData, INTERVAL_MS);
    console.log(`Polling başlatıldı: ${INTERVAL_MS / 1000} saniyede bir veri çekilecek.`);
},

    // ---------------------------------------------------
    // Kripto Hesaplama
    // ---------------------------------------------------
    updateCryptoCalculation: function () {
        const amountTRY = parseFloat(this.cryptoAmountInput?.value) || 0;
        const selectedCoin = this.cryptoCoinSelect?.value;
        const rate = this.rates[selectedCoin] || 0;
        const wallet = this.wallets[selectedCoin] || null;
        const errorDiv = document.getElementById('crypto-error');

        if (wallet) {
            if (this.cryptoWalletInfo) this.cryptoWalletInfo.style.display = 'block';
            if (errorDiv) errorDiv.style.display = 'none';

            if (this.cryptoAddressText) {
                this.cryptoAddressText.innerText = wallet.address;
            }

            if (amountTRY > 0 && rate > 0) {
                const amountCrypto = (amountTRY / rate).toFixed(6);
                if (this.cryptoCalcResult) {
                    this.cryptoCalcResult.innerHTML =
                        `Yaklaşık <strong>${amountCrypto} ${selectedCoin}</strong> göndermelisiniz.`;
                }
            } else if (this.cryptoCalcResult) {
                this.cryptoCalcResult.innerText = 'Lütfen geçerli bir TL tutarı girin.';
            }
        } else {
            if (this.cryptoWalletInfo) this.cryptoWalletInfo.style.display = 'none';
            if (errorDiv) {
                errorDiv.style.display = 'block';
                errorDiv.innerText = 'Bu coin için aktif cüzdan bulunamadı.';
            }
        }
    },

    // ---------------------------------------------------
    // Timer (Aktif Deposit Geri Sayım)
    // ---------------------------------------------------
    startTimer: function () {
        if (this.timerInterval) clearInterval(this.timerInterval);

        const updateTimer = () => {
            const now = Date.now();
            const distance = ACTIVE_DEPOSIT_EXPIRY_TIME_MS - now;

            if (distance < 0) {
                if (this.timerDisplay) this.timerDisplay.innerText = "Süre Doldu";
                if (this.timerCardDisplay) this.timerCardDisplay.innerText = "SÜRE DOLDU";

                this.timerDisplay?.classList.add('is-urgent');
                this.timerCardDisplay?.classList.add('is-urgent');

                clearInterval(this.timerInterval);
                setTimeout(() => { window.location.reload(); }, 1000);
                return;
            }

            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);

            const displayTime =
                `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

            if (this.timerDisplay) this.timerDisplay.innerText = displayTime;
            if (this.timerCardDisplay) this.timerCardDisplay.innerText = displayTime;

            if (minutes === 0) {
                this.timerDisplay?.classList.add('is-urgent');
                this.timerCardDisplay?.classList.add('is-urgent');
            }
        };

        this.timerInterval = setInterval(updateTimer, 1000);
        updateTimer();
    },

    // ---------------------------------------------------
    // Kopyalama
    // ---------------------------------------------------
    copyToClipboard: function (buttonElement, target) {
        let element = null;
        const originalText = 'Kopyala';

        if (target === 'card-iban') {
            element = document.getElementById('card-iban-display');
        } else if (target === 'card-holder') {
            element = document.getElementById('card-holder-display');
        } else if (target === 'card-crypto') {
            element = document.getElementById('card-crypto-display');
        } else if (target === 'iban') {
            element = document.getElementById('havale-iban-display');
        } else if (target === 'holder') {
            element = document.getElementById('havale-holder-display');
        } else if (target === 'active-iban') {
            element = document.getElementById('active-iban-text');
        } else if (target === 'crypto') {
            element = this.cryptoAddressText || document.getElementById('crypto-address-display');
        }

        const originalButton = buttonElement;
        let textToCopy = '';

        const attrText = originalButton.getAttribute('data-copy-text');
        if (attrText && attrText.trim() !== '') {
            textToCopy = attrText.trim();
        } else if (element) {
            if (typeof element.innerText !== 'undefined') {
                textToCopy = (element.innerText || '').trim();
            } else if (typeof element.textContent !== 'undefined') {
                textToCopy = (element.textContent || '').trim();
            } else if (typeof element.value !== 'undefined') {
                textToCopy = (element.value || '').trim();
            }
        }

        if (!textToCopy) {
            alert('Kopyalanacak bir içerik bulunamadı.');
            return;
        }

        if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
            navigator.clipboard.writeText(textToCopy).then(function () {
                originalButton.innerText = 'Kopyalandı!';
                const oldBg = originalButton.style.backgroundColor;
                originalButton.setAttribute('data-old-bg', oldBg || '');
                originalButton.style.backgroundColor = '#10b981';

                setTimeout(function () {
                    originalButton.innerText = originalText;
                    const savedBg = originalButton.getAttribute('data-old-bg');
                    if (savedBg !== null) {
                        originalButton.style.backgroundColor = savedBg;
                    } else {
                        originalButton.style.backgroundColor = '';
                    }
                }, 1500);
            }).catch(function () {
                alert('Kopyalama başarısız.');
            });
        } else {
            alert('Kopyalama özelliği tarayıcınızda desteklenmiyor.');
        }
    }
};
