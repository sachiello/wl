// Giriş noktası: modüler dosyaları başlatır
document.addEventListener('DOMContentLoaded', () => {
    if (typeof initThemeFromStorage === 'function') {
        initThemeFromStorage();
    }

    if (window.DEPOSIT_APP) {
        DEPOSIT_APP.init();
        DEPOSIT_APP.startPolling();
    }

    // Modal helper'ları globalde tut
    window.openModal = openModal;
    window.closeModal = closeModal;
    window.switchTab = switchTab;

    // Wallet target dropdown davranışı
    document
        .querySelectorAll('.bw-wallet-target-select')
        .forEach(select => {
            const selected = select.querySelector('.bw-wallet-target-selected');
            if (!selected) return;

            selected.addEventListener('click', (e) => {
                e.stopPropagation();
                const isOpen = select.classList.contains('is-open');

                document
                    .querySelectorAll('.bw-wallet-target-select.is-open')
                    .forEach(el => el.classList.remove('is-open'));

                if (!isOpen) {
                    select.classList.add('is-open');
                }
            });
        });

    if (window.USER_PANEL) {
        USER_PANEL.init();
    }
});

// DEPOSIT_APP ile bağla (header’daki onclick bunu çağırıyor)
window.DEPOSIT_APP = window.DEPOSIT_APP || DEPOSIT_APP;
DEPOSIT_APP.toggleUserPanel = function (triggerEl) {
    if (window.USER_PANEL) {
        USER_PANEL.toggleDropdown(triggerEl);
    }
};

// Destek talepleri arasında geçiş (liste -> konuşma)
document.addEventListener('click', function (e) {
    const item = e.target.closest('.support-ticket-item');
    if (!item) return;

    const ticketId = item.getAttribute('data-ticket-id');
    if (!ticketId) return;

    const threadRadio = document.getElementById('sv-thread');
    if (threadRadio) {
        threadRadio.checked = true;
    }

    document.querySelectorAll('.support-thread').forEach(function (el) {
        el.style.display = 'none';
    });

    const activeThread = document.querySelector(
        '.support-thread[data-ticket-id=\"' + ticketId + '\"]'
    );
    if (activeThread) {
        activeThread.style.display = 'block';

        const threadContainer = activeThread.closest('.support-card');
        if (threadContainer) {
            threadContainer.scrollTop = 0;
        }
    }
});
