// Wallet JS konfigürasyon köprüsü
(function () {
    window.BW_CONFIG = window.BW_CONFIG || {};
    const cfg = window.BW_CONFIG;

    window.ACTIVE_DEPOSIT_EXPIRY_TIME_MS =
        typeof window.ACTIVE_DEPOSIT_EXPIRY_TIME_MS !== 'undefined'
            ? window.ACTIVE_DEPOSIT_EXPIRY_TIME_MS
            : Number(cfg.ACTIVE_DEPOSIT_EXPIRY_TIME_MS) || 0;

    window.ACTIVE_DEPOSIT_ID =
        typeof window.ACTIVE_DEPOSIT_ID !== 'undefined'
            ? window.ACTIVE_DEPOSIT_ID
            : Number(cfg.ACTIVE_DEPOSIT_ID) || 0;

    window.USER_BALANCE_USDT =
        typeof window.USER_BALANCE_USDT !== 'undefined'
            ? window.USER_BALANCE_USDT
            : Number(cfg.USER_BALANCE_USDT) || 0;

    window.TRANSFER_SUCCESS_DATA = window.TRANSFER_SUCCESS_DATA || cfg.TRANSFER_SUCCESS_DATA || null;
    window.CSRF_TOKEN            = window.CSRF_TOKEN || cfg.CSRF_TOKEN || null;
    window.STATUS_API_URL        = window.STATUS_API_URL || cfg.STATUS_API_URL || null;
    window.POLLING_INTERVAL_MS   = window.POLLING_INTERVAL_MS || cfg.POLLING_INTERVAL_MS || 5000;

    // Eski kodun kullandığı yardımcı global değişkenler
    if (typeof window.rateUsdt === 'undefined' && cfg.rates && cfg.rates.USDT) {
        window.rateUsdt = cfg.rates.USDT;
    }
    if (typeof window.userUsdt === 'undefined') {
        window.userUsdt = window.USER_BALANCE_USDT;
    }
})();
