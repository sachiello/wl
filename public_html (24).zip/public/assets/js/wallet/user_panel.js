// Kullanıcı paneli ve güvenlik modülleri
window.USER_PANEL = {
    isOpen: false,
    twofaInitCalled: false, // 2FA sekmesi ilk kez açıldığında QR yüklenmesi için

    init() {
        const wrapper  = document.getElementById('user-panel-wrapper');
        const dropdown = document.getElementById('user-panel-dropdown');
        const overlay  = document.getElementById('user-modal-overlay');

        if (!wrapper || !dropdown) return;

        // Dropdown dışı click ile kapatma
        document.addEventListener('click', (e) => {
            if (!wrapper.contains(e.target)) {
                this.closeDropdown();
            }
        });

        // Modal dışına tıklayınca kapat
        if (overlay) {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    this.closeModal();
                }
            });
        }

        // Dropdown içindeki modal butonlarını bağla
        dropdown.querySelectorAll('[data-user-modal]').forEach(btn => {
            btn.addEventListener('click', () => {
                const type = btn.getAttribute('data-user-modal');
                this.openModal(type);
            });
        });
    },

    toggleDropdown(triggerEl) {
        const dropdown = document.getElementById('user-panel-dropdown');
        const trigger  = triggerEl || document.querySelector('.user-panel-trigger');
        if (!dropdown || !trigger) return;

        this.isOpen = !this.isOpen;

        if (this.isOpen) {
            dropdown.classList.add('is-active');
            trigger.classList.add('is-active');
        } else {
            dropdown.classList.remove('is-active');
            trigger.classList.remove('is-active');
        }
    },

    closeDropdown() {
        const dropdown = document.getElementById('user-panel-dropdown');
        const trigger  = document.querySelector('.user-panel-trigger');
        if (!dropdown || !trigger) return;

        this.isOpen = false;
        dropdown.classList.remove('is-active');
        trigger.classList.remove('is-active');
    },

    openModal(type) {
        const overlay = document.getElementById('user-modal-overlay');
        const titleEl = document.getElementById('user-modal-title');
        const bodyEl  = document.getElementById('user-modal-body');

        if (!overlay || !titleEl || !bodyEl) return;

        this.closeDropdown();

        // Başlık
        let title = '';
        switch (type) {
            case 'account':
                title = 'Hesap Özeti';
                break;
            case 'security':
                title = 'Güvenlik Ayarları';
                break;
            default:
                title = 'Bilgilendirme';
                type  = 'account'; // fallback
        }
        titleEl.textContent = title;

        // İçerik göster/gizle: data-modal-type’e göre
        const contents = bodyEl.querySelectorAll('.user-modal-content[data-modal-type]');
        contents.forEach(el => {
            const modalType = el.getAttribute('data-modal-type');
            if (modalType === type) {
                el.classList.add('is-active');
                el.style.display = 'block';
            } else {
                el.classList.remove('is-active');
                el.style.display = 'none';
            }
        });

        overlay.classList.add('is-active');
        document.body.classList.add('modal-open');

        if (type === 'security') {
            this.bindSecurityEvents();

            const cfg          = window.BW_CONFIG || {};
            const twofaEnabled = !!cfg.TWOFA_ENABLED;

            if (!twofaEnabled && !this.twofaInitCalled) {
                this.initTwoFa();
            }
        }
    },

    closeModal() {
        const overlay = document.getElementById('user-modal-overlay');
        if (!overlay) return;
        overlay.classList.remove('is-active');
        document.body.classList.remove('modal-open');

        // Güvenlik modalı kapandığında, tekrar açıldığında QR yeniden hazırlanabilsin
        this.twofaInitCalled = false;
    },

    // -------------------------------
    // SECURITY EVENT BIND / BACKEND
    // -------------------------------
    bindSecurityEvents() {
        const passwordForm = document.getElementById('user-password-form');
        if (passwordForm && !passwordForm._bw_bound) {
            passwordForm._bw_bound = true;
            passwordForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.submitSecurityForm(passwordForm);
            });
        }

        const cfg          = window.BW_CONFIG || {};
        const twofaEnabled = !!cfg.TWOFA_ENABLED;

        const tabButtons = document.querySelectorAll('.user-modal-tab');
        const panels     = document.querySelectorAll('.user-modal-tab-panel');

        tabButtons.forEach(btn => {
            if (btn._bw_bound) return;
            btn._bw_bound = true;

            btn.addEventListener('click', () => {
                const target = btn.getAttribute('data-security-tab');
                if (!target) return;

                // aktif tab butonu
                tabButtons.forEach(b => b.classList.remove('is-active'));
                btn.classList.add('is-active');

                // aktif panel
                panels.forEach(p => {
                    const panelName = p.getAttribute('data-security-panel');
                    if (panelName === target) {
                        p.classList.add('is-active');
                    } else {
                        p.classList.remove('is-active');
                    }
                });

                // Sekme 2FA'ya geçtiyse ve daha önce init edilmediyse yine çalıştır
                if (target === '2fa' && !twofaEnabled && !this.twofaInitCalled) {
                    this.initTwoFa();
                }
            });
        });

        // 2FA kapatma alanı: butona tıklayınca formu göster/gizle
        const btnDisable2fa = document.getElementById('btn-disable-2fa');
        const disableArea   = document.getElementById('twofa-disable-area');
        const disableForm   = document.getElementById('twofa-disable-form');

        if (btnDisable2fa && disableArea && !btnDisable2fa._bw_bound) {
            btnDisable2fa._bw_bound = true;
            btnDisable2fa.addEventListener('click', () => {
                // inline mini "accordion" gibi aç/kapa
                disableArea.classList.toggle('is-hidden');

                if (!disableArea.classList.contains('is-hidden')) {
                    const pwdInput = disableArea.querySelector('input[name="current_password"]');
                    if (pwdInput) {
                        pwdInput.focus();
                    }
                }
            });
        }

        if (disableForm && !disableForm._bw_bound) {
            disableForm._bw_bound = true;
            disableForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.disableTwoFa(disableForm);
            });
        }
    },

    // -------------------------------
    // ALERT HELPER
    // -------------------------------
    showAlert(context, type, message) {
        const id  = (context === 'twofa')
            ? 'twofa-alert-box'
            : 'password-alert-box';

        const box = document.getElementById(id);
        if (!box) return;

        // Eski sınıfları temizle
        box.classList.remove(
            'user-security-alert--hidden',
            'user-security-alert--success',
            'user-security-alert--error',
            'user-security-alert--info'
        );

        // Yeni sınıf ekle
        const variant = type || 'info';
        box.classList.add(`user-security-alert--${variant}`);

        // Mesaj
        box.textContent = message || '';
    },

    clearAlert(context) {
        const id  = (context === 'twofa')
            ? 'twofa-alert-box'
            : 'password-alert-box';

        const box = document.getElementById(id);
        if (!box) return;

        box.classList.add('user-security-alert--hidden');
        box.classList.remove(
            'user-security-alert--success',
            'user-security-alert--error',
            'user-security-alert--info'
        );
        box.textContent = '';
    },

    submitSecurityForm(formEl) {
        const formData = new FormData(formEl);

        // önce eski uyarıyı temizle
        this.clearAlert('password');

        fetch('/src/controllers/user_security.php', {
            method: 'POST',
            body: formData
        })
            .then(res => res.json())
            .then(json => {
                if (json.success) {
                    this.showAlert(
                        'password',
                        'success',
                        json.message || 'Şifreniz başarıyla güncellendi.'
                    );
                    formEl.reset();
                } else {
                    this.showAlert(
                        'password',
                        'error',
                        json.message || 'Şifre güncellenemedi.'
                    );
                }
            })
            .catch(() => {
                this.showAlert(
                    'password',
                    'error',
                    'Şifre değişikliği sırasında bir hata oluştu.'
                );
            });
    },

    initTwoFa() {
        this.twofaInitCalled = true;

        const cfg  = window.BW_CONFIG || {};
        let csrf   = cfg.CSRF_TOKEN || '';

        // BW_CONFIG boşsa form inputlarından dene
        if (!csrf) {
            const csrfInput =
                document.querySelector('#twofa-verify-form input[name="csrf_token"]') ||
                document.querySelector('#user-password-form input[name="csrf_token"]');

            if (csrfInput) {
                csrf = csrfInput.value;
            }
        }

        const area  = document.getElementById('twofa-setup-area');
        if (!area) return;

        const formData = new FormData();
        formData.append('csrf_token', csrf);
        formData.append('action', 'init_2fa');

        this.clearAlert('twofa');

        fetch('/src/controllers/user_security.php', {
            method: 'POST',
            body: formData
        })
            .then(res => res.json())
            .then(json => {
                if (!json.success) {
                    this.twofaInitCalled = false;
                    this.showAlert(
                        'twofa',
                        'error',
                        json.message || '2FA başlatılırken bir hata oluştu.'
                    );
                    return;
                }

                const data = json.data || {};

                const qrImg       = area.querySelector('#twofa-qr-image');
                const secretInput = area.querySelector('#twofa-secret-key');
                const otpInput    = area.querySelector('#twofa-otp-input');
                const verifyForm  = area.querySelector('#twofa-verify-form');

                if (qrImg) {
                    qrImg.src = data.qr_url || '';
                }
                if (secretInput) {
                    secretInput.value = data.secret || '';
                }

                if (verifyForm && otpInput) {
                    // Eski eventleri temizlemek için clone tekniği
                    const newForm = verifyForm.cloneNode(true);
                    verifyForm.parentNode.replaceChild(newForm, verifyForm);

                    newForm.addEventListener('submit', (e) => {
                        e.preventDefault();

                        const code = (otpInput.value || '').replace(/\D/g, '').slice(0, 6);
                        otpInput.value = code;

                        if (code.length !== 6) {
                            this.showAlert(
                                'twofa',
                                'error',
                                'Lütfen 6 haneli kodu eksiksiz girin.'
                            );
                            return;
                        }

                        this.clearAlert('twofa');

                        const submitData = new FormData(newForm);
                        submitData.set('csrf_token', csrf);
                        submitData.set('action', 'verify_enable_2fa');
                        submitData.set('otp_code', code);

                        fetch('/src/controllers/user_security.php', {
                            method: 'POST',
                            body: submitData
                        })
                            .then(r => r.json())
                            .then(j => {
                                if (j.error_code === 'TWOFA_ALREADY_ENABLED') {
                                    this.showAlert(
                                        'twofa',
                                        'info',
                                        j.message || '2FA zaten aktif. Yeni bir kurulum yapmanıza gerek yok.'
                                    );

                                    const statusEl = document.getElementById('twofa-status');
                                    if (statusEl) {
                                        statusEl.innerHTML = '<strong>AKTİF</strong>';
                                        statusEl.classList.remove('is-off');
                                        statusEl.classList.add('is-on');
                                    }

                                    if (window.BW_CONFIG) {
                                        window.BW_CONFIG.TWOFA_ENABLED = true;
                                    }
                                    return;
                                }

                                if (j.success) {
                                    this.showAlert(
                                        'twofa',
                                        'success',
                                        j.message || '2FA başarıyla aktifleştirildi.'
                                    );
                                    setTimeout(() => window.location.reload(), 1000);
                                } else {
                                    this.showAlert(
                                        'twofa',
                                        'error',
                                        j.message || 'Doğrulama başarısız. Lütfen kodu kontrol edin.'
                                    );
                                }
                            })
                            .catch(() => {
                                this.showAlert(
                                    'twofa',
                                    'error',
                                    'Doğrulama sırasında bir hata oluştu.'
                                );
                            });
                    });
                }
            })
            .catch(() => {
                this.twofaInitCalled = false;
                this.showAlert(
                    'twofa',
                    'error',
                    '2FA başlatma isteği sırasında bir hata oluştu.'
                );
            });
    },

    disableTwoFa(formEl) {
        if (!formEl) return;

        const formData = new FormData(formEl);

        const pwd = (formData.get('current_password') || '').toString().trim();
        const otp = (formData.get('otp_code') || '').toString().trim();

        if (!pwd || !otp) {
            this.showAlert(
                'twofa',
                'error',
                'Lütfen hem şifrenizi hem de 2FA kodunuzu girin.'
            );
            return;
        }

        this.clearAlert('twofa');

        fetch('/src/controllers/user_security.php', {
            method: 'POST',
            body: formData
        })
            .then(res => res.json())
            .then(json => {
                if (json.success) {
                    this.showAlert(
                        'twofa',
                        'success',
                        json.message || '2FA başarıyla kapatıldı.'
                    );

                    // UI'de de güncelle
                    const statusEl    = document.getElementById('twofa-status');
                    const setupArea   = document.getElementById('twofa-setup-area');
                    const disableArea = document.getElementById('twofa-disable-area');

                    if (statusEl) {
                        statusEl.innerHTML = '<strong>PASİF</strong>';
                        statusEl.classList.remove('is-on');
                        statusEl.classList.add('is-off');
                    }

                    if (setupArea) {
                        setupArea.classList.remove('is-hidden'); // tekrar aktivasyon yapılabilir
                    }
                    if (disableArea) {
                        disableArea.classList.add('is-hidden');  // formu kapat
                    }

                    if (window.BW_CONFIG) {
                        window.BW_CONFIG.TWOFA_ENABLED = false;
                    }

                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);

                } else {
                    this.showAlert(
                        'twofa',
                        'error',
                        json.message || '2FA kapatılamadı. Şifreyi ve kodu kontrol edin.'
                    );
                }
            })
            .catch(() => {
                this.showAlert(
                    'twofa',
                    'error',
                    '2FA kapatma isteği sırasında bir hata oluştu.'
                );
            });
    }
};
