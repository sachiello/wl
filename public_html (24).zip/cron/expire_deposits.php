<?php
require __DIR__ . '/../config/config.php';

// Süresi dolan pending havale taleplerini çek
$stmt = $pdo->prepare("
    SELECT 
        d.id,
        d.amount_try,
        d.agent_id,
        d.payment_method
    FROM deposit_orders d
    WHERE d.status = 'pending'
      AND d.payment_method = 'havale'
      AND d.expire_at IS NOT NULL
      AND d.expire_at < NOW()
    LIMIT 100
");
$stmt->execute();

$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($orders as $order) {
    try {
        $pdo->beginTransaction();

        $amountTRY = (float)$order['amount_try'];
        $agentId   = (int)$order['agent_id'];
        $orderId   = (int)$order['id'];

        // Kaydı tekrar kilitle
        $lock = $pdo->prepare("
            SELECT status 
            FROM deposit_orders 
            WHERE id = ? AND status = 'pending'
            FOR UPDATE
        ");
        $lock->execute([$orderId]);
        if (!$lock->fetch()) {
            $pdo->rollBack();
            continue;
        }

        // Emri expire yap
        $pdo->prepare("
            UPDATE deposit_orders
            SET status='expired',
                fail_reason='Süre doldu',
                confirmed_at=NOW()
            WHERE id = ?
        ")->execute([$orderId]);

        // Rezervi iade et
        $pdo->prepare("
            UPDATE deposit_agents
            SET system_balance = system_balance + :amt
            WHERE id = :id
        ")->execute([
            ':amt' => $amountTRY,
            ':id'  => $agentId
        ]);

        $pdo->commit();

    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
    }
}
