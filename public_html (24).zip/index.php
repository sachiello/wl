<?php


session_start();
require_once __DIR__ . '/config/config.php';

// Basic routing logic
$requestUri = strtok($_SERVER['REQUEST_URI'], '?'); // "/", "/login", "/wallet"
$route = $requestUri === '/' ? '/' : rtrim($requestUri, '/');

// Define routes
switch ($route) {
    case '/':
    case '/index.php':
        require __DIR__ . '/src/views/landing.php';
        break;
    case '/register':
        require __DIR__ . '/src/views/register.php';
        break;
    case '/login':
        require __DIR__ . '/src/views/login.php';
        break;
    case '/wallet':
        require __DIR__ . '/src/views/wallet.php';
        break;
    default:
        http_response_code(404);
        echo "404 Not Found: $route";
        exit;
}
