<?php
// api/request_withdraw.php
// Merchant Sitelerden Gelen "Kullanıcı Çekim" İsteklerini Karşılar

header('Content-Type: application/json');
require __DIR__ . '/../config/config.php';

// 1. Gelen Veriyi Al
$input = json_decode(file_get_contents('php://input'), true);

// Gerekli Parametreler
$apiKey     = $input['api_key'] ?? '';
$siteUserId = $input['site_user_id'] ?? ''; // Sitedeki Kullanıcı ID/Adı
$bwUsername = $input['bw_username'] ?? '';  // BetWallet Kullanıcı Adı (Kullanıcı siteye bunu girer)
$amount     = isset($input['amount']) ? (float)$input['amount'] : 0;
$orderId    = $input['order_id'] ?? '';     // Sitenin benzersiz işlem kodu
$timestamp  = $input['ts'] ?? 0;
$signature  = $input['sig'] ?? '';

// 2. Basit Validasyonlar
if (!$apiKey || !$siteUserId || !$bwUsername || $amount <= 0 || !$orderId || !$timestamp || !$signature) {
    echo json_encode(['status' => 'error', 'message' => 'Eksik parametre.']);
    exit;
}

// 3. Siteyi ve API Secret'ı Bul
$stmt = $pdo->prepare("SELECT id, api_secret, net_balance, is_active FROM sites WHERE api_key = ? LIMIT 1");
$stmt->execute([$apiKey]);
$site = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$site) {
    echo json_encode(['status' => 'error', 'message' => 'Geçersiz API Anahtarı.']);
    exit;
}

if ($site['is_active'] == 0) {
    echo json_encode(['status' => 'error', 'message' => 'Site pasif durumda.']);
    exit;
}

// 4. İmza Doğrulama (Güvenlik)
// İmza Mantığı: api_key + order_id + amount + bw_username + ts
$payload = $apiKey . $orderId . $amount . $bwUsername . $timestamp;
$expectedSig = hash_hmac('sha256', $payload, $site['api_secret']);

if (!hash_equals($expectedSig, $signature)) {
    echo json_encode(['status' => 'error', 'message' => 'Geçersiz İmza (Signature Mismatch).']);
    exit;
}

// Zaman Aşımı Kontrolü (5 Dakika)
if (abs(time() - $timestamp) > 300) {
    echo json_encode(['status' => 'error', 'message' => 'Zaman aşımı (Request Timeout).']);
    exit;
}

// 5. Mükerrer İşlem Kontrolü
$dupCheck = $pdo->prepare("SELECT id FROM merchant_player_withdraws WHERE site_id = ? AND order_id = ?");
$dupCheck->execute([$site['id'], $orderId]);
if ($dupCheck->fetch()) {
    echo json_encode(['status' => 'error', 'message' => 'Bu Sipariş ID daha önce kullanılmış.']);
    exit;
}

// 6. BetWallet Kullanıcısını Bul
$userCheck = $pdo->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
$userCheck->execute([$bwUsername]);
$bwUserId = $userCheck->fetchColumn();

if (!$bwUserId) {
    echo json_encode(['status' => 'error', 'message' => 'Belirtilen BetWallet kullanıcısı bulunamadı.']);
    exit;
}

// 7. Bakiye Ön Kontrolü (Opsiyonel: Admin onayında kesin kontrol yapılır ama burada uyarmak iyidir)
if ($site['net_balance'] < $amount) {
    // İsteğe bağlı: Bakiye yetersizse direkt reddetmek istersen burayı açabilirsin.
    // Şimdilik kabul edip admin panelinde "Yetersiz Bakiye" uyarısı gösteriyoruz.
}

// 8. Talebi Kaydet
try {
    $insert = $pdo->prepare("
        INSERT INTO merchant_player_withdraws 
        (site_id, user_id, site_user_ref, order_id, amount, net_amount, status, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW())
    ");
    
    // net_amount şimdilik amount ile aynı, admin onaylarken komisyon eklenip düşülecek.
    $insert->execute([
        $site['id'], 
        $bwUserId, 
        $siteUserId, 
        $orderId, 
        $amount, 
        $amount 
    ]);

    echo json_encode([
        'status' => 'success',
        'message' => 'Çekim talebi alındı, onay bekleniyor.',
        'bw_ref' => $pdo->lastInsertId()
    ]);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Veritabanı hatası: ' . $e->getMessage()]);
}