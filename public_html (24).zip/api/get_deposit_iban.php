<?php
// api/get_deposit_iban.php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Invalid Method"]); exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$amount = (float)($data['amount'] ?? 0);
$userId = (int)($data['user_id'] ?? 0);

if ($amount <= 0) {
    echo json_encode(["status" => "error", "message" => "Geçersiz tutar."]); exit;
}

try {
    // AKILLI IBAN SEÇİM ALGORİTMASI (GÜNCELLENDİ)
    // Kural 1: IBAN ve Agent Aktif olmalı.
    // Kural 2: Tutar, IBAN limitlerine uymalı.
    // Kural 3: Agent'ın 'system_balance'ı (Teminatı) bu yatırımı karşılamalı.
    //          (Çünkü yatırım alınca teminat düşecek, eksiye düşmemeli)
    
    $sql = "
        SELECT 
            i.id as iban_id,
            i.bank_name,
            i.holder_name,
            i.iban,
            i.agent_id
        FROM deposit_ibans i
        JOIN deposit_agents a ON a.id = i.agent_id
        WHERE 
            i.is_active = 1 
            AND a.is_active = 1
            AND i.min_deposit_limit <= :amount 
            AND i.max_deposit_limit >= :amount
            AND i.current_daily_txn < i.max_daily_txn
            AND (i.quota_used + :amount2) <= i.quota_limit
            AND a.system_balance >= :amount3  -- KRİTİK: Teminat Kontrolü
        ORDER BY RAND() 
        LIMIT 1
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'amount'  => $amount,
        'amount2' => $amount,
        'amount3' => $amount
    ]);
    $iban = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($iban) {
        // Sipariş Oluştur
        $ins = $pdo->prepare("INSERT INTO deposit_orders (user_id, iban_id, agent_id, coin_type, amount_try, status, created_at, expire_at) VALUES (?, ?, ?, 'TRY', ?, 'pending', NOW(), DATE_ADD(NOW(), INTERVAL 15 MINUTE))");
        $ins->execute([$userId, $iban['iban_id'], $iban['agent_id'], $amount]);
        
        echo json_encode([
            "status" => "success",
            "data" => [
                "order_id" => $pdo->lastInsertId(),
                "bank_name" => $iban['bank_name'],
                "holder_name" => $iban['holder_name'],
                "iban" => $iban['iban']
            ]
        ]);
    } else {
        // Eğer uygun hesap yoksa
        echo json_encode(["status" => "error", "message" => "Şu an bu tutar için uygun yatırım hesabı bulunamadı."]);
    }

} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => "Sistem hatası."]);
}
?>