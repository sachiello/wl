<?php
// api/config.php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, GET");
header("Access-Control-Allow-Origin: *"); // Canlıda kendi site adresini yazmalısın

require_once __DIR__ . '/../config/config.php';

// Basit bir API Key kontrolü (Güvenlik için)
// Frontend tarafı Header'da 'X-API-KEY: 123456' göndermeli.
$apiKey = "123456"; // Bunu değiştirmeyi unutma
$headers = getallheaders();

if (!isset($headers['X-API-KEY']) || $headers['X-API-KEY'] !== $apiKey) {
    // Geçici olarak devre dışı bırakabilirsin test ederken
    // http_response_code(401);
    // echo json_encode(["status" => "error", "message" => "Yetkisiz Erişim"]);
    // exit;
}
?>