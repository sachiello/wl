<?php
// api/create_withdraw_request.php
// Bu dosya hem isteği alır hem de ANINDA uygun Agent'a atar.

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Origin: *");

require_once __DIR__ . '/../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Invalid Method"]); exit;
}

$data = json_decode(file_get_contents("php://input"), true);

// Gerekli Veriler
$siteApiKey   = $_SERVER['HTTP_X_API_KEY'] ?? ''; 
$userId       = (int)($data['user_id'] ?? 0);
$amount       = (float)($data['amount'] ?? 0);
$method       = $data['method'] ?? 'bank';
$userBank     = $data['bank_name'] ?? null;
$userIban     = $data['iban'] ?? null;
$userFullname = $data['full_name'] ?? null;
$walletAddr   = $data['wallet_address'] ?? null;

if ($amount <= 0) {
    echo json_encode(["status" => "error", "message" => "Geçersiz tutar."]); exit;
}

try {
    $pdo->beginTransaction();

    // 1. SİTE KONTROLÜ VE BAKİYE DÜŞME
    $stmtSite = $pdo->prepare("SELECT id, balance FROM sites WHERE api_key = ? LIMIT 1 FOR UPDATE");
    $stmtSite->execute([$siteApiKey]);
    $site = $stmtSite->fetch(PDO::FETCH_ASSOC);

    if (!$site) throw new Exception("Geçersiz API Key.");
    if ($site['balance'] < $amount) throw new Exception("Yetersiz Site Bakiyesi.");

    // Site Bakiyesini Düş
    $pdo->prepare("UPDATE sites SET balance = balance - ? WHERE id = ?")->execute([$amount, $site['id']]);

    // 2. ÇEKİM TALEBİNİ KAYDET
    // Kripto ise IBAN yerine cüzdan adresi yazalım
    if ($method == 'crypto') {
        $userIban = $walletAddr; 
        $userBank = 'TRC20';
    }

    $sql = "INSERT INTO withdraw_requests 
            (user_id, site_id, amount, method, user_bank_name, user_iban, user_full_name, status, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', NOW())";
    
    $stmtIns = $pdo->prepare($sql);
    $stmtIns->execute([$userId, $site['id'], $amount, $method, $userBank, $userIban, $userFullname]);
    $requestId = $pdo->lastInsertId();

    // 3. ANLIK OTOMATİK DAĞITIM (INSTANT DISPATCH)
    // Burada hemen uygun Agent arıyoruz. Beklemek yok.
    
    $stmtAgent = $pdo->prepare("
        SELECT id, current_cash 
        FROM deposit_agents 
        WHERE is_active = 1 
          AND current_cash >= ? 
        ORDER BY current_cash DESC 
        LIMIT 1
    ");
    $stmtAgent->execute([$amount]);
    $bestAgent = $stmtAgent->fetch(PDO::FETCH_ASSOC);

    $assigned = false;
    
    if ($bestAgent) {
        // UYGUN AGENT BULUNDU!
        $agentId = $bestAgent['id'];

        // a) Ana isteği 'processing' yap
        $pdo->prepare("UPDATE withdraw_requests SET status = 'processing' WHERE id = ?")->execute([$requestId]);

        // b) Agent'a iş emri oluştur (Onun ekranına düşsün)
        $taskSql = "INSERT INTO agent_withdraw_orders 
                    (site_id, agent_id, user_id, amount, to_bank_name, to_iban, to_full_name, status, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', NOW())";
        
        $pdo->prepare($taskSql)->execute([
            $site['id'], 
            $agentId, 
            $userId, 
            $amount, 
            $userBank, 
            $userIban, 
            $userFullname
        ]);
        
        $assigned = true;
    }

    $pdo->commit();

    // 4. SONUÇ DÖNDÜR
    if ($assigned) {
        echo json_encode([
            "status" => "success", 
            "message" => "Çekim talebi alındı ve finans birimine iletildi.",
            "request_id" => $requestId,
            "dispatch" => "instant" // Anında atandı
        ]);
    } else {
        // Eğer şu an uygun Agent yoksa (Hepsinin kasası boşsa)
        // İşlem 'pending' olarak havuzda kalır, Admin manuel atar veya Cron devreye girer.
        echo json_encode([
            "status" => "success",
            "message" => "Çekim talebi alındı, sırada bekliyor.",
            "request_id" => $requestId,
            "dispatch" => "queued" // Havuza düştü
        ]);
    }

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>