<?php
// merchant/test_tool.php
// BU DOSYA SADECE TEST AMAÇLIDIR. CANLI ORTAMDA SİLİNİZ.

session_start();
require __DIR__ . '/../config/config.php';

$response = null;
$requestData = null;

// Kendi URL'ini otomatik bul
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$apiUrl = "$protocol://$_SERVER[HTTP_HOST]/api/request_withdraw.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $apiKey    = trim($_POST['api_key']);
    $apiSecret = trim($_POST['api_secret']);
    $siteUser  = trim($_POST['site_user']);
    $bwUser    = trim($_POST['bw_user']);
    $amount    = (float)$_POST['amount'];
    $orderId   = trim($_POST['order_id']);
    $ts        = time();

    // 1. İmzayı Oluştur (API Dokümantasyonundaki Gibi)
    // Sıralama: api_key + order_id + amount + bw_username + ts
    $payload = $apiKey . $orderId . $amount . $bwUser . $ts;
    $signature = hash_hmac('sha256', $payload, $apiSecret);

    // 2. Veriyi Hazırla
    $data = [
        'api_key'      => $apiKey,
        'site_user_id' => $siteUser,
        'bw_username'  => $bwUser,
        'amount'       => $amount,
        'order_id'     => $orderId,
        'ts'           => $ts,
        'sig'          => $signature
    ];
    
    $requestData = json_encode($data, JSON_PRETTY_PRINT);

    // 3. cURL İle İsteği Gönder
    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    
    $apiResponse = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $response = [
        'code' => $httpCode,
        'body' => json_decode($apiResponse, true) ?? $apiResponse
    ];
}

// Kolaylık olsun diye veritabanından ilk siteyi çekelim (Varsayılan doldurmak için)
$demoSite = $pdo->query("SELECT * FROM sites WHERE is_active=1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Merchant Çekim Simülatörü</title>
    <style>
        body { font-family: sans-serif; background: #f3f4f6; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .card { background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        h2 { margin-top: 0; color: #333; border-bottom: 2px solid #eee; padding-bottom: 10px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; font-size: 12px; }
        input { width: 100%; padding: 8px; margin-bottom: 15px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background: #c2273f; color: #fff; border: none; border-radius: 4px; cursor: pointer; font-weight: bold; }
        button:hover { background: #a01e32; }
        pre { background: #1e293b; color: #a5b4fc; padding: 15px; border-radius: 6px; overflow-x: auto; font-size: 12px; }
        .status-200 { color: #22c55e; }
        .status-error { color: #ef4444; }
    </style>
</head>
<body>

<div class="container">
    <div class="card">
        <h2>📡 İstek Gönderici</h2>
        <form method="post">
            <label>API URL (Hedef)</label>
            <input type="text" value="<?= $apiUrl ?>" disabled style="background:#eee;">

            <label>Merchant API Key</label>
            <input type="text" name="api_key" value="<?= $demoSite['api_key'] ?? '' ?>" required>

            <label>Merchant Secret Key (İmza İçin)</label>
            <input type="text" name="api_secret" value="<?= $demoSite['api_secret'] ?? '' ?>" required>

            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px;">
                <div>
                    <label>Site User ID (Ref)</label>
                    <input type="text" name="site_user" value="user_<?= rand(1000,9999) ?>">
                </div>
                <div>
                    <label>BetWallet Username</label>
                    <input type="text" name="bw_user" placeholder="Örn: dalton1234" required>
                </div>
            </div>

            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px;">
                <div>
                    <label>Tutar (TL)</label>
                    <input type="number" name="amount" value="100.00" step="0.01">
                </div>
                <div>
                    <label>Order ID (Benzersiz)</label>
                    <input type="text" name="order_id" value="ORD-<?= time() ?>">
                </div>
            </div>

            <button type="submit">İSTEK GÖNDER (POST)</button>
        </form>
    </div>

    <div class="card">
        <h2>📝 Sonuçlar</h2>
        
        <?php if ($requestData): ?>
            <label>Gönderilen JSON (Body)</label>
            <pre><?= $requestData ?></pre>
        <?php endif; ?>

        <?php if ($response): ?>
            <label>HTTP Durumu</label>
            <div style="font-weight:bold; margin-bottom:10px;" class="<?= $response['code'] == 200 ? 'status-200' : 'status-error' ?>">
                <?= $response['code'] ?>
            </div>

            <label>API Cevabı</label>
            <pre><?= json_encode($response['body'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) ?></pre>
        <?php else: ?>
            <p style="color:#999;">Henüz istek gönderilmedi.</p>
        <?php endif; ?>
    </div>
</div>

</body>
</html>