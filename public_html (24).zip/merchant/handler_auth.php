<?php
// merchant/handler_auth.php
// BetWallet - Giriş ve Kayıt İşlemleri
// SQL Uyumluluk: users tablosu (password_hash, trc20_address zorunlu)

session_start();
require __DIR__ . '/../config/config.php';

// 1. Güvenlik: Sadece Gateway üzerinden gelenleri al
if (empty($_SESSION['merchant_site_id'])) {
    die("Erişim Reddedildi: Oturum bulunamadı.");
}

// 2. CSRF Koruması
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    die("Güvenlik Hatası: Geçersiz istek (CSRF Token).");
}

$merchantId = (int)$_SESSION['merchant_site_id'];
$action     = $_POST['action'] ?? '';

// Yardımcı Fonksiyonlar
function redirectError($msg) {
    header("Location: /merchant/index.php?error=" . urlencode($msg));
    exit;
}

function createWallet($pdo, $userId) {
    // Cüzdan yoksa USDT cüzdanı oluştur
    $stmt = $pdo->prepare("INSERT IGNORE INTO wallets (user_id, coin_type, balance, created_at) VALUES (?, 'USDT', 0, NOW())");
    $stmt->execute([$userId]);
}

// Rastgele TRC20 Adresi Üretici (Veritabanı zorunlu kıldığı için)
function generateRandomTRC20() {
    // T ile başlayan 34 karakterlik hex string
    return 'T' . bin2hex(random_bytes(16)) . substr(bin2hex(random_bytes(1)), 0, 1);
}

try {
    // ====================================================================
    // SENARYO 1: KAYIT OL (REGISTER)
    // ====================================================================
    if ($action === 'register') {
        $username = trim($_POST['username'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        // Validasyon
        if (strlen($username) < 3) redirectError("Kullanıcı adı en az 3 karakter olmalı.");
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) redirectError("Geçerli bir E-Posta girin.");
        if (strlen($password) < 6) redirectError("Şifre en az 6 karakter olmalı.");

        // Mükerrer Kontrol (username veya email)
        $chk = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1");
        $chk->execute([$username, $email]);
        if ($chk->fetch()) {
            redirectError("Bu kullanıcı adı veya e-posta zaten kullanımda.");
        }

        // İşlemi Başlat
        $pdo->beginTransaction();

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $trc20 = generateRandomTRC20();

        // SQL UYUMU: password_hash ve trc20_address zorunlu
        // `password` sütunu SQL'de var ama boş geçilebilir, biz hash kullanacağız.
        $stmt = $pdo->prepare("
            INSERT INTO users (username, email, password_hash, trc20_address, created_at, is_banned) 
            VALUES (?, ?, ?, ?, NOW(), 0)
        ");
        
        // TRC20 adresi unique olduğu için çakışma ihtimaline karşı basit try-catch
        try {
            $stmt->execute([$username, $email, $hash, $trc20]);
        } catch (PDOException $e) {
            // Çok düşük ihtimal ama adres çakışırsa bir daha dene
            if ($e->errorInfo[1] == 1062) { // Duplicate entry
                $trc20 = generateRandomTRC20(); 
                $stmt->execute([$username, $email, $hash, $trc20]);
            } else {
                throw $e;
            }
        }
        
        $newUserId = $pdo->lastInsertId();

        // Cüzdan Oluştur
        createWallet($pdo, $newUserId);

        $pdo->commit();

        // Otomatik Giriş
        $_SESSION['user_id']     = $newUserId;
        $_SESSION['merchant_id'] = $merchantId; 
        
        header("Location: /merchant/pay.php");
        exit;
    }

    // ====================================================================
    // SENARYO 2: GİRİŞ YAP (LOGIN)
    // ====================================================================
    elseif ($action === 'login') {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if (!$username || !$password) redirectError("Lütfen tüm alanları doldurun.");

        // SQL UYUMU: Şifre kontrolü password_hash üzerinden
        $stmt = $pdo->prepare("SELECT id, password_hash, is_banned FROM users WHERE username = ? LIMIT 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Kullanıcı yoksa veya şifre uyuşmazsa
        if (!$user || !password_verify($password, $user['password_hash'])) {
            redirectError("Kullanıcı adı veya şifre hatalı.");
        }

        if ($user['is_banned'] == 1) {
            redirectError("Hesabınız erişime engellenmiştir.");
        }

        // Giriş Başarılı
        session_regenerate_id(true);

        $_SESSION['user_id']     = $user['id'];
        $_SESSION['merchant_id'] = $merchantId;

        // Her ihtimale karşı cüzdan kontrolü (Eski kullanıcılarda cüzdan yoksa oluştur)
        createWallet($pdo, $user['id']);

        header("Location: /merchant/pay.php");
        exit;
    } 
    
    else {
        redirectError("Geçersiz işlem.");
    }

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    // Hata detayını logla, kullanıcıya genel mesaj göster
    error_log("Auth Error: " . $e->getMessage());
    redirectError("Sistem hatası oluştu. Lütfen daha sonra tekrar deneyin.");
}
?>