<?php
// merchant/pay.php
// BetWallet Cüzdan Ödemesi & Webhook Tetikleyici
// GÜNCELLEME: Site bakiyesi artık 'net_balance' sütununa ekleniyor.

session_start();
require __DIR__ . '/../config/config.php';

// 1. Güvenlik
if (empty($_SESSION['user_id']) || empty($_SESSION['merchant_site_id'])) {
    header("Location: /merchant/index.php");
    exit;
}

$userId     = $_SESSION['user_id'];
$merchantId = (int)$_SESSION['merchant_site_id'];
$userRef    = $_SESSION['merchant_user_ref'] ?? null;

// 2. Veri Çekme
$stmt = $pdo->prepare("SELECT name, api_secret, callback_url, commission_rate FROM sites WHERE id = ?");
$stmt->execute([$merchantId]);
$merchant = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$merchant) die("Site veritabanında bulunamadı.");

$stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
$stmt->execute([$userId]);
$username = $stmt->fetchColumn();

// Cüzdan Bakiyesi
$stmt = $pdo->prepare("SELECT balance FROM wallets WHERE user_id = ? AND coin_type = 'USDT'");
$stmt->execute([$userId]);
$usdtBalance = (float)$stmt->fetchColumn();

// Kur Bilgisi
$usdtRate = 34.50; 
$rateStmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'usdt_try_rate' LIMIT 1");
$rateStmt->execute();
$dbRate = $rateStmt->fetchColumn();
if($dbRate && $dbRate > 0) $usdtRate = (float)$dbRate;

$totalWealthTL = $usdtBalance * $usdtRate;

$pageState = 'form'; 
$msg = '';
$txnIdDisplay = '';

// 3. Ödeme İşlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amountTL = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);
    $coin     = $_POST['coin'] ?? 'USDT';

    if (!$amountTL || $amountTL <= 0) {
        $msg = "Lütfen geçerli bir tutar girin.";
        $pageState = 'error';
    } elseif ($coin !== 'USDT') {
        $msg = "Şu an sadece USDT desteklenmektedir.";
        $pageState = 'error';
    } else {
        $neededCoin = round($amountTL / $usdtRate, 6); 
        
        if ($neededCoin > $usdtBalance) {
            $msg = "Yetersiz Bakiye! İşlem için " . number_format($neededCoin, 2) . " USDT gerekiyor.";
            $pageState = 'error';
        } else {
            try {
                $pdo->beginTransaction();

                // A. Kullanıcıdan Düş
                $updUser = $pdo->prepare("UPDATE wallets SET balance = balance - ? WHERE user_id = ? AND coin_type = 'USDT'");
                $updUser->execute([$neededCoin, $userId]);

                // B. Komisyon Hesapla
                $commissionRate = (float)$merchant['commission_rate']; 
                $commissionAmount = $amountTL * ($commissionRate / 100);
                $netAmount = $amountTL - $commissionAmount;

                // DÜZELTME BURADA: Sitenin 'net_balance' (Çekilebilir) bakiyesini güncelle
                $updSite = $pdo->prepare("UPDATE sites SET net_balance = net_balance + ? WHERE id = ?");
                $updSite->execute([$netAmount, $merchantId]);

                // C. İşlemi Kaydet (merchant_orders)
                $txnId = 'ORD-' . time() . '-' . rand(1000, 9999);
                
                $ins = $pdo->prepare("
                    INSERT INTO merchant_orders 
                    (site_id, user_id, order_id, amount_try, commission_rate, commission_amount, net_amount, coin_amount, coin_type, status, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'USDT', 'success', NOW())
                ");
                $ins->execute([
                    $merchantId,
                    $userId,
                    $txnId,
                    $amountTL,
                    $commissionRate,
                    $commissionAmount,
                    $netAmount,
                    $neededCoin
                ]);
                
                $pdo->commit();

                // D. Webhook (JSON & Follow Redirects)
                if (!empty($merchant['callback_url'])) {
                    $payload = [
                        'merchant_id' => $merchantId,
                        'order_id'    => $txnId,
                        'user_ref'    => $userRef,
                        'amount'      => $amountTL,     
                        'net_amount'  => $netAmount,    
                        'currency'    => 'TRY',
                        'status'      => 'success',
                        'ts'          => time()
                    ];

                    $dataStr = $payload['order_id'] . '|' . $payload['amount'] . '|' . $payload['status'] . '|' . $payload['ts'];
                    $payload['hash'] = hash_hmac('sha256', $dataStr, $merchant['api_secret']);

                    $jsonPayload = json_encode($payload);

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, $merchant['callback_url']);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonPayload);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Yönlendirmeyi takip et
                    curl_setopt($ch, CURLOPT_POSTREDIR, 3);         // POST verisini koru
                    
                    curl_setopt($ch, CURLOPT_HTTPHEADER, [
                        'Content-Type: application/json',
                        'Content-Length: ' . strlen($jsonPayload),
                        'User-Agent: BetWallet-Merchant/1.0'
                    ]);
                    
                    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    
                    // Debug için loglama (Gerekirse açarsın)
                    // $resp = curl_exec($ch);
                    // file_put_contents(__DIR__.'/webhook_debug.log', $resp);
                    
                    curl_exec($ch);
                    curl_close($ch);
                }

                // E. UI Güncelleme
                $pageState = 'success';
                $usdtBalance -= $neededCoin;
                $totalWealthTL = $usdtBalance * $usdtRate;
                $txnIdDisplay = $txnId;

            } catch (Exception $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $msg = "İşlem başarısız: " . $e->getMessage();
                $pageState = 'error';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BetWallet Ödeme</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* Önceki CSS Tasarımı */
        :root { --bg-color: #f3f4f6; --card-bg: #ffffff; --primary: #dc2626; --primary-hover: #b91c1c; --text-dark: #111827; --text-gray: #6b7280; --border: #e5e7eb; }
        body { font-family: 'Inter', sans-serif; background-color: var(--bg-color); margin: 0; padding: 20px; display: flex; justify-content: center; min-height: 100vh; }
        .container { width: 100%; max-width: 440px; margin-top: 20px; }
        .card { background: var(--card-bg); border-radius: 20px; padding: 24px; border: 1px solid var(--border); box-shadow: 0 4px 15px rgba(0,0,0,0.03); margin-bottom: 20px; }
        .text-center { text-align: center; }
        .tw-amount { font-size: 36px; font-weight: 800; color: var(--text-dark); margin: 5px 0 10px 0; letter-spacing: -1px; }
        .asset-item { display: flex; align-items: center; padding: 16px; border-radius: 16px; cursor: pointer; transition: 0.2s; border: 1px solid transparent; background: #fff; margin-bottom: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.02); }
        .asset-item:hover { background: #f9fafb; }
        .asset-item.selected { background: #fef2f2; border-color: #fecaca; }
        .asset-icon { width: 44px; height: 44px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 24px; color: white; margin-right: 14px; flex-shrink: 0; }
        .payment-area { background: #fff; border-radius: 20px; padding: 20px; margin-top: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); display: none; }
        .big-input { width: 100%; padding: 16px; font-size: 24px; font-weight: 800; border: 2px solid var(--border); border-radius: 14px; outline: none; box-sizing: border-box; }
        .big-input:focus { border-color: var(--primary); }
        .btn-full { width: 100%; padding: 16px; background: var(--primary); color: white; border: none; border-radius: 12px; font-size: 16px; font-weight: 700; cursor: pointer; display: block; text-decoration: none; text-align: center; }
        .btn-full:hover { background: var(--primary-hover); }
        .alert { padding: 12px; border-radius: 10px; margin-bottom: 20px; font-size: 13px; text-align: center; }
        .alert-err { background: #fee2e2; color: #991b1b; }
        .success-icon { width: 80px; height: 80px; background: #dcfce7; color: #166534; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 40px; margin: 0 auto 20px auto; }
    </style>
</head>
<body>
    <div class="container">
        
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
            <div style="font-weight:700; font-size:18px; color:var(--primary);"><i class="ri-shield-check-fill"></i> BetWallet</div>
            <div style="background:#fff; padding:6px 12px; border-radius:20px; border:1px solid #e5e7eb; font-size:12px; font-weight:600;">
                <?= htmlspecialchars($username) ?>
            </div>
        </div>

        <?php if ($pageState === 'success'): ?>
            <div class="card text-center" style="padding: 40px 20px;">
                <div class="success-icon"><i class="ri-check-line"></i></div>
                <h2 style="font-size:22px; font-weight:800; margin-bottom:10px;">Ödeme Başarılı!</h2>
                <p style="color:#6b7280; font-size:14px; margin-bottom:30px; line-height:1.5;">
                    Ödeme onaylandı. Tutar <strong><?= htmlspecialchars($merchant['name']) ?></strong> hesabınıza aktarıldı.
                </p>
                
                <a href="#" onclick="window.close()" class="btn-full" style="background:#16a34a;">Pencereyi Kapat</a>
                <div style="margin-top:15px; font-size:12px; color:#9ca3af;">İşlem ID: #<?= htmlspecialchars($txnIdDisplay) ?></div>
            </div>

        <?php else: ?>
            
            <?php if($msg): ?>
                <div class="alert alert-err"><?= htmlspecialchars($msg) ?></div>
            <?php endif; ?>

            <div class="card text-center">
                <div style="font-size:12px; font-weight:700; color:#6b7280; letter-spacing:1px;">TOPLAM VARLIK</div>
                <div class="tw-amount">₺<?= number_format($totalWealthTL, 2) ?></div>
                <div style="font-size:13px; color:#6b7280; background:#f3f4f6; padding:8px; border-radius:8px; display:inline-block;">
                    <i class="ri-store-2-line"></i> <strong><?= htmlspecialchars($merchant['name']) ?></strong> Ödemesi
                </div>
            </div>

            <div style="font-size:13px; font-weight:700; color:#6b7280; margin-bottom:10px; margin-left:5px;">VARLIK SEÇİNİZ</div>

            <div class="asset-item" onclick="selectAsset('USDT', <?= $usdtRate ?>, this)">
                <div class="asset-icon" style="background:#22c55e;"><i class="ri-money-dollar-circle-line"></i></div>
                <div style="flex:1;">
                    <div style="font-weight:700; font-size:15px;">Tether</div>
                    <div style="font-size:11px; color:#6b7280;">USDT</div>
                </div>
                <div style="text-align:right;">
                    <div style="font-weight:700; font-size:15px;"><?= number_format($usdtBalance, 2) ?></div>
                    <div style="font-size:11px; color:#6b7280;">₺<?= number_format($usdtBalance * $usdtRate, 2) ?></div>
                </div>
            </div>

            <form method="POST" class="payment-area" id="paymentArea">
                <input type="hidden" name="coin" id="coinInput" value="USDT">
                
                <div style="position:relative; margin-bottom:20px;">
                    <input type="number" name="amount" id="tlInput" class="big-input" placeholder="0" onkeyup="calcConversion()" step="any" required>
                    <span style="position:absolute; right:16px; top:50%; transform:translateY(-50%); font-weight:700; color:#6b7280;">TL</span>
                </div>

                <div style="background:#f8fafc; border:1px solid var(--border); border-radius:14px; padding:15px; display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <div>
                        <strong style="font-size:14px;">Düşecek Tutar</strong>
                        <div style="font-size:11px; color:#6b7280;">Kur: <?= $usdtRate ?></div>
                    </div>
                    <div style="text-align:right;">
                        <span style="font-size:18px; font-weight:800; color:#111827;" id="cryptoAmount">0.00</span>
                        <small style="color:#6b7280;">USDT</small>
                    </div>
                </div>

                <button class="btn-full">Ödemeyi Onayla</button>
                <div onclick="history.back()" style="text-align:center; margin-top:15px; font-size:13px; color:#9ca3af; cursor:pointer;">İptal Et</div>
            </form>

        <?php endif; ?>
    </div>

    <script>
        let currentRate = 0;
        
        function selectAsset(symbol, rate, el) {
            document.querySelectorAll('.asset-item').forEach(i => i.classList.remove('selected'));
            el.classList.add('selected');
            
            currentRate = rate;
            document.getElementById('coinInput').value = symbol;
            document.getElementById('paymentArea').style.display = 'block';
            document.getElementById('tlInput').focus();
            calcConversion();
        }

        function calcConversion() {
            const val = document.getElementById('tlInput').value;
            const tl = parseFloat(val) || 0;
            const crypto = tl / currentRate;
            
            document.getElementById('cryptoAmount').innerText = crypto.toLocaleString('en-US', { 
                minimumFractionDigits: 2, 
                maximumFractionDigits: 4 
            });
        }
    </script>
</body>
</html>