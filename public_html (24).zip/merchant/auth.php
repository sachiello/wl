<?php
// merchant/auth.php (Merchant Site)

session_start();

if (!isset($_SESSION['user_id'])) {
    die("Önce giriş yapmalısınız.");
}

$merchantSecret = "MERCHANT_SHARED_SECRET_123"; // BetWallet ile ortak secret
$merchantId     = 17;                           // Bu siteye verilen ID
$userId         = $_SESSION['user_id'];         // Sitenin kendi user id'si
$username       = $_SESSION['username'];
$time           = time();

// Token üret
$token = hash_hmac("sha256", $merchantId . "|" . $userId . "|" . $time, $merchantSecret);

// BetWallet URL
$betwalletUrl = "https://yayincin.com/merchant/login.php";

$query = http_build_query([
    "mid"      => $merchantId,
    "uid"      => $userId,
    "username" => $username,
    "time"     => $time,
    "token"    => $token,
]);

header("Location: {$betwalletUrl}?{$query}");
exit;
?>
