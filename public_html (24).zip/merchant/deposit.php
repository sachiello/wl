<?php
// merchant/deposit.php
// BetWallet - Ödeme Oluşturma Ekranı

session_start();
require __DIR__ . '/../config/config.php';

// 1. Güvenlik Kontrolü
if (empty($_SESSION['user_id']) || empty($_SESSION['merchant_id'])) {
    // Oturum yoksa giriş ekranına at
    header("Location: /merchant/index.php?error=auth_required");
    exit;
}

$userId     = $_SESSION['user_id'];
$merchantId = $_SESSION['merchant_id'];

// 2. Kullanıcı Bilgilerini Çek
$stmt = $pdo->prepare("SELECT username, email FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Cüzdan Bakiyesi (Sadece USDT)
$stmt = $pdo->prepare("SELECT balance FROM wallets WHERE user_id = ? AND coin_type = 'USDT'");
$stmt->execute([$userId]);
$balance = $stmt->fetchColumn() ?: 0.00;

// Merchant Bilgisi (Logosunu göstermek için)
$stmt = $pdo->prepare("SELECT name, logo_url FROM deposit_sites WHERE id = ?");
$stmt->execute([$merchantId]);
$merchant = $stmt->fetch(PDO::FETCH_ASSOC);

$error = $_GET['error'] ?? null;

// 3. POST İşlemi (Yatırım Emri Oluşturma)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF Kontrolü (index.php'den gelen fonksiyonlar config'de yoksa buraya eklenmeli veya require edilmeli)
    // Basitlik adına burada direkt işleme geçiyoruz ama production'da csrf_validate_request() şart.
    
    $amount = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);
    $method = $_POST['method'] ?? 'havale';

    if (!$amount || $amount < 50) { // Örn: Min 50 TL
        $error = "Minimum yatırım tutarı 50 TL'dir.";
    } else {
        try {
            // Uygun bir IBAN/Agent bul (Load Balancer Mantığı)
            // Şu an en basit haliyle: İlk aktif IBAN'ı alıyoruz.
            // İleride burayı "en az yoğun agent" şeklinde güncelleyebiliriz.
            $ibanStmt = $pdo->query("
                SELECT d.id, d.agent_id 
                FROM deposit_ibans d 
                JOIN deposit_agents a ON a.id = d.agent_id 
                WHERE d.is_active = 1 AND a.is_active = 1 
                LIMIT 1
            ");
            $targetIban = $ibanStmt->fetch(PDO::FETCH_ASSOC);

            if (!$targetIban && $method === 'havale') {
                throw new Exception("Şu an uygun havale kanalı bulunmamaktadır. Lütfen Kripto deneyin.");
            }

            // Sipariş Oluştur
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("
                INSERT INTO deposit_orders 
                (user_id, merchant_id, agent_id, iban_id, amount_try, payment_method, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW())
            ");
            
            // Eğer Kripto ise iban_id NULL olabilir veya kripto cüzdan ID'si olabilir.
            // Şimdilik havale üzerinden gidiyoruz, kripto seçilse bile agent atanmalı.
            // *Basitleştirme:* Kripto için de bir agent'a atıyoruz.
            $agentId = $targetIban['agent_id'] ?? 0; // Kripto için özel agent logic eklenebilir
            $ibanId  = $targetIban['id'] ?? null;

            $stmt->execute([
                $userId, 
                $merchantId, 
                $agentId, 
                $ibanId, 
                $amount, 
                $method
            ]);
            
            $orderId = $pdo->lastInsertId();
            $pdo->commit();

            // Başarılı -> Ödeme Detay Sayfasına Yönlendir
            header("Location: /merchant/payment.php?id=" . $orderId);
            exit;

        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Para Yatır - BetWallet</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <style>
        :root {
            --bg-color: #f0f2f5;
            --card-bg: #ffffff;
            --primary: #ef4444;
            --primary-hover: #dc2626;
            --text-main: #1f2937;
            --text-muted: #6b7280;
            --border-color: #e2e8f0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-color);
            margin: 0;
            padding: 20px;
            color: var(--text-main);
            display: flex;
            justify-content: center;
        }

        .container {
            width: 100%;
            max-width: 480px;
        }

        /* Üst Bilgi Kartı */
        .header-card {
            background: var(--card-bg);
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.03);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .user-info h3 { margin: 0; font-size: 16px; }
        .user-info p { margin: 4px 0 0; color: var(--text-muted); font-size: 12px; }

        .balance-badge {
            background: #f0fdf4;
            color: #166534;
            padding: 8px 12px;
            border-radius: 10px;
            font-weight: 700;
            font-size: 14px;
            text-align: right;
            border: 1px solid #bbf7d0;
        }
        .balance-badge small { display: block; font-size: 10px; opacity: 0.8; font-weight: 500; }

        /* Ana İşlem Kartı */
        .main-card {
            background: var(--card-bg);
            border-radius: 16px;
            padding: 25px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.05);
        }

        .section-title {
            font-size: 14px;
            font-weight: 600;
            color: var(--text-muted);
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        /* Ödeme Yöntemleri (Radio Button Hack) */
        .methods-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 25px;
        }
        
        .method-option {
            position: relative;
        }
        
        .method-option input {
            position: absolute;
            opacity: 0;
            cursor: pointer;
        }

        .method-card {
            border: 2px solid var(--border-color);
            border-radius: 12px;
            padding: 15px;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
            height: 100%;
            box-sizing: border-box;
        }

        .method-card i {
            font-size: 24px;
            display: block;
            margin-bottom: 8px;
            color: var(--text-muted);
        }

        .method-card span {
            font-weight: 600;
            font-size: 14px;
        }

        /* Seçili Durum */
        .method-option input:checked + .method-card {
            border-color: var(--primary);
            background: #fef2f2;
            color: var(--primary);
        }
        .method-option input:checked + .method-card i {
            color: var(--primary);
        }

        /* Tutar Alanı */
        .amount-wrapper {
            position: relative;
            margin-bottom: 15px;
        }
        .amount-wrapper input {
            width: 100%;
            padding: 16px;
            font-size: 24px;
            font-weight: 700;
            border: 2px solid var(--border-color);
            border-radius: 12px;
            outline: none;
            box-sizing: border-box;
            transition: border-color 0.2s;
        }
        .amount-wrapper input:focus {
            border-color: var(--primary);
        }
        .currency-symbol {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            font-weight: 600;
            color: var(--text-muted);
        }

        /* Hızlı Tutar Butonları */
        .quick-amounts {
            display: flex;
            gap: 10px;
            margin-bottom: 25px;
            overflow-x: auto;
            padding-bottom: 5px;
        }
        .q-btn {
            background: var(--bg-color);
            border: none;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            color: var(--text-main);
            cursor: pointer;
            white-space: nowrap;
            transition: background 0.2s;
        }
        .q-btn:hover { background: #e2e8f0; }

        .submit-btn {
            width: 100%;
            padding: 16px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: background 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        .submit-btn:hover { background: var(--primary-hover); }

        .error-msg {
            background: #fee2e2;
            color: #991b1b;
            padding: 12px;
            border-radius: 8px;
            font-size: 13px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .back-link {
            text-align: center;
            margin-top: 20px;
            font-size: 13px;
            color: var(--text-muted);
        }
        .back-link a { text-decoration: none; color: var(--text-muted); }
    </style>
</head>
<body>

<div class="container">

    <div class="header-card">
        <div class="user-info">
            <h3>Merhaba, <?= htmlspecialchars($user['username']) ?></h3>
            <p><?= htmlspecialchars($merchant['name'] ?? 'BetWallet') ?> üyesi</p>
        </div>
        <div class="balance-badge">
            <small>BAKİYE</small>
            $<?= number_format($balance, 2) ?>
        </div>
    </div>

    <form method="POST" class="main-card">
        
        <?php if($error): ?>
            <div class="error-msg">
                <i class="ri-error-warning-fill"></i> <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <div class="section-title">Yatırım Yöntemi</div>
        
        <div class="methods-grid">
            <label class="method-option">
                <input type="radio" name="method" value="havale" checked>
                <div class="method-card">
                    <i class="ri-bank-card-2-line"></i>
                    <span>Havale / EFT</span>
                </div>
            </label>
            <label class="method-option">
                <input type="radio" name="method" value="crypto">
                <div class="method-card">
                    <i class="ri-bit-coin-line"></i>
                    <span>Tether (USDT)</span>
                </div>
            </label>
        </div>

        <div class="section-title">Yatırım Tutarı</div>

        <div class="amount-wrapper">
            <input type="number" name="amount" id="amountInput" placeholder="0.00" min="50" step="1" required>
            <span class="currency-symbol">₺</span>
        </div>

        <div class="quick-amounts">
            <button type="button" class="q-btn" onclick="setAmount(100)">+100</button>
            <button type="button" class="q-btn" onclick="setAmount(250)">+250</button>
            <button type="button" class="q-btn" onclick="setAmount(500)">+500</button>
            <button type="button" class="q-btn" onclick="setAmount(1000)">+1000</button>
            <button type="button" class="q-btn" onclick="setAmount(5000)">+5000</button>
        </div>

        <button type="submit" class="submit-btn">
            <i class="ri-secure-payment-line"></i>
            Ödemeyi Başlat
        </button>

        <div class="back-link">
            <i class="ri-arrow-left-line"></i> 
            <a href="#">Merchant Sitesine Dön</a>
        </div>

    </form>
</div>

<script>
    function setAmount(val) {
        document.getElementById('amountInput').value = val;
    }
</script>

</body>
</html>