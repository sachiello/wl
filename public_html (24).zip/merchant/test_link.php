<?php
// test_link.php
// Merchant entegrasyonunu test etmek için geçerli link üretir.

require __DIR__ . '/../config/config.php'; // Config dosyanın yeri önemli, ayarla.

// Config'de tanımlı değilse buraya manuel yaz (index.php ile AYNI olmalı)
if (!defined('BW_MERCHANT_SECRET')) {
    define('BW_MERCHANT_SECRET', 'CHANGE_THIS_SECRET_IN_CONFIG'); 
}

// Test Verileri
$siteId  = 1;              // Veritabanındaki Site ID (Sekabet)
$userRef = 'test_user_' . rand(100,999); // Sitenin gönderdiği rastgele kullanıcı ID'si
$ts      = time();         // Şu anki zaman

// İmza Oluşturma (index.php ile aynı mantık)
$payload = $siteId . '|' . $userRef . '|' . $ts;
$sig     = hash_hmac('sha256', $payload, BW_MERCHANT_SECRET);

// Linki Oluştur
$params = http_build_query([
    'site'     => $siteId,
    'user_ref' => $userRef,
    'ts'       => $ts,
    'sig'      => $sig
]);

$url = "/merchant/index.php?" . $params;

// Ekrana Yaz ve Yönlendir
echo "<h3>Test Linki Oluşturuldu!</h3>";
echo "Yönlendiriliyorsunuz: <a href='$url'>$url</a>";

header("Refresh: 1; url=$url"); // 1 saniye sonra otomatik git
exit;
?>