<?php
// callback_test.php
$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true); // JSON dene

if (!$data) {
    $data = $_POST; // JSON değilse POST dene
}
if (!$data) {
    $data = ["RAW_STRING" => $rawInput]; // Hiçbiri değilse ham veriyi bas
}

$log = "[" . date('Y-m-d H:i:s') . "] WEBHOOK GELDI:\n" . print_r($data, true) . "\n----------------\n";
file_put_contents('webhook.log', $log, FILE_APPEND);
echo "OK";
?>