<?php
// BetWallet / merchant/login.php

session_start();
require __DIR__ . "/../config/config.php";

$merchantSecret = "MERCHANT_SHARED_SECRET_123"; // Aynı secret olmalı

$merchantId = $_GET['mid']  ?? null;
$userId     = $_GET['uid']  ?? null;
$username   = $_GET['username'] ?? null;
$time       = $_GET['time'] ?? null;
$token      = $_GET['token'] ?? null;

if (!$merchantId || !$userId || !$time || !$token) {
    die("Eksik parametre.");
}

// Token kontrol
$check = hash_hmac("sha256", "$merchantId|$userId|$time", $merchantSecret);

if (!hash_equals($check, $token)) {
    die("Yetkisiz giriş.");
}

// Token zaman aşımı (5 dakika)
if (time() - $time > 300) {
    die("Link süresi dolmuş.");
}

// BetWallet kullanıcı eşleştirmesi
$stmt = $pdo->prepare("SELECT id FROM users WHERE external_user_id = ? AND merchant_id = ?");
$stmt->execute([$userId, $merchantId]);
$bwUser = $stmt->fetch(PDO::FETCH_ASSOC);

// Yoksa otomatik oluştur
if (!$bwUser) {
    $stmt = $pdo->prepare("
        INSERT INTO users (username, merchant_id, external_user_id, created_at)
        VALUES (?, ?, ?, NOW())
    ");
    $stmt->execute([$username, $merchantId, $userId]);
    $bwUserId = $pdo->lastInsertId();
} else {
    $bwUserId = $bwUser['id'];
}

// BetWallet oturumu aç
$_SESSION['user_id'] = $bwUserId;
$_SESSION['merchant_id'] = $merchantId;

// Yatırım ekranına gönder
header("Location: /merchant/deposit.php");
exit;
?>
