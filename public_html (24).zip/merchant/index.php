<?php
// merchant/index.php
// BetWallet Gateway - Giriş Kapısı
// SQL Uyumluluk: 'sites' tablosu baz alındı.

if (session_status() === PHP_SESSION_NONE) { session_start(); }
require __DIR__ . '/../config/config.php';
if (!isset($pdo) && isset($db)) { $pdo = $db; }

// --- 1. CSRF Helper ---
if (!function_exists('csrf_token')) {
    function csrf_token() {
        if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        return $_SESSION['csrf_token'];
    }
}

// --- 2. Merchant Token Doğrulama ---
$siteId  = isset($_GET['site']) ? (int)$_GET['site'] : 0;
$userRef = trim($_GET['user_ref'] ?? '');
$ts      = isset($_GET['ts']) ? (int)$_GET['ts'] : 0;
$sig     = $_GET['sig'] ?? '';

// Secret Key (Config'de tanımlı değilse fallback)
// NOT: Bu anahtar link üretimi içindir, veritabanındaki api_secret ile karıştırma.
if (!defined('BW_MERCHANT_SECRET')) define('BW_MERCHANT_SECRET', 'CHANGE_THIS_SECRET_IN_CONFIG');

$tokenError = null;
$currentSite = null;

// Token kontrolü
if ($siteId && $userRef && $ts && $sig) {
    $payload   = $siteId . '|' . $userRef . '|' . $ts;
    $expected  = hash_hmac('sha256', $payload, BW_MERCHANT_SECRET);
    
    if (abs(time() - $ts) > 300) {
        $tokenError = 'Bağlantı zaman aşımı. Site üzerinden tekrar deneyin.';
    } elseif (!hash_equals($expected, $sig)) {
        $tokenError = 'Güvenlik imzası geçersiz.';
    } else {
        $_SESSION['merchant_site_id']  = $siteId;
        $_SESSION['merchant_user_ref'] = $userRef;
    }
} elseif (!empty($_SESSION['merchant_site_id'])) {
    $siteId = (int)$_SESSION['merchant_site_id'];
} else {
    $tokenError = 'Eksik parametre. Doğrudan giriş yapılamaz.';
}

// --- 3. Site Bilgisi (SQL DÜZELTMESİ YAPILDI) ---
if ($siteId > 0 && !$tokenError) {
    // TABLO ADI: sites (Eski kodda deposit_sites idi)
    // SÜTUNLAR: name, logo_url, is_active
    $stmt = $pdo->prepare("SELECT name, logo_url FROM sites WHERE id = ? AND is_active = 1 LIMIT 1");
    $stmt->execute([$siteId]);
    $currentSite = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$currentSite) {
        $tokenError = 'Site aktif değil veya bulunamadı.';
    }
}

// Zaten giriş yapmışsa direkt ödemeye
if (!empty($_SESSION['user_id']) && !$tokenError && $currentSite) {
    header('Location: /merchant/pay.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BetWallet Gateway</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #f3f4f6; --card-bg: #ffffff;
            --primary: #dc2626; --primary-hover: #b91c1c;
            --text-dark: #111827; --text-gray: #6b7280;
            --border: #e5e7eb;
        }
        body {
            font-family: 'Inter', sans-serif; background-color: var(--bg-color);
            margin: 0; padding: 20px; display: flex; justify-content: center; align-items: center; min-height: 100vh;
        }
        .container { width: 100%; max-width: 400px; text-align: center; }
        .bw-logo-area { margin-bottom: 25px; }
        .bw-logo-text { font-size: 26px; font-weight: 900; color: var(--primary); letter-spacing: -1px; vertical-align: middle; margin-left: 8px; }
        .card { background: var(--card-bg); padding: 35px; border-radius: 20px; box-shadow: 0 10px 30px -5px rgba(0,0,0,0.08); }
        .input-group { text-align: left; margin-bottom: 15px; }
        .input-label { display: block; font-size: 12px; font-weight: 700; margin-bottom: 6px; color: var(--text-dark); }
        .bw-input { width: 100%; padding: 14px; background: #f9fafb; border: 1px solid var(--border); border-radius: 10px; font-size: 14px; outline: none; box-sizing: border-box; }
        .bw-input:focus { border-color: var(--primary); background: #fff; }
        .btn { width: 100%; padding: 14px; border: none; border-radius: 10px; font-size: 15px; font-weight: 700; cursor: pointer; transition: 0.2s; display: flex; justify-content: center; align-items: center; gap: 8px; }
        .btn-primary { background: var(--primary); color: white; margin-bottom: 12px; }
        .btn-primary:hover { background: var(--primary-hover); transform: translateY(-1px); }
        .view-section { display: none; animation: fadeIn 0.4s ease; }
        .view-section.active { display: block; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .error-box { background: #fee2e2; color: #991b1b; padding: 12px; border-radius: 8px; margin-bottom: 20px; font-size: 13px; }
        
        /* Logo Varsa Göster */
        .site-logo { max-height: 30px; vertical-align: middle; margin-right: 5px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="bw-logo-area">
            <i class="ri-shield-check-fill" style="color:var(--primary); font-size:32px; vertical-align:middle;"></i>
            <span class="bw-logo-text">BETWALLET</span>
        </div>

        <?php if ($tokenError): ?>
            <div class="card">
                <div class="error-box"><?= htmlspecialchars($tokenError) ?></div>
                <div style="font-size:12px; color:#6b7280;">Lütfen site üzerinden tekrar bağlanın.</div>
            </div>
        <?php else: ?>

            <div id="view-landing" class="view-section active">
                <div class="card">
                    <div style="background:#eff6ff; color:#1e40af; padding:12px; border-radius:10px; font-size:13px; margin-bottom:25px; border:1px solid #dbeafe; display:flex; align-items:center; justify-content:center; gap:8px;">
                        <?php if(!empty($currentSite['logo_url'])): ?>
                            <img src="<?= htmlspecialchars($currentSite['logo_url']) ?>" class="site-logo" alt="Site Logo">
                        <?php else: ?>
                            <i class="ri-link"></i>
                        <?php endif; ?>
                        <strong><?= htmlspecialchars($currentSite['name']) ?></strong>
                    </div>
                    
                    <?php if(isset($_GET['error'])): ?>
                        <div class="error-box"><?= htmlspecialchars($_GET['error']) ?></div>
                    <?php endif; ?>
                    
                    <button class="btn btn-primary" onclick="showView('login')">Giriş Yap</button>
                    <button class="btn btn-primary" style="background:#fff; color:var(--text-dark); border:1px solid var(--border);" onclick="showView('register')">Kayıt Ol</button>
                </div>
            </div>

            <div id="view-login" class="view-section">
                <div class="card">
                    <h3 style="margin:0 0 20px 0; color:var(--text-dark);">Giriş Yap</h3>
                    <form action="/merchant/handler_auth.php" method="POST">
                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                        <input type="hidden" name="action" value="login">
                        
                        <div class="input-group">
                            <label class="input-label">Kullanıcı Adı</label>
                            <input type="text" name="username" class="bw-input" required>
                        </div>
                        <div class="input-group">
                            <label class="input-label">Şifre</label>
                            <input type="password" name="password" class="bw-input" required>
                        </div>
                        <button class="btn btn-primary">Giriş Yap</button>
                    </form>
                    <div onclick="showView('landing')" style="margin-top:20px; font-size:13px; cursor:pointer; color:#6b7280;">
                        <i class="ri-arrow-left-line" style="vertical-align:middle"></i> Geri Dön
                    </div>
                </div>
            </div>

            <div id="view-register" class="view-section">
                <div class="card">
                    <h3 style="margin:0 0 20px 0; color:var(--text-dark);">Hesap Oluştur</h3>
                    <form action="/merchant/handler_auth.php" method="POST">
                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                        <input type="hidden" name="action" value="register">

                        <div class="input-group">
                            <label class="input-label">Kullanıcı Adı</label>
                            <input type="text" name="username" class="bw-input" required>
                        </div>
                        <div class="input-group">
                            <label class="input-label">E-Posta</label>
                            <input type="email" name="email" class="bw-input" required>
                        </div>
                        <div class="input-group">
                            <label class="input-label">Şifre</label>
                            <input type="password" name="password" class="bw-input" required>
                        </div>
                        <button class="btn btn-primary">Kayıt Ol ve Devam Et</button>
                    </form>
                    <div onclick="showView('landing')" style="margin-top:20px; font-size:13px; cursor:pointer; color:#6b7280;">
                        <i class="ri-arrow-left-line" style="vertical-align:middle"></i> Geri Dön
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <script>
        function showView(v) {
            document.querySelectorAll('.view-section').forEach(e => e.classList.remove('active'));
            document.getElementById('view-'+v).classList.add('active');
        }
    </script>
</body>
</html>