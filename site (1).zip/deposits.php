<?php
require 'init.php';

// Filtreler
$start = $_GET['start'] ?? '';
$end = $_GET['end'] ?? '';
$search = $_GET['search'] ?? '';

$sql = "SELECT d.*, u.username FROM deposit_orders d LEFT JOIN users u ON d.user_id = u.id WHERE d.site_id = ? AND d.status = 'confirmed'";
$params = [$site['id']];

if ($start && $end) {
    $sql .= " AND DATE(d.confirmed_at) BETWEEN ? AND ?";
    $params[] = $start; $params[] = $end;
}
if ($search) {
    $sql .= " AND (d.id LIKE ? OR u.username LIKE ?)";
    $params[] = "%$search%"; $params[] = "%$search%";
}

$sql .= " ORDER BY d.confirmed_at DESC LIMIT 50";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$deposits = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    <div class="main-content">
        <div class="topbar"><h1>Yatırım Raporu</h1></div>
        
        <div class="card">
            <form method="get" style="display:flex; gap:10px; margin-bottom:20px; flex-wrap:wrap;">
                <input type="text" name="date_range" id="dateRange" class="form-control" placeholder="Tarih Aralığı" style="width:250px;">
                <input type="hidden" name="start" id="startDate">
                <input type="hidden" name="end" id="endDate">
                <input type="text" name="search" class="form-control" placeholder="ID veya Kullanıcı..." value="<?= htmlspecialchars($search) ?>" style="width:200px;">
                <button class="btn btn-primary">Filtrele</button>
                <?php if($start): ?><a href="deposits.php" class="btn btn-secondary">Temizle</a><?php endif; ?>
            </form>

            <div class="table-responsive">
                <table>
                    <thead><tr><th>ID</th><th>Kullanıcı</th><th>Tutar</th><th>Tarih</th><th>Durum</th></tr></thead>
                    <tbody>
                        <?php foreach($deposits as $d): ?>
                        <tr>
                            <td style="font-family:monospace; color:var(--text-muted);">#<?= $d['id'] ?></td>
                            <td style="font-weight:600;"><?= htmlspecialchars($d['username']) ?></td>
                            <td style="font-weight:bold; color:#10b981;">+<?= number_format($d['amount_try'], 2) ?> ₺</td>
                            <td><?= date('d.m.Y H:i', strtotime($d['confirmed_at'])) ?></td>
                            <td><span class="badge bg-green">ONAYLI</span></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://npmcdn.com/flatpickr/dist/l10n/tr.js"></script>
<script>
    flatpickr("#dateRange", {
        mode: "range",
        dateFormat: "Y-m-d",
        locale: "tr",
        defaultDate: ["<?= $start ?>", "<?= $end ?>"],
        onClose: function(selectedDates, dateStr, instance) {
            if (selectedDates.length === 2) {
                document.getElementById('startDate').value = instance.formatDate(selectedDates[0], "Y-m-d");
                document.getElementById('endDate').value = instance.formatDate(selectedDates[1], "Y-m-d");
            }
        }
    });
</script>
</body></html>