<?php
require 'init.php';

// Yeni Secret Üretme (Opsiyonel)
if (isset($_POST['regen_keys']) && isset($_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
    $newSecret = bin2hex(random_bytes(32));
    $pdo->prepare("UPDATE sites SET api_secret = ? WHERE id = ?")->execute([$newSecret, $site['id']]);
    $site['api_secret'] = $newSecret; // Ekranda güncel görünsün
    $msg = "Secret Key yenilendi.";
}
?>
<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    <div class="main-content">
        <h1>Geliştirici & API</h1>
        
        <div class="card">
            <p>Aşağıdaki anahtarları kullanarak entegrasyon yapabilirsiniz. <strong style="color:red;">Secret Key'i kimseyle paylaşmayın!</strong></p>
            
            <div style="margin-bottom:20px;">
                <label style="font-weight:bold; display:block; margin-bottom:5px;">Merchant ID (API Key)</label>
                <div style="background:#f1f5f9; padding:10px; border-radius:6px; font-family:monospace; font-size:16px;">
                    <?= htmlspecialchars($site['api_key']) ?>
                </div>
            </div>

            <div style="margin-bottom:20px;">
                <label style="font-weight:bold; display:block; margin-bottom:5px;">Secret Key</label>
                <div style="background:#f1f5f9; padding:10px; border-radius:6px; font-family:monospace; font-size:16px; word-break:break-all;">
                    <?= htmlspecialchars($site['api_secret']) ?>
                </div>
            </div>

            <form method="post" onsubmit="return confirm('Secret Key değişecek. Mevcut entegrasyonlarınız durabilir. Onaylıyor musunuz?');">
                <?= csrf_field() ?>
                <button name="regen_keys" class="btn" style="background:#ef4444; color:white;">Secret Key'i Yenile</button>
            </form>
        </div>

        <div class="card">
            <h3>Entegrasyon Dokümanı</h3>
            <p>Postman koleksiyonu ve PHP örnek kodları için <a href="#" style="color:#0ea5e9;">tıklayınız</a>.</p>
        </div>
    </div>
</div>
</body></html>