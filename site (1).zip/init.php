<?php
// site/init.php
ini_set('display_errors', 1); error_reporting(E_ALL);

header("X-Frame-Options: DENY");
header("X-Content-Type-Options: nosniff");

$configPath = __DIR__ . '/../../config/config.php';
$libPath    = __DIR__ . '/../../lib/GoogleAuthenticator.php';

if (!file_exists($configPath)) die("Config bulunamadı!");
require_once $configPath;

if (file_exists($libPath)) require_once $libPath;

if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($pdo)) $pdo = $db;

// Login Kontrolü
$curPage = basename($_SERVER['PHP_SELF']);
if ($curPage != 'login.php' && !isset($_SESSION['site_id'])) {
    header("Location: login.php"); exit;
}

// --- KİMLİK VE YETKİ TESPİTİ ---
$siteId = $_SESSION['site_id'];
$isPersonnel = isset($_SESSION['is_personnel']) && $_SESSION['is_personnel'];
$myId = isset($_SESSION['personnel_id']) ? $_SESSION['personnel_id'] : null;

// Site Bilgilerini Çek
$stmt = $pdo->prepare("SELECT * FROM sites WHERE id = ?");
$stmt->execute([$siteId]);
$site = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$site || !$site['is_active']) { 
    session_destroy(); header("Location: login.php?err=deactivated"); exit; 
}

// Eğer Personelse, Kendi Bilgilerini ve Yetkilerini Çek
$myPermissions = [];
if ($isPersonnel && $myId) {
    $stmtP = $pdo->prepare("SELECT * FROM site_personnel WHERE id = ? AND site_id = ?");
    $stmtP->execute([$myId, $siteId]);
    $me = $stmtP->fetch(PDO::FETCH_ASSOC);
    
    if (!$me || !$me['is_active']) {
        session_destroy(); header("Location: login.php?err=personnel_deactive"); exit;
    }
    $myPermissions = json_decode($me['permissions'] ?? '[]', true);
}

// Bakiyeler
$siteBalance = $site['balance'] ?? 0;
$netBalance  = $site['net_balance'] ?? $siteBalance;

// --- YARDIMCI FONKSİYONLAR ---

// Yetki Kontrolü
if (!function_exists('hasPerm')) {
    function hasPerm($perm) {
        global $isPersonnel, $myPermissions;
        // Site sahibi (Patron) ise her şeye yetkisi var
        if (!$isPersonnel) return true;
        
        // Personel ise listeye bak
        if (empty($myPermissions)) return false;
        return in_array($perm, $myPermissions);
    }
}

// CSRF
if (!function_exists('csrf_token')) {
    function csrf_token() {
        if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        return $_SESSION['csrf_token'];
    }
}
if (!function_exists('csrf_field')) {
    function csrf_field() { return '<input type="hidden" name="csrf_token" value="' . csrf_token() . '">'; }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel - <?= htmlspecialchars($site['name'] ?? '') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
    <link rel="stylesheet" href="site.css?v=1.1">
</head>
<body>
    <script>
    // Dark Mode Logic
    const toggleBtn = document.getElementById('darkModeToggle');
    const body = document.body;
    
    // Kayıtlı tercihi kontrol et
    if (localStorage.getItem('theme') === 'dark') {
        body.classList.add('dark-mode');
    }

    function toggleDarkMode() {
        body.classList.toggle('dark-mode');
        localStorage.setItem('theme', body.classList.contains('dark-mode') ? 'dark' : 'light');
    }
</script>