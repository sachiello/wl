<?php
// site/login.php
session_start();
require __DIR__ . '/../../config/config.php';

// --- 1. ÖNCE ÇIKIŞ KONTROLÜ (Sıralama Önemli!) ---
if (isset($_GET['logout'])) {
    // Session verilerini boşalt
    $_SESSION = [];
    
    // Cookie varsa sil (Tam temizlik)
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }

    // Session'ı yok et
    session_destroy();
    
    // Login sayfasına tertemiz yönlendir
    header('Location: login.php');
    exit;
}

// --- 2. SONRA GİRİŞ KONTROLÜ ---
// Eğer çıkış yapmıyorsa ve zaten girişliyse içeri al
if (isset($_SESSION['site_id'])) {
    header('Location: index.php');
    exit;
}

$error = '';

// --- 3. GİRİŞ İŞLEMLERİ ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username'] ?? '');
    $pass = trim($_POST['password'] ?? '');

    if ($user && $pass) {
        // A) Önce Site Sahibi mi?
        $stmt = $pdo->prepare("SELECT * FROM sites WHERE site_username = ? LIMIT 1");
        $stmt->execute([$user]);
        $siteOwner = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($siteOwner) {
            // Şifre Kontrolü (Hash veya Düz Metin)
            $isMatch = password_verify($pass, $siteOwner['site_password']);
            if (!$isMatch && $siteOwner['site_password'] === $pass) {
                $isMatch = true; // Düz metin desteği
            }

            if ($isMatch) {
                if (!$siteOwner['is_active']) {
                    $error = "Hesabınız pasif durumda.";
                } else {
                    $_SESSION['site_id'] = $siteOwner['id'];
                    $_SESSION['site_name'] = $siteOwner['name'];
                    $_SESSION['is_personnel'] = false; // Patron
                    header('Location: index.php'); exit;
                }
            } else {
                $error = "Hatalı şifre.";
            }
        } 
        else {
            // B) Yoksa Personel mi?
            $stmtP = $pdo->prepare("SELECT * FROM site_personnel WHERE username = ? LIMIT 1");
            $stmtP->execute([$user]);
            $personnel = $stmtP->fetch(PDO::FETCH_ASSOC);

            if ($personnel && password_verify($pass, $personnel['password_hash'])) {
                if (!$personnel['is_active']) {
                    $error = "Personel hesabı pasif.";
                } else {
                    $_SESSION['site_id'] = $personnel['site_id'];
                    $_SESSION['personnel_id'] = $personnel['id'];
                    $_SESSION['is_personnel'] = true; // Personel
                    $_SESSION['personnel_name'] = $personnel['username']; // İsim gösterimi için
                    header('Location: index.php'); exit;
                }
            } else {
                $error = "Kullanıcı bulunamadı veya şifre hatalı.";
            }
        }
    } else {
        $error = "Lütfen bilgileri giriniz.";
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Merchant Giriş</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
    <style>
        body { background: #f1f5f9; font-family: 'Segoe UI', sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .login-box { background: #fff; padding: 40px; border-radius: 12px; width: 100%; max-width: 380px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); }
        .logo { text-align: center; font-size: 24px; font-weight: 800; color: #0ea5e9; margin-bottom: 30px; }
        .form-group { margin-bottom: 15px; }
        input { width: 100%; padding: 12px; border: 1px solid #e2e8f0; border-radius: 8px; box-sizing: border-box; font-size: 14px; transition: 0.2s; }
        input:focus { border-color: #0ea5e9; outline: none; }
        button { width: 100%; padding: 12px; background: #0ea5e9; color: #fff; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; transition: 0.2s; }
        button:hover { background: #0284c7; transform: translateY(-1px); }
        .error { background: #fee2e2; color: #991b1b; padding: 10px; border-radius: 6px; margin-bottom: 20px; font-size: 13px; text-align: center; display: flex; align-items: center; justify-content: center; gap: 5px; }
    </style>
</head>
<body>
    <div class="login-box">
        <div class="logo"><i class="ri-store-2-fill"></i> MerchantPanel</div>
        
        <?php if($error): ?>
            <div class="error"><i class="ri-error-warning-fill"></i> <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="post">
            <div class="form-group">
                <input type="text" name="username" placeholder="Kullanıcı Adı" required autofocus>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Şifre" required>
            </div>
            <button type="submit">Giriş Yap</button>
        </form>
        
        <div style="text-align: center; margin-top: 20px; font-size: 12px; color: #94a3b8;">
            &copy; <?= date('Y') ?> BetWallet Sistemleri
        </div>
    </div>
</body>
</html>