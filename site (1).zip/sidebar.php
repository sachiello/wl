<?php 
$cur = basename($_SERVER['PHP_SELF']); 
$siteName = $site['name'] ?? $_SESSION['site_name'] ?? 'Merchant';
// Bakiye init.php'den $netBalance olarak geliyor
?>
<aside class="sidebar">
    <div class="sidebar-header">
        <div class="brand">
            <i class="ri-store-2-fill"></i> <?= htmlspecialchars($siteName) ?>
        </div>
        
        <div class="sidebar-balance-card">
            <div class="balance-label">GÜNCEL BAKİYE</div>
            <div class="balance-amount"><?= number_format($netBalance, 2) ?> <small>₺</small></div>
            <div class="balance-icon"><i class="ri-wallet-3-line"></i></div>
        </div>
    </div>

    <nav class="sidebar-menu">
        <div class="menu-label">FİNANSAL İŞLEMLER</div>
        
        <a href="index.php" class="sidebar-link <?= $cur=='index.php'?'active':'' ?>">
            <i class="ri-dashboard-line"></i> Genel Bakış
        </a>
        
        <?php if(hasPerm('view_deposits')): ?>
        <a href="deposits.php" class="sidebar-link <?= $cur=='deposits.php'?'active':'' ?>">
            <i class="ri-arrow-down-circle-line"></i> Yatırımlar (Gelen)
        </a>
        <?php endif; ?>

        <?php if(hasPerm('view_users')): ?>
        <a href="user_withdrawals.php" class="sidebar-link <?= $cur=='user_withdrawals.php'?'active':'' ?>">
            <i class="ri-arrow-up-circle-line"></i> Kullanıcı Çekimleri
        </a>
        <?php endif; ?>

        <?php if(hasPerm('create_withdraw')): ?>
        <a href="withdrawals.php" class="sidebar-link <?= $cur=='withdrawals.php'?'active':'' ?>">
            <i class="ri-bank-card-line"></i> Mutabakat (Kasa Çekim)
        </a>
        <?php endif; ?>

        <?php if(hasPerm('request_balance')): ?>
        <a href="balance.php" class="sidebar-link <?= $cur=='balance.php'?'active':'' ?>">
            <i class="ri-add-circle-line"></i> Bakiye Yükle
        </a>
        <?php endif; ?>
        
        <div class="menu-label">YÖNETİM</div>

        <?php if(hasPerm('manage_personnel')): ?>
        <a href="personnel.php" class="sidebar-link <?= $cur=='personnel.php'?'active':'' ?>">
            <i class="ri-team-line"></i> Personel Yönetimi
        </a>
        <?php endif; ?>

        <?php if(hasPerm('manage_settings')): ?>
        <a href="developer.php" class="sidebar-link <?= $cur=='developer.php'?'active':'' ?>">
            <i class="ri-code-s-slash-line"></i> Geliştirici / API
        </a>
        <a href="settings.php" class="sidebar-link <?= $cur=='settings.php'?'active':'' ?>">
            <i class="ri-settings-4-line"></i> Ayarlar & Güvenlik
        </a>
        <?php endif; ?>
    </nav>

    <div class="dark-mode-toggle" onclick="toggleDarkMode()" style="margin: 0 16px 10px; padding: 10px; border-radius: 8px; display: flex; align-items: center; gap: 8px; cursor: pointer; color: var(--text-muted); font-weight: 600; transition: 0.2s;">
        <i class="ri-moon-line"></i> Gece Modu
    </div>

    <div class="sidebar-footer">
        <a href="login.php?logout=1" style="color:#ef4444; display:flex; align-items:center; gap:5px; font-weight:600;">
            <i class="ri-logout-box-line"></i> Çıkış Yap
        </a>
    </div>
</aside>