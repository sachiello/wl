<?php
require 'init.php';

// 2FA Zorunluluğu
if (!$site['two_factor_enabled']) {
    die("<script>alert('GÜVENLİK: Mutabakat talebi için 2FA aktifleştirmeniz gerekmektedir.'); window.location.href='settings.php';</script>");
}

$msg = ""; $err = "";
$ga = class_exists('GoogleAuthenticator') ? new GoogleAuthenticator() : null;

// --- İŞLEM 1: YENİ TALEP OLUŞTURMA (Form Post) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $err = "Güvenlik hatası.";
    } else {
        $amount = (float)$_POST['amount'];
        $wallet = trim($_POST['wallet']);
        $code   = trim($_POST['2fa_code']);

        if ($amount <= 0) $err = "Geçersiz tutar.";
        elseif ($amount > $netBalance) $err = "Yetersiz bakiye!";
        elseif (empty($wallet)) $err = "Cüzdan adresi zorunlu.";
        elseif (!$ga->verifyCode($site['two_factor_secret'], $code, 2)) $err = "Hatalı 2FA Kodu!";
        else {
            try {
                $pdo->beginTransaction();
                
                // Bakiyeden düş
                $upd = $pdo->prepare("UPDATE sites SET net_balance = net_balance - ? WHERE id = ?");
                $upd->execute([$amount, $site['id']]);

                // Talebi oluştur
                $ins = $pdo->prepare("INSERT INTO site_withdrawals (site_id, amount, wallet_address, status, created_at) VALUES (?, ?, ?, 'pending', NOW())");
                $ins->execute([$site['id'], $amount, $wallet]);

                $pdo->commit();
                $msg = "Mutabakat talebi alındı.";
                $netBalance -= $amount; // Görünümü güncelle

            } catch (Exception $e) {
                $pdo->rollBack();
                $err = "Hata: " . $e->getMessage();
            }
        }
    }
}

// --- İŞLEM 2: LİSTELEME VE FİLTRELEME (Deposits.php Mantığı) ---
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20; // Sayfa başı kayıt
$offset = ($page - 1) * $limit;

// Filtre Değişkenleri
$start = $_GET['start'] ?? '';
$end = $_GET['end'] ?? '';
$search = trim($_GET['search'] ?? '');

// Sorgu Hazırlığı
$whereSQL = "WHERE site_id = ?";
$params = [$site['id']];

// Tarih Filtresi
if ($start && $end) {
    $whereSQL .= " AND DATE(created_at) BETWEEN ? AND ?";
    $params[] = $start;
    $params[] = $end;
}

// Arama Filtresi (Tutar veya Cüzdan)
if ($search) {
    $whereSQL .= " AND (wallet_address LIKE ? OR amount LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

// Toplam Kayıt Sayısı (Sayfalama için)
$stmtCount = $pdo->prepare("SELECT COUNT(*) FROM site_withdrawals $whereSQL");
$stmtCount->execute($params);
$totalRecords = $stmtCount->fetchColumn();
$totalPages = ceil($totalRecords / $limit);

// Verileri Çek
$sql = "SELECT * FROM site_withdrawals $whereSQL ORDER BY created_at DESC LIMIT $limit OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$history = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    <div class="main-content">
        <div class="topbar"><h1>Mutabakat (Settlement)</h1></div>
        
        <?php if($msg): ?><div class="card bg-green"><?= $msg ?></div><?php endif; ?>
        <?php if($err): ?><div class="card bg-red" style="color:#991b1b;"><?= $err ?></div><?php endif; ?>

        <div class="card" style="border-left: 4px solid #0ea5e9;">
            <div style="margin-bottom:20px;">
                <span style="color:#64748b; font-weight:600;">Çekilebilir Net Bakiye:</span>
                <br>
                <b style="font-size:24px; color:#0ea5e9;"><?= number_format($netBalance, 2) ?> ₺</b>
            </div>
            
            <form method="post" style="max-width:600px;">
                <?= csrf_field() ?>
                
                <div class="form-group">
                    <label>Çekilecek Tutar (TL)</label>
                    <input type="number" name="amount" id="wdAmount" class="form-control" step="0.01" max="<?= $netBalance ?>" required oninput="calcFee()" placeholder="0.00">
                </div>

                <div style="background:#f8fafc; padding:15px; border-radius:8px; border:1px solid #e2e8f0; margin-bottom:20px;">
                    <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:5px;">
                        <span style="color:#64748b;">İşlem Ücreti (%1):</span>
                        <span style="font-weight:bold; color:#ef4444;" id="feeDisplay">0.00 ₺</span>
                    </div>
                    <div style="display:flex; justify-content:space-between; font-size:15px; font-weight:700; border-top:1px solid #e2e8f0; paddingTop:5px;">
                        <span style="color:#0f172a;">Hesaba Geçecek:</span>
                        <span style="color:#10b981;" id="netDisplay">0.00 ₺</span>
                    </div>
                </div>

                <div class="form-group">
                    <label>USDT (TRC20) Cüzdan Adresi</label>
                    <input type="text" name="wallet" class="form-control" placeholder="T..." required>
                </div>
                
                <div class="form-group">
                    <label>2FA Doğrulama Kodu</label>
                    <input type="text" name="2fa_code" class="form-control" placeholder="Google Auth Kodu (6 Haneli)" style="text-align:center; letter-spacing:3px; font-weight:bold;" required>
                </div>

                <button class="btn btn-primary" style="width:100%;">Mutabakat Talep Et</button>
            </form>
        </div>

        <div class="card">
            <h3 style="margin-bottom:20px;">Geçmiş Talepler</h3>
            
            <form method="get" style="display:flex; gap:10px; margin-bottom:20px; flex-wrap:wrap;">
                <input type="text" name="date_range" id="dateRange" class="form-control" placeholder="Tarih Aralığı" style="width:250px;">
                <input type="hidden" name="start" id="startDate" value="<?= htmlspecialchars($start) ?>">
                <input type="hidden" name="end" id="endDate" value="<?= htmlspecialchars($end) ?>">
                
                <input type="text" name="search" class="form-control" placeholder="Tutar veya Cüzdan Ara..." value="<?= htmlspecialchars($search) ?>" style="flex:1; min-width:200px;">
                
                <button class="btn btn-primary">Filtrele</button>
                <?php if($start || $search): ?>
                    <a href="withdrawals.php" class="btn btn-secondary">Temizle</a>
                <?php endif; ?>
            </form>

            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Tarih</th>
                            <th>Tutar (Brüt)</th>
                            <th>Cüzdan</th>
                            <th>Durum</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($history as $h): ?>
                        <tr>
                            <td style="font-size:13px; color:#64748b;"><?= date('d.m.Y H:i', strtotime($h['created_at'])) ?></td>
                            <td style="font-weight:bold; color:#0f172a;"><?= number_format($h['amount'], 2) ?> ₺</td>
                            <td style="font-family:monospace; font-size:12px; color:#64748b;"><?= htmlspecialchars($h['wallet_address']) ?></td>
                            <td>
                                <?php if($h['status']=='completed') echo '<span class="badge bg-green">ÖDENDİ</span>';
                                      elseif($h['status']=='pending') echo '<span class="badge bg-yellow">BEKLİYOR</span>';
                                      else echo '<span class="badge bg-red">RED</span>'; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($history)): ?>
                            <tr><td colspan="4" style="text-align:center; padding:30px; color:#999;">Kayıt bulunamadı.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($totalPages > 1): ?>
            <div class="pagination" style="margin-top:20px; display:flex; justify-content:center; gap:5px;">
                <?php for($i=1; $i<=$totalPages; $i++): ?>
                    <a href="?page=<?= $i ?>&start=<?= $start ?>&end=<?= $end ?>&search=<?= $search ?>" 
                       class="btn btn-sm <?= $page==$i ? 'btn-primary' : 'btn-secondary' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://npmcdn.com/flatpickr/dist/l10n/tr.js"></script>
<script>
    // Komisyon Hesaplama
    function calcFee() {
        let amount = parseFloat(document.getElementById('wdAmount').value) || 0;
        let fee = amount * 0.01;
        let net = amount - fee;
        document.getElementById('feeDisplay').innerText = fee.toFixed(2) + ' ₺';
        document.getElementById('netDisplay').innerText = net.toFixed(2) + ' ₺';
    }

    // Tarih Seçici
    flatpickr("#dateRange", {
        mode: "range",
        dateFormat: "Y-m-d",
        locale: "tr",
        defaultDate: ["<?= $start ?>", "<?= $end ?>"],
        onClose: function(selectedDates, dateStr, instance) {
            if (selectedDates.length === 2) {
                document.getElementById('startDate').value = instance.formatDate(selectedDates[0], "Y-m-d");
                document.getElementById('endDate').value = instance.formatDate(selectedDates[1], "Y-m-d");
            }
        }
    });
</script>
</body></html>