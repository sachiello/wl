<?php
require 'init.php';

$msg = ""; $err = "";
$ga = class_exists('GoogleAuthenticator') ? new GoogleAuthenticator() : null;

// Secret yoksa oluştur (Session'da tut)
if ($ga && empty($site['two_factor_secret'])) {
    if (!isset($_SESSION['temp_secret'])) $_SESSION['temp_secret'] = $ga->createSecret();
    $secret = $_SESSION['temp_secret'];
} else {
    $secret = $site['two_factor_secret'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $err = "Güvenlik hatası.";
    } else {
        // IP KAYDET
        if (isset($_POST['save_ip'])) {
            $ips = trim($_POST['allowed_ips']);
            $pdo->prepare("UPDATE sites SET allowed_ips = ? WHERE id = ?")->execute([$ips, $site['id']]);
            $msg = "IP ayarları güncellendi.";
            // Sayfayı yenile (Veriyi güncellemek için)
            header("Refresh:0"); exit;
        }

        // 2FA AKTİFLEŞTİR
        if (isset($_POST['enable_2fa'])) {
            $code = $_POST['code'];
            if ($ga->verifyCode($secret, $code, 2)) {
                $pdo->prepare("UPDATE sites SET two_factor_enabled = 1, two_factor_secret = ? WHERE id = ?")->execute([$secret, $site['id']]);
                $msg = "2FA Aktifleştirildi!";
                unset($_SESSION['temp_secret']);
                header("Refresh:0"); exit;
            } else {
                $err = "Hatalı kod.";
            }
        }

        // 2FA KAPAT
        if (isset($_POST['disable_2fa'])) {
            // Buraya şifre kontrolü de eklenebilir ekstra güvenlik için
            $pdo->prepare("UPDATE sites SET two_factor_enabled = 0, two_factor_secret = NULL WHERE id = ?")->execute([$site['id']]);
            $msg = "2FA Kapatıldı.";
            header("Refresh:0"); exit;
        }
    }
}

$qrUrl = ($ga && $secret) ? $ga->getQRCodeGoogleUrl('BetWallet_Site_' . $site['name'], $secret) : '';
?>

<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    <div class="main-content">
        <h1>Ayarlar & Güvenlik</h1>
        
        <?php if($msg): ?><div class="card bg-green"><?= $msg ?></div><?php endif; ?>
        <?php if($err): ?><div class="card bg-yellow" style="color:#92400e;"><?= $err ?></div><?php endif; ?>

        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap:20px;">
            
            <div class="card">
                <h3><i class="ri-shield-cross-line"></i> IP Kısıtlaması</h3>
                <p style="font-size:13px; color:#666;">Panelinize sadece belirlediğiniz IP'lerden erişilsin.</p>
                <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="save_ip" value="1">
                    <div class="form-group">
                        <label>İzinli IP'ler (Virgülle ayırın)</label>
                        <textarea name="allowed_ips" class="form-control" rows="3" placeholder="Örn: 192.168.1.1, 85.44.12.1"><?= htmlspecialchars($site['allowed_ips'] ?? '') ?></textarea>
                    </div>
                    <div style="font-size:12px; color:#0ea5e9; margin-bottom:10px;">
                        Şu anki IP Adresiniz: <b><?= $_SERVER['REMOTE_ADDR'] ?></b>
                    </div>
                    <button class="btn btn-primary">Kaydet</button>
                </form>
            </div>

            <div class="card">
                <h3><i class="ri-smartphone-line"></i> Google Authenticator (2FA)</h3>
                
                <?php if($site['two_factor_enabled']): ?>
                    <div style="text-align:center; padding:30px;">
                        <i class="ri-shield-check-fill" style="font-size:48px; color:#10b981;"></i>
                        <h4 style="color:#10b981;">Hesabınız Güvende</h4>
                        <p>İki adımlı doğrulama aktif.</p>
                        <form method="post">
                            <?= csrf_field() ?>
                            <button name="disable_2fa" class="btn btn-danger" onclick="return confirm('Emin misiniz?')">Devre Dışı Bırak</button>
                        </form>
                    </div>
                <?php else: ?>
                    <div style="text-align:center; margin-bottom:20px;">
                        <img src="<?= $qrUrl ?>" style="border:1px solid #eee; padding:5px; border-radius:8px;">
                        <div style="font-family:monospace; background:#f1f5f9; padding:5px; margin-top:10px; font-size:12px;">Kod: <?= $secret ?></div>
                    </div>
                    <form method="post">
                        <?= csrf_field() ?>
                        <div class="form-group">
                            <label>Doğrulama Kodu</label>
                            <input type="text" name="code" class="form-control" placeholder="123 456" style="text-align:center; letter-spacing:5px; font-size:18px;" required>
                        </div>
                        <button name="enable_2fa" class="btn btn-primary" style="width:100%;">Aktifleştir</button>
                    </form>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>
</body></html>