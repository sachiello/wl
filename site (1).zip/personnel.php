<?php
require 'init.php';

// Sadece Patron veya 'manage_personnel' yetkisi olan personel girebilir
if ($isPersonnel && !hasPerm('manage_personnel')) {
    die("<div class='card bg-yellow' style='color:#854d0e'>Yetkisiz Erişim.</div>");
}

$msg = ""; $err = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $err = "Güvenlik hatası.";
    } 
    
    // EKLEME
    elseif (isset($_POST['add_user'])) {
        $user = trim($_POST['username']);
        $pass = trim($_POST['password']);
        $perms = isset($_POST['perms']) ? $_POST['perms'] : [];
        
        if (strlen($user) < 3 || strlen($pass) < 4) {
            $err = "Kullanıcı adı en az 3, şifre 4 karakter olmalı.";
        } else {
            $check = $pdo->prepare("SELECT id FROM site_personnel WHERE username = ?");
            $check->execute([$user]);
            if ($check->fetch()) {
                $err = "Bu kullanıcı adı dolu.";
            } else {
                $hash = password_hash($pass, PASSWORD_BCRYPT);
                $permJson = json_encode($perms);
                
                $ins = $pdo->prepare("INSERT INTO site_personnel (site_id, username, password_hash, permissions, is_active) VALUES (?, ?, ?, ?, 1)");
                $ins->execute([$site['id'], $user, $hash, $permJson]);
                $msg = "Personel eklendi.";
            }
        }
    }
    
    // DÜZENLEME
    elseif (isset($_POST['edit_user'])) {
        $editId = (int)$_POST['edit_id'];
        $perms = isset($_POST['perms']) ? $_POST['perms'] : [];
        $permJson = json_encode($perms);
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $newPass = trim($_POST['password']);

        if (!empty($newPass)) {
            $hash = password_hash($newPass, PASSWORD_BCRYPT);
            $pdo->prepare("UPDATE site_personnel SET password_hash = ?, permissions = ?, is_active = ? WHERE id = ? AND site_id = ?")->execute([$hash, $permJson, $isActive, $editId, $site['id']]);
        } else {
            $pdo->prepare("UPDATE site_personnel SET permissions = ?, is_active = ? WHERE id = ? AND site_id = ?")->execute([$permJson, $isActive, $editId, $site['id']]);
        }
        $msg = "Personel güncellendi.";
    }

    // SİLME
    elseif (isset($_POST['delete_id'])) {
        $id = (int)$_POST['delete_id'];
        $pdo->prepare("DELETE FROM site_personnel WHERE id = ? AND site_id = ?")->execute([$id, $site['id']]);
        $msg = "Personel silindi.";
    }
}

$users = $pdo->prepare("SELECT * FROM site_personnel WHERE site_id = ? ORDER BY created_at DESC");
$users->execute([$site['id']]);
$list = $users->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    <div class="main-content">
        <div class="topbar">
            <h1>Personel Yönetimi</h1>
            <button class="btn btn-primary" onclick="openModal('addModal')"><i class="ri-user-add-line"></i> Yeni Personel</button>
        </div>
        
        <?php if($msg): ?><div class="card bg-green"><?= $msg ?></div><?php endif; ?>
        <?php if($err): ?><div class="card bg-yellow" style="color:#92400e;"><?= $err ?></div><?php endif; ?>

        <div class="card">
            <table>
                <thead><tr><th>Kullanıcı</th><th>Yetkiler</th><th>Durum</th><th style="text-align:right;">İşlem</th></tr></thead>
                <tbody>
                    <?php foreach($list as $u): $pPerms = json_decode($u['permissions'], true) ?? []; ?>
                    <tr>
                        <td style="font-weight:600;"><?= htmlspecialchars($u['username']) ?></td>
                        <td>
                            <?php if(in_array('view_deposits', $pPerms)) echo '<span class="badge bg-green">Yatırım</span> '; ?>
                            <?php if(in_array('create_withdraw', $pPerms)) echo '<span class="badge bg-yellow">Mutabakat</span> '; ?>
                            <?php if(in_array('request_balance', $pPerms)) echo '<span class="badge bg-blue">Bakiye</span> '; ?>
                            <?php if(in_array('view_users', $pPerms)) echo '<span class="badge bg-purple">Oyuncular</span> '; ?>
                            <?php if(in_array('manage_settings', $pPerms)) echo '<span class="badge" style="background:#e5e7eb;color:#374151">Ayarlar</span> '; ?>
                        </td>
                        <td><?= $u['is_active'] ? '<span class="badge bg-green">AKTİF</span>' : '<span class="badge bg-red">PASİF</span>' ?></td>
                        <td style="text-align:right;">
                            <button class="btn btn-sm btn-secondary" onclick='openEditModal(<?= json_encode($u) ?>)'><i class="ri-edit-line"></i></button>
                            <form method="post" style="display:inline;" onsubmit="return confirm('Silmek istiyor musunuz?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="delete_id" value="<?= $u['id'] ?>">
                                <button class="btn btn-sm btn-danger"><i class="ri-delete-bin-line"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="addModal" class="modal-overlay" style="display:none;">
    <div class="modal-content">
        <div class="modal-header"><h3>Personel Ekle</h3><i class="ri-close-line close-btn" onclick="closeModal('addModal')"></i></div>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="add_user" value="1">
            <div class="form-group"><label>Kullanıcı Adı</label><input type="text" name="username" class="form-control" required></div>
            <div class="form-group"><label>Şifre</label><input type="text" name="password" class="form-control" required></div>
            
            <div class="form-group">
                <label>Yetkiler</label>
                <div class="checkbox-group">
                    <label><input type="checkbox" name="perms[]" value="view_deposits" checked> Yatırımları Görüntüle</label>
                    <label><input type="checkbox" name="perms[]" value="view_users" checked> Kullanıcı Çekimlerini Gör</label>
                    <label><input type="checkbox" name="perms[]" value="create_withdraw"> Mutabakat (Para Çekme) Talebi</label>
                    <label><input type="checkbox" name="perms[]" value="request_balance"> Bakiye Yükleme Talebi</label>
                    <label><input type="checkbox" name="perms[]" value="manage_settings"> Ayarlar ve API Erişimi</label>
                    <label><input type="checkbox" name="perms[]" value="manage_personnel"> Personel Yönetimi</label>
                </div>
            </div>
            
            <button class="btn btn-primary" style="width:100%;">Ekle</button>
        </form>
    </div>
</div>

<div id="editModal" class="modal-overlay" style="display:none;">
    <div class="modal-content">
        <div class="modal-header"><h3>Düzenle: <span id="editName"></span></h3><i class="ri-close-line close-btn" onclick="closeModal('editModal')"></i></div>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="edit_user" value="1">
            <input type="hidden" name="edit_id" id="editId">
            
            <div class="form-group"><label>Yeni Şifre (Boş bırakılabilir)</label><input type="text" name="password" class="form-control"></div>
            <div class="form-group"><label><input type="checkbox" name="is_active" id="editActive" value="1"> Hesap Aktif</label></div>

            <div class="form-group">
                <label>Yetkiler</label>
                <div class="checkbox-group">
                    <label><input type="checkbox" name="perms[]" value="view_deposits" id="p_dep"> Yatırımları Görüntüle</label>
                    <label><input type="checkbox" name="perms[]" value="view_users" id="p_usr"> Kullanıcı Çekimlerini Gör</label>
                    <label><input type="checkbox" name="perms[]" value="create_withdraw" id="p_wd"> Mutabakat Talebi</label>
                    <label><input type="checkbox" name="perms[]" value="request_balance" id="p_bal"> Bakiye Yükleme Talebi</label>
                    <label><input type="checkbox" name="perms[]" value="manage_settings" id="p_set"> Ayarlar ve API</label>
                    <label><input type="checkbox" name="perms[]" value="manage_personnel" id="p_per"> Personel Yönetimi</label>
                </div>
            </div>
            
            <button class="btn btn-primary" style="width:100%;">Güncelle</button>
        </form>
    </div>
</div>

<script>
function openModal(id){document.getElementById(id).style.display='flex';}
function closeModal(id){document.getElementById(id).style.display='none';}
function openEditModal(data){
    document.getElementById('editId').value = data.id;
    document.getElementById('editName').innerText = data.username;
    document.getElementById('editActive').checked = (data.is_active == 1);
    let perms = []; try{perms=JSON.parse(data.permissions);}catch(e){}
    document.getElementById('p_dep').checked = perms.includes('view_deposits');
    document.getElementById('p_usr').checked = perms.includes('view_users');
    document.getElementById('p_wd').checked = perms.includes('create_withdraw');
    document.getElementById('p_bal').checked = perms.includes('request_balance');
    document.getElementById('p_set').checked = perms.includes('manage_settings');
    document.getElementById('p_per').checked = perms.includes('manage_personnel');
    openModal('editModal');
}
</script>
</body></html>