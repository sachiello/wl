<?php
require 'init.php';

// Yetki Kontrolü
if (isset($_SESSION['is_personnel']) && $_SESSION['is_personnel'] && !hasPerm('view_users')) {
    die("<div class='card bg-yellow' style='color:#854d0e'>Yetkisiz Erişim.</div>");
}

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Filtre Parametreleri
$start = $_GET['start'] ?? '';
$end = $_GET['end'] ?? '';
$search = trim($_GET['search'] ?? '');

// Sorgu Hazırlığı
$whereSQL = "WHERE w.site_id = ?";
$params = [$site['id']];

// Tarih Filtresi
if ($start && $end) {
    $whereSQL .= " AND DATE(w.created_at) BETWEEN ? AND ?";
    $params[] = $start;
    $params[] = $end;
}

// Arama Filtresi
if ($search) {
    $whereSQL .= " AND (u.username LIKE ? OR w.amount LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

// Toplam Kayıt
$countSql = "SELECT COUNT(*) FROM withdraw_requests w LEFT JOIN users u ON w.user_id = u.id $whereSQL";
$stmtCount = $pdo->prepare($countSql);
$stmtCount->execute($params);
$totalRecords = $stmtCount->fetchColumn();
$totalPages = ceil($totalRecords / $limit);

// Verileri Çek
$sql = "
    SELECT w.*, u.username 
    FROM withdraw_requests w
    LEFT JOIN users u ON w.user_id = u.id
    $whereSQL
    ORDER BY w.created_at DESC 
    LIMIT $limit OFFSET $offset
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    <div class="main-content">
        <div class="topbar">
            <h1>Kullanıcı Çekim İşlemleri</h1>
        </div>
        
        <div class="card">


            <form method="get" style="display:flex; gap:10px; margin-bottom:20px; flex-wrap:wrap;">
                <input type="text" name="date_range" id="dateRange" class="form-control" placeholder="Tarih Aralığı Seçin" style="width:250px;">
                <input type="hidden" name="start" id="startDate" value="<?= htmlspecialchars($start) ?>">
                <input type="hidden" name="end" id="endDate" value="<?= htmlspecialchars($end) ?>">
                
                <input type="text" name="search" class="form-control" placeholder="Kullanıcı Adı veya Tutar..." value="<?= htmlspecialchars($search) ?>" style="width:200px;">
                
                <button class="btn btn-primary">Filtrele</button>
                <?php if($start || $search): ?>
                    <a href="user_withdrawals.php" class="btn btn-secondary">Temizle</a>
                <?php endif; ?>
            </form>

            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Kullanıcı</th>
                            <th>Tutar</th>
                            <th>Yöntem</th>
                            <th>Tarih</th>
                            <th>Durum</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($rows as $r): ?>
                        <tr>
                            <td style="font-weight:600; color:var(--text-main);">
                                <?= htmlspecialchars($r['username']) ?>
                            </td>
                            <td style="font-weight:bold; color:#ef4444;">
                                -<?= number_format($r['amount'], 2) ?> ₺
                            </td>
                            <td>
                                <?php if($r['method'] == 'bank'): ?>
                                    <span style="font-size:12px; color:var(--text-muted); display:flex; align-items:center; gap:5px;">
                                        <i class="ri-bank-card-line"></i> Banka
                                    </span>
                                <?php else: ?>
                                    <span style="font-size:12px; color:var(--text-muted); display:flex; align-items:center; gap:5px;">
                                        <i class="ri-bit-coin-line"></i> Kripto
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td style="font-size:13px; color:var(--text-muted);">
                                <?= date('d.m.Y H:i', strtotime($r['created_at'])) ?>
                            </td>
                            <td>
                                <?php 
                                $st=$r['status'];
                                if($st=='confirmed'||$st=='approved'||$st=='paid') echo '<span class="badge bg-green">ÖDENDİ</span>';
                                elseif($st=='pending'||$st=='processing') echo '<span class="badge bg-yellow">İŞLEMDE</span>';
                                else echo '<span class="badge bg-red">RED</span>';
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(!$rows): ?>
                            <tr><td colspan="5" style="text-align:center; padding:30px; color:var(--text-muted);">Kayıt bulunamadı.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($totalPages > 1): ?>
            <div class="pagination" style="margin-top:20px; display:flex; justify-content:center; gap:5px;">
                <?php for($i=1; $i<=$totalPages; $i++): ?>
                    <a href="?page=<?= $i ?>&start=<?= $start ?>&end=<?= $end ?>&search=<?= $search ?>" 
                       class="btn btn-sm <?= $page==$i ? 'btn-primary' : 'btn-secondary' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://npmcdn.com/flatpickr/dist/l10n/tr.js"></script>
<script>
    flatpickr("#dateRange", {
        mode: "range",
        dateFormat: "Y-m-d",
        locale: "tr",
        defaultDate: ["<?= $start ?>", "<?= $end ?>"],
        onClose: function(selectedDates, dateStr, instance) {
            if (selectedDates.length === 2) {
                document.getElementById('startDate').value = instance.formatDate(selectedDates[0], "Y-m-d");
                document.getElementById('endDate').value = instance.formatDate(selectedDates[1], "Y-m-d");
            }
        }
    });
</script>

</body></html>