<?php
require 'init.php';

// Yetki (Personel ise yetkisi var mı?)
if ($isPersonnel && !hasPerm('request_balance')) {
    die("<div class='card bg-yellow' style='color:#854d0e'>Yetkisiz Erişim.</div>");
}

$msg = ""; $err = "";

// BAKİYE TALEBİ GÖNDER
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $err = "Güvenlik hatası.";
    } elseif (isset($_POST['amount'])) {
        $amount = (float)$_POST['amount'];
        if ($amount < 100) {
            $err = "Minimum 100 TL yükleyebilirsiniz.";
        } else {
            // Talebi Oluştur
            $pdo->prepare("INSERT INTO site_balance_requests (site_id, amount, status) VALUES (?, ?, 'pending')")
                ->execute([$site['id'], $amount]);
            $msg = "Bakiye yükleme talebiniz alındı. Yönetici onayı bekleniyor.";
        }
    }
}

// Admin Cüzdan Adresi
$walletAddr = $pdo->query("SELECT address FROM admin_crypto_wallets WHERE coin_symbol = 'USDT' AND network = 'TRC20' LIMIT 1")->fetchColumn();

// Geçmiş Talepler
$history = $pdo->prepare("SELECT * FROM site_balance_requests WHERE site_id = ? ORDER BY created_at DESC LIMIT 10");
$history->execute([$site['id']]);
$rows = $history->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    <div class="main-content">
        <h1>Bakiye Yükle</h1>
        
        <?php if($msg): ?><div class="card bg-green"><?= $msg ?></div><?php endif; ?>
        <?php if($err): ?><div class="card bg-red" style="color:#991b1b"><?= $err ?></div><?php endif; ?>

        <div class="card">
            <div style="display:flex; gap:30px; flex-wrap:wrap;">
                <div style="flex:1; min-width:300px;">
                    <h3>1. Ödeme Yapın</h3>
                    <p style="font-size:13px; color:var(--text-muted);">Aşağıdaki TRC20 adresine USDT gönderimi yapınız.</p>
                    <div style="background:var(--bg-body); padding:15px; border-radius:8px; border:1px dashed var(--border-color); position:relative;">
                        <span style="font-family:monospace; font-size:15px; word-break:break-all;"><?= htmlspecialchars($walletAddr) ?></span>
                        <button onclick="navigator.clipboard.writeText('<?= $walletAddr ?>')" style="position:absolute; right:10px; top:10px; border:none; background:var(--bg-card); cursor:pointer; padding:5px; border-radius:4px;">
                            <i class="ri-file-copy-line"></i>
                        </button>
                    </div>
                </div>

                <div style="flex:1; min-width:300px;">
                    <h3>2. Bildirim Gönderin</h3>
                    <form method="post">
                        <?= csrf_field() ?>
                        <div class="form-group" style="margin-bottom:15px;">
                            <label style="display:block; margin-bottom:5px;">Gönderilen Tutar (TL Karşılığı)</label>
                            <input type="number" name="amount" class="form-control" placeholder="Örn: 5000" required>
                        </div>
                        <button class="btn btn-primary" style="width:100%;">Bildirim Gönder</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="card">
            <h3>Geçmiş Talepler</h3>
            <table>
                <thead><tr><th>ID</th><th>Tutar</th><th>Durum</th><th>Tarih</th></tr></thead>
                <tbody>
                    <?php foreach($rows as $r): ?>
                    <tr>
                        <td>#<?= $r['id'] ?></td>
                        <td style="font-weight:bold;"><?= number_format($r['amount'], 2) ?> ₺</td>
                        <td>
                            <?php if($r['status']=='approved') echo '<span class="badge bg-green">ONAYLANDI</span>';
                                  elseif($r['status']=='pending') echo '<span class="badge bg-yellow">BEKLİYOR</span>';
                                  else echo '<span class="badge bg-red">RED</span>'; ?>
                        </td>
                        <td><?= date('d.m.Y H:i', strtotime($r['created_at'])) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body></html>