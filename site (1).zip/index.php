<?php require 'init.php'; 

// İstatistikler
$siteId = $_SESSION['site_id'];
$totalVolume = $pdo->query("SELECT SUM(amount_try) FROM deposit_orders WHERE site_id = $siteId AND status = 'confirmed'")->fetchColumn() ?? 0;
$pendingWithdraw = $pdo->query("SELECT SUM(amount) FROM site_withdrawals WHERE site_id = $siteId AND status = 'pending'")->fetchColumn() ?? 0;
$announcement = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'site_announcement'")->fetchColumn();
$annActive = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'site_announcement_active'")->fetchColumn();
?>
<div class="app-wrapper">
    <?php include 'sidebar.php'; ?>
    
    <div class="main-content">
        <h1 style="margin-bottom:30px;">Genel Bakış</h1>
        
        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap:20px; margin-bottom:30px;">
            <div class="card">
                <div style="color:#64748b; font-size:12px; font-weight:700;">TOPLAM CİRO</div>
                <div style="font-size:28px; font-weight:800; color:#0f172a; margin:10px 0;">
                    <?= number_format($totalVolume, 2) ?> ₺
                </div>
            </div>

            <div class="card" style="border-left: 4px solid #0ea5e9;">
                <div style="color:#0ea5e9; font-size:12px; font-weight:700;">ÇEKİLEBİLİR MİKTAR</div>
                <div style="font-size:28px; font-weight:800; color:#0284c7; margin:10px 0;">
                    <?= number_format($netBalance, 2) ?> ₺
                </div>
                <div style="font-size:12px; color:#64748b;">Mutabakat için uygun</div>
            </div>

            <div class="card">
                <div style="color:#f59e0b; font-size:12px; font-weight:700;">BEKLEYEN MUTABAKAT</div>
                <div style="font-size:28px; font-weight:800; color:#d97706; margin:10px 0;">
                    <?= number_format($pendingWithdraw, 2) ?> ₺
                </div>
            </div>
        </div>
<?php if($annActive == '1' && !empty($announcement)): ?>
        <div class="announcement-bar">
            <i class="ri-notification-3-line"></i>
            <span><?= htmlspecialchars($announcement) ?></span>
        </div>
        <?php endif; ?>
        <h3 style="font-size:16px; color:#334155; margin-bottom:15px;">Sistem Rehberi</h3>
        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap:20px;">
            
            <div class="card" style="border-top:4px solid #0ea5e9;">
                <h4 style="font-size:15px; color:#0f172a; margin-bottom:10px;"><i class="ri-wallet-3-line"></i> Çekilebilir Miktar Nedir?</h4>
                <p style="font-size:13px; color:#475569; line-height:1.6;">
                    Bu bakiye, kullanıcılarınızın yatırımlarından komisyonlar düşüldükten sonra kalan <b>NET</b> tutardır.
                    <br><br>
                    • Bu tutar kadar kullanıcılarınıza çekim yaptırabilirsiniz.<br>
                    • Veya bu tutarı <b>Mutabakat</b> sayfasından kendi hesabınıza çekebilirsiniz.
                </p>
            </div>

            <div class="card" style="border-top:4px solid #10b981;">
                <h4 style="font-size:15px; color:#0f172a; margin-bottom:10px;"><i class="ri-percent-line"></i> Komisyon Yapısı</h4>
                <p style="font-size:13px; color:#475569; line-height:1.6;">
                    • <b>Yatırım:</b> Anlaşmalı oran kesilir, kalanı bakiyenize eklenir.<br>
                    • <b>Kullanıcı Çekimi:</b> %0 Komisyon (Bakiyeden net düşer).<br>
                    • <b>Mutabakat:</b> Kendinize çektiğinizde %1 işlem ücreti uygulanır.
                </p>
            </div>

        </div>
    </div>
</div>
<script>
    // Dark Mode Logic
    const toggleBtn = document.getElementById('darkModeToggle');
    const body = document.body;
    
    // Kayıtlı tercihi kontrol et
    if (localStorage.getItem('theme') === 'dark') {
        body.classList.add('dark-mode');
    }

    function toggleDarkMode() {
        body.classList.toggle('dark-mode');
        localStorage.setItem('theme', body.classList.contains('dark-mode') ? 'dark' : 'light');
    }
</script>
</body></html>